# FI (Fixed Income) — Tài liệu Đặc tả Toàn diện (Full Specification)

> **Mục đích.** Tài liệu này ghi rõ **toàn bộ** nội dung sản phẩm FI một cách chi tiết, kèm **sơ đồ trực quan (Mermaid)**, dành cho người đọc cần hiểu sâu end-to-end: PO, kỹ thuật, QE, vận hành, đối tác. Khác với `FI - Knowledge.md` (bản cô đọng cho AI tra cứu), bản này **viết đầy đủ logic, luồng, schema, công thức, rủi ro**.
>
> **TRUTH-mode.** Mọi dữ kiện trích từ nguồn trong Workspace, có citation `file://#L`. Khi spec và source code mâu thuẫn → **source code thắng về hành vi**; ghi cả hai. Chỗ thiếu nguồn đánh dấu ⚠️.
>
> *Cách xem sơ đồ: file `.md` này dùng fenced code block ngôn ngữ `mermaid` — mở bằng VS Code (ext Mermaid), GitHub, Obsidian, hoặc Confluence (macro Mermaid) để render. Viewer không hỗ trợ sẽ hiển thị code sơ đồ dưới dạng text.*

---

## Mục lục

1. [Thông tin tài liệu](#0-thông-tin-tài-liệu)
2. [Tổng quan sản phẩm](#1-tổng-quan-sản-phẩm)
3. [Bối cảnh kinh doanh](#2-bối-cảnh-kinh-doanh)
4. [Kiến trúc hệ thống](#3-kiến-trúc-hệ-thống)
5. [Mô hình dữ liệu](#4-mô-hình-dữ-liệu)
6. [Onboarding & Binding](#5-onboarding--binding)
7. [Luồng Deposit (nạp / mở gói)](#6-luồng-deposit-nạp--mở-gói)
8. [Luồng Withdrawal (rút / tất toán)](#7-luồng-withdrawal-rút--tất-toán)
9. [Order State Machine](#8-order-state-machine)
10. [Tính lãi & thuế](#9-tính-lãi--thuế)
11. [Tích hợp đối tác Infina](#10-tích-hợp-đối-tác-infina)
12. [Kafi — đối tác kế hoạch](#11-kafi--đối-tác-kế-hoạch)
13. [Rủi ro, Edge cases & xử lý lỗi](#12-rủi-ro-edge-cases--xử-lý-lỗi)
14. [Vận hành](#13-vận-hành)
15. [Trust & Safety](#14-trust--safety)
16. [Tiến độ & Roadmap](#15-tiến-độ--roadmap)
17. [Open Questions & Gaps](#16-open-questions--gaps)
18. [Appendix](#17-appendix)

---

## 0. Thông tin tài liệu

| | |
|---|---|
| **Sản phẩm** | FI (Fixed Income) — "Gói nhận lãi định kỳ"; biến thể combine FC = "Uỷ thác đầu tư / UTĐT" |
| **Loại tài liệu** | Full Specification (đặc tả nghiệp vụ + kỹ thuật + sơ đồ) |
| **Version** | v1.0 (tài liệu mới) — 2026-05-30 |
| **Owner** | DuyNQ5 (PO Wealth Solution) |
| **Trạng thái sản phẩm** | 🟢 Legal duyệt — go-live Production dự kiến **T6/2026**; verified full flow trên Sandbox |
| **Nguồn chính** | Source Code FI (`shared/`, `config`), Confluence Technical (28 trang) + Product (14 trang), Jira `Fixed Income` (~125 ticket), OKR 2026, Vault/FlaggedEmails |
| **Tài liệu liên quan** | `FI - Knowledge.md` (bản cô đọng, v2.0) — cùng thư mục |

**Lưu ý nền tảng (đọc trước khi tin "code = sự thật").** Repo `fixed-income-backend` hiện ở mức scaffolding — `main.go` chỉ in `"Init backend service"` [[main.go:L6](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/main.go#L6)], status repo `Init` [[README:L18](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/README.md#L18)]. **Code đầy đủ & đáng tin nằm ở module `shared/`** (proto contract + `partnersfactory` + Infina client). Các Confluence Technical page mô tả thiết kế (đa số status `BlueDoing`) và các "Process Overview" mô tả luồng chi tiết nhất — tài liệu này dựa nhiều vào hai nguồn đó, đối chiếu code `shared/`.

---

## 1. Tổng quan sản phẩm

**Định nghĩa.** FI là **một marketplace** kết nối user ZaloPay với nhiều đối tác tài chính (Infina, Kafi, …) cung cấp gói "nhận lãi định kỳ" linh hoạt — **không kỳ hạn** hoặc **kỳ hạn 1–6 tháng**; user chọn đối tác và gói (scheme) để gửi tiền, tương tự gửi tiết kiệm [[Product concept:L14](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L14)].

**Value proposition.** Lãi suất cao hơn SDSL (≈4,5%) & FD (~5,8–6%), giúp giữ chân user thay vì chuyển sang Tikop/Topi/Finhay; hạn mức cao và kỳ hạn linh hoạt; rủi ro cao hơn SDSL/FD nhưng thấp hơn Stock/CCQ, xác định theo danh mục đầu tư của đối tác (Infina mua trái phiếu/tiền gửi ngân hàng big4; Kafi dùng cho vay margin), cam kết hiển thị mức rủi ro minh bạch [[Product concept:L22](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L22)].

**Định vị trong portfolio đầu tư ZaloPay.** Số Dư Sinh Lời (SDSL) = thanh toán + tích lũy (mặc định, an toàn); Gửi Tiết Kiệm (FD) = kỳ hạn cố định, ngân hàng bảo trợ; **FI = user có tiền nhàn rỗi muốn lãi cao hơn FD, chấp nhận rủi ro hơn nhưng không muốn phụ thuộc thị trường như Stock/CCQ** [[Product concept:L29](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L29)].

**Use case chính (System Overview)** [[System Overview:L42](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L42)]: UC1 Onboarding & Account Binding · UC2 Fixed-Income Subscription · UC3 Interest Calculation & Payout · UC4 Portfolio Dashboard & Reporting · UC5 Withdrawal / Break Package · UC6 Notifications & Alerts · UC7 Campaign Integration.

**Đối tác & mô hình.**
- **Infina** — đối tác đầu tiên, có client code thật. FI dùng chung backend savings/SDSL của Infina; user ZaloPay được obfuscate ID trước khi gửi sang Infina (dùng chung cơ chế với MMF) [[infina.go:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/infina/infina.go#L30)].
- **Kafi** — đối tác kế hoạch, mô hình đi tiền khác (thu hộ/chi hộ qua merchant wallet — xem §11). Chưa có code.

---

## 2. Bối cảnh kinh doanh

**Mục tiêu.** Giữ dòng tiền nhàn rỗi ở lại ZaloPay; tăng AUM (thêm dòng doanh thu); mở rộng investment portfolio; giảm withdrawal rate [[System Overview:L18](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L18)].

**KPI & doanh thu.** FI nằm trong chỉ số "Union giao dịch MMF + Stock + FD + FC + FI" (đo monthly) [[OKR 2026:L81](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Product%20KPI/00.%20OKR%20Framework/Wealth%20Solution%20OKR%202026.md#L81)]. Trong revenue-mix: **FI Fee (New) = 9%**, lever = Partner deal, KR = "FI Activation (future KR)" [[OKR 2026:L609](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Product%20KPI/00.%20OKR%20Framework/Wealth%20Solution%20OKR%202026.md#L609)]; FI owner/Feature Lead **chưa assign** [[OKR 2026:L656](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Product%20KPI/00.%20OKR%20Framework/Wealth%20Solution%20OKR%202026.md#L656)].

**Revenue model.** Market Research mô tả: Infina thu phí quản lý theo bậc **0.25–0.4%/năm theo AUM** + spread lãi; ZaloPay ăn **revenue-share** từ phí của Infina (scale theo AUM) + cross-selling [[Market Research:L20](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/251077483_%5BFixed%20Income%5D%20Market%20Research.md#L20)]. ⚠️ Product concept ghi "Revenue model: TBU" [[Product concept:L149](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L149)] — con số chính thức cần xác nhận.

**Bối cảnh cạnh tranh** (lãi suất tham khảo, subject to change) [[Market Research:L42](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/251077483_%5BFixed%20Income%5D%20Market%20Research.md#L42)]:

| Provider | Non-term | 3 tháng | 6 tháng | 12 tháng | Hạn mức | Ghi chú |
|---|---|---|---|---|---|---|
| **Infina** | 4.7% | 5.4% | 5.6% | 5.7% | 3B | Backed by ACB Capital & BIDV; TNCN 5%; audit Deloitte |
| Tikop | 3.8–4.5% | ~6% | 6.5% | N/A | 1B–10B | Min 50k; SSC cảnh báo; phí rút nhanh 7.700đ |
| Finhay | 5–7% | N/A | N/A | N/A | — | Min 50k; Thiên Việt FMC; SSC cảnh báo |
| Topi | 5% | 6% | 6.5% | 7% | 250tr/trans | Tới 36 tháng = 8% |
| MoMo Túi Thần Tài | 3.6–4.2% | N/A | N/A | N/A | — | 68% market share; không kỳ hạn |
| Cake / CIMB | 0.1–0.3% | 4.4% | 5.6–5.7% | 5.8–6% | — | Bank |

**Chiến lược.** KHÔNG để FI cạnh tranh trực tiếp SDSL/FD (tránh cannibalization); chỉ cross-sale tại điểm user định opt-out (rút SDSL, đáo hạn FD, vượt hạn mức SDSL) [[Product concept:L45](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L45)].

**Compliance.** TNCN 5% (Infina nộp thay); PII encrypt; whitelist partner IP + client key [[System Overview:L108](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L108)]. Go-live từng pending vì legal (20/01/2026), nay đã duyệt [[Pending checklist:L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L5)].

> ⚠️ **Data-quality:** Product concept (SWOT, metrics) & Market Research (Target group) còn lẫn template **BNPL** — không phải đặc tính FI, bỏ qua khi diễn giải [[Product concept:L126](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L126)].

---

## 3. Kiến trúc hệ thống

FI gồm các service nội bộ + chuỗi thanh toán ZaloPay (FMC → FS-Core → PE → Cashier) + đối tác ngoài, và các hệ thống ngang (Wallet, CRM, Data Platform).

```mermaid
flowchart TB
    User([User ZaloPay App])

    subgraph FI["FI Domain"]
        GW[Gateway Service<br/>auth - routing - middleware]
        US[User Service<br/>onboarding - user mgmt]
        OS[Order Service<br/>deposit - withdraw - schemes]
        AS[Assistant Service<br/>utility - campaign - reconciliation]
        PF[Partners Factory<br/>registry theo PartnerCode]
        FIDB[(FI Database<br/>MySQL)]
    end

    subgraph PAY["ZaloPay Payment Core"]
        Cashier[Cashier UI]
        FMC[FMC - tạo order]
        PE[Payment Engine]
        FSC[FS-Core - centralize and reconcile]
        FSCDB[(FS-Core DB)]
    end

    subgraph EXT["Đối tác ngoài"]
        Infina[Infina API]
        Kafi[Kafi - kế hoạch]
    end

    subgraph PLAT["Hệ thống ngang"]
        Wallet[ZaloPay Wallet]
        CRM[CRM - noti and campaign]
        Data[Data Platform - analytics and PII]
        UM[User Management - KYC profile]
    end

    User --> GW
    GW --> US
    GW --> OS
    US --> PF
    OS --> PF
    US --> UM
    PF --> Infina
    PF -.kế hoạch.-> Kafi
    OS --> FSC
    FMC --> OS
    Cashier --> PE
    PE --> FSC
    FSC --> FSCDB
    OS --> FIDB
    FSC --> PE
    AS --> CRM
    OS --> Wallet
    US --> Data
```

**Diễn giải.**
- **Service split (HLD)**: 2 core area account vs order → tách thành **Order service** (deposit/withdrawal + user investment scheme), **User service** (onboarding + user mgmt), **Assistant service** (utility, campaign, reconciliation) [[HLD:L16](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508472_%5BPCF-FS%5D%5BFixed-Income%5D%201.%20High%20Level%20Design.md#L16)]; **Gateway Service** route App → service nội bộ [[Onboarding:L42](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508480_%5BPCF-FS%5D%5BFixed-Income%5D%201.%20Onboarding.md#L42)]. *(README backend mô tả 3 domain khác: User Management, Transactions & Service Packages, Dashboard & Reporting [[README:L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/README.md#L5)] — cách nhóm khác, chưa hợp nhất.)*
- **Chuỗi thanh toán** [[Order Management:L32](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261520419_%5BPCF-FS%5D%5BFixed-Income%5D%202.%20Order%20Management.md#L32)]: **FMC** khởi tạo order + UI app; **FS-Core** xử lý core, centralize order phục vụ đối soát tập trung, interface tới Payment; **PE** đi tiền với "FI destination of fund"; **Cashier** UI order, chống XSS [[Deposit:L46](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268076002_%5BPCF-FS%5D%5BFixed-Income%5D%202.1.%20Deposit.md#L46)].
- **Tích hợp ngoài** [[System Overview:L24](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L24)]: Partner APIs (subscription/eKYC/fund), Wallet (nạp/rút/settlement), CRM (noti/campaign), Data Platform (analytics + PII).
- **Hạ tầng** [[config.yaml:L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/config/config.yaml#L5)]: Go (Fiber/gRPC/GORM), gRPC 9090, Prometheus 8080, Redis (ElastiCache), MySQL, Kafka/RabbitMQ. NFR: API nội bộ <200ms, availability ≥99.9%, modular cho partner mới [[System Overview:L106](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L106)].

> ✅ Config dev hardcode `db_name: stock_qc_core` + `client_id: mmf` chỉ là default dev [[config.yaml:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/config/config.yaml#L30)]; `prod/stg/qc.yaml` dùng template namespace FI riêng `fin.fi.*` [[prod.yaml:L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/config/prod.yaml#L44)].

---

## 4. Mô hình dữ liệu

**Schema chuẩn (authoritative)** lấy từ Technical "Database Design" — gồm 5 bảng [[Database Design:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508546_%5BPCF-FS%5D%5BFixed-Income%5D%202.%20Database%20Design.md#L30)]. *(Bản này thay thế trang Product "Data model" vốn còn lẫn schema FD — xem ⚠️ cuối mục.)*

```mermaid
erDiagram
    PARTNERS ||--o{ ACCOUNTS : "scopes"
    ACCOUNTS ||--o{ ORDERS : "generates"
    ACCOUNTS ||--o{ TERM_DEPOSIT : "holds savings"
    ACCOUNTS ||--o{ BINDING_HISTORIES : "logs binding"
    TERM_DEPOSIT ||--o{ ORDERS : "referenced by"

    PARTNERS {
        BIGINT partner_id PK
        VARCHAR name
        ENUM status "ACTIVE INACTIVE WHITELIST"
    }
    ACCOUNTS {
        BIGINT zalopay_id PK
        BIGINT partner_id PK
        VARCHAR partner_account_id
        VARCHAR origin "zlp_fi zlp_prd partner"
        ENUM status "active inactive locked closed"
        TIMESTAMP created_at
    }
    BINDING_HISTORIES {
        BIGINT zalopay_id PK
        TIMESTAMP created_at PK
        BIGINT partner_id
        ENUM binding_type "register cross-linking linking"
        VARCHAR status "processing rejected approved"
        VARCHAR reject_code
        JSON extra
    }
    ORDERS {
        BIGINT id PK
        BIGINT zp_trans_id UK
        VARCHAR app_trans_id
        VARCHAR shared_trans_id
        VARCHAR partner_trans_id
        VARCHAR term_deposit_id
        VARCHAR scheme_id
        BIGINT zp_user_id
        ENUM trans_type "OPEN BREAK"
        VARCHAR partner_code
        BIGINT amount
        ENUM status "INIT PROCESSING SUCCEEDED FAILED"
    }
    TERM_DEPOSIT {
        VARCHAR term_deposit_id PK
        VARCHAR scheme_id
        BIGINT zp_user_id
        BIGINT zp_trans_id
        ENUM status "ACTIVE PENDING CLOSE ROLLOVER"
        ENUM origin "OPEN ROLLOVER"
        BIGINT total_balance
        BIGINT total_interest
        BIGINT available_balance
        BIGINT estimated_interest
        FLOAT interest_rate
        DATETIME start_date
        DATETIME end_date
    }
```

**Mô tả bảng:**
- **`accounts`** — tài khoản partner của user + trạng thái. PK `(zalopay_id, partner_id)`; `origin ∈ {zlp_fi, zlp_prd, partner}`; `status ∈ {active, inactive, locked, closed}`; index `status`, `partner_account_id` (reverse-trace khi partner gọi vào) [[Database Design:L48](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508546_%5BPCF-FS%5D%5BFixed-Income%5D%202.%20Database%20Design.md#L48)].
- **`binding_histories`** — log mỗi lượt binding (phục vụ business + xử lý ticket). `binding_type`: register (user mới từ hệ thống mình) / cross-linking (từ sản phẩm ZLP khác) / linking (từ partner); `status` free-text (processing/rejected/approved); `reject_code`; `extra` JSON. PK `(zalopay_id, created_at)` [[Database Design:L126](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508546_%5BPCF-FS%5D%5BFixed-Income%5D%202.%20Database%20Design.md#L126)].
- **`partners`** — quản lý trạng thái đối tác (phục vụ maintenance). `status ∈ {ACTIVE, INACTIVE, WHITELIST}`; seed `(1, 'Infina', 'ACTIVE')` [[Database Design:L190](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508546_%5BPCF-FS%5D%5BFixed-Income%5D%202.%20Database%20Design.md#L190)].
- **`orders`** — mỗi giao dịch qua FI. `zp_trans_id` UNIQUE; `shared_trans_id = "app_id:app_trans_id"`; `term_deposit_id` = account_saving_id phía partner; `trans_type ∈ {OPEN, BREAK}`; `status ∈ {INIT, PROCESSING, SUCCEEDED, FAILED}`; index `zp_user_id`, `created_at`, `(app_trans_id, app_id)` (query khi exchange trigger) [[Database Design:L224](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508546_%5BPCF-FS%5D%5BFixed-Income%5D%202.%20Database%20Design.md#L224)].
- **`term_deposit`** (AccountSavings) — sổ tích luỹ của account (1 account nhiều sổ). `status ∈ {ACTIVE, PENDING, CLOSE, ROLLOVER}`; `origin ∈ {OPEN, ROLLOVER}`; giữ `total_balance`, `total_interest`, `available_balance`, `estimated_interest`, `interest_rate`, `start_date`, `end_date`. PK `(zp_user_id, status)` [[Database Design:L300](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508546_%5BPCF-FS%5D%5BFixed-Income%5D%202.%20Database%20Design.md#L300)].

> ⚠️ **Hai phiên bản data model — mâu thuẫn nguồn.** Trang Product "Data model" liệt kê 4 bảng `users / orders / fixed_income / balance_histories` và nửa dưới lẫn schema FD (account, fixed_deposit, bc_request_id…) [[Data model:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/285005666_Fixed%20Income%20-%20Data%20model.md#L9)]. Trang Technical "Database Design" mới là bản DDL chi tiết & nhất quán (`accounts/binding_histories/partners/orders/term_deposit`). **Tài liệu này lấy Database Design làm chuẩn.** Cần hợp nhất 2 trang (Phần 16).

---

## 5. Onboarding & Binding

Onboarding có **2 entry path** [[Onboarding:L33](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508480_%5BPCF-FS%5D%5BFixed-Income%5D%201.%20Onboarding.md#L33)]:
- **Account Linking** — user đã có account đối tác → verify & link với profile ZaloPay (không KYC lại). User đã có SDSL (Infina) dùng FI không cần re-register.
- **Registration** — user mới → full onboarding: eKYC, consent, tạo account phía partner, set investment preference.

```mermaid
sequenceDiagram
    participant App
    participant FIU as FI User Service
    participant UM as User Management
    participant PF as Partners Factory
    participant P as Partner Infina

    Note over App: 1 - Kiểm tra quyền và tài khoản
    App->>FIU: checkAccountInternal
    FIU-->>App: accountInfo
    App->>FIU: checkHasFirstDeposit
    FIU-->>App: depositInfo
    alt hasFirstDeposit == true
        App->>App: showHomeBind
    else chưa có first deposit
        Note over App: 2 - Landing và chọn gói
        App->>FIU: listUserScheme
        FIU->>PF: listUserScheme
        PF-->>FIU: schemes
        FIU-->>App: schemes
        App->>FIU: getUserScheme
        FIU-->>App: scheme detail
        Note over App: 3 - Precheck KYC
        App->>FIU: checkKycPermission
        FIU->>UM: getProfile
        UM-->>FIU: profileData
        FIU->>FIU: evaluateKycRules
        App->>FIU: checkPartnerAccount
        FIU->>PF: checkPartnerAccount
        PF-->>FIU: exists
        Note over App: 4 - Onboarding
        alt partner account đã tồn tại
            App->>FIU: linkPartnerAccount
            FIU->>FIU: acquireLock và saveRegisterHistory INIT
            FIU->>PF: linkAccount
            PF-->>FIU: result
            FIU->>FIU: saveUser linked và updateRegisterHistory
        else chưa tồn tại
            App->>FIU: registerAccount
            FIU->>PF: registerToPartner
            PF-->>FIU: result
        end
        Note over App: 5 - Sau binding
        App->>FIU: sendDepositInfo amount schemeID
        FIU-->>App: depositResult
    end
```

**Chi tiết.**
- **Check Account 2 phase** [[Check Account:L48](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268076268_%5BPCF-FS%5D%5BFixed-Income%5D%201.1%20Check%20Account.md#L48)]: Phase 1 check internal FI-DB (`getUserPartnersAccount` → accountMap, status unbinding/linking/locked) trả partial response cho nhanh; Phase 2 check partner account **async song song** từng partnerCode.
- **Account Linking** dùng **distributed lock theo user** + ghi `binding_histories` [[Account Linking:L59](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268076692_%5BPCF-FS%5D%5BFixed-Income%5D%201.3%20Account%20Linking.md#L59)].
- **Registration routing (quan trọng):** Partners Factory xử lý mọi đăng ký; **nếu `partnerCode == "Infina"` → route qua MMF API → Partner System; partner khác đi thẳng** [[Register flow:L87](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508483_%5BPCF-FS%5D%5BFixed-Income%5D%201.2%20Register%20flow.md#L87)] — khớp việc FI tái dùng proto user "illuminate" của MMF (§10.4). Register flow ghi `binding_histories(INIT)` → loop registerToPartner → success: `saveAccount` + `updateRegisterHistory(SUCCESS)` [[Register flow:L61](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508483_%5BPCF-FS%5D%5BFixed-Income%5D%201.2%20Register%20flow.md#L61)].
- **eKYC** tự động qua partner API; consent thu thập tại onboarding [[System Overview:L56](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L56)].
- **UTĐT** (combine FI + FC): 3 flow — Survey nhu cầu → chọn FI → chọn FC; user pick "Sinh lời ổn định / theo hiệu suất" + Home combine [[UTĐT Onboarding:L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/285014263_%5BUT%C4%90T%5D%20Onboarding.md#L5)].

---

## 6. Luồng Deposit (nạp / mở gói)

Nguồn tiền nạp: **Ví / VietQR**, hoặc từ **SDSL / Stock / FD**. Đây là giao dịch `trans_type = OPEN`, Action thanh toán phía core = **ADD**. Happy case [[Deposit Process Overview:L8](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297801866_%5BPCF-FS%5D%5BFixed-Income%5D%20Deposit%20Process%20Overview.md#L8)]:

```mermaid
sequenceDiagram
    participant User
    participant FI as FI Backend
    participant FMC
    participant Cashier
    participant PE as Payment Engine
    participant FSC as FS-Core
    participant P as Infina

    Note over User: PHASE 1 - Tạo deposit order
    User->>FI: POST deposit - zpUserID schemeID amount
    FI->>FMC: CreateOrder PaymentType PAYMENT
    FMC-->>FI: OrderURL OrderToken
    FI->>FI: Save Order status INIT trans_type OPEN
    FI-->>User: OrderURL ZPTransToken
    Note over User: PHASE 2 - User xác nhận trả tiền
    User->>Cashier: Mở OrderURL và Confirm Pay
    Cashier->>PE: Payment completed - trừ ví user
    Note over User: PHASE 3 - FS-Core Exchange
    PE->>FSC: Exchange Action ADD
    FSC->>FSC: Create hoặc Get Payment
    FSC->>FI: gRPC Exchange Action ADD
    Note over User: PHASE 4 - FI ExchangeDeposit
    FI->>FI: ObtainLock appTransID
    FI->>FI: Load Order và Account
    FI->>P: CreateDeposit partnerAccountID schemeID amount
    P-->>FI: PID totalAmount
    FI->>FI: Save PID status PROCESSING
    FI->>FI: Validate totalAmount == order.amount
    FI->>P: ConfirmDeposit PID SUCCESS
    P-->>FI: ConfirmResponse termInfo
    FI->>FI: depositFinalize - BEGIN TX - UpdateOrder SUCCEEDED - COMMIT
    FI-->>FSC: SUCCEEDED
    FSC->>PE: ExchangeResponse
```

**Các step (Process Overview).** Phase 1 tạo order: FI gọi `FMC CreateOrder(Amount, PaymentType=PAYMENT)` → lưu order `INIT` (AppID, AppTransID, SchemeID, Amount, PartnerTransID=NULL) [[Deposit Process Overview:L77](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297801866_%5BPCF-FS%5D%5BFixed-Income%5D%20Deposit%20Process%20Overview.md#L77)]. Phase 4 FI nhận `Exchange(Action=ADD)` từ FS-Core, `ObtainLock(AppTransID)`, load order + account, rồi rẽ nhánh theo `Order.Status`:
- **SUCCEEDED / FAILED** → trả luôn (idempotent).
- **INIT → `depositStart()`**: `CreateDeposit` → lưu PID + `PROCESSING` → validate amount → `ConfirmDeposit(PID, SUCCESS)` → `depositFinalize()` (BEGIN TX, `InquiryAndUpsertUserAsset`, update `SUCCEEDED`, COMMIT) [[Deposit Process Overview:L139](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297801866_%5BPCF-FS%5D%5BFixed-Income%5D%20Deposit%20Process%20Overview.md#L139)].
- **PROCESSING → `depositResume()`**: nếu không có PID → `FAILED` (data corruption, cần điều tra); có PID → `GetTransactions(PID)` → map SUCCESS/PENDING/FAILED [[Deposit Process Overview:L229](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297801866_%5BPCF-FS%5D%5BFixed-Income%5D%20Deposit%20Process%20Overview.md#L229)].

Nếu amount **mismatch** → `ConfirmDeposit(PID, FAILED)` → order `FAILED` → ⚠️ user đã trả tiền nhưng deposit bị từ chối → cần refund qua reconciliation [[Deposit Process Overview:L191](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297801866_%5BPCF-FS%5D%5BFixed-Income%5D%20Deposit%20Process%20Overview.md#L191)]. (Rủi ro idempotency → §12.)

---

## 7. Luồng Withdrawal (rút / tất toán)

Rút về **Ví**, hoặc top-up sang **SDSL / FD / Stock**. Đây là `trans_type = BREAK`, Action thanh toán = **DEDUCT**. Với gói có kỳ hạn (Term Savings) có thêm bước **Preview** (lãi tất toán sớm + thuế) [[Withdrawal Process Overview:L72](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297801870_%5BPCF-FS%5D%5BFixed-Income%5D%20Withdrawal%20Process%20Overview.md#L72)]:

```mermaid
sequenceDiagram
    participant User
    participant FI as FI Backend
    participant FMC
    participant Cashier
    participant PE as Payment Engine
    participant FSC as FS-Core
    participant P as Infina

    Note over User: PHASE 1 - Tạo break order
    User->>FI: POST break - zpUserID savingID amount
    FI->>FI: Get Account và UserAsset - savingType TS hoặc FS
    opt Term Savings TS
        FI->>P: GetSavingsWithdrawPreview
        P-->>FI: preview interest tax
        Note over FI: FinalAmount = Principal + Interest - Tax
    end
    FI->>FMC: CreateOrder Dest UserWallet
    FMC-->>FI: OrderURL OrderToken
    FI->>FI: Save Order INIT - term_deposit_id savingID
    FI-->>User: OrderURL ZPTransToken
    Note over User: PHASE 2 - Xác nhận
    User->>Cashier: Confirm và Authenticate
    Cashier->>PE: Order confirmed
    Note over User: PHASE 3 - FS-Core Exchange
    PE->>FSC: Exchange Action DEDUCT
    FSC->>FSC: GetPayment SELECT FOR UPDATE - check expiry 10 phút
    FSC->>FI: gRPC Exchange Action DEDUCT
    Note over User: PHASE 4 - FI ExchangeDeduct
    FI->>FI: ObtainLock appTransID
    FI->>P: CreateWithdrawal partnerRefID amount accountPID
    P-->>FI: PID totalAmount
    FI->>FI: Save PID PROCESSING - validate amount
    FI->>P: ConfirmWithdrawal PID SUCCESS
    P-->>FI: ConfirmResponse termInfo
    FI->>FI: withdrawFinalize update SUCCEEDED
    FI-->>FSC: SUCCEEDED
    FSC->>PE: ExchangeResponse
```

**Khác biệt so với deposit** [[Withdrawal Process Overview:L150](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297801870_%5BPCF-FS%5D%5BFixed-Income%5D%20Withdrawal%20Process%20Overview.md#L150)]:
- Action = **DEDUCT** (deposit là ADD); có bước **Preview** cho TS; FS-Core check **payment expiry > 10 phút** (`SELECT FOR UPDATE`) [[Withdrawal Process Overview:L112](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297801870_%5BPCF-FS%5D%5BFixed-Income%5D%20Withdrawal%20Process%20Overview.md#L112)].
- Trạng thái: **`withdrawStart()`** (INIT) → **`withdrawFinalize()`** (SUCCESS) → **`withdrawResume()`** (PROCESSING). Riêng `withdrawResume` khi partner trả **FAILED** sẽ gọi **`withdrawRecreate()`** — tạo `CreateWithdrawal` mới với PID mới (vì rút thất bại = tiền chưa chuyển, được tạo lại an toàn) [[Withdrawal Process Overview:L213](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297801870_%5BPCF-FS%5D%5BFixed-Income%5D%20Withdrawal%20Process%20Overview.md#L213)].

---

## 8. Order State Machine

Trạng thái order ở phía ZaloPay (`orders.status`): `INIT → PROCESSING → SUCCEEDED / FAILED`. PENDING/UNKNOWN của Infina không phải là trạng thái ZLP — được map về `PROCESSING` + retry [[Order State Diagram:L57](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297815713_%5BPCF-FS%5D%5BFixed-Income%5D%202.3.%20Order%20State%20Diagram.md#L57)].

```mermaid
stateDiagram-v2
    [*] --> INIT: Create Order trong DB
    INIT --> PROCESSING: Partner Create API OK - lưu PID
    INIT --> FAILED: Partner Create API lỗi nghiệp vụ
    PROCESSING --> SUCCEEDED: Query Infina trả SUCCESS
    PROCESSING --> FAILED: Query Infina trả FAILED
    PROCESSING --> PROCESSING: Infina PENDING hoặc UNKNOWN - retry sau
    SUCCEEDED --> [*]
    FAILED --> [*]
```

**Đối chiếu spec ↔ code (KHỚP):**

| Tầng | Giá trị trạng thái | Nguồn |
|---|---|---|
| `orders.status` (DB chuẩn) | INIT, PROCESSING, SUCCEEDED, FAILED | [[Database Design:L237](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508546_%5BPCF-FS%5D%5BFixed-Income%5D%202.%20Database%20Design.md#L237)] |
| `fscore.proto` Status | PROCESSING, SUCCESS, FAILED | [[fscore.proto:L12](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/proto/server/fscore/fscore.proto#L12)] |
| `partnersfactory.DeliveryStatus` | pending, success, failed, unknown | [[const.go:L12](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/const.go#L12)] |
| Infina status mapper | SUCCESS/FAILED/PENDING ↔ DeliveryStatus; khác → unknown | [[status_mapper.go:L11](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/infina/status_mapper.go#L11)] |

*(Lưu ý: trang Product "Data model" ghi `zlp_status` có thêm `pending` — nhưng Database Design + state diagram + code đều dùng 4 trạng thái INIT/PROCESSING/SUCCEEDED/FAILED ở phía ZLP; `pending` là trạng thái Infina, được gộp vào PROCESSING.)*

---

## 9. Tính lãi & thuế

Công thức do **Infina** quy định, FI hiển thị/đối chiếu [[Công thức tính lãi:L14](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/278880443_%5BFixed%20Income%5D%20Infina%20-%20C%C3%B4ng%20th%E1%BB%A9c%20t%C3%ADnh%20l%C3%A3i.md#L14)].

### 9.1 Gói KHÔNG kỳ hạn — lãi theo ngày (lãi kép)

**Quy tắc ngày bắt đầu sinh lời** (T = ngày nạp):
- Nạp **Thứ 2 → Thứ 5**: sinh lời từ **T+1**, nhận lời **T+2**. *(VD: nạp Thứ 3 → sinh lời Thứ 4 → nhận Thứ 5.)*
- Nạp **Thứ 6 / Thứ 7 / CN / lễ**: sinh lời từ **ngày làm việc kế tiếp**. *(VD: nạp Thứ 6 → sinh lời Thứ 2 → nhận Thứ 3.)*
- Quy tắc T+1 chỉ áp cho khoản nạp **mới**; khi đã sinh lời thì tính **liên tục** kể cả cuối tuần/lễ [[Công thức tính lãi:L38](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/278880443_%5BFixed%20Income%5D%20Infina%20-%20C%C3%B4ng%20th%E1%BB%A9c%20t%C3%ADnh%20l%C3%A3i.md#L38)].

> **Tiền lời hàng ngày = Mức sinh lời / 365 × Số dư đang sinh lời** — lãi cộng vào số dư để sinh lời ngày kế (sinh lời kép) [[Công thức tính lãi:L45](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/278880443_%5BFixed%20Income%5D%20Infina%20-%20C%C3%B4ng%20th%E1%BB%A9c%20t%C3%ADnh%20l%C3%A3i.md#L45)].

*VD: nạp 5.000.000đ vào Thứ 3, mức sinh lời trước thuế 4.842105%/năm (≈ 4.60% sau thuế). Đầu Thứ 5: lời trước thuế = 0.04842105/365 × 5.000.000 = 663đ; thuế = 33đ; thực nhận 630đ → số dư 5.000.630đ.*

### 9.2 Gói CÓ kỳ hạn — lãi cuối kỳ

Sinh lời từ T+1, nhận **gốc + lãi vào ngày đáo hạn**. Rút trước hạn → tính theo **chính sách rút sớm** tại ngày rút. **Tái tục tự động T+0**: sau đáo hạn, gốc + lãi tự chuyển sang gói mới, sinh lời ngay; khi rút sẽ nhận lãi kỳ cũ + lãi kỳ mới theo số ngày đã gửi [[Công thức tính lãi:L80](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/278880443_%5BFixed%20Income%5D%20Infina%20-%20C%C3%B4ng%20th%E1%BB%A9c%20t%C3%ADnh%20l%C3%A3i.md#L80)].

> **Tiền lời cuối kỳ = Mức sinh lời / 365 × Số tiền gốc × Số ngày kỳ hạn** [[Công thức tính lãi:L100](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/278880443_%5BFixed%20Income%5D%20Infina%20-%20C%C3%B4ng%20th%E1%BB%A9c%20t%C3%ADnh%20l%C3%A3i.md#L100)].

*VD: 5.000.000đ, kỳ hạn 6 tháng (180 ngày) @ 4.842105% trước thuế → lời = 119.394đ; thuế = 5.969đ; thực nhận 113.425đ → tổng 5.113.425đ.*

### 9.3 Làm tròn & thuế
- **Làm tròn:** kết quả ≥ 0.5 → làm tròn lên số nguyên kế; < 0.5 → giữ số nguyên hiện tại.
- **Thuế TNCN 5%** trên tiền lời được chia; **Infina khấu trừ & nộp thay** [[Công thức tính lãi:L52](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/278880443_%5BFixed%20Income%5D%20Infina%20-%20C%C3%B4ng%20th%E1%BB%A9c%20t%C3%ADnh%20l%C3%A3i.md#L52)].
- ⚠️ **Công thức lãi luồng rút sớm** để trống trong tài liệu Infina [[Công thức tính lãi:L124](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/278880443_%5BFixed%20Income%5D%20Infina%20-%20C%C3%B4ng%20th%E1%BB%A9c%20t%C3%ADnh%20l%C3%A3i.md#L124)] — nhưng `GetSavingsWithdrawPreview` trả sẵn `preMaturedInterestAmount`, `taxAmount`, `earlyWithdrawInterestRate`, `holdingDays` để hiển thị [[dto.go:L403](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/dto.go#L403)].

---

## 10. Tích hợp đối tác Infina

### 10.1 Lớp trừu tượng partnersfactory

FI dùng pattern **factory + registry**: interface `PartnerFactory` (16 method) + `RegisterPartnerFactory(code)/GetPartnerFactory(code)` [[factory.go:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/factory.go#L9)]. Mỗi partner đăng ký một implementation; hiện chỉ có `PartnerCodeInfina = "infina"` [[const.go:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/const.go#L7)].

```mermaid
flowchart LR
    OS["Order / User Service"] --> REG{"Partners Factory<br/>registry theo PartnerCode"}
    REG -->|infina| INF["Infina Client"]
    REG -.->|kế hoạch| KAF["Kafi Client"]
    INF --> AUTH["Auth - GetToken OAuth2<br/>và HMAC-SHA256 checksum"]
    AUTH --> API["Infina REST API"]
    API --> EP
    subgraph EP["Nhóm endpoint Infina"]
        E1["user và consent"]
        E2["savings schemes và accounts"]
        E3["deposit partner-wallet"]
        E4["withdraw partner-wallet và ts preview"]
        E5["transactions và reports interest"]
    end
```

### 10.2 Authentication (2 lớp)
[[Infina:L78](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261518007_%5BPCF-FS%5D%5BFixed-Income%5D%203.1%20Infina.md#L78)] + xác nhận qua code [[client.go:L63](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/infina/client.go#L63)]:
- **GetToken** — OAuth2: `POST {AUTH_DOMAIN}/api/v1/auth/token` với `clientId` + `clientSecret`, header `x-api-key`; token sống 24h, client cache & refresh trước hạn 5s.
- **Checksum** — `HMAC-SHA256` (UTF-8 → HEX), secret key do Infina cấp; stringify JSON body, **sort key alphabetically đệ quy**; gửi qua header `x-checksum`, `x-checksum-id`, `x-checksum-timestamp` [[Infina:L104](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261518007_%5BPCF-FS%5D%5BFixed-Income%5D%203.1%20Infina.md#L104)]. Routing: path prefix `/api/v1/partner/user` → `userClient`, còn lại → `baseClient` [[client.go:L116](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/infina/client.go#L116)].
> ⚠️ Confluence mô tả ngược tên `x-checksum-id` (ghi là ISO-8601) và `x-checksum-timestamp` (ghi là UUIDv4) — đối chiếu code khi implement; expiry 30 phút / 5 phút.

### 10.3 Catalog endpoint Infina (từ code `infina.go`)
[[infina.go:L25](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/infina/infina.go#L25)]

| Method | Endpoint | Mục đích |
|---|---|---|
| GetPartnerUser | `GET /api/v1/partner/user/sdsl/{hashUserID}` | Lấy user partner |
| LinkAccount | `POST /api/v1/partner/user/consent` | Liên kết / consent |
| GetUserSchemes | `GET /api/v1/partner/savings/schemes` | Danh sách gói |
| GetUserAsset / GetSavingAccount | `GET /api/v1/partner/savings/accounts` | Tài sản / sổ |
| GetDepositLimit | `GET /api/v1/partner/savings/deposit/partner-wallet/metadata` | Hạn mức nạp |
| CreateDeposit | `POST /api/v1/partner/savings/deposit/partner-wallet` | Tạo deposit |
| ConfirmDeposit | `POST /api/v1/partner/savings/deposit/partner-wallet/update` | Xác nhận deposit |
| GetWithdrawLimit | `GET /api/v1/partner/savings/withdraw/partner-wallet/metadata` | Hạn mức rút |
| CreateWithdrawal | `POST /api/v1/partner/savings/withdraw/partner-wallet` | Tạo rút |
| ConfirmWithdrawal | `POST /api/v1/partner/savings/withdraw/partner-wallet/update` | Xác nhận rút |
| GetSavingsWithdrawPreview | `GET /api/v1/partner/savings/withdraw/ts/preview` | Preview rút sớm |
| GetTransactions | `GET /api/v1/partner/savings/transactions` | Lịch sử GD |
| GetSavingsInterestReports | `GET /api/v1/partner/savings/reports/interest` | Báo cáo lãi theo ngày |

**DTO chính:** `CreateDepositRequest{partner_account_id, scheme_id, amount}` → trả `transaction_pid`, `interest_started_at`, `interest_rate`, `total_amount` [[dto.go:L167](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/dto.go#L167)]; `ConfirmDeposit.delivery_status ∈ {success, failed}` [[dto.go:L208](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/dto.go#L208)]; `CreateWithdrawal.trigger_type ∈ {AUTO, MANUAL}` [[dto.go:L299](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/dto.go#L299)]. Transaction description: `DEPOSIT / WITHDRAW / INTEREST / ADJUST_INTEREST` [[dto.go:L263](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/dto.go#L263)].

### 10.4 Lớp User Service dùng chung với MMF
FI dùng proto `fin.illuminate.user.v1` (`UserService`: `SubmitBindingAuto`, `UpgradeAccountTier`, `GetPriorityToggle`, `UpdatePriorityToggle`) [[mmf user.proto:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/proto/client/mmf/user.proto#L7)]; `binding_flow = "fixed_income"`. Sub_code lỗi binding: 1071 user existed, 1082 IDType invalid, 1085 only NFC missing KYC, 1086 invalid account tier (SME), 2011/2012 KYC, 3001/3005/3030/3xxx Infina [[mmf user.proto:L39](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/proto/client/mmf/user.proto#L39)]. → Khớp việc đăng ký Infina route qua MMF API (§5).

### 10.5 Contract FS-Core (proto `payment`)
Service `Payment`: `Exchange` + `QueryStatus`; `Action ∈ {DEDUCT, ADD}` (rút = DEDUCT, nạp = ADD); `Status ∈ {PROCESSING, SUCCESS, FAILED}`; `ReturnCode` có `Code ∈ {SUCCEEDED, FAILED, SUBMITTED}` + `Status ∈ {OK, SYSTEM_ERROR, RETRYABLE, NOT_FOUND, INVALID_ARGUMENT}` [[fscore.proto:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/proto/server/fscore/fscore.proto#L7)]. `QueryStatus` dùng cho luồng FS-Core query order: FI check DB final status trước, chưa final thì query partner [[Query order fs-core:L41](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/278858761_%5BPCF-FS%5D%5BFixed-Income%5D%20Query%20order%20fs-core.md#L41)].

---

## 11. Kafi — đối tác kế hoạch

Mô hình Kafi **khác Infina**: ZaloPay quảng cáo/giới thiệu KH + làm **thu hộ/chi hộ** qua **ví doanh nghiệp (merchant wallet)** của Kafi; ZaloPay **không** tham gia mở gói vay [[Kafi email:L8](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Fixed%20Income/2025-06-12%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQANajEG_GHaVAl2rE6xEEYiA%3D%20-%20%5BZalopay%20x%20Kafi%5D%20Lu%E1%BB%93ng%20d%E1%BB%8Bch%20v%E1%BB%A5%20h%E1%BB%A3p%20t%C3%A1c.md#L8)].

```mermaid
flowchart TB
    User(["User ZaloPay"])
    subgraph ZLP["ZaloPay"]
        SRC["Nguồn tiền hợp lệ - ví hoặc bank"]
        TH["Thu hộ - collect"]
        CH["Chi hộ - disburse"]
    end
    subgraph KAFI["Kafi"]
        MW["Merchant Wallet<br/>liên kết tài khoản BIDV"]
        LP["Liquid Pool dự trữ"]
        VA["Tài khoản VA của user"]
        LOAN["Gói vay margin"]
    end
    User -->|nạp| SRC --> TH -->|settle 3-5 lần mỗi ngày| MW
    MW --> VA
    VA -.->|Kafi tự mở khi ZLP gọi API| LOAN
    User -->|rút hoặc tất toán| CH
    LP --> CH --> User
    MW --> LP
```

**Điểm chính** [[Kafi email:L24](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Fixed%20Income/2025-06-12%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQANajEG_GHaVAl2rE6xEEYiA%3D%20-%20%5BZalopay%20x%20Kafi%5D%20Lu%E1%BB%93ng%20d%E1%BB%8Bch%20v%E1%BB%A5%20h%E1%BB%A3p%20t%C3%A1c.md#L24)]:
- Kafi mở merchant wallet tại ZaloPay (định danh tổ chức, liên kết tài khoản BIDV).
- **Thu hộ:** user nạp → ZaloPay settle đến merchant wallet Kafi **3–5 lần/ngày**. **Chi hộ:** user rút/tất toán → ZaloPay chi từ merchant wallet về ví/bank user.
- **Liquid Pool**: tiền dự trữ trong merchant wallet phục vụ chi hộ.
- ZaloPay prefer vận hành **24/7**; chỉ thu hộ đến **VA của KH**, **không facilitate cho vay** → UI phải highlight "nạp vào tài khoản Kafi" thay vì "nạp vào gói vay" [[Kafi email:L48](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Fixed%20Income/2025-06-12%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQANajEG_GHaVAl2rE6xEEYiA%3D%20-%20%5BZalopay%20x%20Kafi%5D%20Lu%E1%BB%93ng%20d%E1%BB%8Bch%20v%E1%BB%A5%20h%E1%BB%A3p%20t%C3%A1c.md#L48)].
- ⚠️ Cần làm rõ cơ sở pháp lý Kafi nhận tiền thu hộ (ngành nghề KD để đăng ký merchant).

---

## 12. Rủi ro, Edge cases & xử lý lỗi

Cây quyết định `ExchangeDeposit` (rút gọn) — minh hoạ các nhánh & rủi ro [[Deposit Process Overview:L122](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297801866_%5BPCF-FS%5D%5BFixed-Income%5D%20Deposit%20Process%20Overview.md#L122)]:

```mermaid
flowchart TB
    A["FI nhận Exchange ADD"] --> B["ObtainLock và Load Order"]
    B --> C{Order.Status}
    C -->|SUCCEEDED| OK["Trả SUCCEEDED"]
    C -->|FAILED| NG["Trả FAILED"]
    C -->|INIT| S1["depositStart - CreateDeposit"]
    C -->|PROCESSING| R1["depositResume"]
    S1 --> S2{CreateDeposit}
    S2 -->|SUCCESS| S3["Lưu PID và set PROCESSING"]
    S2 -->|TIMEOUT| RISK1["Retry - RỦI RO duplicate"]
    S2 -->|Business error| SAFE1["Retry an toàn - chưa tạo deposit"]
    S3 --> S4{Lưu PID vào DB}
    S4 -->|FAIL| RISK2["Retry - RỦI RO duplicate vì PID chưa lưu"]
    S4 -->|OK| S5{Amount khớp}
    S5 -->|Mismatch| MM["ConfirmDeposit FAILED - cần refund"]
    S5 -->|Match| S6["ConfirmDeposit SUCCESS"]
    S6 --> S7["depositFinalize - SUCCEEDED"]
    R1 --> R2{Có PID}
    R2 -->|Không| RISK3["FAILED - user đã trả, cần điều tra thủ công"]
    R2 -->|Có| R3["GetTransactions PID rồi map status"]
```

**4 rủi ro critical (Process Overview)** [[Deposit Process Overview:L277](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297801866_%5BPCF-FS%5D%5BFixed-Income%5D%20Deposit%20Process%20Overview.md#L277)]:
1. **Không có Idempotency Key** trong `CreateDeposit` (chỉ có partner_account_id, scheme_id, amount) → retry sau timeout tạo **deposit trùng** → user lợi tiền, ZaloPay mất.
2. **PID save fail** sau khi CreateDeposit thành công → retry tạo trùng.
3. **PROCESSING không có PID** (data corruption) → user đã trả, deposit unknown → điều tra thủ công.
4. **Deposit FAILED trên Infina sau khi user đã trả** → user mất tiền tới khi refund → cần reconciliation.

**Scenario an toàn:** business error (chưa tạo deposit), ConfirmDeposit fail (có PID → query lại), GetTransactions fail (giữ PROCESSING, retry).

**Withdrawal:** khi partner trả FAILED ở `withdrawResume` → **`withdrawRecreate()`** tạo lệnh rút mới (an toàn vì tiền chưa chuyển). Confirm deposit còn 2 mã lỗi Infina: `APPROVE_DEPOSIT_FAILED`, `REJECT_DEPOSIT_FAILED` [[Confirm Deposit Order:L102](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268077540_%5BPCF-FS%5D%5BFixed-Income%5D%20Confirm%20Deposit%20Order.md#L102)].

> ⚠️ **Chưa có CS ticket FI** (`03. Fact/CS Ticket/FI` rỗng — chưa go-live). Edge cases trên là **rủi ro thiết kế** từ tài liệu, chưa phải sự cố thực tế; bổ sung sau launch.

---

## 13. Vận hành

- **Monitoring:** Prometheus 8080 [[config.yaml:L3](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/config/config.yaml#L3)]; BE log order + account; FE event tracking + dashboard **chưa set up**.
- **Đối soát:** file tách bạch 2 file SDSL & FI (sandbox done); FS-Core centralize order [[Pending checklist:L26](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L26)].
- **CS:** cần thông báo CS để set up FAQ/Chatbot + tích hợp CS tool hiển thị account FI (PCFFS-19079) — chưa xong [[Pending checklist:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L30)].
- **Pre-prod checklist:** active appID FI lên prod (Jira MI-3692); email set up hạn mức & SOF; config tactic (ưu tiên SOF luồng rút trên cashier; bỏ voucher/xu/thêm ngân hàng); regression test; Loyalty remove appID khỏi tích xu. CRM inventory: `investment_trust_hub`, `investment_trust_banner`, `fix_income_uythac_banner` [[Pending checklist:L47](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L47)].
- **Partner maintenance:** bảng `partners` có status WHITELIST/INACTIVE để tắt partner khi bảo trì.

---

## 14. Trust & Safety

- **Trust signals:** Infina backed by ACB Capital & BIDV, audit Deloitte; hiển thị mức rủi ro minh bạch + asset allocation [[Market Research:L45](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/251077483_%5BFixed%20Income%5D%20Market%20Research.md#L45)].
- **Money transparency:** Cashier hiển thị order minh bạch, chống XSS [[Deposit:L46](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268076002_%5BPCF-FS%5D%5BFixed-Income%5D%202.1.%20Deposit.md#L46)]; PII encrypt + whitelist IP/key; ZaloPay ID obfuscate trước khi gửi partner.
- **Consent:** TnC yêu cầu consent BCC mới của Infina khi nạp FI; hợp đồng SDSL cập nhật thêm điều khoản FI [[TnC:L20](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/268083035_Fixed%20Income%20-%20TnC.md#L20)]. ⚠️ TnC/BCC/hợp đồng **chưa gắn** vào onboarding.

---

## 15. Tiến độ & Roadmap

**Jira `Fixed Income` (~125 ticket PCFFS).** Nhóm chính: Infra/setup (FS Core schema, repo+CICD, datasource) · Onboarding (checkInternalAccount, register SDSL, consent) · Deposit/Order (Init Order, Integrate Open Infina, query status, sync Kafka) · Withdraw (Init withdraw, Integrate partner, State Machine, preview redemption, Confirm withdraw) · Interest/maturity (công thức lãi, tiền lời hàng ngày, tính thử, gói matured, chặn rút cuối ngày, hạn mức) · CRM/tracking (Advertising, Notification, AB test, event tracking FE, Data Platform, sync CS tool) · UTĐT (design UTĐT-FC, onboarding screens, asset/recommend/discovery) · Go-live (checklist, release staging, FS Hub, maintenance). *(Trạng thái từng ticket chưa đọc chi tiết.)*

**Roadmap:**
- ✅ Dev + verify Sandbox (onboarding, deposit, withdraw, interest, đối soát).
- 🟡 Pre-prod: TnC/BCC/hợp đồng, noti content, FE tracking + dashboard, CS tool, regression test, active appID prod, hạn mức/SOF.
- 🟡 FS Hub integration (PCFFS-19501) — chưa.
- 🔜 Go-live Production **T6/2026**.
- 🔜 Kafi onboarding (partner thứ 2) — chưa code.

---

## 16. Open Questions & Gaps

- [ ] **Hợp nhất 2 data model**: Product "Data model" (4 bảng + lẫn FD) vs Technical "Database Design" (5 bảng chuẩn) → chốt 1 bản.
- [ ] **Revenue model** con số chính thức (Product concept TBU vs Market Research rev-share 0.25–0.4% AUM).
- [ ] **FI Feature Lead/owner** chưa assign.
- [ ] **Idempotency key cho CreateDeposit** — rủi ro duplicate, cần bổ sung trước prod.
- [ ] **Công thức lãi luồng rút sớm** để trống (dù preview API đã trả sẵn).
- [ ] **Nạp FI từ SDSL**: ZLP ghi nhận GD hay Infina tự chuyển (ảnh hưởng đối soát & lịch sử GD).
- [ ] TnC/BCC/hợp đồng chưa gắn onboarding; noti content chưa define; FE tracking chưa set up.
- [ ] Kafi: cơ sở pháp lý thu hộ + role ZION; chưa có code.
- [ ] `prod.yaml` đặt `env: stg` — xác minh placeholder.
- [ ] Mô tả header checksum Infina ngược tên trong Confluence.
- [ ] **Chưa ingest:** Golive checklist (Prod/Staging/Internal), Repository structure, Git flow, FC Fmarket dependency chi tiết, Home 2026 & Flow choose FC (UX UTĐT), User research/UXR pptx, phần lớn Shared Email/Chat, nội dung từng Jira ticket, Figma. CS Ticket (sau launch).

---

## 17. Appendix

### 17.1 Glossary
- **FI / Fixed Income** — "Gói nhận lãi định kỳ"; **UTĐT** — Uỷ thác đầu tư, biến thể combine FI + FC.
- **SDSL** — Số Dư Sinh Lời (MMF, Infina); FI dùng chung backend savings/SDSL của Infina.
- **PartnerRefId / partner_account_id** — định danh user phía partner.
- **Scheme / Product** — gói sinh lời / category (Infina: `nfs`, `pfs`).
- **term_deposit (AccountSavings)** — sổ tích luỹ; **TS** term savings, **FS** flexible savings.
- **FMC / FS-Core / PE / Cashier** — chuỗi thanh toán nội bộ (tạo order / core đối soát / đi tiền / UI).
- **Action ADD / DEDUCT** — nạp / rút trong `fscore.proto Exchange`.
- **depositStart/Resume/Finalize, withdrawStart/Resume/Finalize/Recreate** — các hàm xử lý theo trạng thái order.
- **Liquid Pool** — dự trữ trong merchant wallet Kafi cho chi hộ.

### 17.2 Source Index (nguồn đã dùng)
- **Source code:** `fixed-income-backend` (main.go, README, config/*.yaml), `shared/proto/server/fscore/fscore.proto`, `shared/proto/client/mmf/user.proto`, `shared/client/partnersfactory/{factory,const,dto}.go`, `.../infina/{infina,client,const,status_mapper}.go`.
- **Confluence Technical:** System Overview, HLD, Business Design, Order Management, Order State Diagram, Deposit, Withdrawal, Deposit/Withdrawal Process Overview, Onboarding, Check Account, Account Linking, Register flow, Status handling, Partner API Integration, Infina, Confirm/Create Deposit Order, Handling Order Status, Query order fs-core, Database Design.
- **Confluence Product:** Product concept, Market Research, Công thức tính lãi, Data model, TnC, Partners, Pending checklist, UTĐT Onboarding, FC Fmarket dependency.
- **Khác:** Jira `Fixed Income` (~125 ticket), OKR 2026, Vault/FlaggedEmails (Kafi cooperation 2025-06-12).

### 17.3 Tài liệu liên quan
- `FI - Knowledge.md` (v2.0) — bản cô đọng cho AI tra cứu, cùng thư mục `05. Knowlege/FI/`.

---
*FI — Full Specification · v1.0 · 2026-05-30 · DuyNQ5. TRUTH-mode: mọi dữ kiện có citation `file://#L`; gap đánh dấu ⚠️; Source Code thắng về hành vi. Sơ đồ: Mermaid (render trong VS Code / GitHub / Confluence Mermaid macro).*
