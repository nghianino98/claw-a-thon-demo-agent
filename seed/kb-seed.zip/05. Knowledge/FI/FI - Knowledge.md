# 📘 FI (Fixed Income) — Product Knowledge

> **Tài liệu sản phẩm toàn diện (living document)** · maintained by skill `product-documentation`.
> Đây là điểm-một-cửa để PO/CS/FA/đối tác/kỹ thuật hiểu FI từ đầu đến cuối: làm gì, vận hành ra sao, logic nghiệp vụ nào, tích hợp hệ thống thế nào, rủi ro đã biết. **Mô tả sự thật, không chấm điểm** (đánh giá chất lượng → `product-audit`).

## ⚡ Fact Sheet (TL;DR)

| | |
|---|---|
| **Sản phẩm** | FI (Fixed Income) — "Gói nhận lãi định kỳ"; biến thể combine với FC gọi "Uỷ thác đầu tư / UTĐT" |
| **Mô hình** | **Marketplace đa đối tác** — kết nối user ZaloPay với đối tác cung cấp gói sinh lời; pattern factory/registry trong code đã sẵn sàng cho nhiều partner |
| **Đối tác** | **Infina** (đã tích hợp, code thật, sandbox-verified); **Kafi** (kế hoạch — đã có draft luồng hợp tác merchant-wallet, chưa có code) |
| **Trạng thái** | 🟢 Legal đã duyệt — go-live Production dự kiến **T6/2026**; đã verify full flow onboard + deposit + withdraw trên Sandbox; backend repo ở mức `Init` (scaffolding + contract layer) |
| **Hạn mức / Kỳ hạn** | Tối đa **2 tỷ/user** (giảm từ 3 tỷ); không kỳ hạn hoặc 1–6 tháng; min/max deposit lấy động từ partner API |
| **Rule lãi** | Lãi kép theo ngày (không kỳ hạn) / lãi cuối kỳ (có kỳ hạn); **T+1** bắt đầu sinh lời; **thuế TNCN 5%** (Infina nộp thay); tái tục tự động **T+0** |
| **Order status (zlp)** | `init → processing → succeeded / failed` (PENDING/UNKNOWN từ Infina → giữ `processing` + retry) |
| **Revenue** | FI Fee = **9%** trong revenue-mix Investment (partner-deal based); ZaloPay rev-share từ phí Infina (0.25–0.4% AUM) + cross-sell |
| **Owner / Version** | DuyNQ5 / **v2.0** — cập nhật 2026-05-30 |

**Tóm tắt 3 dòng:** FI là marketplace kết nối user ZaloPay với các đối tác (Infina, Kafi) cung cấp gói nhận lãi định kỳ linh hoạt; nhắm user có tiền nhàn rỗi muốn lãi cao hơn SDSL/FD nhưng an toàn & đơn giản hơn Stock/CCQ. Sản phẩm đã dev & verify trên Sandbox, đang chuẩn bị go-live Production T6/2026 sau khi legal duyệt. Hành vi tiền/đơn hàng được điều phối qua chuỗi FMC → FS-Core → PE và đẩy tiền sang đối tác qua lớp `partnersfactory` (Infina là implementation đầu tiên).

---

## 0. Document Control

| | |
|---|---|
| **Version** | **v2.0** (major — mở rộng toàn diện + đối chiếu source code thật) |
| **Ngày cập nhật** | 2026-05-30 |
| **Owner** | DuyNQ5 (PO Wealth Solution) |
| **Status** | Draft (đang chờ go-live; nhiều technical page status `BlueDoing`) |
| **Phạm vi** | 1 sản phẩm FI · Full compile · Max-fidelity (deep-read source code) |
| **Engine** | skill `product-documentation` (CREATE v1.0 → UPDATE v1.1 → UPDATE v2.0) |

**Quy ước:** ⚠️ = thiếu nguồn / cần xác minh (xem Phần 9). Source Code = sự thật về hành vi; spec/Confluence = ý định. Mâu thuẫn → ghi cả hai. Source Index + Changelog ở cuối tài liệu.

---

## 1. Tổng quan sản phẩm

<!-- updated: 2026-05-30 v2.0 -->

**Định nghĩa.** FI được định vị là **một marketplace** kết nối user với nhiều đối tác (Infina, Kafi, …) cung cấp gói "nhận lãi định kỳ" linh hoạt — không kỳ hạn hoặc kỳ hạn 1–6 tháng; user chọn đối tác và gói để gửi tiền, tương tự gửi tiết kiệm [[Product concept:L14](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L14)]. System Overview xác nhận mục tiêu: marketplace kết nối nhiều partner, cross-sell across MMF/Stocks/FC/FD, giảm withdrawal rate và tăng AUM [[System Overview:L18](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L18)].

**Value proposition / định vị.** Lãi suất cao hơn SDSL (≈4,5%) & FD (~5,8–6%) → giữ chân user, hạn chế chuyển sang Tikop/Topi/Finhay; hạn mức cao và kỳ hạn linh hoạt; rủi ro cao hơn SDSL/FD nhưng thấp hơn Stock/CCQ, định nghĩa theo danh mục đầu tư của đối tác (Infina mua trái phiếu/tiền gửi ngân hàng big4; Kafi dùng cho vay margin); cam kết hiển thị mức rủi ro minh bạch [[Product concept:L22](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L22)]. Trong product tiering: SDSL = thanh toán + tích lũy; FD = gửi kỳ hạn cố định; **FI = user có tiền nhàn rỗi muốn lãi cao hơn & chấp nhận rủi ro hơn FD nhưng không muốn rủi ro/phụ thuộc thị trường như Stock/CCQ** [[Product concept:L29](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L29)].

**Đối tác & mô hình vận hành.**
- **Infina** — đối tác đầu tiên, đã có client code thật (`partnersfactory/infina`). FI gọi backend "savings/SDSL" của Infina; user ZaloPay được obfuscate ID trước khi gửi sang Infina (dùng chung cơ chế obfuscation với MMF) [[infina.go:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/infina/infina.go#L30)].
- **Kafi** — đối tác kế hoạch. Draft luồng hợp tác (2025-06-12): ZaloPay quảng cáo/giới thiệu KH cho Kafi + thu hộ/chi hộ qua **ví doanh nghiệp (merchant wallet)** của Kafi (liên kết tài khoản BIDV); settle 3–5 lần/ngày; có **Liquid Pool** dự trữ cho luồng chi hộ; ZaloPay **chỉ thu hộ đến tài khoản VA của KH, không involve vào việc mở gói vay** (tránh facilitate hoạt động cho vay) [[Kafi email:L15](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Fixed%20Income/2025-06-12%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQANajEG_GHaVAl2rE6xEEYiA%3D%20-%20%5BZalopay%20x%20Kafi%5D%20Lu%E1%BB%93ng%20d%E1%BB%8Bch%20v%E1%BB%A5%20h%E1%BB%A3p%20t%C3%A1c.md#L15)]. → Hai đối tác có **mô hình đi tiền khác nhau**; lớp `partnersfactory` được thiết kế để mỗi partner cắm vào bằng một implementation riêng.

**User & use case.** User ZaloPay có tiền nhàn rỗi, lãi ngân hàng thấp / chạm trần SDSL, muốn lợi suất cao hơn SDSL/FD nhưng an toàn & đơn giản hơn Stock/CCQ; user đã đăng ký SDSL dùng FI **không cần re-register** [[Product concept:L169](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L169)].

**Vị trí trong hệ ZaloPay.** FI tương tác với 4 hệ thống: **Partner APIs** (subscription/eKYC/fund), **ZaloPay Wallet** (nạp/rút/settlement), **CRM** (noti/campaign), **Data Platform** (analytics + PII encryption) [[System Overview:L24](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L24)]. Có biến thể **Uỷ thác đầu tư (UTĐT)** combine FI + FC (Fmarket) trên một Home chung [[Pending checklist:L20](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L20)].

---

## 2. Business Context

<!-- updated: 2026-05-30 v2.0 -->

**Mục tiêu sản phẩm.** Thu hút & giữ dòng tiền nhàn rỗi ở lại ZaloPay (hạn chế chuyển sang Tikop/Topi/Finhay vì lãi suất); tăng AUM (thêm dòng doanh thu); mở rộng investment portfolio [[Product concept:L36](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L36)].

**KPI / vị trí doanh thu.** FI là một thành phần của chỉ số "Union giao dịch MMF + Stock + FD + FC + FI" đo monthly [[OKR 2026:L81](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Product%20KPI/00.%20OKR%20Framework/Wealth%20Solution%20OKR%202026.md#L81)]. Trong revenue-mix: **FI Fee (New) = 9%**, lever = Partner deal, KR = "FI Activation (future KR)", owner TBD [[OKR 2026:L609](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Product%20KPI/00.%20OKR%20Framework/Wealth%20Solution%20OKR%202026.md#L609)]. OKR còn ghi action chưa đóng: "Xác nhận FI (Uỷ thác đầu tư) owner — hiện chưa assign Feature Lead" [[OKR 2026:L656](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Product%20KPI/00.%20OKR%20Framework/Wealth%20Solution%20OKR%202026.md#L656)]. Metrics theo dõi: AARRR framework [[Product concept:L191](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L191)].

**Revenue model (đối chiếu 2 nguồn — có khác biệt):**
- Product concept ghi **"TBU"** (chưa xác định) [[Product concept:L149](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L149)].
- Market Research lại có mô tả chi tiết: **Infina** thu phí quản lý theo bậc (0.25–0.4%/năm theo AUM) + spread lãi; **ZaloPay** ăn revenue-share từ phí của Infina (scale theo AUM) + cross-selling [[Market Research:L20](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/251077483_%5BFixed%20Income%5D%20Market%20Research.md#L20)].
- → Lấy Market Research làm mô tả cụ thể hơn; Product concept để "TBU" có thể do chưa chốt con số cuối. Cần xác nhận số chính thức (Phần 9).

**Bối cảnh thị trường (Market Research).** Vấn đề: Tikop/Topi/Finhay quảng cáo lãi cao hơn FD/SDSL → nguy cơ dòng tiền chảy ra khỏi ZaloPay; FI tung ra để giữ tiền nhàn rỗi trong hệ sinh thái [[Product concept:L96](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L96)]. Bảng lãi suất tham khảo (subject to change) [[Market Research:L42](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/251077483_%5BFixed%20Income%5D%20Market%20Research.md#L42)]:

| Provider | Non-term | 3 tháng | 6 tháng | 12 tháng | Hạn mức |
|---|---|---|---|---|---|
| **Infina** (backed by ACB Capital & BIDV, TNCN 5%) | 4.7% | 5.4% | 5.6% | 5.7% | 3B |
| Tikop (min 50k; SSC cảnh báo; phí rút nhanh 7.700đ) | 3.8–4.5% | ~6% | 6.5% | N/A | 1B–10B |
| Finhay (min 50k; Thiên Việt FMC; SSC cảnh báo) | 5–7% | N/A | N/A | N/A | — |
| Topi (tới 36 tháng = 8%) | 5% | 6% | 6.5% | 7% | 250tr/trans |
| MoMo Túi Thần Tài (68% market share) | 3.6–4.2% | N/A | N/A | N/A | — |
| Cake / CIMB (bank) | 0.1–0.3% | 4.4% | 5.6–5.7% | 5.8–6% | — |

Positioning ladder: SDSL (mặc định, an toàn) → Infina non-term (lợi suất/hạn mức cao hơn) → Infina có kỳ hạn 1–6 tháng → CIMB (>6 tháng) [[Market Research:L33](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/251077483_%5BFixed%20Income%5D%20Market%20Research.md#L33)].

**Chiến lược định vị.** KHÔNG để FI cạnh tranh trực tiếp SDSL/FD (tránh cannibalization — SDSL là "thanh toán + tích lũy" chủ lực, FD generate doanh thu cao hơn); chỉ cross-sale tại điểm user định opt-out: rút SDSL, đáo hạn FD, vượt hạn mức SDSL [[Product concept:L45](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L45)].

**Ràng buộc pháp lý / compliance.** TNCN 5% (Infina khấu trừ & nộp thay); PII phải encrypt; whitelist partner IP + client key; với Kafi cần làm rõ cơ sở pháp lý nhận tiền thu hộ + ZaloPay không facilitate cho vay [[System Overview:L108](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L108)]. Go-live Production từng pending vì issue legal (20/01/2026), nay đã được duyệt [[Pending checklist:L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L5)].

> ⚠️ **Data-quality flag:** Trang Product concept (SWOT, Product metrics) và Market Research (Target group) còn lẫn nội dung **template BNPL** (trả góp, "installments no interest", "reduce cart abandonment", "loan disbursement") — KHÔNG phải đặc tính FI. Bỏ qua các đoạn này khi diễn giải FI [[Product concept:L126](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L126)].

---

## 3. User Journey & UX

<!-- updated: 2026-05-30 v2.0 -->

### 3.1 Onboarding & Binding (2 entry path)

Onboarding xử lý **2 path** [[Onboarding:L33](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508480_%5BPCF-FS%5D%5BFixed-Income%5D%201.%20Onboarding.md#L33)]:
- **LinkAccount (Account Linking)** — user đã có account với đối tác → chỉ verify & link account đối tác với profile ZaloPay (không KYC lại). User đã đăng ký SDSL (Infina) dùng FI không cần re-register.
- **Registration (New User)** — user mới với cả ZaloPay & partner → full onboarding: eKYC, consent, tạo account phía partner, set up investment preference.

Sequence onboarding chuẩn (FI_Server ↔ Partners Factory) [[Onboarding:L52](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508480_%5BPCF-FS%5D%5BFixed-Income%5D%201.%20Onboarding.md#L52)]:
1. **User permission:** `checkAccountInternal()` → `checkHasFirstDeposit()`; nếu `hasFirstDeposit == true` → `showHomeBind()`.
2. **Landing data:** `listUserScheme(partnerCodes)` → `showLandingPage()` → `getUserScheme(schemeID, partnerCode)` → `showDepositScreen()`.
3. **Precheck onboarding:** `checkKycPermission(userId)` → UM `getProfile` → `evaluateKycRules()` (fail → `checkKycStatus`); `checkPartnerAccount(partnerCode)` → exists?
4. **Onboarding:** nếu `exists == true` → `linkPartnerAccount`; nếu `false` → `registerAccount`.
5. **After binding:** thành công → `sendDepositInfo(amount, schemeID)`; thất bại → `showError`.

**Check Account (2 phase)** [[Check Account:L48](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268076268_%5BPCF-FS%5D%5BFixed-Income%5D%201.1%20Check%20Account.md#L48)]: Phase 1 check internal FI-DB (`getUserPartnersAccount` → accountMap, xác định status unbinding/linking/locked) trả partial response cho nhanh; Phase 2 check partner account **async song song** từng partnerCode → final response.

**Account Linking** dùng **lock theo user** + audit history [[Account Linking:L59](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268076692_%5BPCF-FS%5D%5BFixed-Income%5D%201.3%20Account%20Linking.md#L59)]: `acquireLock(userId)` → check status → PF `linkAccount` → success: `saveUser(linked=true)` + `saveRegisterHistory(SUCCESS)`; fail: `saveRegisterHistory(FAILED, errorCode)` → `releaseLock`.

**UTĐT onboarding** gồm 3 flow: (1) Survey nhu cầu đầu tư, (2) Flow sau khi chọn FI, (3) Flow sau khi chọn FC [[UTĐT Onboarding:L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/285014263_%5BUT%C4%90T%5D%20Onboarding.md#L5)]; user chọn "Sinh lời ổn định / Sinh lời theo hiệu suất" + Home combine FI+FC [[Pending checklist:L20](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L20)].

### 3.2 Deposit (nạp mở gói)
Nguồn tiền: **Ví / VietQR**, hoặc từ **SDSL / Stock / FD** [[Product concept:L53](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L53)]. Các bước: Get Deposit Metadata → Khởi tạo deposit order → Xác nhận deposit order → Sync final status & confirm → Refund nếu failed [[Deposit:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268076002_%5BPCF-FS%5D%5BFixed-Income%5D%202.1.%20Deposit.md#L30)]. (Chi tiết kỹ thuật → Phần 5.)

### 3.3 Withdrawal (rút)
Rút về **Ví**, hoặc top-up sang **SDSL / FD / Stock** [[Product concept:L65](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L65)]. Có màn **Withdraw Preview** hiển thị tiền lời tất toán sớm + thuế trước khi xác nhận (xem Phần 4/5).

### 3.4 Portfolio / Lịch sử giao dịch
Dashboard hiển thị số dư hiện tại, lãi tích luỹ + dự kiến, tổng tài sản, lịch sử giao dịch; downloadable transaction report [[System Overview:L69](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L69)]. Jira có ticket riêng cho "Lịch sử giao dịch - Tiền lời hàng ngày", "Ngày nhận lời", "Tính thử tiền lời", "Matured package UI".

---

## 4. Functional Spec (Feature inventory + Business Rules)

### 4.1 Bản đồ tính năng

| Tính năng | Mô tả ngắn | Trạng thái | Nguồn |
|---|---|---|---|
| Deposit (nạp mở gói) | Ví / VietQR; hoặc từ SDSL / Stock / FD | ✅ Verified Sandbox | [concept:L53](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L53) |
| Withdrawal (rút) | Về Ví; hoặc top-up SDSL / FD / Stock; có Preview | ✅ Verified Sandbox | [Withdrawal:L20](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/284985907_%5BPCF-FS%5D%5BFixed-Income%5D%202.2.%20Withdrawal.md#L20) |
| Onboarding / Binding | FI-only + UTĐT; eKYC qua partner API; link nếu đã có SDSL | 🟡 Done flow, **chưa gắn TnC/Hợp đồng** | [Pending:L16](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L16) |
| Interest calc & payout | Lãi ngày / cuối kỳ; lãi kép; tái tục T+0 | ✅ BE log done | [Pending:L33](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L33) |
| Portfolio / Lịch sử GD | Số dư, tổng tài sản, lãi hàng ngày, lịch sử | ✅ | [System Overview:L69](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L69) |
| Marketplace đa đối tác | Factory/registry pattern; Infina implemented, Kafi planned | 🟡 Infina only | [factory.go:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/factory.go#L9) |
| Notifications (CRM + push) | Service noti + CRM tích hợp | 🟡 **Chưa define content** | [Pending:L40](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L40) |
| Reconciliation | File đối soát tách bạch SDSL & FI | ✅ Sandbox | [Pending:L26](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L26) |
| FS Hub integration | Tích hợp lên FS Hub (PCFFS-19501) | ❌ Chưa | [Pending:L14](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L14) |
| Data tracking FE | Event tracking FE (PCFFS-19296) | ❌ Chưa define | [Pending:L34](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L34) |

*(FI chưa go-live nên chưa có tính năng deprecated.)*

### 4.2 Business Rules & công thức

**Hạn mức & kỳ hạn.** Tối đa **2 tỷ/user** [Trao đổi với Duy 2026-05-30] — điều chỉnh từ định vị ban đầu 3 tỷ trong concept [[concept:L23](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L23)]; kỳ hạn không kỳ hạn hoặc 1–6 tháng. **Min/max deposit lấy động từ partner** qua `GetDepositLimit` → trả `min_deposit_amount`, `max_savings_balance`, `remaining_deposit_amount` [[partnersfactory dto.go:L133](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/dto.go#L133)] → giá trị "min X VND" trong System Overview không hardcode mà do partner quyết định. Có rule **chặn rút tiền cuối ngày** (PCFFS-19317).

**Công thức lãi (Infina)** [[Công thức tính lãi:L25](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/278880443_%5BFixed%20Income%5D%20Infina%20-%20C%C3%B4ng%20th%E1%BB%A9c%20t%C3%ADnh%20l%C3%A3i.md#L25)]:

- **Gói KHÔNG kỳ hạn — lãi theo ngày (lãi kép).** Quy tắc ngày bắt đầu sinh lời: nạp **T2–T5** → sinh lời từ **T+1**, nhận lời **T+2**; nạp **T6/T7/CN/lễ** → sinh lời từ ngày làm việc kế tiếp. Quy tắc T+1 chỉ áp cho khoản nạp mới; khi đã sinh lời thì tính liên tục kể cả cuối tuần/lễ. Lãi cộng trực tiếp vào số dư để sinh lời ngày kế (sinh lời kép).
  **`Tiền lời hàng ngày = Mức sinh lời / 365 × Số dư đang sinh lời`** [[Công thức tính lãi:L45](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/278880443_%5BFixed%20Income%5D%20Infina%20-%20C%C3%B4ng%20th%E1%BB%A9c%20t%C3%ADnh%20l%C3%A3i.md#L45)]. *VD: 5.000.000đ @ 4.842105%/năm trước thuế → ngày: 663đ, thuế 33đ, thực nhận 630đ.*
- **Gói CÓ kỳ hạn — lãi cuối kỳ.** Sinh lời T+1, nhận gốc+lãi ngày đáo hạn; rút trước hạn → tính theo **chính sách rút sớm**; **tái tục tự động T+0** (sau đáo hạn tự chuyển sang gói mới, sinh lời ngay).
  **`Tiền lời cuối kỳ = Mức sinh lời / 365 × Gốc × số ngày kỳ hạn`** [[Công thức tính lãi:L100](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/278880443_%5BFixed%20Income%5D%20Infina%20-%20C%C3%B4ng%20th%E1%BB%A9c%20t%C3%ADnh%20l%C3%A3i.md#L100)]. *VD: 5.000.000đ, 6 tháng (180 ngày) @ 4.842105% → 119.394đ trước thuế, thuế 5.969đ, thực nhận 113.425đ.*
- **Làm tròn:** ≥0.5 làm tròn lên, <0.5 giữ nguyên số nguyên. **Thuế TNCN 5%** trên tiền lời, Infina khấu trừ & nộp thay.
- ⚠️ **Công thức tính tiền lời luồng rút** (rút sớm) còn để trống trong tài liệu [[Công thức tính lãi:L124](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/278880443_%5BFixed%20Income%5D%20Infina%20-%20C%C3%B4ng%20th%E1%BB%A9c%20t%C3%ADnh%20l%C3%A3i.md#L124)] — nhưng `GetSavingsWithdrawPreview` trả sẵn `preMaturedInterestAmount`, `taxAmount`, `earlyWithdrawInterestRate`, `holdingDays` (đối tác tính, FI hiển thị) [[partnersfactory dto.go:L403](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/dto.go#L403)].

### 4.3 Transaction State Machine (đối chiếu spec ↔ code — KHỚP)

Order state diagram chuẩn [[Order State Diagram:L14](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297815713_%5BPCF-FS%5D%5BFixed-Income%5D%202.3.%20Order%20State%20Diagram.md#L14)]:

1. ZaloPay: Create Order → `INIT` (DB).
2. Infina: Call Create API (Deposit/Withdrawal) → success: trả PID, Infina = `PENDING`; fail: stop.
3. ZaloPay: Save PID → `PROCESSING` (ZaloPay PROCESSING / Infina PENDING).
4. Infina: Confirm API → `SUCCESS` / `FAILED`.
5. ZaloPay: Query & map: SUCCESS→`SUCCEEDED`; FAILED→`FAILED`; **PENDING/UNKNOWN→`PROCESSING` + retry later**.

**Cross-validation với source code:** `fscore.proto` enum `Status {PROCESSING, SUCCESS, FAILED}` [[fscore.proto:L12](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/proto/server/fscore/fscore.proto#L12)]; `partnersfactory.DeliveryStatus {pending, success, failed, unknown}` [[partnersfactory const.go:L12](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/const.go#L12)]; `orders.zlp_status {init, failed, pending, succeeded}` [[Data model:L46](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/285005666_Fixed%20Income%20-%20Data%20model.md#L46)]. Status mapper Infina↔internal là 1-1 (SUCCESS/FAILED/PENDING; khác → `unknown`) [[infina status_mapper.go:L11](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/infina/status_mapper.go#L11)].

### 4.4 Confirm Deposit (flow đồng bộ + xử lý lỗi)
Infina deposit đi **đồng bộ** [[Confirm Deposit Order:L43](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268077540_%5BPCF-FS%5D%5BFixed-Income%5D%20Confirm%20Deposit%20Order.md#L43)]: FS-Core→FI `Exchange` → FI `Acquire DistributedLock(orderId)` → Precheck (`status in {INIT}`, user existed) → Partner `Deposit`; SUCCESS→mark SUCCESS; FAILURE→phân loại: **Non-retryable→FAILED**, **Retryable→PROCESSING**; release lock. **Rủi ro fundlost** nếu xác định final status sai → Infina có 2 mã failed: `APPROVE_DEPOSIT_FAILED`, `REJECT_DEPOSIT_FAILED` [[Confirm Deposit Order:L102](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268077540_%5BPCF-FS%5D%5BFixed-Income%5D%20Confirm%20Deposit%20Order.md#L102)].

---

## 5. System & Technical

<!-- updated: 2026-05-30 v2.0 -->

### 5.1 Kiến trúc & service

HLD chia FI thành các service theo 2 core area (account vs order) [[HLD:L16](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508472_%5BPCF-FS%5D%5BFixed-Income%5D%201.%20High%20Level%20Design.md#L16)]:
- **Order service** — deposit/withdrawal + quản lý user investment scheme.
- **User service** — onboarding + user management.
- **Assistant service** — utility task, campaign execution, reconciliation.
- **Gateway Service** — route request App → internal FI services (auth/routing/middleware) [[Onboarding:L42](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508480_%5BPCF-FS%5D%5BFixed-Income%5D%201.%20Onboarding.md#L42)].

> ⚠️ README backend lại mô tả theo **3 domain** khác: User Management; Transactions & Service Packages; Dashboard & Reporting (squad "Investment", tạo 2025-07-08, status `Init`, maintainer @duynv4) [[backend README:L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/README.md#L5)]. Hai cách phân nhóm khác nhau (service vs domain) — chưa hợp nhất.

**⚠️ Trạng thái source code (quan trọng).** Repo `fixed-income-backend` đang ở mức **scaffolding** — `main.go` chỉ in "Init backend service", các package `app/controller/handler/interceptor/repository` mới là khai báo rỗng (chỉ có 1 interface `UserRepository.GetUserByZaloPayID`) [[backend main.go:L6](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/main.go#L6)] (status repo `Init` [[backend README:L18](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/README.md#L18)]). **Phần code thật & đầy đủ nằm ở module `shared/`** (proto contract + `partnersfactory` + Infina client). → Sự thật hành vi đáng tin nhất hiện ở: (1) `shared/` code, (2) các Technical Page (đa số status `BlueDoing`).

### 5.2 Hệ thống thanh toán liên quan (FMC / FS-Core / PE / Cashier)
Order management có 3 stakeholder đi tiền: nguồn tiền ZaloPay, partner, product [[Order Management:L28](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261520419_%5BPCF-FS%5D%5BFixed-Income%5D%202.%20Order%20Management.md#L28)]:
- **FMC** — khởi tạo order, UI trên app.
- **FS-Core** — xử lý trực tiếp với core, centralize order phục vụ đối soát tập trung; interface tới Payment ZaloPay.
- **PE** — tương tác "FI destination of fund" để đi tiền với đối tác.
- **Cashier** — UI hiển thị order, đảm bảo minh bạch & tránh XSS injection [[Deposit:L46](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268076002_%5BPCF-FS%5D%5BFixed-Income%5D%202.1.%20Deposit.md#L46)].

**Withdrawal sequence (4 phase)** [[Withdrawal:L19](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/284985907_%5BPCF-FS%5D%5BFixed-Income%5D%202.2.%20Withdrawal.md#L19)]: (1) Preview + Create Break Order (FI→Partner Create Withdrawal, FI→FMC Create Order, FI Init order); (2) Confirm Pay with Cashier; (3) Exchange do PE khởi tạo (PE→FS-Core Exchange→Queue); (4) Settlement (FS-Core consume queue, validate expired, →FI Exchange→Partner Confirm→ FS-Core update `PROCESSING`).

### 5.3 Data model

**4 bảng FI thật** [[Data model:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/285005666_Fixed%20Income%20-%20Data%20model.md#L9)]:
- **`users`** — `user_id`, `binding_status` (active/unbind), `origin` (mmf/fixed_income), `extra` (consent_time, account_tier).
- **`orders`** — `transtype` (deposit/withdraw), `partner_order_type` (redemption/…), `zp_trans_id`, `zlp_status` (init/failed/pending/succeeded), `partner_status`, `amount`, `partner_trans_id`, `fixed_income_id`, `metadata` (partner_error_code), `apptransid`, `appid`.
- **`fixed_income`** — package management.
- **`balance_histories`** — `zalopay_id`, `Earning_interest_balance`, … (timestamps + soft-delete).

> ⚠️ **Data-quality flag (đã biết):** nửa dưới trang Data model còn lẫn **schema FD/CIMB** — bảng `account` (partner_account_number, FD status), `order` thứ 2 (fixed_deposit_id, bc_request_id BankConnector, internal_fd_id, trans_type OPEN/BREAK, status PROCESSING/BANKTRANS_*/REFUNDED), `fixed_deposit` (tenor, maturity_instruction, estimated_interest) — KHÔNG thuộc FI [[Data model:L82](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/285005666_Fixed%20Income%20-%20Data%20model.md#L82)]. Trang `2. Database Design` (378 dòng) chưa ingest — cần đối chiếu để chốt schema chuẩn (Phần 9).

### 5.4 API & tích hợp đối tác (Infina — source-of-truth từ code)

**Lớp trừu tượng đa đối tác:** interface `PartnerFactory` (16 method) + registry `RegisterPartnerFactory(code)/GetPartnerFactory(code)` [[factory.go:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/factory.go#L9)]. PartnerCode hiện chỉ có `"infina"` [[partnersfactory const.go:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/const.go#L7)].

**Methods (capability surface):** GetPartnerUser, GetUserSchemes, GetUserAsset, GetSavingAccount, GetDepositLimit, LinkAccount, RegisterAccount, CreateDeposit, ConfirmDeposit, GetTransactions, GetWithdrawLimit, CreateWithdrawal, ConfirmWithdrawal, GetSavingsWithdrawPreview, GetSavingsInterestReports.

**Auth Infina = OAuth2 + checksum** [[Infina:L78](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261518007_%5BPCF-FS%5D%5BFixed-Income%5D%203.1%20Infina.md#L78)] — xác nhận bằng code [[infina client.go:L63](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/infina/client.go#L63)]:
- **GetToken** `POST {AUTH}/api/v1/auth/token` với `clientId` + `clientSecret` + header `x-api-key`; token cache, refresh trước hạn 5s (spec: token sống 24h).
- **Checksum** `HMAC-SHA256` (UTF-8 → HEX), secret key do Infina cấp; headers `x-checksum`, `x-checksum-id`, `x-checksum-timestamp`; JSON body sort key alphabetically đệ quy [[Infina:L104](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261518007_%5BPCF-FS%5D%5BFixed-Income%5D%203.1%20Infina.md#L104)]. Routing: path prefix `/api/v1/partner/user` đi `userClient`, còn lại đi `baseClient` [[infina client.go:L116](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/infina/client.go#L116)].
  > ⚠️ Mô tả `x-checksum-id` / `x-checksum-timestamp` trong Confluence bị **mô tả ngược tên** (id ghi là ISO-8601 time, timestamp ghi là UUIDv4) — cần đối chiếu code/Infina khi implement; expiry: 30 phút / 5 phút.

**Endpoint Infina thật (từ `infina.go`)** [[infina.go:L25](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/infina/infina.go#L25)]:

| Method nội bộ | Endpoint Infina |
|---|---|
| GetPartnerUser | `GET /api/v1/partner/user/sdsl/{hashUserID}` |
| GetUserSchemes | `GET /api/v1/partner/savings/schemes` |
| GetUserAsset / GetSavingAccount | `GET /api/v1/partner/savings/accounts` |
| GetDepositLimit | `GET /api/v1/partner/savings/deposit/partner-wallet/metadata` |
| LinkAccount | `POST /api/v1/partner/user/consent` |
| CreateDeposit | `POST /api/v1/partner/savings/deposit/partner-wallet` |
| ConfirmDeposit | `POST /api/v1/partner/savings/deposit/partner-wallet/update` |
| GetTransactions | `GET /api/v1/partner/savings/transactions` |
| GetWithdrawLimit | `GET /api/v1/partner/savings/withdraw/partner-wallet/metadata` |
| CreateWithdrawal | `POST /api/v1/partner/savings/withdraw/partner-wallet` |
| ConfirmWithdrawal | `POST /api/v1/partner/savings/withdraw/partner-wallet/update` |
| GetSavingsWithdrawPreview | `GET /api/v1/partner/savings/withdraw/ts/preview` |
| GetSavingsInterestReports | `GET /api/v1/partner/savings/reports/interest` |

**Hợp đồng dữ liệu chính (DTO):**
- `CreateDepositRequest{partner_account_id, scheme_id, amount}` → `CreateDepositResponse{transaction_pid, status, interest_started_at, interest_rate, total_amount, …}` [[dto.go:L167](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/dto.go#L167)].
- `ConfirmDepositRequest.delivery_status` chỉ nhận `success`/`failed` (validation) [[dto.go:L208](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/dto.go#L208)].
- `CreateWithdrawalRequest{partner_ref_id, withdraw_amount, trigger_type}` với `trigger_type ∈ {AUTO, MANUAL}` [[const.go:L19](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/const.go#L19)]; `ConfirmWithdrawalRequest` yêu cầu `partner_transaction_id`+`withdrawn_at` nếu status SUCCESS [[dto.go:L343](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/dto.go#L343)].
- Transaction description: `DEPOSIT / WITHDRAW / INTEREST / ADJUST_INTEREST` [[dto.go:L263](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/dto.go#L263)]. Interest report theo ngày (`interestAmount`, `reportDate` ISO8601) [[dto.go:L514](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/dto.go#L514)].

**Concept key Infina** [[Infina:L34](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261518007_%5BPCF-FS%5D%5BFixed-Income%5D%203.1%20Infina.md#L34)]: `PartnerRefId` (định danh ví user ở partner), `User` (1 user nhiều account), `Account` (mỗi khoản đầu tư), `Scheme` (cấu hình sản phẩm), `Product` (category `nfs`/`pfs`), `Transaction`. Onboarding API Infina: CheckBindUser, ContactPreview, SendOTP `/sms/bind`, ProcessBindUser `/bind`, SendKYCImage [[Infina:L133](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261518007_%5BPCF-FS%5D%5BFixed-Income%5D%203.1%20Infina.md#L133)].

### 5.5 Lớp User Service (dùng chung proto với MMF)
FI dùng proto `fin.illuminate.user.v1` (go_package `.../fixed_income/mmf`) — service `UserService`: `SubmitBindingAuto`, `UpgradeAccountTier`, `GetPriorityToggle`, `UpdatePriorityToggle` [[mmf user.proto:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/proto/client/mmf/user.proto#L7)]. `SubmitBindingAutoRequest{user_id, binding_flow, consent_time, account_tier}`; `binding_flow = "fixed_income"` [[infina.go:L22](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/infina/infina.go#L22)]; `AccountTier ∈ {VIETQR_ONLY, SME}`. Sub_code lỗi binding: 1071 User existed, 1082 IDType Invalid, 1085 Only NFC missing KYC, 1086 Invalid Account Tier, 2011/2012 KYC, 3001/3005/3030/3xxx Infina [[mmf user.proto:L39](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/proto/client/mmf/user.proto#L39)]. → FI tái sử dụng tầng user/binding "illuminate" của MMF.

### 5.6 Hạ tầng & config
gRPC port 9090, Prometheus 8080, Redis ElastiCache, MySQL, tích hợp `user_profile` + `ekyc_service` (client_id `financial`) [[config.yaml:L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/config/config.yaml#L5)]. NFR: PII encrypt, whitelist partner IP/key, API nội bộ <200ms, availability ≥99.9%, modular cho partner mới [[System Overview:L106](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L106)].

> ✅ **RESOLVED (so với v1.1):** `config.yaml` (dev) hardcode `db_name: stock_qc_core` + `user_profile.client_id: mmf` **chỉ là default môi trường dev** [[config.yaml:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/config/config.yaml#L30)]. `prod.yaml`/`stg.yaml`/`qc.yaml` đều dùng **giá trị template namespace FI riêng**: `{{ fin.fi_user_service.user_profile.client_id }}`, `{{ fin.fi.data_source.db_name }}` … → FI có DB/client riêng ở môi trường thật [[prod.yaml:L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/config/prod.yaml#L44)]. *(Lưu ý nhỏ: `prod.yaml` đặt `env: stg` ở dòng 2 — có thể là placeholder copy, cần xác minh.)*

### 5.7 Đối soát & degraded/DR
Đối soát: file tách bạch 2 file SDSL & FI (sandbox); FS-Core centralize order cho đối soát tập trung. ⚠️ Degraded/DR mode chưa có nguồn riêng cho FI (Phần 9).

---

## 6. Operational Playbook

<!-- updated: 2026-05-30 v2.0 -->

**Monitoring.** Prometheus port 8080 [[config.yaml:L3](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/fixed-income-backend/config/config.yaml#L3)]; BE đã log order + account; FE event tracking + dashboard **chưa set up** [[Pending:L33](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L33)].

**Sự cố đã biết / rủi ro thiết kế.**
- Order `PENDING/UNKNOWN` từ Infina → giữ `PROCESSING` + **retry** (cần job retry & timeout) [[Order State Diagram:L75](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/297815713_%5BPCF-FS%5D%5BFixed-Income%5D%202.3.%20Order%20State%20Diagram.md#L75)].
- Confirm deposit timeout / xác định final status sai → **rủi ro fundlost** (Infina: `APPROVE_DEPOSIT_FAILED`, `REJECT_DEPOSIT_FAILED`) [[Confirm Deposit Order:L101](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268077540_%5BPCF-FS%5D%5BFixed-Income%5D%20Confirm%20Deposit%20Order.md#L101)]. Deposit failed → **Refund** [[Deposit:L34](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268076002_%5BPCF-FS%5D%5BFixed-Income%5D%202.1.%20Deposit.md#L34)].
- ⚠️ **Chưa có CS ticket FI** (thư mục `03. Fact/CS Ticket/FI` rỗng — sản phẩm chưa go-live); bổ sung sau launch qua SYNC.

**Hỗ trợ CS/FA.** Cần thông báo CS mô tả tính năng để set up FAQ & Chatbot; tích hợp CS tool để hiển thị account FI (PCFFS-19079) — **chưa xong** [[Pending:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L30)].

**Pre-prod checklist (Technical deployment)** [[Pending:L47](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/305020246_%5BUpdate%2020_1_2026%5D%20Pending%20checklist.md#L47)]: active appID FI lên prod (Jira MI-3692); email set up hạn mức & SOF cho FS SOF + appID luồng nạp/rút; config tactic (ưu tiên hiển thị SOF cho luồng rút trên cashier; bỏ voucher; bỏ apply xu; bỏ luồng thêm ngân hàng); regression test trước prod; request Loyalty remove appID khỏi luồng tích xu nâng hạng. CRM inventory: `investment_trust_hub`, `investment_trust_banner`, `fix_income_uythac_banner`.

---

## 7. Trust & Safety

<!-- updated: 2026-05-30 v2.0 -->

- **Trust signals:** Infina backed by ACB Capital & BIDV, audit Deloitte; cam kết hiển thị **mức rủi ro minh bạch** + asset allocation per fund [[Market Research:L45](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/251077483_%5BFixed%20Income%5D%20Market%20Research.md#L45)].
- **Money transparency:** Cashier hiển thị order minh bạch, chống XSS injection [[Deposit:L46](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/268076002_%5BPCF-FS%5D%5BFixed-Income%5D%202.1.%20Deposit.md#L46)]; PII encrypt + whitelist IP/key [[System Overview:L108](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Technical%20Page/261508471_%5BPCF-FS%5D%5BFixed-Income%5D%200.%20System%20Overview.md#L108)]. ZaloPay ID được obfuscate trước khi gửi partner [[infina.go:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/client/partnersfactory/infina/infina.go#L30)].
- **Consent / hợp đồng:** TnC yêu cầu user consent với BCC mới của Infina khi nạp FI; hợp đồng SDSL cập nhật thêm điều khoản FI; FAQ FI/SDSL [[TnC:L20](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/268083035_Fixed%20Income%20-%20TnC.md#L20)]. ⚠️ TnC/BCC/Hợp đồng **chưa gắn** vào luồng onboarding (Phần 9).
- **An toàn tài chính (Kafi):** ZaloPay chỉ thu hộ đến VA của KH, **không facilitate cho vay**; UI phải highlight "nạp vào tài khoản Kafi" thay vì "nạp vào gói vay" [[Kafi email:L48](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Fixed%20Income/2025-06-12%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQANajEG_GHaVAl2rE6xEEYiA%3D%20-%20%5BZalopay%20x%20Kafi%5D%20Lu%E1%BB%93ng%20d%E1%BB%8Bch%20v%E1%BB%A5%20h%E1%BB%A3p%20t%C3%A1c.md#L48)].

---

## 8. Lịch sử & Roadmap

<!-- updated: 2026-05-30 v2.0 -->

**Tiến độ build (Jira `Fixed Income`, ~125 ticket PCFFS — `Jira/FI` là bản trùng nội dung).** Các nhóm chính:
- **Infra/setup:** FS Core schema (15034), User/Gateway/Order repo + CICD (15152/15319/15338), Init datasource (15341).
- **Onboarding:** checkInternalAccount (15343), register SDSL (15348), API consent (15349), Submit onboarding Infina (16023).
- **Deposit/Order:** Design term & order (15364), Init Order (16235), Integrate Open với Infina (16237), Query status (16329/16330), Sync final status Kafka (16331).
- **Withdraw:** Init withdraw order (16870), Integrate Partner withdraw (16871), Enhance State Machine (16873), preview redemption (17547), Confirm withdraw qua Infina (17734), Infina trả lãi luồng rút (19071).
- **Interest/maturity:** Update công thức lãi (17125), Lịch sử GD tiền lời hàng ngày (17748), Tính thử tiền lời (19260), filter/UI gói matured (19311/19312), chặn rút cuối ngày (19317), update hạn mức nạp/rút (19321).
- **CRM/tracking:** CRM Advertising (17738), Notification (17755), AB test (18732), event tracking FE (19296), Data Platform (19507), Sync FI qua CS tool (19079).
- **UTĐT:** Design solution UTĐT-FC (17541), onboarding screens (18455–18465), asset/recommend/discovery (19540–19544).
- **Go-live:** Checklist go live (18754), Review go live FE (18756), Release staging (19322), **Tích hợp FI lên FS Hub (19501)**, Maintenance (18029/18748).

> ⚠️ Trạng thái từng ticket (Done/In-progress) chưa đọc nội dung từng file — chỉ mới inventory tiêu đề; chi tiết → SYNC sau.

**Roadmap / mốc:**
- ✅ Dev + verify Sandbox (onboarding, deposit, withdraw, interest, đối soát).
- 🟡 Pre-prod: gắn TnC/BCC/hợp đồng, define noti content, FE tracking + dashboard, tích hợp CS tool, regression test, active appID prod, set up hạn mức/SOF.
- 🟡 FS Hub integration (chưa).
- 🔜 Go-live Production T6/2026.
- 🔜 Kafi onboarding (partner thứ 2) — chưa có code.

---

## 9. Open Questions & Gaps

<!-- updated: 2026-05-30 v2.0 -->

**Đã RESOLVED ở v2.0:** ✅ Config prod dùng namespace FI riêng (không phải stock_qc_core/mmf — chỉ dev); ✅ Min/max deposit lấy động từ partner `GetDepositLimit` (không hardcode); ✅ Revenue model có mô tả ở Market Research (rev-share phí Infina 0.25–0.4% AUM).

**Còn mở:**
- [ ] **Revenue model — con số chính thức:** Product concept ghi TBU, Market Research ghi rev-share — cần chốt số/deal cuối với Infina & Kafi.
- [ ] **FI Feature Lead/owner chưa assign** (OKR action chưa đóng) [[OKR 2026:L656](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Product%20KPI/00.%20OKR%20Framework/Wealth%20Solution%20OKR%202026.md#L656)].
- [ ] ⚠️ **Data model trang Confluence lẫn schema FD** — cần đối chiếu `2. Database Design` (378 dòng, chưa ingest) để chốt schema chuẩn 4 bảng FI.
- [ ] **Công thức tính tiền lời luồng rút sớm** để trống — dù `GetSavingsWithdrawPreview` đã trả `preMaturedInterestAmount`/`taxAmount`; cần document công thức/nguyên tắc.
- [ ] **Nạp FI từ SDSL:** ZLP ghi nhận giao dịch hay Infina tự chuyển đổi? (ảnh hưởng đối soát & hiển thị lịch sử GD) [[concept:L57](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FI/Product%20Page/254647549_%5BFixed%20Income%5D%20Product%20concept.md#L57)].
- [ ] TnC/BCC/Hợp đồng chưa gắn onboarding; nội dung notification chưa define; FE event tracking + dashboard chưa set up.
- [ ] Kafi chưa tích hợp (chưa code); cần làm rõ cơ sở pháp lý thu hộ + role ZION.
- [ ] Segment/whitelist theo entry point chưa rõ tiêu chí.
- [ ] `prod.yaml` đặt `env: stg` (dòng 2) — xác minh placeholder hay nhầm.
- [ ] Mô tả header checksum Infina (`x-checksum-id`/`x-checksum-timestamp`) bị ngược tên trong Confluence — đối chiếu khi implement.
- [ ] **Chưa ingest (để SYNC sau):** Database Design, Deposit/Withdrawal Process Overview (313/245 dòng), Golive checklist Prod/Staging/Internal, Register flow, Repository structure, Query order fs-core, Git flow; Market/User research chi tiết + UXR pptx; phần lớn Shared Email/Chat; nội dung từng Jira ticket; Figma design; CS Ticket (sau launch).

---

## 10. Appendix

### 10.1 Glossary (FI-specific)
- **UTĐT** — Uỷ thác đầu tư (Passive Investment): biến thể combine FI + FC (Fmarket).
- **SDSL** — Số Dư Sinh Lời (MMF, Infina) — FI dùng chung backend savings/SDSL của Infina.
- **PartnerRefId** — định danh ví user phía partner (Infina).
- **Scheme / Product** — gói sinh lời / category sản phẩm (Infina: `nfs`, `pfs`).
- **FMC / FS-Core / PE / Cashier** — chuỗi hệ thống thanh toán nội bộ ZaloPay (khởi tạo order / core đối soát / đi tiền / UI).
- **Liquid Pool** — khoản dự trữ trong merchant wallet Kafi cho luồng chi hộ.
- **DEDUCT / ADD** — Action trong `fscore.proto Exchange` (trừ ví / cộng ví) [[fscore.proto:L27](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/FI/shared/proto/server/fscore/fscore.proto#L27)].

### 10.2 Source Index chi tiết — xem Source Manifest ở cuối.

---

## 🔖 Changelog

| Version | Ngày | Mục | Thay đổi (cũ → mới) | Nguồn |
|---|---|---|---|---|
| **v2.0** | **2026-05-30** | **Toàn bộ (tái cấu trúc 11 phần) + 1,2,4,5,7,8** | **Mở rộng comprehensive + max-fidelity.** Deep-read source code `shared/` → bổ sung: PartnerFactory interface (16 method), 13 endpoint Infina thật, OAuth2+HMAC-SHA256 checksum, DTO deposit/withdraw/interest, status mapper, mmf user proto (binding sub_codes), fscore proto (Exchange DEDUCT/ADD). **RESOLVED:** config prod dùng namespace FI riêng (không phải stock_qc_core); min/max deposit động từ partner; revenue model (Market Research). Bổ sung: Kafi partner model (merchant wallet/Liquid Pool), OKR (FI Fee 9%, owner TBD), competitive table, onboarding/check-account/account-linking sequence, confirm-deposit flow + fundlost risk, Jira ~125 ticket inventory. Flag: backend repo mức `Init` (scaffolding), BNPL template residue, FD-schema contamination trong Data model. | Source Code FI `shared/` + `config`; Confluence Technical (System Overview, HLD, Order Mgmt, State Diagram, Deposit, Withdrawal, Onboarding, Check Account, Account Linking, Partner API, Infina, Confirm Deposit); Product (concept, công thức lãi, data model, market research, TnC, pending); Jira/Fixed Income; OKR 2026; Vault/FlaggedEmails (Kafi) |
| v1.1 | 2026-05-30 | Fact Sheet, 1, 2, 10 | Legal duyệt go-live (T6/2026); hạn mức **3 tỷ → 2 tỷ/user**; trạng thái Pending → Legal approved | Trao đổi với Duy 2026-05-30 |
| v1.0 | 2026-05-30 | BUILD | Khởi tạo mục 1–9, 12 từ Confluence (Product+Technical) + Source Code FI | Confluence FI (~12/47 trang), Source Code FI backend |

## 🗂️ Source Manifest (watermark để UPDATE/SYNC)

| Nguồn | Watermark đã đọc | Đã đọc / Tổng | Ghi chú |
|---|---|---|---|
| Confluence Product | page id `305020246` (20/01/2026) | ~10 / 14 | concept, market research, công thức lãi, data model, TnC, partners, pending, UTĐT onboarding, FC dependency, uỷ thác |
| Confluence Technical | page id `297815713` | ~16 / 28 | System Overview, HLD, Business Design, Tech Doc, Order Mgmt, State Diagram, Deposit, Withdrawal, Onboarding, Check Account, Account Linking, Status handling, Partner API, Infina, Confirm/Create Deposit Order, Handling Order Status |
| Source Code | `shared/` full + `config` (đọc 2026-05-30) | proto + partnersfactory + infina client + config; backend `internal/` = scaffolding | README, config.yaml/prod.yaml, fscore.proto, mmf user.proto, factory.go, const.go, dto.go, infina.go, client.go, status_mapper.go |
| Jira (Fixed Income) | `PCFFS-19544` | inventory tiêu đề ~125 (chưa đọc nội dung) | `Jira/FI` trùng nội dung `Jira/Fixed Income` |
| KPI / OKR | OKR 2026 (FI lines) | FI-relevant rows | FI Fee 9%, owner TBD, union metric |
| Shared Email | Kafi (2025-06-12) | 1 / nhiều | Vault/FlaggedEmails: Fixed Income (12), Investment (nhiều) — UXR, Kafi, wireframe chưa đọc hết |
| CS Ticket | — (rỗng) | 0 / 0 | FI chưa go-live |
| Figma / Design | — | — | Chưa ingest |
| Issue Investigation | — | — | Không có folder FI riêng |
| Data / Database Design | Data model (product page) | 1 / 2 | `2. Database Design` (378 dòng) chưa ingest |

---
*FI — Product Knowledge · v2.0 · maintained by skill `product-documentation` (mode SYNC định kỳ). TRUTH-mode: mọi dữ kiện có citation `file://`; gap đánh dấu ⚠️; Source Code thắng về hành vi.*
