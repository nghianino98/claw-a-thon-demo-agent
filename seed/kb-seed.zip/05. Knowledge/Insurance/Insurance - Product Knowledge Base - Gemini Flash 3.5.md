# 📘 Insurance (Bảo hiểm) — Product Knowledge Base

---

## ⚡ Fact Sheet (TL;DR)

| Thuộc tính | Chi tiết |
|---|---|
| **Tên sản phẩm** | **Insurance (Sản phẩm Bảo hiểm)** trên Zalopay |
| **Đối tác công nghệ (Aggregators)** | **SaveMoney**, **Saladin**, **Fuse**, **Igloo**, **Payoo** (cho luồng thu hộ phí bảo hiểm). |
| **Nhà bảo hiểm (Insurers)** | **Chubb**, **VBI**, **GIC**, **Bảo Việt**, **PVI**, **ABIC**, **VNI**, **MIC**, **Bảo Minh**, **Generali**, **MetLife**, **FWD**, **Cathay Life**. |
| **Trạng thái** | 🟢 Live (Đang chạy thực tế trên môi trường Production). |
| **Dòng sản phẩm chính** | 1. **Distribution (Phân phối)**: Bán bảo hiểm tự nguyện/bắt buộc qua miniapp độc lập (Hub bảo hiểm) hoặc nhúng trực tiếp (Embedded) vào các luồng thanh toán hóa đơn, nạp điện thoại, và chuyển tiền P2P.<br>2. **Collection (Thu hộ)**: Hub thanh toán phí bảo hiểm định kỳ cho các công ty bảo hiểm nhân thọ đối tác. |
| **Mã Dòng sản phẩm (Product Line ID)** | * **Micro Insurance**: **3275** (Bao gồm hầu hết các gói bảo hiểm nhúng).<br>* **BH Nhân thọ (Collection)**: **3081** (Generali, MetLife, FWD, Cathay). |
| **Hạ tầng backend** | Monorepo Go service tên là **`ares`** (gồm các module chính: `bill`, `provider`, `service`, `database`, `queue`). |
| **Hệ thống liên lạc bất đồng bộ** | Sử dụng **RabbitMQ** với cơ chế trì hoãn lệnh (Delay queue) thông qua plugin `x-delayed-message` để kiểm tra trạng thái và thực hiện hoàn tiền tự động khi giao dịch lỗi. |
| **Hệ thống định tuyến (Routing)** | Hỗ trợ cấu hình động hiển thị bảo hiểm (theo tỷ lệ % traffic, đuôi số ID người dùng để A/B test, lịch sử thanh toán, trạng thái hợp đồng đang hoạt động, và lịch sử tương tác click/untick). |
| **Đăng ký gia hạn tự động** | Tích hợp **Auto Debit Oneflow subscription** cho phép trích nợ tự động ví Zalopay hoặc tài khoản liên kết để đóng phí duy trì hợp đồng bảo hiểm định kỳ (áp dụng cho bảo hiểm an ninh mạng, sức khỏe tích lũy, sống tự tin, người thanh toán, rơi vỡ màn hình, sống an vui). |
| **Chính sách hoàn/hủy** | Tùy vào quy định của từng đối tác và nhà bảo hiểm (có sản phẩm không cho hoàn/hủy, có sản phẩm hỗ trợ hoàn tiền 100% trong thời gian cân nhắc freelook 14-15 ngày đầu tiên như Chubb Sống An Vui). |
| **Owner / Phiên bản** | DuyNQ5 / **v1.0** — Cập nhật ngày 2026-06-03. |

---

## 1. Tổng quan & Định vị Chiến lược

Sản phẩm Bảo hiểm (Insurance) là một mảng kinh doanh quan trọng thuộc hệ sinh thái tài chính Zalopay Wealth. Tận dụng lượng người dùng lớn và các điểm chạm thanh toán hàng ngày (Telco, Bill, P2P Transfer, OTA), Zalopay đóng vai trò là kênh phân phối và thu hộ phí bảo hiểm số hóa cao, mang lại trải nghiệm tiện lợi "tất cả trong một" cho khách hàng.

### 1.1 Phân loại Dòng sản phẩm (Product Classification)
Hệ thống quản lý bảo hiểm được chia thành hai nhánh chính:
1. **Distribution (Bán bảo hiểm)**: 
   * **Standalone (Bán độc lập)**: Người dùng chủ động vào Hub bảo hiểm trên Zalopay App để đăng ký các gói bảo hiểm bắt buộc hoặc tự nguyện (Xe máy, Ô tô, Sức khỏe, Tai nạn, Nhà...).
   * **Embedded / Cross-sell (Bán kèm)**: Gói bảo hiểm được gợi ý tích hợp (opt-out hoặc opt-in) ngay trong luồng thanh toán dịch vụ chính nhằm tối ưu tỷ lệ chuyển đổi.
2. **Collection (Thu hộ phí bảo hiểm)**:
   * Cho phép khách hàng đang sở hữu hợp đồng bảo hiểm nhân thọ của các đối tác lớn thực hiện tra cứu kỳ đóng phí và thanh toán phí định kỳ ngay trên Zalopay qua kết nối cổng trung gian hoặc tích hợp trực tiếp.

### 1.2 Các đối tác công nghệ và vai trò của Ares Core
Hệ thống lõi backend **`ares`** chịu trách nhiệm kết nối, chuẩn hóa dữ liệu và điều phối giao dịch giữa ví Zalopay và các nền tảng công nghệ bảo hiểm (Insurtech Aggregators):
* **SaveMoney**: Phân phối bảo hiểm xe máy/ô tô bắt buộc, bảo hiểm nhà độc lập, bảo hiểm tai nạn UIC.
* **Saladin**: Phân phối bảo hiểm xe máy/ô tô bắt buộc, bảo hiểm du lịch chuyến bay/chuyến xe, bảo hiểm người thanh toán hóa đơn điện/nước/CF, bảo hiểm sức khỏe/tai nạn/hiểm nghèo.
* **Fuse**: Phân phối bảo hiểm sức khỏe tích lũy (postpaid), bảo hiểm học đường vui khỏe (edu), bảo hiểm sống tự tin (cf).
* **Igloo**: Phân phối bảo hiểm rơi vỡ màn hình điện thoại (với bảo hiểm gốc của PVI).
* **Payoo**: Cổng thanh toán trung gian để xử lý tra cứu và thu hộ phí cho các đối tác Generali, MetLife, FWD.
* **Cathay Life**: Kết nối trực tiếp để xử lý thu hộ phí bảo hiểm nhân thọ Cathay.

### 1.3 Định hướng Phân phối theo Điểm chạm (Contextual Distribution & Touchpoints)
Nhằm giải quyết rào cản về mức độ liên quan (relevance) và tối ưu hóa tỷ lệ chuyển đổi, Zalopay thực hiện chiến lược **phân phối bảo hiểm nhúng ngữ cảnh (Contextual Embedded Insurance)**. Bản đồ đề xuất bảo hiểm được liên kết trực tiếp với các điểm chạm thanh toán hàng ngày của người dùng:
* **Hóa đơn thiết yếu (Điện, Nước, Internet, Truyền hình)**: Đề xuất **Bảo hiểm Người thanh toán (Payer Protection)** hoặc **Bảo hiểm Nhà (Property Protection)** để bảo vệ rủi ro tai nạn của chủ hộ hoặc hư hại tài sản ngôi nhà.
* **Hóa đơn Học phí (Tuition Fee)**: Đề xuất **Bảo hiểm Học đường vui khỏe (Happy Edu)** nhằm hỗ trợ chi phí y tế học sinh và rủi ro gián đoạn học tập do tai nạn hoặc bạo lực học đường.
* **Thanh toán Khoản vay & Thẻ tín dụng**: Đề xuất **Bảo hiểm Sống tự tin (Credit Protection)** để hỗ trợ tài chính cho khách hàng trước các rủi ro mất thu nhập, thất nghiệp hoặc tai nạn.
* **Mua thẻ điện thoại & Nạp tiền (Telco Topup)**: Đề xuất **Bảo hiểm Màn hình điện thoại (Cracked Screen)** hoặc **Bảo hiểm Sức khỏe tích lũy (Health Accumulate)**.
* **Đặt vé du lịch, máy bay, xe khách (OTA Travel & Flight)**: Đề xuất **Bảo hiểm trễ/hủy chuyến bay (Flight Delay)**, **Bảo hiểm du lịch (Travel Insurance)**, hoặc **Bảo hiểm chuyến đi (Trip Insurance)** để bảo vệ rủi ro di chuyển của khách hàng.
* **Chuyển tiền P2P (Money Transfer)**: Bán chéo **Bảo hiểm an ninh mạng (Cyber Risk)** để bảo vệ tài khoản ví trước các rủi ro lừa đảo, tấn công mạng.

---


## 2. Nghiệp vụ & Danh mục Sản phẩm (Detailed Offerings & Rules)

### 2.1 Bảng Tổng quan Danh mục Sản phẩm

Bảng dưới đây chi tiết hóa toàn bộ danh mục sản phẩm bảo hiểm đang vận hành trên hệ thống Zalopay:

| Nhóm | Sản phẩm | Ứng dụng bán kèm (App ID) | Nhà cung cấp (Supplier) | Nhà bảo hiểm gốc (Insurer) | Quy tắc Phí & Ràng buộc |
|---|---|---|---|---|---|
| **Distribution - Compulsory** | Bảo hiểm xe máy bắt buộc | 1020, 3951, 4326 | SaveMoney, Saladin | ABIC, VNI, PVI, VBI, Bảo Minh, MIC | Phí cố định theo loại xe (dưới 50cc, trên 50cc). Không áp dụng hoàn/hủy. |
| | Bảo hiểm ô tô bắt buộc | 3507, 3951 | SaveMoney, Saladin | MIC, Tasco, HDI, PVI, Bảo Việt, Bảo Minh | Phí tính theo loại xe, mục đích sử dụng. Không áp dụng hoàn/hủy. |
| **Distribution - Travel** | BH trễ/hủy chuyến bay & hỏng hành lý | 3274 | Saladin | Bảo Việt | Embedded opt-out trong luồng đặt vé máy bay nội địa. Hoàn hủy trước giờ bay 3h qua email CS. |
| | BH du lịch Chubb (Domestic / Intl) | 3834 | Chubb | Chubb Việt Nam | Embedded/Cross-sell trong luồng vé máy bay Flight. Không cho hoàn hủy trừ trường hợp bị từ chối thị thực. |
| | BH chuyến đi (xe Bus) | 3676 | Saladin | Bảo Việt | Embedded opt-out trong luồng mua vé xe Bus. Hoàn hủy trước giờ khởi hành. |
| **Distribution - Cyber** | Bảo hiểm an ninh mạng | 3682 | VBI | VBI | Embedded trong Telco Top-up và cross-sell trong chuyển tiền P2P. Hoàn phí trong 24h qua VBI admin tool. |
| **Distribution - Health** | Bảo hiểm Chăm sóc sức khỏe MiniHealth | 3951 / 305029879 | Fullerton Health | MSIG | Bán standalone. Quyền lợi khám nội/ngoại trú kết hợp bảo lãnh thuốc trực tuyến & giao thuốc Pharmacity. Ràng buộc tuổi $\geq 18$. |
| | Bảo hiểm sức khỏe / thai sản / hiểm nghèo | 3951 | Saladin | VBI, MIC, Bảo Việt, Liberty, PVI | Đăng ký trên Hub bảo hiểm standalone. Ràng buộc độ tuổi của từng gói cụ thể. |
| **Distribution - Bill (Embedded)** | BH người thanh toán (Payer Protection) | 2390 | Saladin | Bảo Việt | Embedded opt-in trong thanh toán hóa đơn Điện. Phí 1% giá trị bill. Không hoàn hủy. |
| | BH người thanh toán (Sống An Vui) | 4491 | Chubb | Chubb Việt Nam | Đóng phí định kỳ hàng tháng (3k/tháng hoặc 5k/tháng). Hủy trong 14-15 ngày đầu được hoàn 100% phí (Freelook). Quá hạn đóng phí 8 ngày tự động hủy. |
| | BH sống tự tin (Confidence Living) | 4015 | Fuse | GIC | Embedded opt-in trong thanh toán Hóa đơn trả khoản vay (Credit Loan). Hủy hoàn phí trong vòng 3 ngày nếu chưa phát sinh khiếu nại. |
| | BH màn hình điện thoại (Cracked Screen) | 3394 | Igloo | PVI | Embedded opt-in trong luồng mua thẻ điện thoại. Yêu cầu chụp ảnh IMEI nền sáng để kích hoạt. Hủy hoàn phí trong 24h (chịu phí hoàn 1.100đ). |
| | BH học đường vui khỏe (Happy Edu) | 4041 | Fuse | GIC | Embedded opt-in trong thanh toán Học phí. Hủy hoàn phí trong vòng 3 ngày nếu chưa phát sinh tổn thất. |
| | BH sức khỏe tích lũy (Health Accumulate) | 4042 | Fuse | Bảo Long | Embedded trong Telco trả sau (Postpaid). Không áp dụng hoàn phí, chỉ hỗ trợ chấm dứt hợp đồng. |
| **Collection (Thu hộ phí)** | Thu phí bảo hiểm định kỳ | 3232, 3082 | Payoo, Cathay Life | Generali, MetLife, FWD, Cathay Life | Standalone tra cứu nợ phí theo mã hợp đồng. Chỉ hỗ trợ thanh toán, không hoàn hủy qua ví. |

---

### 2.2 Chi tiết Nghiệp vụ & Product Requirement từng Sản phẩm

#### 1. Bảo hiểm Người thanh toán (Payer Protection) - Saladin x Bảo Việt (App ID 2390)
* **Kịch bản phân phối (Embedded opt-in)**: Đề xuất mua kèm ngay tại màn hình thanh toán hóa đơn tiêu dùng.
* **Quy tắc tính phí bảo hiểm**:
  * **Hóa đơn Điện & Nước**: Phí bảo hiểm tính bằng **1% giá trị hóa đơn** thanh toán thực tế (Ví dụ: hóa đơn 1.000.000đ thì phí là 10.000đ).
  * **Hóa đơn Internet & Truyền hình**: Phí cố định **2.000đ/giao dịch**.
  * **Hóa đơn Học phí (Edu) & Khoản vay (CF)**: Phí cố định **10.000đ/giao dịch**.
* **Quyền lợi chính**:
  * Trường hợp Người được bảo hiểm bị tử vong hoặc thương tật toàn bộ vĩnh viễn do tai nạn: Bảo hiểm chi trả số tiền gấp 100 lần giá trị hóa đơn (đối với Điện & Nước) hoặc chi trả theo hạn mức gói cố định.
  * Hỗ trợ chi phí y tế điều trị nội/ngoại trú và trợ cấp nằm viện do tai nạn.
* **Chính sách Hoàn/Hủy**: **Không áp dụng hoàn/hủy**. Hiệu lực đơn hàng bắt đầu ngay khi giao dịch thanh toán thành công và kéo dài trong vòng 1 tháng.

#### 2. Bảo hiểm Sống An Vui (Bill Protection) - Chubb x Chubb Việt Nam (App ID 4491)
* **Kịch bản phân phối (Auto Debit Subscription)**: Đề xuất đóng phí định kỳ hàng tháng thông qua trích nợ tự động ví Zalopay hoặc tài khoản liên kết (Auto Debit Oneflow).
* **Danh mục SKUs & Biểu phí**:
  * **SKU 10001 (Gói 3.000đ/tháng)**: Quyền lợi tai nạn 15 triệu + Quà tặng 3 tháng tư vấn sức khỏe tâm lý và giải tỏa stress từ chuyên gia Teledoc (trả về coupon code khi mua thành công).
  * **SKU 10002 (Gói 3.000đ/tháng)**: Quyền lợi tai nạn 15 triệu (Không kèm quà tặng Teledoc).
  * **SKU 10003 (Gói 5.000đ/tháng)**: Quyền lợi tai nạn 30 triệu + Trợ cấp nằm viện đến 7 ngày + Quà tặng 3 tháng tư vấn tâm lý Teledoc.
  * **SKU 10004 (Gói 5.000đ/tháng)**: Quyền lợi tai nạn 30 triệu + Trợ cấp nằm viện đến 7 ngày (Không kèm quà tặng Teledoc).
* **Quy tắc chu kỳ & Hiệu lực**:
  * **Kỳ đầu tiên (Tháng 1)**: Bắt đầu ngay khi mua thành công (Coverage Start Date = Ngày T; Coverage End Date = Ngày T + 1 tháng).
  * **Freelook 14-15 ngày đầu**: Khách hàng được quyền hủy hợp đồng trong vòng 14 ngày kể từ ngày thanh toán kỳ 1 để nhận lại **100% phí bảo hiểm** (Ops hoàn thủ công qua Merchant Tool). Nếu hủy sau 14 ngày đầu, Chubb không hoàn phí và hợp đồng có hiệu lực đến hết kỳ.
  * **Kỳ tiếp theo (Tháng 2 - 12)**: Hệ thống tự động trích nợ (Auto Pay) từ ngày hết kỳ cũ (`Coverage End Date`) đến hạn thanh toán (`Payment Due Date = Coverage End Date kỳ trước + 7 ngày`).
  * **Wording & Cảnh báo trích nợ**:
    * **T-1 (19:00 PM)**: Bắn tin nhắn nhắc nhở: *"Đã đến kỳ thanh toán tự động bảo hiểm Sống An Vui..."* để khách hàng chuẩn bị số dư ví.
    * **Auto Pay thất bại do thiếu số dư**: Gửi thông báo: *"Thanh toán tự động... thất bại do không đủ tiền"* và chuyển sang thời gian gia hạn 7 ngày đóng phí thủ công.
    * **Quá hạn thanh toán (D8)**: Lúc **00h01 ngày thứ 8** (Payment Due date + 1 ngày), hệ thống tự động chấm dứt hợp đồng (Terminated/Cancelled). Reset giao diện về trạng thái chưa mua để khách hàng đăng ký lại từ đầu.
* **Độ tuổi tham gia**: Từ 18 đến 65 tuổi. Mỗi khách hàng chỉ được tham gia tối đa 1 hợp đồng Sống An Vui có hiệu lực tại một thời điểm.

#### 3. Bảo hiểm An ninh mạng (Cyber Risk) - VBI x VBI (App ID 3682)
* **Kịch bản phân phối**: Bán kèm (Embedded opt-in) trong luồng Nạp điện thoại (Telco Topup), Mua thẻ điện thoại hoặc Chuyển tiền P2P (chỉ hiển thị đề xuất cho người dùng đã bật nhận tiền chuyển vào Số dư sinh lời).
* **Danh mục SKUs & Hạn mức**:
  * **Gói Tháng (5.000đ/lần)**: Quyền lợi bảo vệ tài khoản ví 10 triệu/vụ (tối đa 25 triệu/năm) + Tử vong/thương tật vĩnh viễn do tai nạn đến 10 triệu. Hiệu lực 1 tháng.
  * **Gói Năm (3.000đ/kỳ - 12 kỳ đóng phí)**: Tổng phí 36.000đ/năm. Quyền lợi bảo vệ tài khoản ví 10 triệu/vụ (tối đa 50 triệu/năm) + Tử vong/thương tật vĩnh viễn do tai nạn đến 10 triệu. Đóng phí hàng tháng qua Auto Debit.
* **Chương trình khuyến mãi & Trích nợ tự động**:
  * **Khuyến mãi Lần đầu (Free trial)**: Miễn phí 100% phí kỳ thanh toán đầu tiên (kỳ 1 giảm từ 3.000đ còn 0đ) cho khách hàng chưa từng mua sản phẩm này và không nằm trong blacklist rủi ro hệ thống.
  * **Đăng ký Auto Debit**: Lịch trích nợ tự động hàng tháng (Ngày T) được đề xuất động:
    * Nếu Ngày đăng ký (Ngày R) < Ngày bắt đầu kỳ tiếp theo (Ngày S = Ngày hết hạn E - 15 ngày) $\rightarrow$ Ngày T = Ngày mua kỳ 1 (Ngày P).
    * Nếu R $\geq$ S $\rightarrow$ Ngày T = Ngày đăng ký + 1 (Ngày R + 1).
    * Lịch chọn ngày T giới hạn từ Ngày Min (R + 1) đến Ngày Max (E - 8 ngày).
  * **Chính sách hoàn hủy**: Đơn bảo hiểm đã được cấp giấy chứng nhận (COI) thì không được hoàn phí dưới mọi hình thức. Gói năm nếu quá hạn thanh toán kỳ tiếp theo mà trích nợ thất bại/không đóng phí thủ công sẽ tự động chấm dứt hiệu lực hợp đồng.

#### 4. Bảo hiểm Màn hình điện thoại (Phone Cracked Screen) - Igloo x PVI (App ID 3394)
* **Kịch bản phân phối**: Bán kèm (Embedded opt-in) trong luồng Mua thẻ điện thoại / Nạp tiền điện thoại.
* **Danh mục SKUs & Phí**:
  * **Gói 1 (7.700đ/tháng)**: Quyền lợi bồi thường tối đa 1.000.000đ.
  * **Gói 2 (12.100đ/tháng)**: Quyền lợi bồi thường tối đa 2.000.000đ.
  * **Gói 3 (17.600đ/tháng)**: Quyền lợi bồi thường tối đa 3.000.000đ.
* **Quy trình xác thực thiết bị (IMEI Verification - Bắt buộc)**:
  * Sau khi thanh toán thành công, khách hàng bắt buộc phải vào Portal của Igloo trong vòng tối đa **30 ngày** để xác thực thiết bị.
  * Thao tác: Bấm `*#06#` để hiển thị mã IMEI của điện thoại đang dùng mua bảo hiểm, chụp ảnh màn hình đó và upload lên Portal của Igloo cùng thông tin cá nhân.
  * **Thời gian chờ (Waiting period)**: 24 giờ kể từ thời điểm xác thực IMEI thành công, khách hàng mới được quyền gửi đơn yêu cầu bồi thường.
* **Quy tắc bồi thường**: Chỉ bồi thường tối đa 1 lần/hợp đồng cho các thiệt hại vật lý (nứt, vỡ màn hình do va đập) tại các trung tâm sửa chữa chính hãng/đối tác của Igloo toàn quốc. Yêu cầu bồi thường phải gửi trong vòng 3 ngày kể từ ngày xảy ra sự cố.
* **Chính sách Hoàn/Hủy (Freelook & Cancellation)**:
  - Hủy trong vòng 48 giờ kể từ lúc mua (nếu chưa xác thực thiết bị): Hoàn phí 100% về ví Zalopay (chịu phí xử lý giao dịch 1.100đ, tự động khấu trừ vào tiền hoàn).
  - Hủy sau 48 giờ: Hoàn lại 70% phí bảo hiểm tính trên số ngày còn lại của hợp đồng, chịu phí hoàn 1.100đ. Khách hàng liên hệ tổng đài Igloo (Hotline: 024 6657 9884 / Email: hotro@iglooinsure.com) hoặc PVI để yêu cầu hủy, hoàn tiền trong vòng 72 giờ.

#### 5. Bảo hiểm Chăm sóc sức khỏe MiniHealth MSIG (App ID 3951 / 305029879)
* **Kịch bản phân phối**: Phân phối độc lập (Standalone) trên Hub bảo hiểm Zalopay.
* **Mạng lưới đối tác liên kết**:
  * **MSIG Việt Nam**: Nhà bảo hiểm gốc cấp đơn và bảo an.
  * **Fullerton Health**: Đơn vị cung cấp mạng lưới bác sĩ và dịch vụ khám chữa bệnh/tư vấn trực tuyến (Telemedicine) 24/7.
  * **Pharmacity**: Hệ thống nhà thuốc đối tác xử lý bồi thường/bảo lãnh thuốc trực tiếp và giao thuốc tận nơi (Free Ship).
* **Danh mục các gói bảo hiểm & Biểu phí**:
  * **Gói 1 (Cơ bản - Basic)**: Phí **577.000 VNĐ/năm** (~2.000 VNĐ/ngày). Tổng hạn mức bảo vệ: **20.000.000 VNĐ/năm**. Hạn mức ngoại trú: 2.000.000 VNĐ/năm. Bảo lãnh thuốc trực tiếp tại Pharmacity: 500.000 VNĐ/lần.
  * **Gói 2 (Tiêu chuẩn - Standard)**: Phí **1.189.000 VNĐ/năm**. Tổng hạn mức bảo vệ: **50.000.000 VNĐ/năm**. Hạn mức ngoại trú: 5.000.000 VNĐ/năm. Bảo lãnh thuốc trực tiếp tại Pharmacity: 1.000.000 VNĐ/lần.
  * **Gói 3 (Nâng cao - Advanced)**: Phí **1.645.000 VNĐ/năm**. Tổng hạn mức bảo vệ: **70.000.000 VNĐ/năm**. Hạn mức ngoại trú: 10.000.000 VNĐ/năm. Bảo lãnh thuốc trực tiếp tại Pharmacity: 1.500.000 VNĐ/lần.
* **Quy tắc sản phẩm đặc thù**:
  - Hỗ trợ trẻ em tham gia bảo hiểm độc lập (không bắt buộc mua kèm bố mẹ như các loại bảo hiểm sức khỏe truyền thống).
  - Không áp dụng đồng bảo hiểm (khách hàng không phải chi trả thêm % chi phí khi khám đúng tuyến/quy định).
  - Khám online 24/7 với bác sĩ chuyên khoa qua Fullerton. Đơn thuốc điện tử xuất trực tiếp trên hệ thống để tự động bảo lãnh tại Pharmacity và giao tận tay.

#### 6. Bảo hiểm Học đường vui khỏe (Happy Edu) - Fuse x GIC (App ID 4041)
* **Kịch bản phân phối**: Bán kèm (Embedded opt-in) trong luồng thanh toán hóa đơn Học phí.
* **Biểu phí**: Gói trung cấp **10.000đ/tháng** (chu kỳ 6 tháng hoặc 12 tháng).
* **Quy tắc xác định điều kiện học sinh (Eligibility check)**:
  * Để đáp ứng yêu cầu của nhà bảo hiểm GIC (chỉ bán cho học sinh từ 6 tuổi trở lên), Ares backend thực hiện thuật toán lọc đối tượng thanh toán hóa đơn như sau:
    1. **Kiểm tra Ngày sinh (DOB)**: Nếu `Năm sinh của học sinh <= Năm hiện tại - 6` (ví dụ từ năm 2018 trở về trước) $\rightarrow$ Đạt điều kiện.
    2. **Kiểm tra Tên lớp (Classname)**: Nếu DOB trống, phân tích text tên lớp. Nếu chứa các chữ số từ lớp 1 đến lớp 12 (hoặc dạng chữ Một, Hai... Mười hai) $\rightarrow$ Đạt điều kiện.
    3. **Kiểm tra Tên trường (Schoolname)**: Nếu tên lớp trống, phân tích tên trường học. Nếu chứa các từ khóa chỉ cấp học: Tiểu học (TH), THCS, THPT, PTLC, GDTX, Cao đẳng (CĐ), Đại học (ĐH)... $\rightarrow$ Đạt điều kiện.
    4. Nếu tất cả các trường dữ liệu trên không xác định được hoặc không thỏa mãn điều kiện tuổi đi học $\geq 6$, hệ thống sẽ ẩn component đề xuất bảo hiểm.
* **Quyền lợi bảo hiểm chính**:
  * Nằm viện điều trị nội trú do bệnh học đường cấp tính (hô hấp, đường ruột, sốt nhiệt đới): 200.000đ/ngày, tối đa 5.000.000đ/năm.
  * Chi phí điều trị y tế do ngộ độc thực phẩm: tối đa 1.500.000đ.
  * Chi phí điều trị y tế do tai nạn: tối đa 1.500.000đ.
  * Nằm viện >60 ngày do tai nạn/bệnh tật: Bồi thường 200% học phí đã thanh toán (tối đa 10.000.000đ).
  * Hỗ trợ chuyển trường hoặc đóng cửa trường do bạo lực học đường thể chất: tối đa 5.000.000đ (điều trị y tế do bạo lực thể chất) và hỗ trợ gián đoạn học tập tối đa 1.000.000đ.
* **Chính sách Hoàn/Hủy**: Được yêu cầu hủy đơn và hoàn phí 100% trong vòng **3 ngày kể từ ngày thanh toán kỳ đầu tiên thành công và chưa phát sinh tổn thất**. Các lần đóng phí gia hạn cho kỳ sau sẽ không được áp dụng yêu cầu hủy hoàn phí.

#### 7. Bảo hiểm Sức khỏe tích lũy (Health Accumulate) - Fuse x Bảo Long (App ID 4042)
* **Kịch bản phân phối**: Bán kèm (Embedded opt-in) trong luồng thanh toán hóa đơn điện thoại trả sau (Postpaid Telco).
* **Phương thức tích lũy quyền lợi**:
  * Khách hàng đóng phí nhỏ **2.400đ/giao dịch** hóa đơn. Mỗi lần đóng phí, hạn mức bồi thường của hợp đồng sẽ được cộng dồn tích lũy. Tích lũy tối đa 200 giao dịch để đạt quyền lợi tối đa của năm.
* **Quyền lợi bảo hiểm**:
  * Chi trả chi phí điều trị khi mắc lần đầu các bệnh văn phòng: Thoát vị đĩa đệm, sốt xuất huyết, bệnh trĩ cần can thiệp ngoại khoa, hội chứng ống cổ tay, giãn tĩnh mạch. Hạn mức chi trả tối đa lên đến 20.000.000đ/năm.
  * Trợ cấp nằm viện do tai nạn (từ ngày thứ 3): 300.000đ/ngày (khi đã tích lũy từ 6 giao dịch đóng phí trở lên), tối đa 7 ngày/năm.
* **Cam kết & Ràng buộc**:
  * Khi đăng ký giao dịch đầu tiên (mở hợp đồng), khách hàng bắt buộc phải tick chọn ô cam kết sức khỏe trên UI: Chưa từng điều trị/chẩn đoán các bệnh lý trên trong vòng 6 tháng gần nhất và không bị thương tật vĩnh viễn $\geq 50\%$. Các giao dịch nạp tiền bổ sung sau đó không cần hiển thị lại câu cam kết này.
  * **Chính sách hoàn hủy**: Sản phẩm không hỗ trợ hoàn lại số phí tích lũy đã đóng. Khách hàng có thể liên hệ CS của Fuse để hủy/chấm dứt hợp đồng bảo hiểm trước thời hạn, nhưng phí bảo hiểm sẽ không được hoàn trả.

#### 8. Bảo hiểm Du lịch & Trễ hủy chuyến bay (Travel & Flight Delay) - Saladin x Bảo Việt / Chubb (App ID 3274, 3834)
* **Kịch bản phân phối**: Bán kèm embedded (opt-out hoặc opt-in tùy chiến dịch) trong luồng đặt vé máy bay (Flight) hoặc vé xe bus (Bus) trên Zalopay.
* **Chi tiết dòng sản phẩm**:
  * **Bảo hiểm trễ/hủy chuyến & hỏng hành lý (Saladin - App ID 3274)**:
    * *Phí bảo hiểm*: Trễ/hủy chuyến: 30.000đ/1 chiều, 60.000đ/khứ hồi. Hành lý hỏng/mất: 15.000đ/1 chiều, 30.000đ/khứ hồi.
    * *Quyền lợi*: Chi trả khi chuyến bay bị trễ trên 2 giờ liên tiếp hoặc bị hãng hàng không hủy chuyến; bồi thường khi hành lý ký gửi bị mất hoặc hư hỏng.
    * *Hủy hoàn phí*: Yêu cầu hủy và hoàn phí phải được thực hiện **trước giờ khởi hành theo lịch trình ít nhất 3 giờ**. Khách hàng liên hệ CS Zalopay để chuyển tiếp email yêu cầu sang Saladin xử lý hoàn tiền trong 24h.
  * **Bảo hiểm chuyến đi xe Bus (Saladin - App ID 3676)**:
    * *Phí bảo hiểm*: 10.000đ hoặc 20.000đ/chuyến.
    * *Quyền lợi*: Rủi ro tai nạn xảy ra từ lúc lên xe đến khi xuống xe. Hoàn tiền vé xe do các nguyên nhân bất khả kháng (thiên tai, bạo loạn, người thân nhập viện...) mà không có chuyến thay thế trong 6 giờ.
    * *Hủy hoàn phí*: Yêu cầu hủy thực hiện **trước giờ xe khởi hành**.
  * **Bảo hiểm du lịch quốc nội/quốc tế (Chubb - App ID 3834)**:
    * *Phí bảo hiểm*: Tính lũy tiến theo số ngày đi và phạm vi lãnh thổ (Đông Nam Á, Châu Á, Toàn cầu).
    * *Quyền lợi*: Tai nạn cá nhân, chi phí y tế khẩn cấp, cứu trợ y tế khẩn cấp toàn cầu 24/7 (Hotline Chubb Assistant: +84 28 3822 8779), trễ/hủy chuyến đi.
    * *Hủy hoàn phí*: Không cho hủy hoàn phí sau khi đã thanh toán thành công, ngoại trừ trường hợp bị từ chối cấp thị thực (Visa) đối với các chuyến du lịch nước ngoài và thông báo cho Chubb trước giờ khởi hành dự kiến.

#### 9. Bảo hiểm Xe máy & Ô tô bắt buộc (Compulsory Motor Liability) - SaveMoney/Saladin (App ID 1020, 3951, 4326, 3507)
* **Kịch bản phân phối**: Bán độc lập (Standalone) trên Hub bảo hiểm Zalopay hoặc bán kèm trong các luồng thanh toán khác.
* **Chi tiết dòng sản phẩm**:
  * **Bảo hiểm xe máy bắt buộc**:
    * *Phí bảo hiểm*: 66.000đ/1 năm, 132.000đ/2 năm, 198.000đ/3 năm (cho xe trên 50cc). Xe dưới 50cc là 60.500đ/năm.
    * *Quyền lợi*: Bồi thường trách nhiệm dân sự đối với bên thứ ba về người (đến 150 triệu đồng/người/vụ) và về tài sản (đến 50 triệu đồng/vụ).
  * **Bảo hiểm ô tô bắt buộc**:
    * *Phí bảo hiểm*: Tra cứu tự động theo biểu phí quy định của Bộ Tài chính dựa vào số chỗ ngồi, mục đích kinh doanh/phi kinh doanh.
* **Chính sách Hoàn/Hủy**: Không áp dụng hoàn/hủy phí theo luật định, trừ trường hợp xe cơ giới bị thu hồi đăng ký hoặc biển số theo quy định của pháp luật.

#### 10. Dịch vụ Thu hộ phí Bảo hiểm (Premium Collection) - Payoo / Cathay (App ID 3232, 3082)
* **Kịch bản phân phối**: Thanh toán hóa đơn (Billing standalone). Khách hàng nhập mã hợp đồng bảo hiểm nhân thọ để tra cứu nợ phí định kỳ và đóng phí.
* **Thông tin cổng kết nối**:
  * **Cổng Payoo (App ID 3232)**: Thu hộ phí bảo hiểm định kỳ cho Generali, MetLife, FWD. Hạn chế nguồn tiền: Chỉ chấp nhận Ví Zalopay, Tài khoản liên kết, và nguồn tiền VietQR (Chặn hoàn toàn nguồn thẻ tín dụng - CC để tuân thủ quy định tài chính).
  * **Cathay Life (App ID 3082)**: Kết nối API trực tiếp để tra cứu nợ phí và đóng phí cho Cathay Life.
* **Chính sách**: Không hỗ trợ hoàn hủy giao dịch thu hộ trên ví Zalopay. Mọi khiếu nại về đóng phí sai lệch khách hàng cần làm việc trực tiếp với nhà bảo hiểm để được ghi nhận/hoàn trả trên hệ thống của họ.

---


---

## 3. Bản đồ tính năng dạng UML Use Case Diagram

Sơ đồ ca sử dụng mô tả các tương tác của Khách hàng (User), Nhân viên vận hành (Admin/Ops) và Hệ thống Ares core đối với các tính năng hiện tại và các tính năng định tuyến/gia hạn:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }, "flowchart": { "curve": "basis" }}}%%
graph TD
    User((Khách hàng Zalopay))
    Admin((Vận hành / CS / Ops))
    Ares((Hệ thống Ares Core))

    subgraph "Các Ca Sử Dụng Phân Phối (Distribution)"
        UC_Standalone(Mua BH Standalone tại Hub)
        UC_Embedded(Mua BH Embedded kèm Hóa đơn/Telco/OTA)
        UC_Autodebit(Đăng ký đóng phí tự động Auto Debit)
        UC_Cancel(Yêu cầu hủy hợp đồng - Freelook/Opt-out)
    end

    subgraph "Các Ca Sử Dụng Thu Hộ (Collection)"
        UC_QueryBill(Tra cứu nợ phí bảo hiểm nhân thọ)
        UC_PayPremium(Thanh toán phí bảo hiểm định kỳ)
    end

    subgraph "Nghiệp vụ Hệ thống (Ares Core)"
        UC_Routing(Định tuyến gói bảo hiểm hiển thị - Routing)
        UC_Deliver(Cấp đơn và Gửi Giấy chứng nhận bảo hiểm)
        UC_AutoRefund(Tự động hoàn tiền khi cấp đơn lỗi - Refund Job)
        UC_ManualRefund(Thao tác hoàn tiền thủ công qua Backoffice)
        UC_Autodebit_Job(Job quét và trích nạp tự động định kỳ)
    end

    User --> UC_Standalone
    User --> UC_Embedded
    User --> UC_Autodebit
    User --> UC_Cancel
    User --> UC_QueryBill
    User --> UC_PayPremium

    Admin --> UC_ManualRefund

    Ares --> UC_Routing
    Ares --> UC_Deliver
    Ares --> UC_AutoRefund
    Ares --> UC_Autodebit_Job

    UC_Embedded -.->|includes| UC_Routing
    UC_Deliver -.->|fails| UC_AutoRefund
```

---

## 4. Quy trình Nghiệp vụ Chi tiết (Core Workflows)

### 4.1 Vòng đời Trạng thái Đơn hàng (Order State Machine Diagram)

Quy trình quản lý trạng thái của một đơn hàng bảo hiểm trong hệ thống `ares` được biểu diễn qua sơ đồ trạng thái dưới đây:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
stateDiagram-v2
    [*] --> Created : Khởi tạo đơn hàng (OrderStatusCreated = 5)
    
    Created --> PaymentSuccess : Thanh toán thành công (OrderStatusPaymentSuccess = 6)
    Created --> Created : Lỗi thanh toán / Hủy (Hợp đồng bị treo/hủy)
    
    PaymentSuccess --> DeliverProcessing : Đang cấp đơn tại đối tác (OrderStatusDeliverProcessing = 7)
    
    DeliverProcessing --> DeliverSuccess : Đối tác xác nhận cấp đơn thành công (OrderStatusDeliverSuccess = 1)
    
    DeliverProcessing --> DeliverFailed : Đối tác báo lỗi / Timeout hết lượt retry (OrderStatusDeliverFailed = -401)

    PaymentSuccess --> DeliverSuccess : Cấp đơn đồng bộ thành công lập tức
    PaymentSuccess --> DeliverFailed : Đối tác báo lỗi trực tiếp không retry
    
    PaymentSuccess --> DeliverManualCheck : Có sự cố lấp lửng (OrderStatusDeliverManualCheck = -400)

    DeliverProcessing --> DeliverManualCheck : Lỗi kết nối / Hết lượt kiểm tra tự động
    
    DeliverFailed --> Refunded : Hoàn tiền thành công cho khách hàng
    DeliverManualCheck --> DeliverSuccess : Ops cập nhật trạng thái thủ công thành công
    DeliverManualCheck --> DeliverFailed : Ops cập nhật trạng thái thất bại -> Kích hoạt hoàn tiền
    
    DeliverSuccess --> [*]
    Refunded --> [*]
```

#### Chi tiết hành vi xử lý chuyển đổi trạng thái:

| Hướng chuyển đổi (Transition) | Tác nhân & Hành vi chi tiết của hệ thống Ares |
| :--- | :--- |
| **PaymentSuccess** $\rightarrow$ **DeliverProcessing** | Ares gọi API Deliver sang Provider. Nếu nhận mã phản hồi trì hoãn (`DeliverCodeWaitForGetStatus = 7`), Ares cập nhật trạng thái đơn hàng thành `DeliverProcessing` và đẩy thông tin vào delay-queue của RabbitMQ để kiểm tra trạng thái sau. |
| **DeliverProcessing** $\rightarrow$ **DeliverFailed** | Khi Provider phản hồi lỗi cấp đơn hoặc đã hết số lượt retry tối đa (Timeout) mà vẫn không nhận được phản hồi thành công, Ares cập nhật trạng thái đơn hàng thành `DeliverFailed` và đẩy lệnh vào queue tự động hoàn phí cho khách hàng. |
| **PaymentSuccess** $\rightarrow$ **DeliverManualCheck** | Khi gặp lỗi kết nối (Network timeout/Connection refused) hoặc nhận mã lỗi chưa xác định từ Provider, Ares chuyển trạng thái đơn hàng sang `DeliverManualCheck`. Đơn hàng được giữ nguyên trạng thái lấp lửng này để bộ phận vận hành (Ops) kiểm tra thủ công với Provider, tránh hoàn tiền sai lệch. |


### 4.2 Luồng mua bảo hiểm Embedded & Delivery (DeliverV1 Service)
Quy trình cấp đơn bảo hiểm bất đồng bộ sau khi thanh toán thành công qua backend Ares:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
sequenceDiagram
    autonumber
    participant User as Khách hàng
    participant Cashier as Cổng Cashier / PE
    participant Ares as Ares Service (deliver.go)
    participant Redis as Redis Cache
    participant DB as MySQL DB (History & Log)
    participant Queue as RabbitMQ Broker
    participant Partner as Provider API (Client)

    Cashier->>Ares: Callback báo thanh toán thành công (app_id, order_id)
    
    rect rgb(240, 248, 255)
        Note over Ares: Xử lý an toàn luồng giao dịch
        Ares->>Redis: Lock đơn hàng (LockOrderMutex: app_id + order_id)
        Ares->>Redis: Lấy thông tin đơn hàng từ Cache
        Ares->>DB: Đọc thông tin đơn hàng gốc (Kiểm tra status == PaymentSuccess)
        Ares->>Redis: Cập nhật status đơn hàng sang DeliverManualCheck (Trạng thái an toàn)
    end
    
    Ares->>Partner: Gọi API Deliver mua tài sản bảo hiểm (DeliverRequest)
    
    alt Đối tác phản hồi THÀNH CÔNG (DeliverCodeSuccess = 1)
        Partner-->>Ares: Trả thông tin Policy ID & Link Giấy chứng nhận (COI)
        Ares->>Redis: Cập nhật trạng thái = DeliverSuccess
        Ares->>DB: Ghi nhận đơn hàng thành công (Lưu trữ Policy & URL)
        Ares->>Queue: EnqueueFinalOrderBackOffice (Đẩy sang hệ thống Backoffice)
        Ares-->>Cashier: Phản hồi thành công
        Ares-->>User: Hiển thị màn hình mua bảo hiểm thành công + Link GCNBH
    
    else Đối tác phản hồi CHỜ XỬ LÝ (DeliverCodeWaitForGetStatus = 7)
        Partner-->>Ares: Trả mã trạng thái chờ duyệt (Pending / Processing)
        Ares->>Redis: Cập nhật trạng thái = DeliverProcessing
        Ares->>Queue: Đẩy command GetDeliverStatus vào delay-queue (ví dụ 60s)
        Ares-->>Cashier: Phản hồi đang xử lý
        Ares-->>User: Hiển thị trạng thái "Đang cấp đơn bảo hiểm"
    
    else Đối tác phản hồi THẤT BẠI (DeliverCodeFail = -401)
        Partner-->>Ares: Trả mã lỗi từ chối cấp đơn
        Ares->>Redis: Cập nhật trạng thái = DeliverFailed
        Ares->>Queue: Đẩy lệnh hoàn tiền vào Queue (EnqueueRefundOrder)
        Ares-->>Cashier: Phản hồi đơn hàng thất bại
        Ares-->>User: Hiển thị đơn hàng lỗi và thông báo hoàn tiền ví
    
    else Lỗi kết nối / Phản hồi không xác định (DeliverCodeManualCheck = -400)
        Ares->>Redis: Giữ nguyên trạng thái = DeliverManualCheck
        Note over Ares, DB: Không tự động hoàn tiền, lưu vết chờ Ops kiểm tra
        Ares-->>Cashier: Phản hồi lỗi hệ thống
    end
    
    Ares->>Redis: Giải phóng khóa (UnlockOrderMutex)
```

---

### 4.3 Luồng gia hạn tự động & Auto Debit Oneflow (Chubb Sống An Vui)
Sản phẩm **Bảo hiểm Sống An Vui của Chubb (App ID 4491)** đóng vai trò tiêu biểu cho luồng đóng phí tự động hàng tháng duy trì hợp đồng năm.

#### 4.3.1 Quy tắc chu kỳ hoạt động và hiệu lực
* **Chu kỳ hợp đồng**: Cấp theo năm. Phí bảo hiểm được thu hàng tháng (3.000đ hoặc 5.000đ) liên tục 12 tháng để bảo toàn hiệu lực cả năm.
* **Thời gian cân nhắc (Freelook 14-15 ngày)**: Khách hàng có quyền hủy hợp đồng trong vòng 14 ngày tính từ ngày thanh toán kỳ đầu tiên (ngày hiệu lực chính thức D1). Nếu hủy trong giai đoạn này, tiền phí sẽ được hoàn trả 100% về ví qua xử lý thủ công của Chubb Ops trên công cụ Merchant Tool.
* **Hạn đóng phí hàng tháng (Due date)**: Từ tháng thứ 2 trở đi, khách hàng phải thanh toán trong vòng 7 ngày kể từ ngày kết thúc kỳ bảo vệ trước đó (Payment Due date = Coverage End Date + 7 ngày).
* **Quy tắc đứt hiệu lực (Cutoff)**: Vào lúc **00h01 ngày thứ 8** sau khi hết hạn kỳ bảo vệ trước đó (Payment Due date + 1 ngày), nếu hệ thống không trích nợ tự động thành công hoặc khách hàng không đóng phí tự động/thủ công, hợp đồng sẽ **tự động chấm dứt hiệu lực (Terminated/Cancelled)**.

#### 4.3.2 Kịch bản Auto Pay và Thông báo (Wording & Alerts)
Nhằm tăng tỷ lệ giữ chân khách hàng (Retention), hệ thống Ares cấu hình tự động trích nạp kết hợp gửi tin nhắn nhắc nhở qua ZNS/ZPN theo các mốc cụ thể:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }, "flowchart": { "curve": "basis" }}}%%
graph TD
    T_1[Ngày T-1: Trước kỳ trích nợ 1 ngày] -->|19:00 PM| Alert_T1[Gửi thông báo nhắc nhở đóng phí <br> 'Đã đến kỳ thanh toán tự động...']
    Alert_T1 --> Check_Balance{Ví Zalopay đủ tiền?}

    Check_Balance -->|Đủ tiền| Auto_Pay[Ngày T: Trích nợ tự động thành công]
    Auto_Pay --> Alert_Success[Gửi thông báo thành công <br> 'Thanh toán tự động... thành công']
    Auto_Pay --> Update_Policy[Gia hạn hợp đồng thêm 1 tháng]

    Check_Balance -->|Không đủ tiền| Auto_Pay_Fail[Ngày T: Trích nợ thất bại]
    Auto_Pay_Fail --> Alert_Fail[Gửi thông báo nạp tiền <br> 'Thanh toán tự động... thất bại do không đủ tiền']
    Auto_Pay_Fail --> Retry_Period[Bắt đầu thời gian gia hạn 7 ngày đóng phí thủ công]

    Retry_Period -->|Thanh toán thành công trước D8| Update_Policy
    Retry_Period -->|Không đóng tiền đến hết D7| Cancel_Policy[00:01 Ngày D8: Hủy hợp đồng tự động]
    Cancel_Policy --> Alert_Cancel[Gửi thông báo chấm dứt hiệu lực bảo hiểm]
```

* **Thông báo T-1**:
  * *Tiêu đề*: Đã đến kỳ thanh toán tự động bảo hiểm Sống An Vui.
  * *Nội dung*: Hợp đồng XXXXXXXXXX sẽ được đóng phí tự động Y.YYYđ vào ngày mai dd/mm/yy. Bạn hãy đảm bảo số dư ví để giao dịch thành công nhé!
  * *CTA*: Nạp tiền vào Ví.
* **Thông báo thất bại do thiếu tiền**:
  * *Tiêu đề*: Thanh toán tự động bảo hiểm Sống An Vui thất bại.
  * *Nội dung*: Thanh toán thất bại vì Ví Zalopay không đủ tiền. Nạp tiền vào Ví và thanh toán lại nhé.
* **Thông báo thành công**:
  * *Tiêu đề*: Thanh toán tự động bảo hiểm Sống An Vui thành công.
  * *Nội dung*: Hợp đồng XXXXXXXXXX đã được nạp tự động Y.YYYđ.
* **Thông báo hoàn tất 12 kỳ**:
  * *Tiêu đề*: Bạn đã thanh toán đủ 12 kỳ của hợp đồng bảo hiểm Sống An Vui.
  * *Nội dung*: Hợp đồng XXXXXXXXXX có hiệu lực bảo vệ trọn vẹn đến ngày DD/MM/YYYY.

---

### 4.4 Luồng Cross-selling P2P MoneyTransfer x VBI
Đây là tính năng tích hợp bán chéo bảo hiểm an ninh mạng VBI (App ID 3682, Supplier ID 12) ngay khi người dùng thực hiện chuyển tiền P2P. Hệ thống hỗ trợ 2 kịch bản xử lý:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
sequenceDiagram
    autonumber
    participant User as Khách hàng
    participant ZApp as Zalopay Client
    participant AutoDebit as Autodebit Management
    participant Worker as Telco/Autodebit Worker
    participant Ares as Ares Core (Go)
    participant Provider as VBI Partner API

    User->>ZApp: Thực hiện chuyển tiền P2P + Tích chọn mua bảo hiểm an ninh mạng
    ZApp->>AutoDebit: POST /app/binding (Khởi tạo binding mua tự động)
    AutoDebit-->>ZApp: Trả về binding_id
    ZApp->>ZApp: Xác thực mã PIN & Submit giao dịch chuyển tiền chính
    Note over ZApp: Giao dịch chuyển tiền thành công
    AutoDebit->>Worker: Dispatch sự kiện đăng ký thành công thỏa thuận (Agreement & Binding)
    Worker->>Ares: Gọi QueryBill (supplier_id = 12)
    Ares->>Provider: QueryBill sang đối tác VBI
    Provider-->>Ares: Trả thông tin hóa đơn phí bảo hiểm

    alt PayNow flag = true
        Worker->>Ares: Lấy danh sách hợp đồng (zalopay_id, supplier_id = 12)
        Ares-->>Worker: Trả về danh sách hợp đồng
        Worker->>Worker: Kiểm tra nếu người dùng chưa có hợp đồng VBI nào (FirstUser)
        alt IsFirstUser = true
            Worker->>Ares: Gọi Deliver cấp đơn
            Ares->>Provider: Deliver cấp đơn
            Provider-->>Ares: Trả về kết quả cấp đơn thành công (GCNBH)
            Ares-->>Worker: Trả về kết quả cấp đơn thành công
            Worker->>Worker: Hoàn tất luồng PayNow cấp đơn tức thì
        else IsFirstUser = false
            Worker->>Worker: Bỏ qua / từ chối luồng PayNow cấp đơn tức thì
        end
    else PayNow flag = false
        Worker->>Worker: Tiếp tục luồng xử lý thông thường
        Worker->>Ares: Tạo đơn hàng bảo hiểm (Create order)
        Ares-->>Worker: Trả về order_token
        Worker->>AutoDebit: Gọi submitPay(order_token)
        AutoDebit->>Ares: Thực hiện trích nợ ví tự động qua AgreementPay
        Ares-->>Worker: Trả kết quả thanh toán thành công
        Worker->>Ares: Gọi Deliver cấp đơn
        Ares->>Provider: Deliver cấp đơn
        Provider-->>Ares: Trả về kết quả cấp đơn (GCNBH)
        Ares-->>Worker: Kết quả cấp đơn thành công
    end
    Worker-->>User: Gửi thông báo cấp đơn thành công
```

* **Cơ chế PayNow**: Chỉ áp dụng cho người dùng lần đầu mua (FirstUser) và được kích hoạt qua cờ cấu hình `PayNow flag = true`. Luồng này bỏ qua bước tạo hóa đơn thanh toán kỳ 1 trên Ares và thực hiện gọi cấp đơn tức thời sang đối tác, giúp giảm thiểu rủi ro lỗi thanh toán lúc khởi tạo luồng ([329207148_MoneyTransfer x VBI.md:L140-L155](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Technical%20Page/329207148_MoneyTransfer%20x%20VBI.md#L140-L155)).

### 4.5 Luồng thu hộ phí bảo hiểm nhân thọ (Collection Premium Payment Sequence)
Quy trình tra cứu nợ phí định kỳ và thực hiện thanh toán phí bảo hiểm nhân thọ của các đối tác thông qua Ares kết nối cổng trung gian hoặc trực tiếp:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
sequenceDiagram
    autonumber
    participant User as Khách hàng
    participant UI as Giao diện Thu hộ phí
    participant Ares as Ares Core (Go)
    participant Partner as Cổng Payoo / Cathay Life
    participant Pay as Cổng Thanh toán Cashier
    participant DB as MySQL / Bill Storage

    User->>UI: Nhập mã khách hàng / số hợp đồng bảo hiểm
    UI->>Ares: Gửi yêu cầu tra cứu hóa đơn (QueryBill)
    Ares->>Partner: Forward yêu cầu tra cứu nợ phí bảo hiểm
    Partner-->>Ares: Trả thông tin hóa đơn (Số kỳ nợ, số tiền, thông tin khách hàng)
    Ares-->>UI: Hiển thị hóa đơn nợ phí & quy tắc thanh toán
    User->>UI: Xác nhận thanh toán hóa đơn
    UI->>Ares: Khởi tạo giao dịch đóng phí (Create order)
    Ares->>Pay: Tạo hóa đơn thanh toán trên hệ thống Cashier
    Pay-->>Ares: Callback báo thanh toán thành công
    Ares->>Partner: Gửi yêu cầu gạch nợ (Deliver payment)
    Ares->>DB: Ghi nhận thông tin giao dịch vào Bill Storage & Order History
    Ares-->>UI: Hiển thị màn hình gạch nợ thành công / đang xử lý
```

* **Hạn chế nguồn tiền**: Đối với cổng thu hộ Payoo (App ID 3232), hệ thống kiểm soát chặt chẽ nguồn tiền thanh toán, chỉ chấp nhận Ví Zalopay, Tài khoản liên kết và VietQR. Chặn hoàn toàn thanh toán bằng Thẻ tín dụng (Credit Card) nhằm tuân thủ quy định phòng chống rửa tiền và đầu cơ tín dụng ([230292981_[Insurance] Thông tin Sản phẩm - Đối tác để hỗ trợ CS xử lý ticket.md:L72-L86](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Tho%CC%82ng%20tin%20Sa%CC%83n%20pha%CC%82%CC%89m%20-%20%C4%90o%CC%82́i%20ta%CC%81c%20%C4%91e%CC%82̉%20ho%CC%83%20tro%CC%A3%20CS%20xu%CC%82%CC%81ly%CC%81%20ticket.md#L72-L86)).

---

## 5. Giao diện Người dùng & Các điểm chạm (User Surface Map)

### 5.1 Trang chủ Bảo hiểm (Insurance Hub)
Insurance Hub là điểm 발견 (discovery) trung tâm của sản phẩm bảo hiểm trên Zalopay App, bao gồm hai tab chính:
* **Tab `Mua bảo hiểm`**: Cho phép người dùng duyệt qua danh mục các gói bảo hiểm bắt buộc và tự nguyện, xem các chương trình khuyến mãi/quà tặng ([FE03](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/features/home/GroupTabs/index.tsx#L23)).
* **Tab `Thanh toán phí`**: Nơi người dùng thực hiện đóng phí bảo hiểm nhân thọ định kỳ cho các hợp đồng đã liên kết hoặc tra cứu nợ phí mới ([FE03](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/features/home/GroupTabs/index.tsx#L38)).

### 5.2 Bảo hiểm Nhúng & Bán kèm (Embedded / Cross-Sell)
Component bảo hiểm được tích hợp trực tiếp vào màn hình thanh toán của các dịch vụ host (Hóa đơn, Telco, OTA, P2P Transfer):
1. Khi giao dịch chính tải lên, hệ thống gọi API Ares để kiểm tra tính hợp lệ và cấu hình định tuyến (Routing).
2. Hiển thị box bảo hiểm với trạng thái mặc định (opt-in/opt-out tùy theo kịch bản quy định).
3. Cho phép khách hàng xem chi tiết quyền lợi (CTA Detail) hoặc click vào checkbox để mua kèm.
4. **Giới hạn hiển thị (Exposure Control)**: Email thảo luận thống nhất kịch bản giới hạn hiển thị tối đa 3 lần đối với cùng một người dùng để tránh gây phiền nhiễu khi khách hàng đã liên tục không tích chọn mua ([261513493_Insurance Zone display.md:L10-L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/261513493_Insurance%20Zone%20display.md#L10-L44)).

### 5.3 Trang Quản lý Hợp đồng (Contract Management)
Giao diện quản lý các hợp đồng bảo hiểm đã mua trên Zalopay và danh sách hóa đơn liên kết:
* **Tab `Bảo hiểm trên Zalopay`**: Quản lý các đơn bảo hiểm phi nhân thọ (Cyber, Xe máy, Thiết bị, Sức khỏe MiniHealth) đã mua qua luồng Distribution. Hỗ trợ xem Giấy chứng nhận bảo hiểm trực tuyến (COI link), xem lịch sử trích nợ tự động của các kỳ tiếp theo và yêu cầu hủy hợp đồng đối với các gói có chính sách hoàn hủy ([224783660_Insurance Contract Management.md:L21](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/224783660_Insurance%20Contract%20Management.md#L21)).
* **Tab `Hợp đồng nhân thọ`**: Lưu trữ danh sách mã hợp đồng đóng phí định kỳ của khách hàng (Generali, Cathay, FWD...) giúp tự động truy vấn nợ phí và nhắc nhở đóng tiền mỗi khi đến kỳ hạn thanh toán ([224783660_Insurance Contract Management.md:L38](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/224783660_Insurance%20Contract%20Management.md#L38)).

### 5.4 Chi tiết User Flow & UI từng Sản phẩm Bảo hiểm

Phần này mô tả chi tiết hành trình người dùng (User Flow) và giao diện (UI) thực tế của từng sản phẩm bảo hiểm trên Zalopay, bao gồm các điểm vào (Entry Points), các bước màn hình và hành vi đặc thù.

#### 5.4.1 Bảo hiểm Sống An Vui — Chubb (App ID 4491)

| Thuộc tính | Chi tiết |
|---|---|
| **Loại phân phối** | Embedded (Nhúng trong hóa đơn) + Auto Debit Subscription |
| **Entry Point** | Thanh toán hóa đơn tiêu dùng (Điện, Nước, Internet, Truyền hình) trên Zalopay |
| **Mô hình UI** | Utility box nhúng trực tiếp trong màn hình chi tiết hóa đơn (Bill Detail) |

**Luồng User Flow chi tiết:**
1. **Bước 1 — Bill Detail (Embedded box)**: Người dùng mở màn hình chi tiết hóa đơn (vd: Hóa đơn điện EVN). Phía dưới thông tin hóa đơn hiển thị **box bảo hiểm Sống An Vui** dạng checkbox (mặc định chưa tick). Hiển thị rõ: Tên gói, phí hàng tháng (3.000đ hoặc 5.000đ), và mô tả quyền lợi ngắn gọn.
2. **Bước 2 — Tick chọn mua kèm**: Người dùng tick checkbox → Tổng tiền thanh toán cộng thêm phí bảo hiểm kỳ đầu tiên. Toggle Auto Debit (Đóng phí tự động) hiển thị kèm thông tin: *"Đóng tự động tiện lợi, hủy bất cứ khi nào bạn muốn"*.
3. **Bước 3 — Cashier (Xác nhận thanh toán)**: Màn hình Cashier hiển thị tách bạch rõ ràng: Tiền hóa đơn chính + Tiền bảo hiểm Sống An Vui. Hỗ trợ nhiều phương thức thanh toán (Ví Zalopay, Tài khoản liên kết, VietQR).
4. **Bước 4 — Kết quả**: Giao dịch thành công → Hiển thị thông tin hợp đồng và link xem Giấy chứng nhận bảo hiểm (COI).

#### 5.4.2 Bảo hiểm An ninh mạng — VBI (App ID 3682)

| Thuộc tính | Chi tiết |
|---|---|
| **Loại phân phối** | Embedded + Cross-sell (Telco Topup, Mua thẻ, Chuyển tiền P2P) |
| **Entry Point 1** | Nạp tiền/Mua thẻ điện thoại (Telco) |
| **Entry Point 2** | Chuyển tiền P2P (Money Transfer) |
| **Entry Point 3** | Insurance Hub (Standalone) |
| **Mô hình UI** | Box embedded với hiệu ứng lật chữ (flip animation) hiển thị quyền lợi |

**Luồng User Flow chi tiết:**

**A. Luồng Telco Topup / Mua thẻ:**
1. **Bước 1 — Telco Screen**: Người dùng chọn mệnh giá nạp/mua thẻ. Phía dưới hiển thị **box bảo hiểm an ninh mạng** với animation lật chữ: *"Bảo vệ ví 25tr-50tr / Bảo vệ tai nạn cá nhân 10tr"*.
2. **Bước 2 — Tick chọn**: Người dùng tick checkbox → Tổng tiền cộng thêm 5.000đ (gói tháng) hoặc 3.000đ (gói năm kỳ đầu).
3. **Bước 3 — Cashier**: Xác nhận thanh toán tổng.
4. **Bước 4 — Kết quả**: Cấp đơn thành công → Link GCNBH + Đề xuất đăng ký Auto Debit cho gói năm.

**B. Luồng Chuyển tiền P2P (Cross-sell):**
1. **Bước 1 — Transfer Screen**: Người dùng nhập thông tin chuyển tiền. Box bảo hiểm hiển thị với wording điều chỉnh: *"Bảo vệ tiền trước lừa đảo mạng / Quyền lợi đến 50 triệu"*.
2. **Bước 2 — Tick chọn + Xác nhận PIN**: Giao dịch chuyển tiền chính xử lý trước, bảo hiểm được cấp đơn sau qua luồng Autodebit Worker → Ares → VBI.

#### 5.4.3 Bảo hiểm Du lịch — Chubb Travel (App ID 3834)

| Thuộc tính | Chi tiết |
|---|---|
| **Loại phân phối** | Embedded (Cross-sell trong luồng vé máy bay Flight) |
| **Entry Point** | Đặt vé máy bay nội địa/quốc tế trên Zalopay |
| **Mô hình UI** | Webview đối tác Chubb nhúng trong luồng OTA Flight |

**Luồng User Flow chi tiết:**
1. **Bước 1 — Chọn chuyến bay**: Người dùng tìm kiếm và chọn chuyến bay trên Zalopay OTA.
2. **Bước 2 — Thông tin hành khách**: Nhập thông tin cá nhân hành khách (Họ tên, Ngày sinh, CMND/CCCD).
3. **Bước 3 — Đề xuất bảo hiểm du lịch**: Hiển thị gói bảo hiểm du lịch Chubb với các gói (Trong nước / ĐNA / Châu Á / Toàn cầu). Người dùng có thể chọn mua kèm hoặc bỏ qua.
4. **Bước 4 — Cashier**: Thanh toán vé máy bay + Phí bảo hiểm du lịch (nếu đã chọn).
5. **Bước 5 — Kết quả**: Email/App thông báo cấp đơn thành công kèm link PDF Giấy chứng nhận từ Chubb.

#### 5.4.4 Bảo hiểm Du lịch & Chuyến đi — Saladin Travel (App ID 3274) & Saladin Trip (App ID 3676)

| Thuộc tính | Chi tiết |
|---|---|
| **Loại phân phối** | Embedded opt-out (Travel 3274) / Embedded opt-out (Trip 3676) |
| **Entry Point (3274)** | Đặt vé máy bay nội địa trên Zalopay OTA |
| **Entry Point (3676)** | Đặt vé xe Bus trên Zalopay OTA |
| **Mô hình UI** | Checkbox mặc định bật (opt-out) trong màn hình thông tin chuyến đi |

**Luồng User Flow chi tiết (BH Trễ/Hủy chuyến bay 3274):**
1. **Bước 1 — Chọn vé máy bay**: Người dùng tìm kiếm chuyến bay và chọn chuyến phù hợp.
2. **Bước 2 — Thông tin hành khách + Bảo hiểm**: Màn hình điền thông tin hành khách. Bên dưới hiển thị gói **BH trễ/hủy chuyến & hỏng hành lý** với checkbox mặc định đã tick (opt-out). Phí hiển thị rõ: 30.000đ/1 chiều hoặc 60.000đ/khứ hồi cho trễ/hủy chuyến, 15.000đ/1 chiều hoặc 30.000đ/khứ hồi cho hỏng hành lý.
3. **Bước 3 — Cashier**: Tổng tiền bao gồm vé + bảo hiểm (nếu giữ nguyên tick). Người dùng có thể bỏ tick để loại bảo hiểm.
4. **Bước 4 — Kết quả**: Giao dịch thành công → Thông tin vé + Link GCNBH Saladin/Bảo Việt.

**Luồng User Flow chi tiết (BH Chuyến đi xe Bus 3676):**
1. **Bước 1 — Chọn chuyến xe Bus**: Người dùng chọn tuyến đường, ngày đi và nhà xe.
2. **Bước 2 — Thông tin hành khách + Bảo hiểm**: Hiển thị gói **BH chuyến đi** dạng checkbox mặc định bật. Phí: 10.000đ hoặc 20.000đ/chuyến.
3. **Bước 3 — Cashier**: Thanh toán tổng (vé + bảo hiểm nếu giữ tick).
4. **Bước 4 — Kết quả**: Thông tin vé + GCNBH.

#### 5.4.5 Bảo hiểm Xe máy bắt buộc — SaveMoney Bike (App ID 4326)

| Thuộc tính | Chi tiết |
|---|---|
| **Loại phân phối** | Standalone (Trên Insurance Hub) |
| **Entry Point** | Insurance Hub → Tab Mua bảo hiểm → Mục Xe máy |
| **Mô hình UI** | Webview đối tác SaveMoney nhúng trong Insurance Hub |

**Luồng User Flow chi tiết:**
1. **Bước 1 — Insurance Hub**: Người dùng mở Hub bảo hiểm, chọn danh mục **Xe máy** trong tab "Mua bảo hiểm".
2. **Bước 2 — Webview SaveMoney**: Chuyển sang Webview của SaveMoney. Người dùng nhập thông tin xe (Biển số, Loại xe dưới/trên 50cc), chọn thời hạn bảo hiểm (1 năm / 2 năm / 3 năm), và nhập thông tin chủ xe.
3. **Bước 3 — Chọn nhà bảo hiểm**: Hệ thống hiển thị danh sách nhà bảo hiểm khả dụng (ABIC, VNI, PVI, VBI, Bảo Minh, MIC) và biểu phí tương ứng. Người dùng chọn nhà bảo hiểm ưa thích.
4. **Bước 4 — Cashier Zalopay**: Quay về giao diện Cashier Zalopay để thanh toán. Hiển thị rõ: Tên sản phẩm, Nhà cung cấp SaveMoney, Số tiền phí bảo hiểm.
5. **Bước 5 — Kết quả**: Thanh toán thành công → Giấy chứng nhận bảo hiểm xe máy bắt buộc (PDF) sẵn sàng tải về hoặc xem trực tuyến.

#### 5.4.6 Bảo hiểm Nhà — SaveMoney x PVI (App ID 3935)

| Thuộc tính | Chi tiết |
|---|---|
| **Loại phân phối** | Embedded (Nhúng trong hóa đơn nước) + Standalone (Insurance Hub → Web view) |
| **Entry Point 1** | Thanh toán hóa đơn tiền nước trên Zalopay |
| **Entry Point 2** | Insurance Hub → Tab Mua bảo hiểm → Mục Nhà |
| **Nhà bảo hiểm gốc** | PVI |
| **Mô hình UI** | Checkbox embedded trong Bill Detail (EP1), Webview trên Hub (EP2) |

**Luồng User Flow chi tiết:**

**A. Entry Point 1 — Từ hóa đơn tiền nước (Embedded):**
1. **Bước 1 — Bill Detail (Chi tiết hóa đơn nước)**: Người dùng mở chi tiết hóa đơn tiền nước. Phía dưới phần thông tin khách hàng (Mã KH, Tên KH, Địa chỉ) hiển thị mục **"Dịch vụ bảo hiểm"** dạng checkbox.
2. **Bước 2 — Chọn gói bảo hiểm nhà**: Checkbox **"Bảo hiểm Nhà tư nhân"** hiển thị với phí **10.000đ**. Bên dưới liệt kê các quyền lợi dạng bullet:
   * Bảo vệ tài sản bất động sản tại nơi ở (nhà, vật kiến trúc, trang thiết bị)
   * Bảo vệ nhà tối đa 100.000.000đ
   * Bảo vệ tài sản trong nhà tối đa 50.000.000đ
   * Bảo vệ tài sản cho thuê tối đa 30.000.000đ
   * Từ 1/10 - 31/7 hoàn tiền 5% khi mua thành công
   * Cung cấp bởi: **PVI** × **SaveMoney**
3. **Bước 3 — Tick chọn**: Người dùng tick checkbox → Tổng tiền thanh toán = Tiền hóa đơn nước + 10.000đ phí bảo hiểm.
4. **Bước 4 — Cashier (Xác nhận giao dịch)**: Màn hình **"Xác nhận giao dịch"** hiển thị tách bạch:
   * Phần trên: Thông tin thanh toán tiền nước (Mã KH, Nhà cung cấp nước, Tên KH, Địa chỉ, Phí hóa đơn, Số tiền).
   * Phần dưới: **Bảo hiểm nhà PVI** — Đơn hàng số, Mã hợp đồng, Nhà cung cấp (Bảo hiểm Nhà PVI), Số tiền 10.000đ, Tạm tính, Phí dịch vụ 0đ, Số tiền cuối.
   * Phương thức thanh toán: Ví Zalopay / Tài khoản liên kết.
   * Nút **"Giảm phí nước: Áp dụng thành công"** (badge khuyến mãi giảm phí nước).
5. **Bước 5 — Xác nhận & Kết quả**: Nhấn "Xác nhận" → Thanh toán thành công. GCNBH bảo hiểm nhà PVI sẵn sàng xem.

**B. Entry Point 2 — Từ Insurance Hub (Web view):**
1. Người dùng mở Insurance Hub → Chọn mục **Nhà** → Chuyển sang Webview đối tác SaveMoney để nhập thông tin tài sản và chọn gói bảo hiểm.
2. Hoàn tất nhập liệu → Quay về Cashier Zalopay thanh toán.

#### 5.4.7 Bảo hiểm Màn hình điện thoại — Igloo x PVI (App ID 3394)

| Thuộc tính | Chi tiết |
|---|---|
| **Loại phân phối** | Embedded (Nhúng trong luồng mua thẻ điện thoại) + Standalone (Insurance Hub) |
| **Entry Point 1** | Insurance Hub → Tab Mua bảo hiểm → Mục Màn hình ĐT |
| **Entry Point 2** | Mua thẻ điện thoại trên Zalopay (hiện tạm off do không có promotion) |
| **Nhà bảo hiểm gốc** | PVI |
| **Mô hình UI** | Grid chọn gói trong Insurance Hub (EP1), Checkbox embedded trong Telco (EP2) |

**Luồng User Flow chi tiết:**

**A. Entry Point 1 — Từ Insurance Hub (Chính - Promotion):**
1. **Bước 1 — Insurance Hub (Promotion mode)**: Người dùng mở Hub bảo hiểm. Khi có promotion, banner **"Vỡ màn hình nhận ngay 3 triệu"** hiển thị nổi bật trên đầu trang. Tab chức năng trên cùng gồm: Quản lý hợp đồng, Ưu đãi cho bạn, Thanh toán tự động, Tìm hiểu bảo hiểm.
2. **Bước 2 — Chọn danh mục**: Trong mục "Mua bảo hiểm", người dùng chọn **Màn hình ĐT** (hoặc bấm vào mục "Đề xuất cho bạn" → Tab "Màn hình điện thoại").
3. **Bước 3 — Chọn gói bảo hiểm**: Hiển thị 3 gói dạng grid ngang:
   * **Gói 3**: 17.600đ/tháng — Bồi thường tối đa 3.000.000đ
   * **Gói 2**: 12.100đ/tháng — Bồi thường tối đa 2.000.000đ
   * **Gói 1**: 7.700đ/tháng — Bồi thường tối đa 1.000.000đ
   * Mô tả chi tiết: Bồi thường đến 3 triệu, chi phí sửa chữa màn hình khi nứt vỡ, thời hạn bảo vệ 1 tháng, điều kiện màn hình chưa qua thay thế.
   * Toggle: **"Đồng ý đăng ký và tham gia bảo hiểm..."** (người dùng bật toggle xác nhận đồng ý điều khoản tự động trích nợ).
4. **Bước 4 — Chọn "0đ tháng đầu - Đăng ký"**: Nếu có promotion, nút CTA hiển thị: **"0đ tháng đầu - Đăng ký"**. Nếu không có promotion, nút CTA: **"Mua ngay"**.
5. **Bước 5 — Cashier**: Màn hình thanh toán hiển thị: **Bảo hiểm màn hình điện thoại**, Gói đã chọn, Số tiền (VD: 17.600đ). Badge discount "Giảm 50% đến 40k" (nếu có). Phương thức thanh toán: Ví Zalopay / Tài khoản liên kết. Nút **"Xác nhận"**.
6. **Bước 6 — Kết quả + Kích hoạt IMEI**: Sau thanh toán thành công, người dùng được yêu cầu vào Portal Igloo (trong vòng 30 ngày) để chụp ảnh IMEI thiết bị kích hoạt bảo hiểm.

**B. Entry Point 2 — Từ mua thẻ điện thoại (Embedded - Tạm off):**
1. Người dùng mua thẻ điện thoại. Phía dưới hiển thị checkbox bảo hiểm màn hình.
2. **Ghi chú thực tế**: Entry point này hiện **đang tạm tắt** do không có chương trình promotion đang chạy.

**C. Non-Promotion mode (Insurance Hub):**
1. Khi không có promotion, Insurance Hub hiển thị giao diện đơn giản hơn (không có banner khuyến mãi). Danh mục sản phẩm mở rộng thêm các mục: Thanh toán, Du lịch, Chuyến đi, Màn hình ĐT.
2. Mục "Đề xuất cho bạn" hiển thị 3 gói bảo hiểm màn hình với giá gốc (không giảm giá), nút CTA: **"Mua ngay"** (thay vì "0đ tháng đầu - Đăng ký").

#### 5.4.8 Bảo hiểm Sống tự tin — Fuse x GIC (App ID 4015)

| Thuộc tính | Chi tiết |
|---|---|
| **Loại phân phối** | Embedded (Nhúng trong thanh toán khoản vay Credit Loan) + Standalone (Insurance Hub) |
| **Entry Point 1** | Mua thẻ điện thoại trên Zalopay |
| **Entry Point 2** | Insurance Hub → Tab Mua bảo hiểm |
| **Nhà bảo hiểm gốc** | GIC |
| **Mô hình UI** | Checkbox embedded trong Telco (EP1), Card chọn mua trên Hub (EP2) |

**Luồng User Flow chi tiết:**

**A. Entry Point 1 — Từ mua thẻ điện thoại (Telco):**
1. **Bước 1 — Telco Screen (Hoàn tiền mọi mệnh giá)**: Người dùng mở trang mua thẻ điện thoại, chọn nhà mạng và mệnh giá (10.000đ - 500.000đ). Phía dưới mục "Mua kèm giá tốt cho bạn" hiển thị:
   * **Bảo hiểm Sống tự tin** — 4.000đ ↗ (có mũi tên xem thêm)
   * Checkbox chưa tick (opt-in).
2. **Bước 2 — Tick chọn mua kèm**: Người dùng tick checkbox → Mở rộng mô tả quyền lợi:
   * *Quyền lợi chính*:
     * Bồi thường tai nạn cá nhân đến 5.000.000đ
     * Trợ cấp thất nghiệp 2.000.000đ/lần (doanh nghiệp phá sản/cắt giảm nhân sự hoặc giảm chi phí)
   * Cung cấp bởi: **GIC** × **Fuse**
   * Số lượng mua: 1 (mặc định).
3. **Bước 3 — Thanh toán tổng**: Nút CTA cập nhật: **"Mua ngay > 54.000đ"** (VD: 50.000đ thẻ + 4.000đ bảo hiểm).
4. **Bước 4 — Cashier**: Xác nhận thanh toán tổng. Hiển thị chi tiết dòng sản phẩm.
5. **Bước 5 — Kết quả**: Cấp đơn thành công → GCNBH từ GIC/Fuse.

**B. Entry Point 2 — Từ Insurance Hub:**
1. **Bước 1 — Insurance Hub**: Người dùng mở Hub bảo hiểm. Khi có promotion, banner **"Giảm 40%, bảo hiểm từ bất trắc, hơn 200k.hiểm"** hiển thị.
2. **Bước 2 — Chọn mục**: Trong tab "Mua bảo hiểm", người dùng chọn **Sống tự tin** (hoặc bấm mục "Đề xuất cho bạn" → Tab "Sống tự tin").
3. **Bước 3 — Chi tiết gói**: Hiển thị card bảo hiểm Sống tự tin — 4.000đ. Mô tả quyền lợi chi tiết.
4. **Bước 4 — Chọn "Mua ngay"**: Nút CTA → Chuyển đến Cashier thanh toán.
5. **Bước 5 — Cashier & Kết quả**: Thanh toán thành công → GCNBH.

#### 5.4.9 Bảo hiểm Học đường vui khỏe — Fuse x GIC (App ID 4041)

| Thuộc tính | Chi tiết |
|---|---|
| **Loại phân phối** | Embedded (Nhúng trong thanh toán hóa đơn học phí) |
| **Entry Point** | Thanh toán hóa đơn học phí (Education bill) trên Zalopay |
| **Nhà bảo hiểm gốc** | GIC |
| **Mô hình UI** | Checkbox embedded trong Bill Detail hóa đơn học phí |

**Luồng User Flow chi tiết:**
1. **Bước 1 — Education Bill Detail (Chi tiết hóa đơn học phí)**: Người dùng mở chi tiết hóa đơn học phí từ nhà cung cấp (VD: EnerPay). Hiển thị danh sách các khoản phí cần thanh toán:
   * Ví dụ: Đợt thu đầu năm học THU BHYT BHXH... 770.000đ, Thu tiền tháng 12 thư bảo hiểm y tế... 10.000đ, Thu khoản trả sách tháng 12 5.000đ, Thu khoản trả sau tháng 11 3.000đ, Khoản trả sau tháng 10 2.000đ, Khuyến 120.000đ.
   * **Thông tin khách hàng**: Mã định danh, Họ và tên học sinh (VD: Trần Huyền Anh), Trường học (VD: MN-TH-THCS-THPT Thủ Đô), Lớp (VD: 1A1).
2. **Bước 2 — Dịch vụ bảo hiểm sức khỏe học đường**: Phía dưới thông tin học sinh hiển thị mục **"Dịch vụ bảo hiểm sức khỏe học đường"** dạng checkbox:
   * **Checkbox**: "Học đường vui khỏe" — **10.000đ / 1 tháng** (opt-in, mặc định chưa tick).
   * Quyền lợi hiển thị dạng bullet:
     * Bảo vệ các bệnh học đường đến 5.000.000đ
     * Bảo vệ tai nạn & bệnh tật đến 13.000.000đ
     * Bảo vệ tai nạn học đường đến 6.000.000đ
     * Bảo vệ bạo lực học đường tối đa 6.000.000đ
     * *Phụ huynh được chọn nhiều thánh để bồi thường nhiều hơn* (nguyên văn UI).
   * Cung cấp bởi: **GIC** × **Fuse**
3. **Bước 3 — Chọn thời hạn bảo vệ**: Sau khi tick checkbox, hiển thị 3 lựa chọn kỳ hạn:
   * **Gói bảo vệ 1 tháng**: 10.000đ — Tương đương 10.000đ/tháng
   * **Gói bảo vệ 6 tháng**: 10.000đ/tháng — Tương ứng 60.000đ
   * **Gói bảo vệ 1 năm**: 10.000đ/tháng — Tương ứng 120.000đ
   * *Lưu ý*: Giao diện cho thấy phí hiển thị có thể thay đổi khi chọn gói 6 tháng hoặc 1 năm. Ví dụ: Chọn gói 1 năm → Tổng tiền thanh toán tăng 10.000đ (chỉ thu phí kỳ đầu tiên, các kỳ sau thu qua Auto Debit hoặc thanh toán kèm hóa đơn học phí lần sau).
4. **Bước 4 — Tick chọn → Cập nhật tổng tiền**: Tổng tiền thanh toán cập nhật: 910.000đ (chưa mua BH) → **920.000đ** (đã tick mua BH + chọn gói 1 năm). Nút **"Thanh toán"** cập nhật số tiền mới.
5. **Bước 5 — Cashier (Xác nhận)**: Chuyển sang màn hình Cashier Zalopay với thông tin tách bạch: Tiền học phí + Phí bảo hiểm học đường.
6. **Bước 6 — Kết quả**: Thanh toán thành công → GCNBH học đường vui khỏe từ GIC/Fuse.

**Quy tắc ẩn/hiện đặc biệt (Eligibility Check):**
* Hệ thống Ares backend kiểm tra tuổi học sinh (≥ 6 tuổi) và cấp học dựa trên trường Ngày sinh, Tên lớp, hoặc Tên trường trước khi hiển thị mục bảo hiểm. Nếu không thỏa mãn điều kiện, mục "Dịch vụ bảo hiểm sức khỏe học đường" sẽ bị ẩn hoàn toàn trên giao diện.

---

## 6. Chiến lược Content Message & Hệ thống Cảnh báo (Content Message & Notification Strategy)

Để giải quyết rào cản về "Niềm tin thấp" (Low Trust) và "Mức độ hiểu biết kém" (Low Understanding) của người dùng, Zalopay thực hiện chiến lược tối ưu hóa ngôn từ (Content Wording) trên giao diện mua và xây dựng hệ thống thông báo đa kênh nhắc nhở đóng phí tự động hoặc thủ công.

### 6.1 Định hướng Wording hiển thị trên Giao diện UI/UX

Zalopay loại bỏ các mô tả học thuật phức tạp, thay thế bằng các thông điệp trực quan và gần gũi:

#### 1. Bảo hiểm An ninh mạng (VBI Cyber Risk - App ID 3682)
* **Kịch bản Bán kèm thông thường (không có khuyến mãi)**:
  * **Title**: Bảo hiểm an ninh mạng
  * **Subtext lật chữ (Flip animation)**:
    * Text 1: *Bảo vệ ví 25 triệu đến 50 triệu*
    * Text 2: *Bảo vệ tai nạn cá nhân 10 triệu*
  * **Cơ chế**: Hiệu ứng lật chữ giúp nhấn mạnh quyền lợi thiết thực thay vì định nghĩa "Cyber" trừu tượng ([194755527_Cyber Risk -VBI-Bảo hiểm an ninh mạng.md#L475](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-Ba%CC%89o%20hie%CC%82%CC%89m%20an%20ninh%20ma%CC%A3ng.md#L475)).
* **Kịch bản Bán kèm có khuyến mãi Free Trial (Kỳ 1 giảm còn 0đ)**:
  * Treo Badge: **MIỄN PHÍ**
  * **Subtext lật chữ**:
    * Text 1: *Nhận ưu đãi ở bước thanh toán*
    * Text 2: *Bảo vệ ví 25 triệu đến 50 triệu*
    * Text 3: *Bảo vệ tai nạn cá nhân 10 triệu*
    * Quy tắc: Chỉ treo badge và hiển thị Text 1 nếu người dùng thỏa mãn điều kiện mua lần đầu và không thuộc blacklist hệ thống ([194755527_Cyber Risk -VBI-Bảo hiểm an ninh mạng.md#L472-L475](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-Ba%CC%89o%20hie%CC%82%CC%89m%20an%20ninh%20ma%CC%A3ng.md#L472-L475)).
* **Kịch bản Bán chéo luồng Chuyển tiền P2P (Money Transfer)**:
  * Để tạo sự liên quan tối đa với hành vi chuyển khoản lớn, wording được điều chỉnh động:
    * Text 1: *Bảo vệ tiền trước lừa đảo mạng*
    * Text 2: *Quyền lợi đến 50 triệu*
    * Text 3: *Thêm quyền lợi tai nạn 10 triệu*
    * (Có khuyến mãi): Thêm câu *Hoàn tiền 100% lần đầu thanh toán* lên đầu danh sách ([194755527_Cyber Risk -VBI-Bảo hiểm an ninh mạng.md#L691-L703](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-Ba%CC%89o%20hie%CC%82%CC%89m%20an%20ninh%20ma%CC%A3ng.md#L691-L703)).
* **Người dùng đang có hợp đồng có hiệu lực (chưa đóng đủ 12 kỳ)**:
  * **Title**: Bảo hiểm an ninh mạng
  * **Subtext**: *Đã thanh toán được X/12 kỳ / Hết hạn vào dd/mm/yy / Duy trì bảo vệ mua tiếp ngay* ([194755527_Cyber Risk -VBI-Bảo hiểm an ninh mạng.md#L708-L713](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-Ba%CC%89o%20hie%CC%82%CC%89m%20an%20ninh%20ma%CC%A3ng.md#L708-L713)).

#### 2. Bảo hiểm Sống An Vui (Chubb Sống An Vui - App ID 4491)
* **Kịch bản Bán kèm hóa đơn (kèm gói quà tặng)**:
  * **Title**: Bảo hiểm Sống an vui + quà tặng
  * **Subtext**:
    * *Bảo vệ tai nạn đến 30 triệu*
    * *Tặng 3 tháng tư vấn giải tỏa stress* (quà tặng thực tế là mã ưu đãi Teledoc Health để giảm bớt lo lắng về sức khỏe tâm lý của người trẻ)
    * *Trợ cấp y tế nằm viện đến 7 ngày* ([261511567_Chubb  Bill protection auto debit oneflow.md#L51-L53](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L51-L53)).
* **Thông tin minh bạch về Subscription (Auto Debit Toggle)**:
  * Để xóa tan lo ngại bị trích nợ ẩn, giao diện hiển thị thông tin rõ ràng ngay dưới nút bật đóng phí tự động: *"Đóng tự động tiện lợi, hủy bất cứ khi nào bạn muốn. Xem"* ([261511567_Chubb  Bill protection auto debit oneflow.md#L58](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L58)).

#### 3. Bảo hiểm Sức khỏe Tích lũy (Fuse - App ID 4042)
* **Wording cam kết sức khỏe (Health Consent Checkbox)**:
  * Do sản phẩm có điều khoản loại trừ bệnh có sẵn, UI/UX buộc người dùng cam kết tại kỳ đầu: *"Tôi xác nhận chưa từng điều trị/chẩn đoán các bệnh lý trên trong 6 tháng gần nhất..."* ([230287402_Fuse - BH sức khỏe tích lũy.md#L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/230287402_Fuse%20-%20BH%20s%C6%B0%CC%81c%20kho%CC%8B%20ti%CC%81ch%20lu%CC%83y.md#L30)).
* **Wording quyền lợi**: Nhấn mạnh hiệu suất chi phí bằng lật chữ: *"Quyền lợi gấp 230 lần phí / Trợ cấp nằm viện do tai nạn / Quyền lợi chi trả tối đa đến 20 triệu VNĐ"* ([251070828_New UI Component adapt routing insurance & A_B Testing UI.md#L25](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/251070828_New%20UI%20Component%20adapt%20routing%20insurance%20%26%20A_B%20Testing%20UI.md#L25)).

### 6.2 Hệ thống Thông báo nhắc nhở & Chu kỳ Đóng phí (Alerts & Notifications)

Zalopay cấu hình 2 luồng thông báo chính để nhắc nhở và giữ chân khách hàng (Retention) mà không gây cảm giác chèo kéo:

#### 1. Thông báo Cấp đơn bảo hiểm thành công (Delivery Notification)
Bắn ngay sau khi giao dịch chính hoàn tất và đối tác cấp đơn thành công nhằm thông báo rõ quyền lợi:
* **Bảo hiểm an ninh mạng**: *"Bạn đã được cấp giấy chứng nhận bảo hiểm an ninh mạng từ VBI. Bảo vệ bạn trước rủi ro lừa đảo trực tuyến bồi thường đến 50 triệu và bảo vệ tai nạn cá nhân 10 triệu. Xem giấy chứng nhận bảo hiểm"* ([213882556_Noti Thông báo cấp đơn bảo hiểm thành công (Delivery COI successfully).md#L21-L28](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/213882556_Noti%20Tho%CC%82ng%20ba%CC%81o%20ca%CC%82%CC%81p%20%C4%91o%CC%9Bn%20ba%CC%89o%20hie%CC%82%CC%89m%20tha%CC%80nh%20co%CC%82ng%20%28Delivery%20COI%20successfully%29.md#L21-L28)).
* **Bảo hiểm Người thanh toán**: *"Bạn đã được cấp giấy chứng nhận bảo hiểm Người thanh toán từ Bảo Việt. Bảo vệ bạn trước rủi ro tai nạn cá nhân với số tiền bảo hiểm lên đến 100 lần giá trị thanh toán. Xem giấy chứng nhận bảo hiểm"* ([213882556_Noti Thông báo cấp đơn bảo hiểm thành công (Delivery COI successfully).md#L39](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/213882556_Noti%20Tho%CC%82ng%20ba%CC%81o%20ca%CC%82%CC%81p%20%C4%91o%CC%9Bn%20ba%CC%89o%20hie%CC%82%CC%89m%20tha%CC%80nh%20co%CC%82ng%20%28Delivery%20COI%20successfully%29.md#L39)).
* **Bảo hiểm màn hình điện thoại**: *"Bạn đã mua bảo hiểm màn hình điện thoại thành công. Bấm kích hoạt xác thực thiết bị để đảm bảo quyền lợi nhé. Bảo vệ màn hình điện thoại của bạn trước sự cố rơi vỡ với số tiền bảo hiểm từ 1 triệu đến 3 triệu. Xem giấy chứng nhận bảo hiểm"* ([213882556_Noti Thông báo cấp đơn bảo hiểm thành công (Delivery COI successfully).md#L40](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/213882556_Noti%20Tho%CC%82ng%20ba%CC%81o%20ca%CC%82%CC%81p%20%C4%91o%CC%9Bn%20ba%CC%89o%20hie%CC%82%CC%89m%20tha%CC%80nh%20co%CC%82ng%20%28Delivery%20COI%20successfully%29.md#L40)).

#### 2. Thông báo nhắc nợ kỳ thanh toán Auto Debit (Chubb & VBI)
* **Thông báo T-1 (Chuẩn bị số dư - Bắn lúc 19:00 PM)**:
  * *Tiêu đề*: Đã đến kỳ thanh toán tự động bảo hiểm [an ninh mạng / Sống An Vui].
  * *Nội dung*: Hợp đồng XXXXXXXXXX sẽ được nạp tự động YYYY đ vào ngày mai dd/mm/yy. Bạn hãy đảm bảo số dư ví để giao dịch thành công nhé! ([194755527_Cyber Risk -VBI-Bảo hiểm an ninh mạng.md#L572-L574](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-Ba%CC%89o%20hie%CC%82%CC%89m%20an%20ninh%20ma%CC%A3ng.md#L572-L574)).
* **Thông báo thất bại do thiếu số dư ví (Ví không đủ tiền)**:
  * *Tiêu đề*: Thanh toán tự động bảo hiểm [an ninh mạng / Sống An Vui] thất bại.
  * *Nội dung*: Thanh toán thất bại vì Ví Zalopay của bạn không đủ tiền. Nạp tiền vào Ví và thanh toán lại nhé ([194755527_Cyber Risk -VBI-Bảo hiểm an ninh mạng.md#L588-L590](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-Ba%CC%89o%20hie%CC%82%CC%89m%20an%20ninh%20ma%CC%A3ng.md#L588-L590)).
* **Thông báo thành công**:
  * *Tiêu đề*: Thanh toán tự động bảo hiểm [an ninh mạng / Sống An Vui] thành công.
  * *Nội dung*: Hợp đồng XXXXXXXXXX đã được nạp tự động YYYY đ ([194755527_Cyber Risk -VBI-Bảo hiểm an ninh mạng.md#L604](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-Ba%CC%89o%20hie%CC%82%CC%89m%20an%20ninh%20ma%CC%A3ng.md#L604)).
* **Thông báo hoàn tất đủ 12 kỳ**:
  * *Tiêu đề*: Bạn đã thanh toán đủ 12 kỳ của hợp đồng bảo hiểm [an ninh mạng / Sống An Vui].
  * *Nội dung*: Hợp đồng XXXXXXXXXX có hiệu lực bảo vệ trọn vẹn đến ngày DD/MM/YYYY ([194755527_Cyber Risk -VBI-Bảo hiểm an ninh mạng.md#L636](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-Ba%CC%89o%20hie%CC%82%CC%89m%20an%20ninh%20ma%CC%A3ng.md#L636)).

---

## 7. Quy tắc Kinh doanh & Vận hành (Business Rules)

### 7.1 Phương thức Phân phối (Distribution Modes)
* **Standalone**: Người dùng mở trực tiếp Insurance Hub hoặc qua banner để mua bảo hiểm xe máy, sức khỏe, du lịch cá nhân.
* **Embedded**: Opt-in hoặc opt-out nhúng trực tiếp trong hóa đơn Điện/Nước/Học phí, Telco, OTA.
* **Cross-sell**: Đề xuất bán Cyber Risk tại màn hình kết quả chuyển khoản P2P.
* **Thu hộ phí (Collection)**: Tra cứu đóng phí bảo hiểm Cathay, FWD, Generali, MetLife. Chặn nguồn tiền Credit Card trên cổng Payoo ([230292981_[Insurance] Thông tin Sản phẩm - Đối tác để hỗ trợ CS xử lý ticket.md#L87-L91](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Tho%CC%82ng%20tin%20Sa%CC%83n%20pha%CC%82%CC%89m%20-%20%C4%90o%CC%82́i%20ta%CC%81c%20%C4%91e%CC%82̉%20ho%CC%83%20tro%CC%A3%20CS%20xu%CC%82%CC%81ly%CC%81%20ticket.md#L87-L91)).

### 7.2 Điều kiện tham gia, Định tuyến & Phân khúc (Eligibility, Routing, And Segments)
* **Routing theo traffic**: Chia tỷ lệ phần trăm phân phối các gói bảo hiểm khi người dùng thanh toán.
* **A/B Testing**: Chia phân khúc người dùng theo chữ số cuối của ID người dùng (Zalopay ID).
* **Ràng buộc tương tác**: Giao diện ẩn box mua bảo hiểm nếu người dùng click nút tắt (untick) 3 lần liên tiếp ([261513493_Insurance Zone display.md#L10](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/261513493_Insurance%20Zone%20display.md#L10)).
* **Lọc trước cuộc gọi đối tác (FAU check)**: Áp dụng kiểm tra phân khúc khách hàng trước khi gọi API VBI để kiểm tra tính hợp lệ mua Cyber Risk nhằm hạn chế quá tải hệ thống đối tác ([PCFFS-19980](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Jira/Insurance/PCFFS-19980_%5BInsur%5D%5Bal%5D%20Apply%20logic%20check%20FAU%20segment%20on%20Insur%20Hub.md)).

### 7.3 Chương trình Khuyến mãi, Free Trial & Giảm giá trực tiếp (Promotion & Free Trial)
* **Lỗi áp dụng voucher với nguồn tiền ngoài ví (non-wallet SoF)**: Email 2026-03-20 phản ánh lỗi nghiêm trọng khi áp dụng voucher giảm giá kỳ đầu tiên về 0đ đối với tài khoản liên kết hoặc thẻ. Do đó, team PO đã đề xuất chiến lược phát hành Cyber Risk bỏ qua voucher mà thực hiện giảm giá trực tiếp (Direct Discount/Direct Pay) kỳ 1 ([2026-03-20 blocker email](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Insurance/2026-03-20%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQADNX9v3wfcpDhiETzjhhXqg=%20-%20%5BWS%20-%20Insurance%5D%20-%20%5BAction%20Required%5D%20Blocker%20on%20Free%20trial%20Feature%20%E2%80%93%20Need%20Support.md)).
* **Cơ chế Skip Pay**: Đề xuất dài hạn bỏ qua thanh toán kỳ đầu tiên, Ares trực tiếp gọi API đối tác cấp đơn và ghi nhận đối soát nội bộ về khoản phí kỳ đầu này ([2026-05-22 free-trial solution email](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Insurance/2026-05-22%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQANsAAQJjlPFKvnNCwAHwPM4=%20-%20Re%20Apply%20free%20trial%20voucher%20for%20other%20SoF%20-%20Discussion.md)).

### 7.4 Đóng phí tự động & Tách bạch giao dịch (Autodebit / Subscription)
* **Check agreement**: Frontend gọi `useAutodebitInsurance` truy vấn thỏa thuận liên kết nạp tự động có sẵn trước khi hiển thị nút bật Auto Debit ([FE06](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/hooks/useAutodebitInsurance.tsx#L22)).
* **Logic trích nợ theo chu kỳ**: Từ kỳ thứ 3 trở đi, lịch trích nợ được tính toán dựa trên ngày hết hiệu lực thực tế của đơn bảo hiểm (Policy Expiry Date) thay vì ngày thực hiện giao dịch gốc nhằm ngăn ngừa lỗi đóng phí lệch ngày do quá hạn trích nợ ví ([PCFFS-21662](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Jira/Insurance/PCFFS-21662_%5BInsur%5D%5Bbe%5D%20Update%20logic%20charge%20phi%CC%81%20cho%20tha%CC%81ng%20thu%CC%82%203%20tro%CC%82%20di%CC%A3.md)).

### 7.5 Vòng đời Hợp đồng bảo hiểm (Policy Lifecycle)
Trạng thái hợp đồng bảo hiểm hiển thị trên giao diện người dùng được phân chia:
* **ACTIVE**: Hợp đồng có hiệu lực.
* **EXPIRED**: Hợp đồng hết hiệu lực.
* **CANCELED**: Hợp đồng bị hủy bởi người dùng hoặc hệ thống quá hạn thanh toán.
* **Đồng bộ hóa dữ liệu**: Kiểm tra tính đồng bộ của cơ sở dữ liệu Elasticsearch `insurance_policy` với trạng thái lưu trữ trên bảng MySQL `aqr_telco_ares_bill_history` để user tránh việc xem hợp đồng đã bị chấm dứt hiệu lực ([S09](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/get_policy.go#L19)).

### 7.6 Cơ chế xử lý hoàn tiền, Kiểm tra thủ công & Phục hồi lỗi
* **Trạng thái -400 (DeliverManualCheck)**: Được áp dụng để treo giao dịch khi có lỗi kết nối mạng không xác định giữa Ares và đối tác. Hệ thống không hoàn tiền tự động ngay để phòng tránh double-charge (vừa cấp đơn vừa hoàn tiền) ([S05](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/deliver.go#L15)).
* **Hoàn tiền tự động (-401 - DeliverFailed)**: Khi đối tác trả mã lỗi từ chối cấp đơn chính thức, đơn được cập nhật trạng thái `DeliverFailed` và đẩy vào Queue của RabbitMQ để tự động gạch nợ hoàn tiền ví Zalopay ngay lập tức ([S10](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/refund.go#L17)).

---

## 8. Kiến trúc Kỹ thuật & Tích hợp (Technical Architecture)

### 8.1 Backend Service: Ares Core
Ares là một monorepo viết bằng ngôn ngữ Go. Module quản lý bảo hiểm phi nhân thọ nằm tại `internal/bill` kết nối với DB MySQL và Elasticsearch:
* **Supplier mapping & Constant config**: Mappings các đối tác, Supplier ID và kịch bản thanh toán nằm tại `internal/bill/constant.go` ([S02](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/ares/internal/bill/constant.go#L75)).
* **Cơ chế xử lý callback**: Xác thực chữ ký SHA256 kết hợp khóa Redis Lock để chống giao dịch trùng lặp ([S04](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/handle_payment_callback.go#L19)).

### 8.2 Frontend Service: Insurance Webapp
Ứng dụng vi mô React chạy dưới dạng Webview nhúng:
* **Features Home**: Quản lý trang Hub bảo hiểm, các chip category hiển thị và banner ([FE03](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/features/home/index.tsx#L12)).
* **Hooks & Constants**: Quản lý sự kiện tracking và đóng gói dữ liệu ([FE02](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/constants/insurancePurchase.ts#L3)).

### 8.3 Điểm bất đồng bộ cần kiểm chứng (Source Snapshot Inconsistencies)
* Các file cấu hình front-end chứa một số Supplier ID mới (như School, OfficeHealth, Motorbike, PeacefulLiving) nhưng cơ sở dữ liệu backend chưa đồng bộ hoàn toàn cấu hình mapping. Cần kiểm tra kỹ các file migration SQL để tránh lệch dữ liệu ([FE02](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/constants/insurancePurchase.ts#L10), [S02](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/ares/internal/bill/constant.go#L75)).

---

## 9. Đo lường & Phân tích sự kiện (Tracking And Analytics)

### 9.1 Hệ sự kiện (Event Family)
Tracking sự kiện bảo hiểm chủ yếu được định nghĩa thông qua họ sự kiện `4072.*` và `1130.*` cho Cashier thanh toán:
* **`4072.000`**: Loaded component bảo hiểm nhúng trên trang thanh toán của dịch vụ host ([FE02](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/constants/insurancePurchase.ts#L15)).
* **`4072.001`**: Người dùng tick chọn mua bảo hiểm (Check action) ([FE02](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/constants/insurancePurchase.ts#L22)).
* **`4072.002`**: Người dùng hủy chọn mua bảo hiểm (Untick action) ([FE02](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/constants/insurancePurchase.ts#L30)).

### 9.2 Vấn đề sai lệch dữ liệu tracking (Known Dashboard Issues)
Confluence ghi nhận sự lệch pha giữa số liệu event Loaded component (`4072.000`) và số liệu gạch nợ Cashier do lỗi ghi nhận thiếu thuộc tính ID vùng bảo hiểm (Zone ID). Cần bổ sung trường metadata `zone_id` vào mọi payload event để đảm bảo phễu chuyển đổi chuẩn xác ([219680272_Embedded Insurance Funnel.md:L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/219680272_Embedded%20Insurance%20Funnel.md#L5)).

### 9.3 Mô tả Phễu tối thiểu cho Audit (Funnel Audit Definition)

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
flowchart LR
    A["Giao dịch chính đủ điều kiện"] --> B["Component tải thành công<br/>4072.000"]
    B --> C["Tích chọn mua bảo hiểm<br/>4072.001"]
    B --> D["Hủy chọn mua bảo hiểm<br/>4072.002"]
    C --> E["Xác nhận thanh toán<br/>1130.000"]
    E --> F["Giao dịch hoàn tất<br/>1130.011"]
    F --> G["Cấp giấy chứng nhận (COI)"]
```

---

## 10. Mô hình Vận hành & Rủi ro Đối tác (Operational Model)

### 10.1 Nhân sự & Giao diện kết nối đối tác
* **Đội ngũ vận hành nội bộ**: PO/Squad Lead Wealth Solution chịu trách nhiệm kinh doanh & tính năng, Dev BE/FE thiết kế Ares/Webapp và QC kiểm thử.
* **Đối tác ngoại vi**: Nhóm hỗ trợ kỹ thuật của SaveMoney, Saladin, VBI, Fuse, Igloo xử lý bồi thường và gạch nợ ([268084164_Handover Insurance (Distribution).md:L8](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/268084164_Handover%20Insurance%20%28Distribution%29.md#L8)).

### 10.2 Bản đồ rủi ro đối tác (Partner Risk Matrix)
* **SaveMoney**: Rủi ro chậm trễ đồng bộ danh mục hợp đồng từ cổng Webview về database Zalopay, tạo phản ánh CS Ticket xấu ([CS01](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/CS%20Ticket/Insurance/ISSUE-30191_%5BU%CC%9B%CC%81ng%20du%CC%A3ng%5D%20-%20%5B1020%20-%20SAVEMONEY%5D%20Lo%CC%82%CC%83i%20u%CC%9B%CC%81ng%20du%CC%A3ng%20-%20Cas.md)).
* **VBI**: Rủi ro quá tải API khi lượng giao dịch P2P chuyển tiền lớn quét liên tục. Khắc phục bằng giải pháp cache trạng thái và kiểm tra segment trước khi gọi API ([E03](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Insurance/2026-03-24%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQAEyY1VPARKtPgrfD1gCnGVc=%20-%20%5BWS%20-%20Insurance%5D%20Cyber%20Insurance%20%E2%80%93%20VBI%20Feedback.md)).
* **Igloo**: Rủi ro tỷ lệ kích hoạt bồi thường cực thấp do trải nghiệm IMEI quá phức tạp đối với tệp khách hàng phổ thông ([132339429_Phone Cracked Screen​ (Bảo hiểm rơi vỡ màn hình).md:L134](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/132339429_Phone%20Cracked%20Screen%E2%80%8B%20%28B%E1%BA%A3o%20hi%E1%BB%83m%20r%C6%A1i%20v%E1%BB%A1%20m%C3%A0n%20h%C3%ACnh%29.md#L134)).

---

## 11. Sổ tay CS Ticket & SLA đối tác (CS Playbook & Support)

### 11.1 Danh bạ liên hệ và SLA xử lý của các đối tác

| Nhà cung cấp (Supplier) | Email hỗ trợ kỹ thuật / vận hành | Hotline hỗ trợ | SLA xử lý hủy và hoàn phí | SLA xuất hóa đơn điện tử | Tài liệu tham khảo kỹ thuật |
|---|---|---|---|---|---|
| **Saladin** (Du lịch, Chuyến đi, Người thanh toán) | [cs@saladin.vn](mailto:cs@saladin.vn) | 1900 638 454 | Trong vòng 24h đối với ngày làm việc. Yêu cầu gửi trước giờ khởi hành. | Khách hàng gửi thông tin cho CS Zalopay chuyển tiếp qua email đối tác trong ngày. | [Checkout Saladin checklist](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product Page/230292981_[Insurance] Thông tin Sản phẩm - Đối tác để hỗ trợ CS xử lý ticket.md#L14-L62) |
| **Igloo** (Rơi vỡ màn hình điện thoại) | [thien.le@iglooinsure.com](mailto:thien.le@iglooinsure.com) <br> [yennt4@pvi.com.vn](mailto:yennt4@pvi.com.vn) | 070 391 3575 <br> 0961887293 | Hỗ trợ hủy đơn trong vòng 24h nếu chưa kích hoạt. Phí hoàn trả 1.100đ/giao dịch. | 2-3 ngày làm việc. | [Igloo cracked screen design](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product Page/230292981_[Insurance] Thông tin Sản phẩm - Đối tác để hỗ trợ CS xử lý ticket.md#L63) |
| **VBI** (An ninh mạng) | [cskh@myvbi.vn](mailto:cskh@myvbi.vn) <br> [binhpb@myvbi.vn](mailto:binhpb@myvbi.vn) | 1900 1566 | CS Zalopay gửi trans_id cần hủy qua email. SLA hủy đơn trong 24h. | 2-3 ngày làm việc. | [VBI Cyber Risk design](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product Page/230292981_[Insurance] Thông tin Sản phẩm - Đối tác để hỗ trợ CS xử lý ticket.md#L64-L71) |
| **SaveMoney** (Nhà, Xe máy, Ô tô) | [tho.tran@savemoney.vn](mailto:tho.tran@savemoney.vn) | 0376 871 793 | Các gói bảo hiểm phân phối qua SaveMoney **không hỗ trợ hoàn/hủy**. | 2-3 ngày làm việc. | [SaveMoney CS guide](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product Page/230292981_[Insurance] Thông tin Sản phẩm - Đối tác để hỗ trợ CS xử lý ticket.md#L72-L86) |
| **Chubb** (Sống An Vui, Du lịch Chubb) | [inquiries.vn@chubb.com](mailto:inquiries.vn@chubb.com) | 028 3910 7300 <br> 028 3910 7260 | * Flight: Không hoàn hủy.<br>* Sống An Vui: Hủy trong 14-15 ngày đầu hoàn phí 100%. Quá hạn sẽ ngưng trừ tiền tháng tiếp theo. | 2-3 ngày làm việc. | [Chubb integration checklist](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product Page/230292981_[Insurance] Thông tin Sản phẩm - Đối tác để hỗ trợ CS xử lý ticket.md#L87-L91) |
| **Fuse** (Sống tự tin, Học đường vui khỏe) | [cs@fuse.com.vn](mailto:cs@fuse.com.vn) | 028 7300 8803 | Hủy đơn và hoàn phí trong vòng 3 ngày kể từ khi thanh toán thành công nếu chưa phát sinh tổn thất/yêu cầu bồi thường. | 2-3 ngày làm việc. | [Fuse Education design](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product Page/230292981_[Insurance] Thông tin Sản phẩm - Đối tác để hỗ trợ CS xử lý ticket.md#L100-L108) |

### 11.2 Các kịch bản lỗi thường gặp và Playbook xử lý nhanh

#### Kịch bản 1: Đơn hàng bảo hiểm bị kẹt trạng thái xử lý lấp lửng (`DeliverManualCheck = -400`)
* **Dấu hiệu**: Khách hàng đã bị trừ tiền ví thành công, nhưng trên ứng dụng hiển thị trạng thái đơn hàng "Đang xử lý/Kiểm tra trạng thái", không xuất hiện Giấy chứng nhận bảo hiểm (COI).
* **Nguyên nhân**: Lỗi kết nối mạng giữa Ares và API đối tác tại thời điểm thanh toán thành công, hoặc API đối tác gặp lỗi hệ thống trả về mã lỗi không có trong bảng mapping. Giao dịch bị treo trạng thái `DeliverManualCheck` trong DB để tránh double-charge.
* **Playbook xử lý**:
  1. Tra cứu thông tin giao dịch trong database `aqr_telco_ares_bill_history` để tìm mã đơn hàng `order_id` và mã tham chiếu giao dịch ví `zptransid`.
  2. CS/Ops liên hệ với bộ phận kỹ thuật của đối tác qua email để kiểm tra trạng thái cấp đơn trên hệ thống đối tác:
     * **Trường hợp đối tác báo CẤP ĐƠN THÀNH CÔNG**: Xin thông tin `Policy ID` (Số hợp đồng) và `Policy URL` (Link PDF giấy chứng nhận). Dev chạy script/tool admin cập nhật trạng thái đơn hàng về thành công (`status = 1`) và ghi nhận thông tin policy vào trường `product_infos` trong DB để user có thể view trên app ([ISSUE-38074](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-38074_%5BThanh%20toa%CC%81n%5D%20-%20%5B4015%20-%20So%CC%82%CC%81ng%20tu%CC%9B%CC%A3%20tin%5D%20Kie%CC%82%CC%89m%20tra%20giao%20.md)).
     * **Trường hợp đối tác báo CẤP ĐƠN THẤT BẠI**: Tiến hành đổi trạng thái đơn hàng sang `DeliverFailed = -401` và kích hoạt luồng hoàn tiền tự động qua cổng TPE.

#### Kịch bản 2: Lỗi không thể chọn ngày/tháng/năm sinh khi mua bảo hiểm du lịch
* **Dấu hiệu**: Khách hàng không thể thay đổi hoặc chọn năm sinh mong muốn trên giao diện lịch chọn của sản phẩm bảo hiểm du lịch 3274.
* **Nguyên nhân**: Hệ thống frontend/backend cấu hình ràng buộc độ tuổi tham gia tối thiểu. Đối với bảo hiểm du lịch Saladin, quy tắc quy định người mua bảo hiểm chính phải từ đủ **18 tuổi trở lên** tại thời điểm tham gia. Giao diện lịch sẽ tự động khóa (disable) các năm sinh dưới 18 tuổi để ngăn chặn việc nhập sai quy tắc nghiệp vụ từ đầu ([ISSUE-38955](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-38955_%5BU%CC%9B%CC%81ng%20du%CC%A3ng%5D%20-%20%5B3274%20-%20Ba%CC%89o%20Hie%CC%82%CC%89m%20Du%20Li%CC%A3ch%5D%20Lo%CC%82%CC%83i%20u%CC%9B%CC%81ng%20du%CC%A3n.md)).
* **Playbook xử lý**: Hướng dẫn khách hàng kiểm tra lại thông tin ngày sinh nhập vào đảm bảo đã đủ 18 tuổi để tham gia với tư cách là người mua chính. Trường hợp mua cho con nhỏ (dưới 18 tuổi), bố/mẹ phải là người mua chính đứng tên trên hợp đồng và khai báo thông tin con là người được bảo hiểm phụ.

#### Kịch bản 3: Sự cố kích hoạt bảo hiểm rơi vỡ màn hình điện thoại (Igloo - 3394)
* **Dấu hiệu**: Khách hàng đã thanh toán thành công gói bảo hiểm rơi vỡ màn hình, nhưng sau đó không thể kích hoạt gói bảo hiểm hoặc bị đối tác từ chối.
* **Nguyên nhân**: Quy định kích hoạt yêu cầu khách hàng phải chụp hình màn hình điện thoại đang hiển thị mã số IMEI của máy trên một gương sáng/nền trắng trong vòng 24h sau khi mua. Nếu khách hàng chụp ảnh không đạt yêu cầu (mờ, không rõ IMEI, chụp trên nền tối...) hoặc không thể mở trang chụp ảnh kích hoạt.
* **Playbook xử lý**: 
  1. Hướng dẫn khách hàng thực hiện mở bàn phím gọi điện nhấn cú pháp `*#06#` để hiển thị IMEI, sau đó đưa màn hình điện thoại trước gương để chụp ảnh rõ nét gửi lên link kích hoạt.
  2. Nếu giao diện kích hoạt bị lỗi không thể submit, CS Zalopay thu thập thông tin ảnh chụp màn hình chứa IMEI rõ ràng của khách và gửi qua email cho đầu mối của Igloo (`thien.le@iglooinsure.com`) để hỗ trợ duyệt và kích hoạt thủ công trên hệ thống backoffice đối tác ([ISSUE-40192](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-40192_%5BThanh%20toa%CC%81n%5D%20-%20%5B3394%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20m%C3%A0n%20h%C3%ACnh%20%C4%91i%E1%BB%87n%20tho%E1%BA%A1.md)).

#### Kịch bản 4: Tranh chấp loại gói bảo hiểm nhận được so với gói đã chọn (Xe máy SaveMoney)
* **Dấu hiệu**: Khách hàng phản ánh họ đã chọn mua gói bảo hiểm xe máy dung tích trên 50cc (phí thường là 86.000đ/năm), nhưng khi nhận được giấy chứng nhận lại hiển thị gói dưới 50cc (phí 60.500đ/năm).
* **Nguyên nhân**: Người dùng thường nhầm lẫn khi tích chọn gói bảo hiểm trên giao diện hoặc nhấn nút thanh toán quá nhanh mà không kiểm tra lại phần chi phí thực tế.
* **Playbook xử lý**:
  1. Truy cập log giao dịch hoặc tìm kiểm tra thông tin SKU trong log thanh toán của đơn hàng qua `zp_trans_id`.
  2. Kiểm tra mã SKU trong `embeddata.promotioninfo.productinfo` (Ví dụ: `4326_18_ABI-MTU50_1` là mã dành cho xe máy dưới 50cc của ABIC) và số tiền thực tế khách đã thanh toán (60.500đ) ([ISSUE-37225](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-37225_%5BThanh%20toa%CC%81n%5D%20-%20%5B4326%20-%20Ba%CC%89o%20hie%CC%82%CC%89m%20xe%20ma%CC%81y%20Save%20Money%5D.md)).
  3. Phản hồi giải thích rõ ràng cho khách hàng rằng hệ thống đã ghi nhận đúng gói mà họ đã chọn mua trên giao diện (thể hiện qua số tiền thanh toán thực nhận) và hướng dẫn họ hủy hoặc mua bổ sung nếu cần thiết.

---

## 12. Nhật ký Quyết định từ Email & Chat (Email / Chat Decision Log)

Các nội dung trao đổi nội bộ làm cơ sở giải thích hành vi thực tế của luồng sản phẩm bảo hiểm:

| Ngày gửi / Kênh | Nội dung quyết định thực tế | Ý nghĩa đối với audit sản phẩm |
|---|---|---|
| 2025-12-31 / Email | Bàn giao scope PO bảo hiểm phi nhân thọ (Distribution) và định hướng tập trung Cyber P2P ([2025-12-31 handover email](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Insurance/2025-12-31%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQADr0iuNc781Ig4cEpTIb8wI=%20-%20Xa%CC%81c%20nh%C2%A2%CC%A3n%20handover%20scope%20co%CC%82ng%20vie%CC%A3%CC%82c%20PO%20%E2%80%93%20Domain%20Insurance%20%28Distribution%29.md)). | Xác nhận team Wealth Solution chính thức quản lý luồng Distribution và tiếp tục triển khai Cyber MT. |
| 2026-03-20 / Email | Tính năng Free Trial Cyber Risk bị chặn lỗi áp dụng voucher cho các nguồn tiền ngoài ví (Agreement Pay blocker) ([2026-03-20 blocker email](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Insurance/2026-03-20%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQADNX9v3wfcpDhiETzjhhXqg=%20-%20%5BWS%20-%20Insurance%5D%20-%20%5BAction%20Required%5D%20Blocker%20on%20Free%20trial%20Feature%20%E2%80%93%20Need%20Support.md)). | Chứng minh tầm quan trọng của việc kiểm tra toàn diện các nguồn tiền (SoF) khi chạy khuyến mãi bảo hiểm. |
| 2026-03-24 / Email | VBI phản ánh lượng API gọi kiểm tra trạng thái quá lớn. Zalopay cần lưu trữ trạng thái nội bộ để giảm tải ([2026-03-24 VBI feedback](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Insurance/2026-03-24%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQAEyY1VPARKtPgrfD1gCnGVc=%20-%20%5BWS%20-%20Insurance%5D%20Cyber%20Insurance%20%E2%80%93%20VBI%20Feedback.md)). | Áp dụng logic FAU segment check tại in-app để lọc khách hàng trước khi gọi API VBI. |
| 2026-04-16 / Email | Quyết định tạm bỏ Free Trial kỳ 1 và bán Cyber Risk P2P bằng giảm trực tiếp kỳ 1 để tránh trễ hạn go-live. | Cho thấy rào cản tài chính kỹ thuật ảnh hưởng trực tiếp đến lộ trình go-live của tính năng. |
| 2026-05-27 / Email | aligned với Chubb về Term Life: thu thập email người dùng sau khi mua thành công hoặc thông báo qua Zalo OA; không áp dụng esign ở COI sơ bộ ([2026-05-27 Mini Term Life email](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Insurance/2026-05-27%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQALL63vhbLIpNhmQhFnETmTk=%20-%20RE%20%5BChubb%20Life%20-%20Zalopay%5D%20Tech%20Meeting%20-%20Mini%20Term%20Life.md)). | Xác nhận Term Life đang ở trạng thái chuẩn bị hạ tầng kỹ thuật, chưa go-live production. |
| 2026-05-28 / Email | Tối ưu hóa UI hóa đơn: tránh văn bản chạy (rolling text) gây phân tâm; cân nhắc tác động tải thức của Auto Debit ([2026-05-28 Bill UI wrap-up](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Insurance/2026-05-28%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQAADU-7vJx00XvjGTmyWepM8=%20-%20Wrap-up%20UI%20Discussion%20Bill%20Payment%20%26%20Insurance.md)). | Chứng minh nỗ lực bảo vệ host journey (thanh toán bill) nhằm tránh làm gián đoạn hành trình chính của khách hàng. |
| 2026-05-06 / Chat | Thảo luận thống nhất cấu hình event tracking bảo hiểm in-app thông qua event gia đình `4072.*` và metadata zone_id ([2026-05-06 chat](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedChats/Group/26-05-06%20-%20Insurance%20System%20Walkthrough%20Meeting%20-%2019_meeting_MDBhNzdhYjQtYzA0NS00YzAwLWFjOGUtODc4MmVlODZjOWEz_thread_v2.md)). | Cơ sở kỹ thuật cho việc audit phễu chuyển đổi dữ liệu hiển thị. |

---

## 13. Lộ trình & Công việc Jira (Jira / Roadmap Snapshot)

* **PCFFS-20739 (In Test)**: Tích hợp hiển thị hợp đồng bảo hiểm trên mini app Quản lý bảo hiểm của Zalopay ([J01](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Jira/Insurance/PCFFS-20739_%5BInsur%5D%5Bbe%5D%20Ti%CC%81ch%20ho%CC%A3p%20H%C4%90%20BH%20vo%CC%81i%20Qua%CC%83n%20li%CC%81%20BH%20cu%CC%83a%20ZLP.md)).
* **PCFFS-21610 (In Dev)**: Cho phép áp dụng ưu đãi Free Trial cho sản phẩm bảo hiểm Sống An Vui trong luồng mua độc lập Standalone ([J02](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Jira/Insurance/PCFFS-21610_%5BInsur%5D%5Bbe%5D%20Enable%20free%20trial%20cho%20BH%20so%CC%81ng%20an%20vui%20-%20Stand%20alone%20flow.md)).
* **PCFFS-21609 (New)**: Hỗ trợ tự động bật liên kết Auto Debit khi người dùng mua bảo hiểm Sống An Vui luồng Standalone ([J03](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Jira/Insurance/PCFFS-21609_%5BInsur%5D%5Bbe%5D%20Enable%20auto%20subcription%20cho%20BH%20so%CC%81ng%20an%20vui%20-%20Stand%20alone%20flow.md)).
* **PCFFS-21662 (Done)**: Điều chỉnh logic quét trích nợ tự động của các kỳ sau (kỳ thứ 3 trở đi) dựa trên ngày hết hạn thực tế của hợp đồng nhằm tránh lệch ngày do quá hạn đóng phí ([J04](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Jira/Insurance/PCFFS-21662_%5BInsur%5D%5Bbe%5D%20Update%20logic%20charge%20phi%CC%81%20cho%20tha%CC%81ng%20thu%CC%82%203%20tro%CC%82%20di%CC%A3.md)).
* **PCFFS-19979 (New)**: Tích hợp cổng thanh toán mới để hỗ trợ Agreement Pay tự động trích nợ cho sản phẩm Cyber Risk ([J05](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Jira/Insurance/PCFFS-19979_%5BInsur%5D%5Bal%5D%20Integration%20with%20Agreement%20Pay%20to%20inject%20new%20SoF.md)).
* **PCFFS-19980 (In Analysis)**: Áp dụng kiểm tra phân khúc khách hàng (FAU segment check) trên Insurance Hub trước khi gọi API VBI nhằm hạn chế lỗi nghẽn cổng đối tác ([J06](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Jira/Insurance/PCFFS-19980_%5BInsur%5D%5Bal%5D%20Apply%20logic%20check%20FAU%20segment%20on%20Insur%20Hub.md)).
* **PCFFS-19978 (In Test)**: Đang thực hiện bàn giao kiến thức kỹ thuật bảo hiểm ([J07](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Jira/Insurance/PCFFS-19978_%5BInsur%5D%5Bal%5D%20Take%20over%20Insurance%20Technical%20Knowledge.md)).

---

## 14. Ma Trận Sẵn Sàng Audit (Audit Readiness Matrix)

### 14.1 UX & Quy trình (UX & Journey)
* **Câu hỏi Audit**: Đề xuất bảo hiểm nhúng có gây cản trở hoặc làm giảm tỷ lệ chuyển đổi của giao dịch thanh toán chính không?
  * *Bằng chứng thực tế*: Email thảo luận về Bill UI cho thấy đội ngũ đã có ý thức giảm thiểu sự phân tâm (chặn rolling text, giới hạn số lần hiển thị) ([261513493_Insurance Zone display.md:L10](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/261513493_Insurance%20Zone%20display.md#L10)).
* **Câu hỏi Audit**: Quy trình hiển thị thông tin và gói có đủ rõ ràng để tránh tranh chấp gói khi khách hàng mua không?
  * *Bằng chứng thực tế*: CS Ticket phản ánh tranh chấp gói bảo hiểm xe máy SaveMoney (khách hàng chọn gói dưới 50cc nhưng nghĩ là mua gói trên 50cc) cho thấy giao diện cần hiển thị rõ ràng hơn thuộc tính dung tích xe ([ISSUE-37225](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-37225_%5BThanh%20toa%CC%81n%5D%20-%20%5B4326%20-%20Ba%CC%89o%20hie%CC%82%CC%89m%20xe%20ma%CC%81y%20Save%20Money%5D.md)).

### 14.2 An toàn Tài chính & Dòng tiền (Financial Safety)
* **Câu hỏi Audit**: Số tiền thực tế trích ví khách hàng có khớp 100% với biểu phí gói bảo hiểm niêm yết không?
  * *Bằng chứng thực tế*: Logic callback Ares thực hiện so khớp số tiền thanh toán từ cổng Cashier trước khi gọi lệnh cấp đơn ([S04](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/handle_payment_callback.go#L19)).
* **Câu hỏi Audit**: Có xảy ra lỗi double-charge trích tiền 2 lần khi thực hiện gia hạn tự động hoặc thanh toán lỗi không?
  * *Bằng chứng thực tế*: Ares truyền khóa tuần tự `X-Idempotency-Key` kết hợp Redis Lock để chống trừ tiền trùng lặp ([S05](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/deliver.go#L15)).

### 14.3 Độ tin cậy Vận hành & Phục hồi lỗi (Operational Reliability)
* **Câu hỏi Audit**: Hệ thống có khả năng tự động khôi phục và hoàn trả ví cho khách khi đối tác lỗi cấp đơn không?
  * *Bằng chứng thực tế*: RabbitMQ Queue xử lý hoàn tiền tự động được kích hoạt ngay khi trạng thái chuyển sang `DeliverFailed` ([S10](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/refund.go#L17)).
* **Câu hỏi Audit**: Giấy chứng nhận bảo hiểm (COI) có được hiển thị đúng hạn cam kết để khách hàng làm bằng chứng bồi thường không?
  * *Bằng chứng thực tế*: CS Ticket phản ánh nhiều trường hợp khách đã trừ tiền ví nhưng không nhận được chứng nhận trên portal do lỗi đồng bộ, buộc dev phải chèn tay số Policy ([ISSUE-30191](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/CS%20Ticket/Insurance/ISSUE-30191_%5BU%CC%9B%CC%81ng%20du%CC%A3ng%5D%20-%20%5B1020%20-%20SAVEMONEY%5D%20Lo%CC%82%CC%83i%20u%CC%9B%CC%81ng%20du%CC%A3ng%20-%20Cas.md)).

### 14.4 Xây dựng Niềm tin & Sự hiểu biết (Trust-building & Literacy)
* **Câu hỏi Audit**: Khách hàng có nắm rõ các điều khoản loại trừ bệnh và cách thức yêu cầu bồi thường không?
  * *Bằng chứng thực tế*: UI thiết lập checkbox cam kết sức khỏe đối với bảo hiểm sức khỏe tích lũy giúp ngăn ngừa tranh chấp từ chối chi trả do bệnh có sẵn ([230287402_Fuse - BH sức khỏe tích lũy.md#L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/230287402_Fuse%20-%20BH%20s%C6%B0%CC%81c%20kho%CC%8B%20ti%CC%81ch%20lu%CC%83y.md#L30)).

---

## 15. Kế hoạch Audit Khuyến nghị (Recommended Audit Plan)

Quy trình 6 bước khuyến nghị cho PO khi thực hiện Audit chất lượng sản phẩm bảo hiểm:
1. **Rà soát danh mục (Product Inventory check)**: Lập danh sách các App ID đang cấu hình trên Ares core và đối chiếu trạng thái hoạt động với front-end Constants ([S02](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/ares/internal/bill/constant.go#L75), [FE02](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/constants/insurancePurchase.ts#L3)).
2. **Kiểm tra phễu chuyển đổi (Conversion Funnel audit)**: Kiểm tra dữ liệu tracking trên Grafana dashboard cho các event `4072.*` để phát hiện chênh lệch do Zone ID ([219680272_Embedded Insurance Funnel.md#L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02. Context/Confluence/Insurance/Product%20Page/219680272_Embedded%20Insurance%20Funnel.md#L5)).
3. **Kiểm tra trải nghiệm người dùng (UX Path test)**: Thực hiện mua thử nghiệm trực tiếp trên môi trường test/staging cho các dòng sản phẩm đặc thù (IMEI Igloo, Lịch sinh nhật Saladin, Checkbox cam kết Fuse).
4. **Kiểm tra dòng tiền & hoàn trả (Money safety audit)**: Xác nhận cơ chế hoàn tiền ví chạy đúng hạn SLA 24h đối với giao dịch lỗi cấp đơn và đối soát số tiền trích nạp Auto Debit ([S10](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/refund.go#L17)).
5. **Kiểm tra quản lý hợp đồng (Policy management audit)**: Kiểm tra tính hiển thị của GCNBH và phân loại đúng trạng thái Active/Expired ([S09](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/get_policy.go#L19)).
6. **Phân tích CS Ticket (Support tickets analysis)**: Tổng hợp dữ liệu khiếu nại CS hàng tháng để phân loại nguyên nhân và tối ưu hóa giao diện/wording mua ([CS01-CS06](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20Zalopay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03. Fact/CS%20Ticket/Insurance/)).

---

## 16. Câu hỏi mở & Khoảng trống Dữ liệu (Open Questions & Evidence Gaps)

* **Thiếu file cấu hình production thực tế**: Hiện tại mã nguồn cục bộ chứa một số điểm bất đồng bộ cấu hình giữa backend và frontend. Cần xin quyền truy cập các file release của Kubernetes/Helm Chart để rà soát tham số config môi trường thật.
* **Tình trạng của Term Life và MiniHealth**: Các trao đổi email cho thấy dự án đang trong quá trình phát triển và kiểm thử tích hợp. Cần đối chiếu với lịch release thực tế để xác nhận thời điểm go-live chính thức trước khi tiến hành chấm điểm audit.
* **Thời gian đáp ứng (SLA) bồi thường của đối tác**: Các Confluence chưa làm rõ quy trình bồi thường thực tế (Claims) từ phía người dùng được đối tác xử lý trong bao lâu và có tỷ lệ bồi thường thành công là bao nhiêu.

---

## 17. Danh mục Nguồn tài liệu (Source Manifest)

### 17.1 Confluence / Product Docs
* **[C01]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/273538069_Insurance product line overview.md` (Tổng quan dòng sản phẩm, App ID, Suppliers).
* **[C02]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/268095061_Insurance portfolio & SKUs summary info.md` (Thông tin SKU, biểu phí).
* **[C03]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/268084164_Handover Insurance (Distribution).md` (Danh sách PIC, bàn giao công việc).
* **[C04]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/244520820_Insurance UIUX 2025.md` (Định hướng UIUX, tối ưu phễu).
* **[C05]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/224783660_Insurance Contract Management.md` (Quy chuẩn thiết kế quản lý hợp đồng bảo hiểm).
* **[C06]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/237002537_Routing Insurance.md` (Quy tắc định tuyến và A/B testing).
* **[C07]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/219680272_Embedded Insurance Funnel.md` (Phân tích lỗi dữ liệu tracking).
* **[C08]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/158044417_Insurance  Promotion Free-Trial Framework.md` (Khung khuyến mãi mua thử).
* **[C09]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/230292981_[Insurance] Thông tin Sản phẩm - Đối tác để hỗ trợ CS xử lý ticket.md` (Sổ tay vận hành CS, SLA đối tác).
* **[C11]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/194755527_Cyber Risk -VBI-Bảo hiểm an ninh mạng.md` (Chi tiết gói Cyber Risk).
* **[C12]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/132339429_Phone Cracked Screen​ (Bảo hiểm rơi vỡ màn hình).md` (Chi tiết gói Rơi vỡ màn hình).
* **[C13]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/224786861_Fuse - Bảo hiểm Sống tự tin (Credit Topup).md` (Chi tiết gói Sống tự tin).
* **[C14]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/230285552_Fuse - Bảo hiểm Education Học đường vui khỏe.md` (Chi tiết gói Học đường vui khỏe).
* **[C15]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/230287402_Fuse - BH sức khỏe tích lũy.md` (Chi tiết gói Sức khỏe tích lũy).
* **[C16]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/219681037_House Protection Embedded Electricity_Water Domain.md` (Chi tiết gói Bảo hiểm nhà).
* **[C18]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/310009933_Health Insurance - Product Overview.md` (Định nghĩa MiniHealth MSIG).
* **[C20]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/261511567_Chubb  Bill protection auto debit oneflow.md` (Chi tiết gói Sống An Vui).
* **[C21]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/165223140_OTA Travel Insurance phase 1 - Bảo hiểm trên chuyến bay 1 chiều (One-way Flight).md` (Chi tiết gói Trễ hủy chuyến bay).
* **[C23]**: `Wealth Solution/02. Context/Confluence/Insurance/Product Page/153773179_DGS - Thu phí bảo hiểm - Insurance Premium collection.md` (Nghiệp vụ thu hộ phí bảo hiểm nhân thọ).
* **[C29]**: `Wealth Solution/02. Context/Confluence/Insurance/Technical Page/329207148_MoneyTransfer x VBI.md` (Tích hợp Cyber Risk luồng chuyển tiền P2P).

### 17.2 Source Code
* **[S01]**: `internal/bill/constant.go` (Cấu hình hằng số, Supplier ID, Product Line).
* **[S04]**: `internal/bill/service/handle_payment_callback.go` (Callback xử lý giao dịch).
* **[S05]**: `internal/bill/service/deliver.go` (API cấp đơn đối tác).
* **[S09]**: `internal/bill/service/get_policy.go` (Query hiển thị hợp đồng).
* **[S10]**: `internal/bill/service/refund.go` (API hoàn tiền ví).
* **[FE02]**: `insurance-webapp/src/constants/insurancePurchase.ts` (Constants hiển thị FE).
* **[FE03]**: `insurance-webapp/src/features/home/GroupTabs/index.tsx` (Giao diện trang chủ Hub).
* **[FE06]**: `insurance-webapp/src/hooks/useAutodebitInsurance.tsx` (Hook đăng ký trích nợ tự động).

### 17.3 Jira
* **[J01]**: `PCFFS-20739` (Tích hợp hợp đồng bảo hiểm).
* **[J02]**: `PCFFS-21610` (Free trial Sống An Vui).
* **[J03]**: `PCFFS-21609` (Auto-subscription Sống An Vui).
* **[J04]**: `PCFFS-21662` (Logic đóng phí tự động kỳ tiếp theo).
* **[J05]**: `PCFFS-19979` (Agreement Pay cho Cyber Risk).
* **[J06]**: `PCFFS-19980` (FAU segment check giảm tải API).

### 17.4 CS Tickets
* **[CS01]**: `ISSUE-30191` (Paid motorbike but COI not visible).
* **[CS02]**: `ISSUE-35616` (Category filter mismatch).
* **[CS03]**: `ISSUE-37225` (Package selection dispute).
* **[CS04]**: `ISSUE-37457` (Paid but status processing).
* **[CS05]**: `ISSUE-38892` (Premium lookup failure).
* **[CS06]**: `ISSUE-38955` (DOB picker Samsung S25).

### 17.5 Email / Chat
* **[E01]**: `2026-03-20 blocker email` (Lỗi trích ví khuyến mãi).
* **[E02]**: `2026-05-22 free-trial solution email` (Định hướng skip pay).
* **[E03]**: `2026-03-24 VBI feedback` (API quá tải).
* **[E04]**: `2026-05-27 Mini Term Life email` (Quyết định Term Life).
* **[E05]**: `2026-05-28 Bill UI wrap-up` (Tối ưu hóa UI hóa đơn).
* **[E06]**: `2025-12-31 handover email` (Bàn giao scope).
* **[CH01]**: `2026-05-06 chat` (Thống nhất event tracking).

### 17.6 HBS Capstone
* **[O01]**: `Zalopay HBS Capstone Final Presentation vSend.pdf` (Tài liệu nghiên cứu capstone của HBS).
* **[O02]**: `Zalopay HBS Capstone Final Presentation vSend - extracted outline.md` (Outline trích xuất từ deck HBS phục vụ trích dẫn dòng).

---

## 18. Lịch sử Thay đổi (Change Log)

* **v1.3** (2026-06-03 / Antigravity): Bổ sung **Section 5.4: Chi tiết User Flow & UI từng Sản phẩm Bảo hiểm** bao gồm 9 sub-section mô tả chi tiết entry point, bước màn hình, hành vi checkbox, và giao diện Cashier cho toàn bộ danh mục sản phẩm (Sống An Vui, An ninh mạng, Du lịch Chubb, Du lịch/Chuyến đi Saladin, Xe máy SaveMoney, Nhà SaveMoney, Màn hình Igloo, Sống tự tin Fuse, Học đường vui khỏe Fuse) dựa trên mockup audit requirement thực tế.
* **v1.2** (2026-06-03 / Antigravity): Bổ sung **Section 6: Chiến lược Content Message & Hệ thống Cảnh báo** chi tiết hóa wording giao diện mua và thông báo đóng phí tự động trích nợ; khôi phục và hoàn thiện Section 4.4, Section 4.5, và các phần còn lại bị mất do sự cố ghi đè file; cập nhật đánh số các phần tiếp theo.
* **v1.1** (2026-06-03 / GPT 5.5): Mở rộng deep dive nghiệp vụ và yêu cầu của từng sản phẩm bảo hiểm phi nhân thọ và thu hộ.
* **v1.0** (2026-06-03 / GPT 5.5): Khởi tạo tài liệu Product Knowledge Base cho mảng Bảo hiểm.
