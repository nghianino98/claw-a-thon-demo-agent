# Insurance - Product Knowledge Base - GPT 5.5

> Document status: Knowledge base v1.2, prepared on 2026-06-03.
> Purpose: systematize Insurance product knowledge across Confluence, Jira, source code, UI flow, CS tickets, email, and chat so the team can later run a structured product audit.
> Scope note: this document does not assign audit scores yet. It organizes evidence, rules, risks, and open questions for a future `/product-audit` pass.

---

## 0. How To Use This Document

Use this as the master map for Insurance before auditing. The fastest reading path is:

1. Read **Fact Sheet** to understand the product in 10 minutes.
2. Use **Product Taxonomy** and **Surface Map** to know where each insurance line lives.
3. Use **Core Flows** and **Architecture** to understand how money, policy issuance, renewal, refund, and contract management work.
4. Use **Issue Patterns**, **Decision Log**, and **Audit Readiness Matrix** to prepare an actual product audit.
5. Use **HBS 2026 Lens** to compare strategic recommendations with what ZaloPay is actually doing.
6. Use **Source Manifest** at the end to trace every claim back to local Workspace sources.

---

## 1. Fact Sheet

| Attribute | Current knowledge |
|---|---|
| Product name | Insurance / Bảo hiểm on ZaloPay |
| Business role | ZaloPay acts as a digital distribution and premium-collection channel for insurance products across daily payment contexts. |
| Primary branches | **Distribution**: sell insurance via Insurance Hub, embedded checkout, cross-sell, or partner webview. **Collection**: collect recurring life-insurance premiums. |
| Core product lines in Ares | **3081**: life-insurance premium collection. **3275**: Micro Insurance distribution, especially embedded/newer flows. Some older partner-webview or standalone flows may sit outside the full Ares direct-delivery path. |
| Main user surfaces | Insurance Hub, embedded/cross-sell components in Bill/Telco/OTA/Money Transfer, policy/contract management, and premium-collection tab. |
| Main partners / aggregators | SaveMoney, Saladin, Chubb, VBI, Fuse, Igloo, Payoo, Cathay Life, and NNX/Chubb Life in roadmap/integration discussions. |
| Main insurers | ABIC, VNI, MIC, PVI, VBI, Bao Minh, Bảo Việt, Liberty, MSIG, GIC, Bảo Long, Chubb, Generali, MetLife, FWD, Cathay Life. |
| Backend core | `ares`, a Go service described as Insurance core, using RabbitMQ and provider integrations. |
| Frontend snapshot | `insurance-webapp`, React 17 micro-app, with Insurance Hub, cross-sell hooks, standalone hooks, autodebit hooks, and policy management components. |
| Key payment states | Created, PaymentSuccess, DeliverProcessing, DeliverSuccess, DeliverManualCheck, DeliverFailed, Refund init/processing/success/failed. |
| Key policy states | ACTIVE, EXPIRED, CANCELED. |
| Key tracking family | Event family `4072.*` for insurance component load/check/uncheck/view/CTA interactions, plus payment funnel events such as `1130.*`. |
| Product audit lens | Best audited across four lenses: UX & Journey, Financial Safety, Operational Reliability, Trust-Building Over Time. |

---

## 2. Product Ecosystem Visual

```mermaid
graph LR
    User["ZaloPay user"]

    subgraph UI["User-facing surfaces"]
        Hub["Insurance Hub"]
        Embedded["Embedded checkout zones<br/>Bill / Telco / OTA / Money Transfer"]
        Collection["Premium collection tab"]
        Management["Policy / contract management"]
    end

    subgraph Core["Insurance core"]
        Ares["Ares service"]
        Routing["Routing / segment / eligibility"]
        Order["Order + payment status"]
        Deliver["Provider delivery + status polling"]
        Policy["Policy storage / ES index"]
        Refund["Refund / manual check"]
    end

    subgraph Payment["Payment rails"]
        Cashier["Cashier / UserPayment"]
        TPE["TPE refund"]
        Agreement["Agreement Pay / Auto debit"]
    end

    subgraph Partners["Provider / partner layer"]
        Saladin["Saladin"]
        Chubb["Chubb"]
        VBI["VBI"]
        Fuse["Fuse"]
        Igloo["Igloo / PVI"]
        SaveMoney["SaveMoney"]
        Payoo["Payoo"]
        Cathay["Cathay Life"]
    end

    User --> Hub
    User --> Embedded
    User --> Collection
    User --> Management

    Hub --> Ares
    Embedded --> Routing --> Ares
    Collection --> Ares
    Management --> Policy

    Ares --> Order --> Cashier
    Cashier --> Ares
    Ares --> Agreement
    Ares --> Deliver
    Deliver --> Partners
    Partners --> Deliver
    Deliver --> Policy
    Deliver --> Refund --> TPE
```

---

## 3. Product Boundaries

| Boundary | Included | Not fully covered / needs separate evidence |
|---|---|---|
| Distribution | Compulsory motor/auto, travel, cyber, home, health, accident, maternity, critical illness, screen, payer protection, school, office health, confident living, peaceful living, term-life roadmap. | Some products are partner webview or roadmap items. Their final production state needs production config and release evidence. |
| Collection | Premium lookup and payment for life-insurance providers such as Generali, MetLife, FWD, Cathay Life through Payoo/direct integrations. | Insurance underwriting, policy claim handling, or insurer-side servicing are outside ZaloPay's direct product control unless exposed in app. |
| Contract management | Active/expired/canceled policies, category filters, certificate link, some cancel/renewal interactions. | Partner-side certificate delays, insurer issuance SLAs, and external portals need partner/Ops evidence. |
| Autodebit / renewal | Agreement Pay and Auto Debit logic for selected recurring products. | Full root-cause fix for free-trial with non-wallet sources remains an open cross-platform dependency. |
| Audit data | Confluence, Jira, source code, CS tickets, emails, chats. | Local `Fact/Data/Insurance` has no usable snapshot found in this pass; dashboard links exist but need current extraction for quantitative audit. |

---

## 4. Product Taxonomy

### 4.1 Product Line Map

| Branch | Category | Product / flow | App IDs / surfaces | Partner / supplier | Source notes |
|---|---|---|---|---|---|
| Distribution | Compulsory | Motorbike insurance | 1020, 3951, 4326 | SaveMoney, Saladin / ABIC, VNI, PVI, VBI, Bao Minh, MIC | C01, C02 |
| Distribution | Compulsory | Auto insurance | 3507, 3951 | SaveMoney, Saladin / MIC, Tasco, HDI, PVI, Bảo Việt, Bao Minh | C01 |
| Distribution | Travel | Flight delay/cancel and baggage | 3274 embedded OTA flight | Saladin / Bảo Việt | C01, C02 |
| Distribution | Travel | Chubb travel domestic / international | 3834 flight embedded/cross-sell | Chubb | C01 |
| Distribution | Travel | Trip / bus insurance | 3676 bus embedded | Saladin / Bảo Việt | C01 |
| Distribution | Cyber | Cyber risk | 3682 Telco Topup embedded, Money Transfer cross-sell | VBI | C01, C02, J05, E01, E02, E03 |
| Distribution | Home | Private home | 3835 standalone and embedded bill scenarios | SaveMoney / ABIC | C01, C02 |
| Distribution | Health | Health, accident, maternity, critical illness | 3951 standalone / hub | Saladin and insurer partners | C01, C02 |
| Distribution | Embedded bill | Payer protection | 2390 bill embedded | Saladin / Bảo Việt | C01, C02 |
| Distribution | Embedded bill | Confident living | 4015 CF/Bill embedded | Fuse / GIC | C01, C02 |
| Distribution | Embedded bill | Cracked screen | 3394 phone-card flow | Igloo / PVI | C01, C02 |
| Distribution | Embedded bill | Peaceful living / bill protection | 4491 bill embedded | Chubb | C01, C02, J03 |
| Distribution | Embedded bill | School insurance | 4041 Edu bill embedded | Fuse / GIC | C01, C02 |
| Distribution | Embedded bill | Office health accumulate | 4042 Telco phone-card/postpaid context | Fuse / Bảo Long | C01, C02 |
| Collection | Premium collection | Life-insurance premium payment | 3232, 3082 | Payoo, Cathay Life / Generali, MetLife, FWD, Cathay | C01, S11 |

### 4.2 SKU And Benefit Anchors

This table is an audit anchor, not a full pricing catalog. For exact benefits and legal wording, use the portfolio source and partner policy docs.

| Sản phẩm | Neo giá/quyền lợi | Hàm ý khi audit |
|---|---|---|
| Xe máy SaveMoney | Portfolio có các lựa chọn thời hạn cố định như 1/2/3 năm. | Cần kiểm tra user có chọn đúng gói, hiểu đúng thời hạn và nhận chứng nhận ổn định sau thanh toán hay không. |
| Bảo hiểm Người Thanh Toán | Một số bill context dùng mức phí cố định thấp theo tháng; điện/nước có thể tính theo phần trăm giá trị bill. | Cần tách rõ "phí bảo hiểm" và "tiền hóa đơn", tránh user tưởng phí bảo hiểm là phí dịch vụ của bill. |
| Sống An Vui / Sống Tự Tin | Portfolio có các gói theo tháng. | Cần kiểm tra consent gia hạn/subscription, quyền hủy và cách giải thích phí định kỳ. |
| An ninh mạng | Phí thấp theo tháng/năm, bảo vệ một số rủi ro số và có thêm quyền lợi tai nạn. | Cần soi kỹ điều kiện đủ điều kiện, logic user đầu tiên/free trial và cách giảm tải API đối tác. |
| Du lịch / chuyến bay / hành lý | Bán trong OTA context, có lúc embedded, có lúc cross-sell. | Cần rõ điều kiện áp dụng theo hành trình, hủy/hoàn, ngoại lệ visa/refund và thời điểm cấp chứng nhận. |
| Nhà | Có gói embedded phí thấp theo tháng và gói standalone theo năm. | Cần phân biệt phạm vi bảo vệ standalone với offer gắn theo hóa đơn điện/nước. |
| Màn hình điện thoại | Phí theo bậc quyền lợi. | Cần rõ bước xác thực thiết bị, hướng dẫn IMEI/hình ảnh và đường claim. |
| Thu phí bảo hiểm | Tra cứu và thanh toán phí cho hợp đồng nhân thọ đã có. | Cần xử lý rõ partner maintenance và boundary "ZaloPay chỉ thu hộ/hiển thị, không phải nhà bảo hiểm". |

### 4.3 Chi Tiết Business & Product Theo Từng Sản Phẩm

Phần này viết theo góc nhìn business/product, để PO/PM nhanh chóng nắm được từng sản phẩm bảo hiểm đang bán, bán ở đâu, bán cho ai, tạo giá trị gì, rule nào quan trọng và khi audit cần soi điểm nào. Các quyền lợi/phí bên dưới là "product anchor" từ Workspace; khi dùng cho nội dung pháp lý, policy wording hoặc audit compliance vẫn cần đối chiếu lại bản T&C/chứng nhận bảo hiểm mới nhất của đối tác.

#### 4.3.1 Bảo hiểm Xe Máy Bắt Buộc / TNDS

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 4326 cho luồng in-app SaveMoney direct API; AppID 1020 và 3951 cho các luồng partner/webview SaveMoney/Saladin; nằm trong Hub bảo hiểm và các entrypoint O2O/management. |
| Đối tác / Nhà bảo hiểm | SaveMoney là đối tác chính trong luồng direct API; portfolio cũ có ABIC, VNI, MIC, PVI, VBI, Bảo Minh tùy theo luồng/đối tác. |
| Bài toán business | Đây là sản phẩm "need-based" và gắn với nhu cầu bắt buộc pháp lý. Business value không nằm ở upsell phức tạp mà nằm ở volume ổn định, sự tiện lợi, và khả năng giữ user trong Hub bảo hiểm thay vì đẩy qua webview đối tác. |
| Khách hàng / context | Chủ xe máy cần mua TNDS nhanh, cần nhận chứng nhận điện tử để chứng minh khi được kiểm tra. Nhu cầu rất cụ thể: chọn loại xe, điền biển số, nhận giấy chứng nhận. |
| Product proposition | "Mua bảo hiểm xe máy bắt buộc nhanh trên ZaloPay"; luồng in-app giúp autofill thông tin KYC nếu là xe của tôi, giảm việc user phải nhập lại nhiều trường như webview đối tác. |
| Gói / giá / quyền lợi anchor | Luồng SaveMoney in-app có chip loại xe: xe > 50cc, xe <= 50cc, xe máy điện, mô tô 3 bánh và xe cơ giới khác. Giá 1 năm trong PRD: xe > 50cc 66.000đ, xe <= 50cc 60.500đ, xe máy điện 60.500đ, mô tô 3 bánh/xe cơ giới khác 319.000đ. Portfolio cũ cũng có option 1/2/3 năm cho một số gói SaveMoney. |
| Journey sản phẩm | User vào Hub/entrypoint xe máy, chọn loại xe, nhập biển số, chọn "xe của tôi" hoặc "xe người khác". Nếu xe của tôi và user đã KYC, hệ thống autofill tên, số điện thoại, email, địa chỉ; nếu xe người khác thì user tự nhập. Sau thanh toán, user cần vào quản lý hợp đồng/xem chứng nhận. |
| Rule vận hành | CS product table ghi không hoàn/hủy. Contract/certificate visibility là điểm cực kỳ quan trọng vì đây là bảo hiểm bắt buộc. |
| Audit lens | Kiểm tra gói >50cc / <=50cc / xe điện có đủ rõ không, có confirm lại gói trước thanh toán không, chứng nhận có hiển thị ngay không, category "Ô tô - Xe máy - Tai nạn" có map đúng không, và log package có khớp với UI user đã chọn không. |

#### 4.3.2 Bảo hiểm Ô Tô TNDS / Vật Chất Ô Tô

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 3507 SaveMoney; AppID 3951 Saladin webview/hub đối tác. Product overview ghi cả TNDS ô tô và vật chất ô tô tùy đối tác. |
| Đối tác / Nhà bảo hiểm | SaveMoney và Saladin; insurer trong overview gồm MIC, Tasco, HDI, PVI, Bảo Việt, Bảo Minh. |
| Bài toán business | Sản phẩm có giá trị giao dịch cao hơn xe máy, gắn với nhóm user có ô tô và nhu cầu bắt buộc/tự nguyện. Do underwriting phức tạp hơn xe máy nên nhiều luồng có thể phụ thuộc webview/đối tác. |
| Khách hàng / context | Chủ xe ô tô cần TNDS bắt buộc, có thể cần thêm vật chất xe. User kỳ vọng thông tin xe, mục đích sử dụng, gói bảo vệ, thời hạn và giấy chứng nhận rõ ràng. |
| Product proposition | ZaloPay đóng vai trò là kênh điều hướng, thanh toán và có thể lưu/quản lý hợp đồng. Lợi ích chính là convenience và tập trung trong một Hub tài chính. |
| Gói / giá / quyền lợi anchor | Workspace chỉ có catalog-level: TNDS ô tô và TNDS + vật chất ô tô. Cần bổ sung bảng giá/chứng nhận từ đối tác nếu audit sau. |
| Journey sản phẩm | User vào Hub bảo hiểm, chọn ô tô, có thể vào webview đối tác Saladin/SaveMoney để nhập thông tin và thanh toán; sau đó cần certificate/management link trong ZaloPay nếu luồng đã được tích hợp. |
| Rule vận hành | CS product table ghi nhóm SaveMoney không hoàn/hủy; với Saladin mweb thì chính sách hoàn/hủy phụ thuộc đối tác và CS ZaloPay tiếp nhận/chuyển đối tác. |
| Audit lens | Cần audit rõ boundary: user đang mua qua ZLP core hay partner webview? Certificate về ZLP hay chỉ ở đối tác? User có biết ZaloPay là trung gian thanh toán/hiển thị không? |

#### 4.3.3 Bảo hiểm Chuyến Bay Saladin / Bảo Việt

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 3274, embedded trong OTA Flight; zone flight nội địa và transaction details trong tracking map. |
| Đối tác / Nhà bảo hiểm | Saladin phân phối, Bảo Việt bảo hiểm. |
| Bài toán business | Upsell trên luồng đặt vé máy bay, tận dụng context user vừa mua một chuyến đi có rủi ro trễ/hủy chuyến, mất/hỏng hành lý. PRD dự báo traffic ticket OTA hằng tháng và take rate cho insurance, với CR dự đoán cho Flight Delay & Cancel cao hơn các gói khác. |
| Khách hàng / context | User đang mua vé máy bay, có nhu cầu bảo vệ rủi ro liên quan trực tiếp đến hành trình. Vì đây là host journey OTA, insurance phải không làm hỏng conversion mua vé. |
| Product proposition | "An tâm bay khi được bảo vệ toàn diện"; user mua bảo hiểm ngay trong màn hình dịch vụ bổ sung/cashier/result. |
| Gói / giá / quyền lợi anchor | PRD Saladin OTA có 3 gói: Trễ và hủy chuyến bay 30.000đ/vé/chuyến/khách, bồi thường 400.000đ nếu trễ trên 2h hoặc hủy theo điều kiện; Mất/hỏng hành lý 15.000đ, quyền lợi lên đến 15.000.000đ; Du lịch nội địa 45.000đ, tai nạn cá nhân lên đến 250.000.000đ và trễ chuyến trên 3h 800.000đ. Giá có thể do Saladin respond theo API. |
| Journey sản phẩm | User chọn gói tại màn hình dịch vụ bổ sung flight, thanh toán multi-order trên Cashier, result page hiển thị trạng thái giao dịch và chứng nhận. Nếu mua sau booking thành công, cross-sale có thể autofill thông tin chuyến bay tại result/booking detail. |
| Rule sản phẩm | Điều kiện nổi bật: mua tối thiểu 3h trước giờ khởi hành; nếu sửa thông tin/đổi lịch do cá nhân hoặc hãng bay cần thông báo Saladin ít nhất 3h trước khởi hành; cá nhân 6 tháng đến 80 tuổi; chuyến bay nội chuyến và một số trường hợp loại trừ không được chi trả. |
| Hoàn/hủy / claim | CS table: nếu hủy do opt-out, ZLP CS thuyết phục trước, nếu không thành công gửi Saladin để hủy GCN và hoàn tiền; yêu cầu phải trước giờ khởi hành, với Flight doc ghi trước 3h. Claim cần thông báo trong 30 ngày và nộp hồ sơ trong 30 ngày sau khi thông báo; Saladin/Bảo Việt xử lý claim theo SLA tại T&C. |
| Audit lens | Kiểm tra default opt-out/opt-in có phù hợp, user có hiểu đây là gói riêng theo từng vé/khách/chuyến, điều kiện 3h trước khởi hành có được chặn bằng hệ thống không, và status certificate có rõ khi provider delivery pending. |

#### 4.3.4 Bảo hiểm Du Lịch Chubb Flight Insurance

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 3834, Flight embedded/cross-sell; tracking map có zone cho Flight, ResultPage, TransactionDetails. |
| Đối tác / Nhà bảo hiểm | Chubb Việt Nam. ZaloPay tích hợp API quote, approve/issue và retrieve COI. |
| Bài toán business | Mở rộng bảo hiểm du lịch ngoài Saladin, có thể routing theo UID để user không bị so sánh 2 gói/2 nhà bảo hiểm trong cùng context. Sản phẩm phù hợp cho chuyến bay nội địa/quốc tế xuất phát từ Việt Nam. |
| Khách hàng / context | User đặt vé máy bay trên ZaloPay, cần bảo vệ tai nạn, hoàn/hủy, trễ chuyến, hành lý. |
| Product proposition | Bảo vệ du lịch "toàn diện hơn" với quyền lợi tai nạn cao, hoàn/hủy chuyến, hành lý chậm trễ, và dịch vụ hỗ trợ khẩn cấp toàn cầu. COI được hiển thị trên ZaloPay app, không cần Chubb gửi email/OA trong luồng Chubb Travel. |
| Gói / giá / quyền lợi anchor | Component highlight: tai nạn cá nhân lên đến 210 triệu; hoàn/hủy chuyến bay nội địa lên đến 5 triệu, quốc tế lên đến 10 triệu; hành lý bị chậm trễ đến 1 triệu/1,6 triệu tùy source; người được bảo hiểm từ 6 tuần đến 85 tuổi. |
| Journey sản phẩm | ZaloPay gọi Quote/Approve trước thanh toán và Issue sau thanh toán thành công; COI Retrieve API trả base64 document để app convert/hiển PDF on demand. |
| Rule sản phẩm | Chỉ áp dụng chuyến bay xuất phát từ Việt Nam; sản phẩm chỉ mua theo vé máy bay trên ZaloPay; sửa thông tin/đổi lịch cần thông báo Chubb ít nhất 3h trước khởi hành; hủy/hoàn phí chỉ trong trường hợp visa bị từ chối theo điều kiện. |
| Hoàn/hủy / claim | CS table ghi Chubb Flight Insurance không hủy/hoàn sau thanh toán, trừ visa refusal và một số case hãng không bảo lưu không có hạn chính xác. Claim có thể gửi online, email hoặc bưu điện trong 30 ngày từ sự kiện; Chubb xử lý trong 7 ngày làm việc sau khi nhận đủ tài liệu theo T&C. |
| Audit lens | Kiểm tra routing Saladin vs Chubb có ổn định theo user, user có biết sản phẩm chỉ áp dụng từ Việt Nam, COI retrieve có nhanh/ổn định, thông tin applicant/traveller có đủ chính xác không, và điều kiện visa refusal có đủ minh bạch. |

#### 4.3.5 Bảo hiểm Chuyến Đi Xe Bus / Trip Protection

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 3676, embedded trong OTA Bus, zoneID 91 theo tracking map. |
| Đối tác / Nhà bảo hiểm | Saladin phân phối, Bảo Việt bảo hiểm. |
| Bài toán business | Mở rộng insurance vào bus ticket, dùng multi-order dependent flow. Business value là tăng transaction/MPU/TPV/revenue Insurance từ context vé xe, với take rate PRD ghi 30%. |
| Khách hàng / context | User đang đặt vé xe bus, cần bảo vệ rủi ro tai nạn/chậm/hủy chuyến, hoàn tiền vé trong case bất khả kháng. |
| Product proposition | Quyền lợi bảo vệ lên đến 200.000.000đ; hỗ trợ viện phí tai nạn 300.000đ/ngày; hoàn tiền vé thực thanh toán nếu bị hủy chuyến bất khả kháng. |
| Gói / giá / quyền lợi anchor | Trip Protection phí 10.000đ/chỗ ngồi/chuyến; ghế đôi/giường đôi phí nhân đôi và quyền lợi tai nạn tương ứng cho 2 người/ghế. |
| Journey sản phẩm | Hiển thị section bảo hiểm trên màn hình thông tin đặt vé; với booking thanh toán ngay, status có thể là thành công/đang xử lý/thất bại; với flow giữ chỗ thanh toán sau, order bảo hiểm có processing/expired theo countdown 15 phút. |
| Rule vận hành | Nếu delivery thành công, user có link xem chi tiết/chứng nhận. Nếu delivery pending, UI cần show "Đang chờ cấp giấy chứng nhận"; nếu fail thì không show status component. |
| Hoàn/hủy / claim | CS table: yêu cầu hủy phải trước giờ khởi hành theo lịch trình; Saladin xử lý trong 24h ngày làm việc, holiday thì phản hồi ngày làm việc đầu tiên sau lễ. |
| Audit lens | Kiểm tra đồng bộ status giữa OTA booking và insurance order, expired countdown có đúng, và user có nhận biết bảo hiểm gắn với số ghế/vé nào. |

#### 4.3.6 Bảo hiểm An Ninh Mạng VBI / Cyber Risk

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 3682, Telco Topup embedded, Insurance Hub, Money Transfer ResultPage/TransactionDetails cross-sell. |
| Đối tác / Nhà bảo hiểm | VBI. |
| Bài toán business | Sản phẩm micro-insurance mới để tăng MPU/TPV/revenue, uplift thanh toán Telco và cross-sell trong Money Transfer. Business sharing trong PRD ghi commission sharing 20%. |
| Khách hàng / context | Chủ ví ZaloPay dùng giao dịch digital, có rủi ro lừa đảo/tấn công mạng/gian lận online. Context bán ban đầu là Telco Topup, sau đó mở rộng MT vì user đang chuyển tiền và có awareness về rủi ro tài chính số. |
| Product proposition | VBI bảo vệ chủ ví trước rủi ro tấn công mạng; phí nhỏ theo tháng/năm; gói năm có discount và chia nhỏ thành 12 lần thanh toán. |
| Gói / giá / quyền lợi anchor | PRD có Pack 1 gói tháng 5.000đ/lần, 60.000đ/năm, quyền lợi cyber 10.000.000đ/vụ tối đa 25.000.000đ/năm và tai nạn cá nhân đến 10.000.000đ; Pack 2 gói năm 3.000đ/lần, 36.000đ/năm, quyền lợi cyber 10.000.000đ/vụ tối đa 50.000.000đ/năm và tai nạn cá nhân đến 10.000.000đ. |
| Journey sản phẩm | Component embedded có checkbox, bottom sheet 3 tab: quyền lợi, yêu cầu bồi thường, FAQ. Sau thanh toán thành công, result page có CTA đăng ký "bảo hiểm tự động"; nếu đã có lịch sử thanh toán thì hiển thị progress 12 kỳ và entrance auto debit. |
| Rule auto debit | Chỉ cho đăng ký auto debit khi user có hợp đồng 1 năm hiệu lực, chưa có AgreementID hiệu lực cho hợp đồng đó, và thời gian đến hạn kỳ tiếp theo > 7 ngày. PRD go-live auto debit note nguồn tiền chỉ mở nguồn Ví. |
| Promotion/free trial | Free trial/direct discount là growth hook lớn nhưng bị blocker với nguồn tiền ngoài ví/Agreement Pay; giải pháp dài hạn được discuss là skip pay kỳ đầu, issue policy chủ động, mark transaction kỳ đầu để đối soát. |
| Hoàn/hủy / ops | CS table: refund/hủy cần gửi trans ID sang VBI để cancel trên MC tool; SLA refund VBI 24h không tính ngày lễ. VBI từng feedback ZLP call API verify quá nhiều, cần lưu/quản lý status nội bộ và dùng segment-first logic. |
| Audit lens | Cyber là sản phẩm cần audit sâu nhất về financial safety: free trial, direct discount, source of funds, auto debit, renewal, API load, segment eligibility, và thông điệp "đang được bảo vệ" theo từng kỳ đóng phí. |

#### 4.3.7 Bảo hiểm Nhà PVI / Private Home

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 3935 cho micro embedded electricity/water domain; AppID 3835 cho standalone/hub theo portfolio; older SaveMoney webview có AppID 1020 cho bảo hiểm nhà. |
| Đối tác / Nhà bảo hiểm | SaveMoney phân phối, PVI bảo hiểm. |
| Bài toán business | Cross-sell trong thanh toán hóa đơn điện/nước: khi user vừa thanh toán hóa đơn gắn với địa chỉ nhà, hệ thống có context tự nhiên để đề xuất bảo vệ nhà theo địa chỉ hóa đơn. |
| Khách hàng / context | Chủ nhà, người thuê nhà hợp pháp, hoặc người thanh toán hóa đơn cho căn nhà. User có thể không phải chủ hợp đồng/người thuê, nhưng căn nhà theo hóa đơn vẫn được bảo hiểm theo T&C. |
| Product proposition | Bảo vệ ngôi nhà có địa chỉ theo mã hóa đơn trước rủi ro cháy nổ, sét đánh, nước tràn từ bể chứa, trộm cắp; đồng thời có quyền lợi tai nạn cho chủ hộ. |
| Gói / giá / quyền lợi anchor | Gói cơ bản 3.000đ/tháng: tổng quyền lợi 100.000.000đ, khung nhà 80.000.000đ, tài sản trong nhà 10.000.000đ, tai nạn chủ hộ 10.000.000đ. Gói nâng cao 10.000đ/tháng: tổng quyền lợi 180.000.000đ, khung nhà 100.000.000đ, tài sản trong nhà 50.000.000đ, tai nạn chủ hộ 30.000.000đ. Mức miễn thường 1.000.000đ. |
| Journey sản phẩm | User thanh toán hóa đơn, component hiển thị title/price/quyền lợi; user bấm tìm hiểu thêm để xem T&C; tổng tiền thanh toán phải tách tiền hóa đơn và tiền bảo hiểm; result page hiển thị dịch vụ Bảo hiểm Nhà PVI. |
| Rule sản phẩm | Áp dụng cho địa chỉ nhà theo mã hóa đơn đã thanh toán kèm giao dịch bảo hiểm. Update 2025 yêu cầu truyền mã bill và địa chỉ mã bill bắt buộc để query gói/cấp hợp đồng. Một khách hàng đang có hợp đồng nhà chưa hết hạn thì không mua thêm bảo hiểm nhà khác. |
| Hoàn/hủy / ops | CS table ghi không hoàn/hủy; đối tác phản hồi 2-3 ngày làm việc. API createHomeInsurance UAT từng bị note latency >1 phút, cần đối chiếu production. |
| Audit lens | Kiểm tra context "địa chỉ theo hóa đơn" có đủ minh bạch, có tách tiền bảo hiểm vs tiền hóa đơn, có chặn duplicate active policy, và có hiển thị mức miễn thường 1 triệu để tránh kỳ vọng sai về claim nhỏ. |

#### 4.3.8 Bảo hiểm Người Thanh Toán / Payer Protection

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 2390, embedded trong các bill context như điện/nước/internet/CF/Edu theo portfolio/routing. |
| Đối tác / Nhà bảo hiểm | Saladin phân phối, Bảo Việt bảo hiểm. |
| Bài toán business | Micro-insurance gắn với hành vi thanh toán hóa đơn: user đang trả một khoản chi phí định kỳ, nên đề xuất bảo vệ người thanh toán nếu có rủi ro tai nạn/sức khỏe ảnh hưởng khả năng chi trả. |
| Khách hàng / context | User thanh toán hóa đơn điện/nước/internet/credit/education. Sản phẩm nhắm vào "người thanh toán" thay vì tài sản/hợp đồng gốc. |
| Product proposition | Phí rất nhỏ theo bill/context; quyền lợi giải thích theo cách "bảo vệ người thanh toán" và với điện/nước có thể bằng % giá trị bill. |
| Gói / giá / quyền lợi anchor | Portfolio ghi CF/Edu 10.000đ, Internet/TV 2.000đ, Electric/Water 1% bill amount. Routing doc ghi payer protection có quyền lợi tai nạn gấp 100 lần giá trị hóa đơn thanh toán trong scenario so sánh với Chubb. |
| Journey sản phẩm | Embedded component trên bill detail/cashier, user tick/untick; tracking 4072 cho load/check/untick; có thể routing với Bảo hiểm Sống Tự Tin hoặc Home theo context. |
| Rule vận hành | CS table ghi không hoàn/hủy. Source of funds all SOF, theo hạn mức ví tối đa 20 triệu. |
| Audit lens | Cần audit copy "1% bill amount" và quyền lợi tương ứng có dễ hiểu không, user có biết đây là sản phẩm riêng không hoàn/hủy không, và có làm tăng friction của bill payment không. |

#### 4.3.9 Bảo hiểm Sống An Vui / Chubb Bill Protection

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 4491, embedded/cross-sell trong Bill; có autodebit. |
| Đối tác / Nhà bảo hiểm | Chubb Viet Nam. |
| Bài toán business | Thay thế/bổ sung payer protection bằng sản phẩm tai nạn cá nhân có giá cố định, để A/B test so với Payer Protection Saladin trên bill điện và các bill context. |
| Khách hàng / context | User đang thanh toán hóa đơn, có thể muốn một gói bảo vệ tai nạn cá nhân giá thấp, đăng ký theo tháng, hủy linh hoạt. |
| Product proposition | "Sống An Vui" là bảo hiểm tai nạn cá nhân cho người thanh toán, quyền lợi rõ ràng theo gói 3.000đ/5.000đ tháng, có option quà tặng tư vấn sức khỏe tâm lý 3 tháng trong một số SKU. |
| Gói / giá / quyền lợi anchor | 4 SKU: 3.000đ/tháng quyền lợi tai nạn 15.000.000đ, có/không stress management; 5.000đ/tháng quyền lợi tai nạn 30.000.000đ, có/không stress management. Component AB phase so sánh payer protection 30% traffic, Chubb 5.000đ + gift 35%, Chubb 5.000đ no gift 35%. |
| Journey sản phẩm | User tick mua bảo hiểm, toggle auto debit được enable; nếu giữ toggle ON thì đăng ký auto debit kèm payment, nếu OFF thì không đăng ký auto debit. Nếu đang có hợp đồng hiệu lực ngoài khung thanh toán manual, UI hiển thị "đang có hợp đồng bảo vệ" và link quản lý hợp đồng. |
| Rule coverage/renewal | Mỗi user chỉ có 1 hợp đồng/COI active. COI cấp theo năm, nhưng phí đóng hằng tháng trong 12 tháng. Kỳ đầu thanh toán trước khi hiệu lực; kỳ tiếp theo phải thanh toán trong khung Coverage End Date + 7 ngày. Qua due date + 1, hệ thống gọi hủy COI nếu không có thanh toán gia hạn. |
| Hoàn/hủy | Chubb có freelook hoàn 100% phí kỳ đầu nếu user hủy trong 14 ngày đầu sau khi mua/cấp COI. Sau 14 ngày không hoàn phí; hủy bất kỳ lúc nào thì không thu phí tháng tiếp theo và hợp đồng hết sau kỳ đã thanh toán gần nhất. |
| Điều kiện | Tuổi 18 đến 65; không bảo vệ bệnh tật, tập trung tai nạn cá nhân; có điều khoản cấm vận và nghĩa vụ khai báo trung thực. |
| Audit lens | Đây là sản phẩm rủi ro UX cao vì bill autodebit và insurance renewal cùng xuất hiện trên bill detail. Audit cần test consent, toggle, copy "hằng tháng", freelook 14 ngày, cancel path trong quản lý hợp đồng, và việc auto-cancel khi quá D8. |

#### 4.3.10 Bảo hiểm Sống Tự Tin / Fuse - GIC

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 4015, embedded trong Credit Topup/CF/Bill và Telco routing; có thể xuất hiện trong Hub zone. |
| Đối tác / Nhà bảo hiểm | Fuse Online phân phối, GIC bảo hiểm. |
| Bài toán business | Bán micro-insurance giá thấp trong các context thanh toán liên quan đến credit/loan/telco, tạo proposition "tự tin" trước rủi ro tai nạn và thất nghiệp. |
| Khách hàng / context | User thanh toán khoản vay/hóa đơn hoặc mua telco, có nhạy cảm với rủi ro mất thu nhập, tai nạn, không đủ khả năng tiếp tục chi trả. |
| Product proposition | Phí 4.000đ/tháng; bảo vệ tai nạn cá nhân quyền lợi đến 5.000.000đ và trợ cấp thất nghiệp 2.000.000đ khi doanh nghiệp phá sản/cắt giảm nhân sự diện rộng. |
| Journey sản phẩm | Embedded component hiển thị title, price, subtext, logo GIC x Fuse; Cashier/Result page hiển thị service và provider; certificate gửi trong mục Bảo hiểm > Quản lý Hợp đồng. |
| Rule sản phẩm | Điều kiện T&C update có thêm "không đang trong quá trình điều trị thương tật"; consent cho Fuse/GIC chia sẻ thông tin hợp đồng cho ZaloPay để hiển thị trên nền tảng. |
| Hoàn/hủy | Khách hàng có thể hủy và hoàn phí nếu yêu cầu trong vòng 3 ngày từ thời điểm thanh toán thành công và chưa nhận tiền bồi thường từ GIC; nếu muốn hủy hợp đồng liên hệ CS Fuse. |
| Audit lens | Kiểm tra user có hiểu đây là tai nạn + trợ cấp thất nghiệp, không phải bảo hiểm thất nghiệp rộng; consent chia sẻ data; hoàn phí 3 ngày; và routing với Cyber/Payer có hợp lý không. |

#### 4.3.11 Bảo hiểm Rơi Vỡ Màn Hình Điện Thoại / Igloo - PVI

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 3394, bán kèm trong PhoneCard/Buycard, zoneID 5 routing; cũng có Hub zone theo tracking map. |
| Đối tác / Nhà bảo hiểm | Igloo/Axinan phân phối/portal, PVI bảo hiểm. |
| Bài toán business | Micro add-on khi user mua thẻ điện thoại; ticket size nhỏ, gắn với tài sản "điện thoại" mà user đang dùng. |
| Khách hàng / context | User mua thẻ điện thoại, có nhu cầu bảo vệ màn hình điện thoại trước vỡ/nứt/hư hỏng vật lý. |
| Product proposition | "Không lo rủi ro vỡ màn hình"; thủ tục bồi thường online, mang thiết bị đến trung tâm sửa chữa đối tác. |
| Gói / giá / quyền lợi anchor | 3 gói tháng: 7.700đ quyền lợi 1.000.000đ, 12.100đ quyền lợi 2.000.000đ, 17.600đ quyền lợi 3.000.000đ; thời hạn 1 tháng. |
| Journey sản phẩm | User tick checkbox trong Buycard, chọn gói, thanh toán; result page nếu thành công có CTA "Kích hoạt bảo hiểm" để redirect sang portal Igloo; trong management có CTA xác thực thiết bị và xem chứng nhận. |
| Rule xác thực | User cần xác thực IMEI/thiết bị trên portal Igloo, có thể xác thực ngay sau thanh toán hoặc tối đa 30 ngày sau khi mua. Sau khi xác thực thành công, cần chờ ít nhất 24h mới yêu cầu bồi thường. Mỗi đơn bảo hiểm chỉ claim một lần. |
| Hoàn/hủy | CS table ghi user có thể hủy trong 24h nếu gói chưa được xác thực và chịu phí hoàn trả 1.100đ; FAQ trong product page ghi thời gian cân nhắc 48h và sau 48h có thể hoàn 70% phí theo thời hạn còn lại, cũng trừ phí 1.100đ. Đây là điểm cần reconcile vì hai source có khác nhau. |
| Claim | Claim trên portal Igloo: đăng nhập bằng số điện thoại/OTP, chọn đơn, tạo yêu cầu, chọn trung tâm sửa chữa, mang máy đến sửa. Cần báo sự cố trong 3 ngày và mang thiết bị đến trung tâm trong 7 ngày kể từ khi khai báo. |
| Audit lens | Kiểm tra rule 24h vs 48h trong CS/FAQ, xác thực IMEI có đủ dễ để user làm, claim path có rõ, và có tránh bán cho user nhưng sau đó không xác thực được thiết bị. |

#### 4.3.12 Bảo hiểm Học Đường Vui Khỏe / Fuse - GIC

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 4041, embedded trong ngữ cảnh bill học phí. |
| Đối tác / Nhà bảo hiểm | Fuse Online phân phối, GIC bảo hiểm. |
| Bài toán business | Bán bảo hiểm theo ngữ cảnh thanh toán học phí, dùng data bill học phí để xác định học sinh/sinh viên và nhu cầu bảo vệ trong năm học. |
| Khách hàng / context | Phụ huynh/người giám hộ thanh toán học phí cho học sinh, hoặc người được bảo hiểm từ 18 tuổi trở lên tự thanh toán. |
| Product proposition | Phí 10.000đ/tháng, chia nhỏ thành 6 hoặc 12 kỳ; bảo vệ bệnh học đường, tai nạn/bệnh tật khác, bạo lực học đường. |
| Gói / quyền lợi anchor | Gói 6 tháng 60.000đ và gói 1 năm 120.000đ, cùng 10.000đ/tháng. Quyền lợi component: bệnh học đường đến 5.000.000đ, tai nạn & bệnh tật khác đến 13.000.000đ, bạo lực học đường đến 6.000.000đ. Bảng T&C giải thích gói trung cấp: nằm viện bệnh học đường 200.000đ/ngày tối đa 5.000.000đ/năm, điều trị ngộ độc thực phẩm 1.500.000đ, điều trị y tế do tai nạn 1.500.000đ, nằm viện >60 ngày tối đa 10.000.000đ, bạo lực học đường 5.000.000đ, gián đoạn học tập tối đa 1.000.000đ. |
| Journey sản phẩm | Stage 1 chưa có hợp đồng: user mua khi thanh toán học phí. Stage 2 đang có hợp đồng: component cho thanh toán tiếp kỳ sau, hiển thị hiệu lực đến ngày nào, đã thanh toán X/12 hoặc X/6 kỳ, link xem chứng nhận. Stage 3 đóng đủ kỳ: hiển thị đang được bảo vệ và không tiếp tục đóng. |
| Eligibility | GIC yêu cầu học sinh từ 6 tuổi trở lên; bạo lực học đường áp dụng 6-23 tuổi, tai nạn/bệnh tật 6-40 tuổi. ZLP validate theo DOB nếu có; nếu DOB thiếu thì xét tên trường và lớp. Nếu không có dữ liệu xác định thì không show bán. |
| Hoàn/hủy | Có thể hủy/hoàn phí nếu yêu cầu trong 3 ngày từ thanh toán phí kỳ đầu và chưa phát sinh tổn thất. Các lần thanh toán phí bổ sung cho kỳ sau không áp dụng hoàn phí. Sản phẩm không tự gia hạn; user mua đơn mới khi đến đợt thanh toán tiếp theo. |
| Audit lens | Kiểm tra data bill học phí có đủ chuẩn để không bán sai đối tượng, copy về mối quan hệ BMBH/NDBH có rõ, 6/12 kỳ có dễ hiểu, và không gây hiểu nhầm là bảo hiểm tự gia hạn. |

#### 4.3.13 Bảo hiểm Sức Khỏe Tích Lũy / Fuse - Bảo Long

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 4042, embedded trong Postpaid/Telco; tracking map có Office Health/accumulated management. |
| Đối tác / Nhà bảo hiểm | Fuse Online phân phối, Bảo Long bảo hiểm. |
| Bài toán business | Tạo sản phẩm "tích lũy quyền lợi" từ từng giao dịch nhỏ, phù hợp context thanh toán định kỳ/postpaid. Đây là micro-payment health proposition: phí nhỏ nhưng tăng dần quyền lợi. |
| Khách hàng / context | User thanh toán Telco/postpaid, có thể mua gói sức khỏe chi phí thấp để tích lũy quyền lợi y tế theo số lần đóng phí/giao dịch. |
| Product proposition | Phí 2.400đ/giao dịch/kỳ; hỗ trợ chi phí y tế đến 20.000.000đ/năm cho các bệnh: thoát vị đĩa đệm, sốt xuất huyết, trĩ, hội chứng ống cổ tay, giãn tĩnh mạch; thêm trợ cấp nằm viện do tai nạn. |
| Journey sản phẩm | Stage 1 chưa có hợp đồng: component opt-in, user tick bảo hiểm thì đồng thời tick consent; nếu untick consent thì untick bảo hiểm. Stage 2 đã có hợp đồng nhưng chưa đạt maximum: không hiển thị lại consent, thêm endorsement/tích lũy thêm giao dịch vào hợp đồng. Stage 3 đã đóng đủ maximum: hiển thị quyền lợi tích lũy và chứng nhận. |
| Quản lý quyền lợi | Trang listing hợp đồng có category Sức khỏe, mã hợp đồng, người được bảo hiểm, hiệu lực đến, chứng nhận, quyền lợi tích lũy. Trang quyền lợi có 2 tab: quyền lợi tích lũy và danh sách giao dịch. Tổng quyền lợi = hỗ trợ chi phí y tế + trợ cấp nằm viện tai nạn. |
| Rule consent | Lần đầu cấp hợp đồng cần hiển thị câu xác nhận user chưa từng điều trị/chẩn đoán/tư vấn y tế/tầm soát các bệnh trên trong 6 tháng gần nhất và không bị thương tật vĩnh viễn từ 50% trở lên. Từ lần 2 chỉ nạp thêm vào hợp đồng có sẵn nên không lặp lại consent. |
| Hoàn/hủy | CS table ghi không áp dụng hoàn phí; nếu user muốn hủy hợp đồng trước thời hạn thì liên hệ CS Fuse, Nhà bảo hiểm hỗ trợ hủy hợp đồng nhưng không hoàn lại phí đã đóng. |
| Audit lens | Kiểm tra user có hiểu "tích lũy quyền lợi" khác với mua bảo hiểm sức khỏe full, có biết không hoàn phí, consent sức khỏe có đủ rõ, và UI tính tổng quyền lợi/số giao dịch tích lũy có đúng. |

#### 4.3.14 MiniHealth / Bảo hiểm Chăm Sóc Sức Khỏe MSIG

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | Product overview gắn với Health Insurance / Mini Healthcare App; cần xác nhận production AppID trong release/config. |
| Đối tác / Nhà bảo hiểm | Fullerton Health/Pharmacity ecosystem trong concept; MSIG là insurer trong product overview. |
| Bài toán business | Đây là hướng sản phẩm health insurance cao hơn micro embedded: kết hợp nội trú/ngoại trú, bảo lãnh thuốc trực tuyến và giao thuốc tận nhà, giải quyết trust deficit của user với bảo hiểm sức khỏe. |
| Khách hàng / context | Khách hàng đại chúng, phụ huynh có con nhỏ, người bận rộn, người đi làm không có bảo hiểm sức khỏe công ty. |
| Product proposition | Bảo hiểm sức khỏe toàn diện nội trú + ngoại trú, "không tiền mặt", bảo lãnh thuốc trực tuyến, giao thuốc miễn phí. Quy trình khám online, bác sĩ ra đơn, hệ thống duyệt bảo lãnh, thuốc giao tận nhà. |
| Gói / giá / quyền lợi anchor | Phí từ 2.000đ/ngày, khoảng 577.000đ/năm. Tổng hạn mức tối đa 70.000.000đ/năm; nội trú 20-70M, ngoại trú 2-10M, bảo lãnh thuốc 500k-1.5M/lần. Gói cơ bản 577k/năm tổng 20M; tiêu chuẩn 1.189M/năm tổng 50M; nâng cao 1.645M/năm tổng 70M. |
| UX/Product strategy | Concept nhấn mạnh 5 vấn đề tâm lý: user phủ nhận rủi ro, sợ fine print, muốn tự chủ, sợ bị trói buộc, cần bằng chứng claim thực tế. Giải pháp gồm anti-fine-print, claim simulator, modular builder, subscription, medical QR, live claim tracking. |
| Audit lens | Đây là sản phẩm trust-heavy. Audit cần căn cứ vào minh bạch loại trừ, claim simulator/claim tracking là tính năng thật hay concept, bảo lãnh thuốc SLA 30 phút, network bác sĩ/Pharmacity, và boundary giữa ZLP - Fullerton - MSIG. |

#### 4.3.15 Bảo hiểm Sức Khỏe / Tai Nạn / Thai Sản / Bệnh Hiểm Nghèo Qua Saladin Mweb

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID 3951, Saladin mweb/hub đối tác. Product overview ghi health, accident, maternity, critical illness, travel standalone và một số motor/auto Saladin. |
| Đối tác / Nhà bảo hiểm | Saladin phân phối; insurers trong portfolio gồm VBI, MIC, Bảo Việt, Liberty, PVI tùy loại. |
| Bài toán business | Đây là "long-tail insurance catalog" trong Hub: ZaloPay tăng độ phủ danh mục mà không cần core integration từng sản phẩm ngay lập tức. |
| Khách hàng / context | User chủ động vào Hub tìm bảo hiểm sức khỏe/tai nạn/thai sản/bệnh hiểm nghèo, có nhu cầu tự nguyện và cần so sánh gói. |
| Product proposition | Sự tiện lợi: từ Hub ZaloPay có thể đi đến Saladin để mua các gói bảo hiểm tự nguyện. |
| Gói / giá / quyền lợi anchor | Workspace chỉ có catalog-level, không có chi tiết gói/phí/quyền lợi theo từng sản phẩm trong pass này. |
| Journey sản phẩm | Chủ yếu partner webview/mweb. ZLP có vai trò entrypoint, hiển thị, và thanh toán; chính sách sản phẩm, cấp đơn, claim, hoàn/hủy phụ thuộc Saladin/insurer. |
| Hoàn/hủy / ops | CS table: Saladin mweb, ZLP CS tiếp nhận mail cho đối tác; chính sách hoàn/hủy phụ thuộc đối tác; SLA phản hồi 2-3 ngày làm việc. |
| Audit lens | Cần bổ sung policy docs/partner catalog cho từng loại trước khi audit sau. Nếu không, audit chỉ nên tập trung vào entrypoint, disclosure boundary, handoff webview và CS escalation. |

#### 4.3.16 Thu Phí Bảo Hiểm Nhân Thọ / Premium Collection

| Khía cạnh | Chi tiết |
|---|---|
| AppID / Kênh bán | AppID/product line 3081 cho Hub in-app; AppID 3232 Payoo; AppID 3082 Cathay Life trong overview/CS. |
| Đối tác / Nhà bảo hiểm | Cathay Life direct; Payoo indirect cho Generali, FWD, BIDV MetLife, Prevoir theo product doc. Tracking map cũng có Cathay, Generali, MetLife, FWD, PREVOIR. |
| Bài toán business | Không phải "bán bảo hiểm" mà là thu hộ phí bảo hiểm nhân thọ. Business objective là tăng TPV/category Insurance TPV và transaction volume từ nhóm user đã có hợp đồng bảo hiểm. |
| Khách hàng / context | User đã có hợp đồng bảo hiểm nhân thọ, cần trả phí định kỳ, tra cứu kỳ nợ, lưu mã hợp đồng, nhận reminder đến hạn. |
| Product proposition | Thanh toán phí bảo hiểm nhanh trên ZaloPay, lưu hợp đồng cho kỳ sau, nhận nhắc nợ/đến hạn, và có thể áp dụng voucher/growth campaign. |
| Journey sản phẩm | User chọn nhà cung cấp, nhập mã hợp đồng/mã khách hàng và thông tin phụ nếu cần, query bill, chọn kỳ phí, thanh toán. Cashier/result hiển thị service "Thanh toán phí bảo hiểm", provider, mã hợp đồng, số tiền, phí giao dịch. |
| Payment rule | Cathay Life cho user thanh toán tất cả kỳ nợ, thanh toán từng kỳ theo thứ tự mới nhất đến cũ nhất, hoặc tick nhiều kỳ nhưng phải theo thứ tự mới nhất đến cũ nhất. Payoo có các query type theo Nhà bảo hiểm: Generali/FWD/BIDV/Prevoir; FWD cần CCCD người thanh toán. |
| Saved contract / reminder | Phase 1 treat contract như bill và dùng Bill Storage V2; hiển thị "Hợp đồng đã nhập gần đây". Reminder cho Cathay có thể daily auto query nợ và nhắc user đến hạn; Payoo phase đầu nhắc chung mã hợp đồng cha. |
| Hoàn/hủy / ops | CS table: Cathay all SOF trừ CC; Payoo only VietQR; chính sách hoàn/hủy phụ thuộc đối tác; SLA đối tác 2-3 ngày làm việc. |
| Audit lens | Kiểm tra user có phân biệt thanh toán phí vs mua bảo hiểm, payment rule multi-cycle có dễ hiểu, Nhà bảo hiểm nào cần CCCD/extra info, partner maintenance copy, và reminder có đúng hạn/nợ phí không. |

#### 4.3.17 Bảo hiểm Term Life / NNX / Các Sản Phẩm Roadmap

| Khía cạnh | Chi tiết |
|---|---|
| Trạng thái | Email/Jira cho thấy Term Life, NNX/bảo lãnh thuốc, Mini Healthcare đang có luồng trao đổi integration/design. Chưa đủ bằng chứng trong pass này để coi là product live production. |
| Business intent | Mở rộng Insurance từ micro embedded sang các sản phẩm có giá trị/niềm tin cao hơn: sinh mạng, sức khỏe, bảo lãnh thuốc, dịch vụ y tế. |
| Product issue đang align | Term Life email 2026-05-27 nêu không có email trong sale journey; option thu email sau bán hoặc gửi thông báo qua Zalo OA; ZLP hiển thị COI không esign sau proposal successful, Chubb gửi COI có esign sau khi policy issued. |
| Audit lens | Chỉ nên audit như roadmap/pipeline: notification, COI timing, esign, claim/servicing boundary, và API spec readiness. Không nên đưa vào score product live nếu chưa có release evidence. |

### 4.4 Góc Nhìn HBS 2026: So Với Thực Tế ZaloPay Đang Làm

Phần này dùng deck HBS 2026 như một bộ câu hỏi rà soát, không mặc định mọi đề xuất trong deck là trạng thái production. Với mỗi ý, tài liệu tách rõ: ZaloPay đang làm gì thật, phần nào mới là gợi ý/giả thuyết, và khi audit nên soi điểm nào. Khi nguồn ZaloPay không có bằng chứng đang triển khai, ghi rõ "Dữ liệu nguồn không đề cập đến vấn đề này".

#### 4.4.1 Tóm Tắt Theo Góc Nhìn Product

| Góc nhìn | HBS đang gợi ý gì | ZaloPay đang làm gì | Khi audit nên soi gì |
|---|---|---|---|
| Góc nhìn nghiên cứu user | Deck gom vấn đề thành 3 rào cản chính: offer không liên quan, thiếu niềm tin, và user không hiểu bảo hiểm; nghiên cứu gồm hơn 25 phỏng vấn nhóm 18-30 tại TP.HCM, 8 phỏng vấn calibration nhóm 25-35 và 2 working session với management. [HBS Extract:L10](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L10), [HBS Extract:L15](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L15) | ZaloPay đã có hướng xử lý ma sát bằng product work cụ thể: UIUX 2025 đặt mục tiêu A/B test component để tăng CR/adoption trên 9 dòng embedded; email Bill UI cũng nhắc rõ nhiệm vụ chính của user là thanh toán bill, nên component bảo hiểm không được làm user mất tập trung. [Insurance UIUX 2025:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/244520820_Insurance%20UIUX%202025.md#L7), [Insurance UIUX 2025:L11](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/244520820_Insurance%20UIUX%202025.md#L11), [Bill UI Email:L19](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Insurance/2026-05-28%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQAADU-7vJx00XvjGTmyWepM8%3D%20-%20Wrap-up%20UI%20Discussion%20Bill%20Payment%20%26%20Insurance.md#L19) | Đừng chỉ hỏi "có bán được không"; nên hỏi thêm "offer này có làm hỏng journey chính không?". Với Bill, MT, Topup, audit nên soi kỹ thời điểm hiển thị, wording, default state, chữ chạy/chữ tĩnh và số lần hiển thị. |
| Offer đúng ngữ cảnh | Deck đề xuất map bảo hiểm theo ngữ cảnh thanh toán và lịch sử chi tiêu để tránh cảm giác bị bán kèm không liên quan. [HBS Extract:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L30), [HBS Extract:L32](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L32) | ZaloPay đã có nền routing theo traffic, UID, lịch sử thanh toán, active contract, click/impression/untick và blacklist; các kịch bản hiện tại đã map Electricity, Flight, Buycard, Bus, Topup, Water, CF, Education sang từng sản phẩm cụ thể. [Routing Insurance:L17](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L17), [Routing Insurance:L27](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L27), [Routing Insurance:L81](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L81), [Insurance Zone:L10](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261513493_Insurance%20Zone%20display.md#L10) | Audit nên đối chiếu context map của HBS với routing hiện tại: context nào đã có sản phẩm thật, context nào mới là ý tưởng như bảo hiểm sự kiện, rental car, laptop/tablet, hoặc gợi ý life/health theo investment/saving. |
| Niềm tin và social proof | Deck đề xuất huy hiệu tin cậy, trạng thái bạn bè được bảo vệ, cơ chế giới thiệu có thưởng/gamification và guardrail quyền riêng tư theo opt-in. [HBS Extract:L37](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L37), [HBS Extract:L39](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L39) | Dữ liệu nguồn không đề cập đến việc ZaloPay Insurance đang có huy hiệu bạn bè, thử thách nhóm, tầng thưởng giới thiệu, hay chia sẻ trạng thái bảo vệ với bạn bè. Nguồn hiện có mô tả routing theo interaction và tracking click/load, chưa mô tả social proof. [Routing Insurance:L49](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L49), [Insurance Hub Tracking:L112](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/207070807_Insurance%20Hub%20-%20Performance%20Tracking.md#L112) | Đây là gap lớn về trust loop. Nếu audit sản phẩm hiện tại, không nên chấm cao phần social proof chỉ vì deck HBS có đề xuất; nên tách thành backlog/growth experiment riêng. |
| Giáo dục user | Deck muốn có chatbot tiếng Việt, trang Learn More, và cách giải thích quyền lợi, phí, gia hạn, hủy/gia hạn, claim bằng ngôn ngữ đơn giản. [HBS Extract:L43](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L43), [HBS Extract:L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L44) | ZaloPay đã có giáo dục ở cấp từng sản phẩm: Cyber có bottom sheet 3 tab; Screen Insurance có bottom sheet quyền lợi/claim/FAQ; Health concept có các ý như Anti-Fine Print, Claim Simulator, Medical QR và Live Claim Tracking. [Cyber Risk VBI:L136](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-B%E1%BA%A3o%20hi%E1%BB%83m%20an%20ninh%20m%E1%BA%A1ng.md#L136), [Phone Screen:L87](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/132339429_Phone%20Cracked%20Screen%E2%80%8B%20%28B%E1%BA%A3o%20hi%E1%BB%83m%20r%C6%A1i%20v%E1%BB%A1%20m%C3%A0n%20h%C3%ACnh%29.md#L87), [Health Concept:L42](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/305007137_Health%20Insurance%20-%20Product%20Concept.md#L42) | Khi audit, nên tách "có T&C/bottom sheet" khỏi "user thật sự hiểu". Chỉ có T&C không đủ để kết luận education tốt, nhất là với các sản phẩm có renewal, claim, exclusion hoặc nhiều kỳ phí. |
| Cyber / Scam Shield | Deck đề xuất đổi framing từ Cyber sang Scam Shield và dùng các điểm kích hoạt dễ hiểu hơn như số tiền giao dịch hoặc người nhận mới/không quen. [HBS Extract:L49](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L49), [HBS Extract:L51](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L51) | Nguồn ZaloPay vẫn gọi sản phẩm là Bảo hiểm an ninh mạng/Cyber Protection. Sản phẩm đang nằm ở Telco Topup và Money Transfer cross-sell; MoneyTransfer x VBI mô tả flow user tick checkbox, binding, PayNow/free-first-user logic và deliver VBI. [Product Overview:L22](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L22), [Cyber Risk VBI:L96](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-B%E1%BA%A3o%20hi%E1%BB%83m%20an%20ninh%20m%E1%BA%A1ng.md#L96), [MoneyTransfer x VBI:L113](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Technical%20Page/329207148_MoneyTransfer%20x%20VBI.md#L113), [Insurance Zone:L39](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261513493_Insurance%20Zone%20display.md#L39) | Dữ liệu nguồn không đề cập đến việc production đã rename thành Scam Shield hoặc đã routing theo transaction size. Đây nên được ghi là đề xuất về positioning/routing, chưa phải current state. |
| Health / MiniHealth | Deck đề xuất chatbot, video FAQ, story trước khi ký, gói micro dưới 500K, gói gia đình, mở rộng nhà thuốc và phân tầng telemedicine. [HBS Extract:L56](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L56), [HBS Extract:L61](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L61), [HBS Extract:L63](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L63) | Nguồn MiniHealth của ZaloPay đã có hướng sản phẩm khá rõ: MSIG, nội trú/ngoại trú, bảo lãnh thuốc trực tuyến, giao thuốc tận nhà, claim offline qua Pharmacity, 40+ bác sĩ, SLA duyệt 30 phút, và 3 gói 577K/1.189M/1.645M. [Health Overview:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009933_Health%20Insurance%20-%20Product%20Overview.md#L7), [Health Overview:L27](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009933_Health%20Insurance%20-%20Product%20Overview.md#L27), [Health Overview:L34](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009933_Health%20Insurance%20-%20Product%20Overview.md#L34), [Health Overview:L66](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009933_Health%20Insurance%20-%20Product%20Overview.md#L66) | Dữ liệu nguồn không đề cập đến tier dưới 500K, family shared pool, Long Châu/Trung Sơn expansion, hay video FAQ đã production. Khi audit Health, cần tách current MiniHealth scope khỏi expansion idea trong deck. |
| Term Life | Deck đề xuất làm Term Life dễ hiểu hơn bằng neo giá theo ngày, planner hướng dẫn, AI assistant; đồng thời đề xuất Remittance-Linked Life, Dependent Care Benefit và AD&D Micro-Policy. [HBS Extract:L67](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L67), [HBS Extract:L68](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L68) | Workspace hiện chỉ cho thấy Mini Term Life ở mức trao đổi tích hợp/vận hành: chưa có email trong sale journey, có option thu email sau bán hoặc gửi qua Zalo OA, ZLP hiển COI không esign sau proposal successful, còn Chubb gửi COI có esign sau khi policy issued. [Mini Term Life Email:L13](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Insurance/2026-05-27%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQALL63vhbLIpNhmQhFnETmTk%3D%20-%20RE%20%5BChubb%20Life%20-%20Zalopay%5D%20Tech%20Meeting%20-%20Mini%20Term%20Life.md#L13), [Mini Term Life Email:L19](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Insurance/2026-05-27%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQALL63vhbLIpNhmQhFnETmTk%3D%20-%20RE%20%5BChubb%20Life%20-%20Zalopay%5D%20Tech%20Meeting%20-%20Mini%20Term%20Life.md#L19) | Dữ liệu nguồn không đề cập đến Remittance-Linked Life, Dependent Care Benefit, hay AD&D Micro-Policy đang live. Audit nên đặt Term Life vào nhóm roadmap/readiness, chưa chấm như product đang vận hành. |
| Nhóm bảo hiểm mới | Deck đề xuất 3 hướng: Lifestyle Insurance, Rental Property Insurance và Device Protection. [HBS Extract:L73](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L73), [HBS Extract:L74](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L74) | ZaloPay đã có một phần overlap: travel/flight/bus insurance, Home PVI theo bill điện/nước, và screen insurance cho điện thoại. [Product Overview:L17](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L17), [Product Overview:L21](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L21), [House Protection:L16](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/219681037_House%20Protection%20Embedded%20Electricity_Water%20Domain.md#L16), [Phone Screen:L37](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/132339429_Phone%20Cracked%20Screen%E2%80%8B%20%28B%E1%BA%A3o%20hi%E1%BB%83m%20r%C6%A1i%20v%E1%BB%A1%20m%C3%A0n%20h%C3%ACnh%29.md#L37) | Khoảng trống hiện tại: Dữ liệu nguồn không đề cập đến event cancellation, rental car insurance, laptop/tablet protection, hay renter/rental-property SKU như deck mô tả. Các ý này nên được để ở backlog opportunity, không trộn vào inventory current product. |
| Giữ chân dài hạn | Deck muốn chuyển từ bán lẻ tại điểm thanh toán sang protection manager: tổng coverage, gap detection, external policy và contextual upsell. [HBS Extract:L80](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L80), [HBS Extract:L82](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L82) | ZaloPay đã có Contract Management để gom hợp đồng mua trên ZaloPay và hợp đồng nhân thọ dùng để thanh toán phí, có active/expired section, category chips, policy card và certificate link. [Contract Management:L21](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224783660_Insurance%20Contract%20Management.md#L21), [Contract Management:L38](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224783660_Insurance%20Contract%20Management.md#L38), [Contract Management:L52](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224783660_Insurance%20Contract%20Management.md#L52) | Hiện trạng đang là "quản lý hợp đồng" nhiều hơn "quản lý mức độ được bảo vệ". Dữ liệu nguồn không đề cập total coverage, gap detection, external policy upload, hay next-best-policy upsell. |
| Đo lường | Deck gom strategy thành 5 hướng lớn. [HBS Extract:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L9) | ZaloPay hiện đã có bộ đo cho routing: load component, tick, untick, submit order, confirm payment, successful transaction, E2E CR; Hub tracking cũng theo dõi traffic/click/click rate/event distribution. [Routing Insurance:L97](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L97), [Routing Insurance:L105](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L105), [Insurance Hub Tracking:L43](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/207070807_Insurance%20Hub%20-%20Performance%20Tracking.md#L43), [Insurance Hub Tracking:L112](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/207070807_Insurance%20Hub%20-%20Performance%20Tracking.md#L112) | Nên bổ sung metric theo lens product, không chỉ CR mua bảo hiểm: độ đúng ngữ cảnh, mức mệt vì bị offer lặp lại, engagement với nội dung giáo dục, trust/social proof, và retention sau khi user đã có hợp đồng. |

#### 4.4.2 Visual Map: HBS So Với Thực Tế ZaloPay

```mermaid
flowchart LR
    HBS["Deck HBS 2026<br/>5 hướng đề xuất"] --> Targeted["Offer đúng ngữ cảnh"]
    HBS --> Social["Tăng niềm tin bằng social proof"]
    HBS --> Edu["Giáo dục user dễ hiểu hơn"]
    HBS --> New["Mở thêm nhóm bảo hiểm mới"]
    HBS --> Long["Giữ user dài hạn"]

    Targeted --> ZRouting["ZaloPay đã có nền:<br/>routing, zone, A/B, interaction rules"]
    Targeted --> GapTarget["Audit cần soi:<br/>context-product fit"]

    Social --> GapSocial["Gap lớn:<br/>chưa thấy nguồn về friend badge/referral/protected status"]

    Edu --> ZEdu["ZaloPay đã có một phần:<br/>bottom sheet, T&C, FAQ, health concept"]
    Edu --> GapEdu["Gap cần xác minh:<br/>platform education/chatbot"]

    New --> Existing["Đã overlap một phần:<br/>travel, home, screen, cyber, health"]
    New --> GapNew["Ý tưởng mới/chưa thấy live:<br/>event, rental, laptop/tablet, rental property"]

    Long --> Mgmt["ZaloPay đã có nền:<br/>contract management và premium collection"]
    Long --> GapLong["Gap chiến lược:<br/>protection manager, gap detection, external policy"]
```

#### 4.4.3 Những Điểm Nên Thêm Vào Checklist Audit

| Hạng mục nên thêm | Cách diễn giải theo product |
|---|---|
| Kiểm tra độ đúng ngữ cảnh của từng embedded zone | HBS nói offer không liên quan sẽ tạo friction, còn ZaloPay đã có routing và zone data để audit cặp context/product. [HBS Extract:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L30), [Routing Insurance:L81](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L81), [Insurance Zone:L10](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261513493_Insurance%20Zone%20display.md#L10) |
| Thêm checklist về trust mechanism | HBS đề xuất social proof, nhưng nguồn ZaloPay hiện đang mô tả interaction routing và click/load tracking nhiều hơn friend badge/referral/protected status. [HBS Extract:L37](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L37), [HBS Extract:L39](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L39), [Routing Insurance:L49](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L49), [Insurance Hub Tracking:L112](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/207070807_Insurance%20Hub%20-%20Performance%20Tracking.md#L112) |
| Chia education thành 3 mức | Mức 1: có T&C/bottom sheet. Mức 2: user hiểu quyền lợi/loại trừ/claim bằng ngôn ngữ dễ hiểu. Mức 3: có education layer dùng chung như Learn More/chatbot. HBS đang hỏi nhiều về mức 2-3, còn nguồn ZaloPay chủ yếu chứng minh mức 1 và một phần concept Health. [HBS Extract:L43](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L43), [HBS Extract:L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L44), [Phone Screen:L87](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/132339429_Phone%20Cracked%20Screen%E2%80%8B%20%28B%E1%BA%A3o%20hi%E1%BB%83m%20r%C6%A1i%20v%E1%BB%A1%20m%C3%A0n%20h%C3%ACnh%29.md#L87), [Health Concept:L42](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/305007137_Health%20Insurance%20-%20Product%20Concept.md#L42) |
| Đưa các ý tưởng HBS vào backlog hypothesis | Scam Shield rename, term-life extensions, event/rental/laptop/rental-property protection, family health pool, và protection manager có trong HBS; nguồn Workspace hiện chỉ support Cyber dưới tên Cyber Protection, Term Life ở mức integration discussion, một phần overlap travel/home/screen, và Contract Management. [HBS Extract:L49](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L49), [HBS Extract:L68](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L68), [HBS Extract:L73](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L73), [Product Overview:L22](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L22), [Mini Term Life Email:L13](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Vault/FlaggedEmails/Insurance/2026-05-27%20-%20AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQALL63vhbLIpNhmQhFnETmTk%3D%20-%20RE%20%5BChubb%20Life%20-%20Zalopay%5D%20Tech%20Meeting%20-%20Mini%20Term%20Life.md#L13) |
| Audit retention vượt khỏi contract listing | Contract Management chứng minh ZaloPay đang gom và hiển thị hợp đồng, nhưng HBS muốn một lớp protection management: tổng coverage, gap detection, external policy và contextual upsell. [Contract Management:L21](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224783660_Insurance%20Contract%20Management.md#L21), [Contract Management:L38](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224783660_Insurance%20Contract%20Management.md#L38), [HBS Extract:L80](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L80), [HBS Extract:L82](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211%40gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Others/03.%20Insurance/09.%20Other%20Task/HBS%202026/Zalopay%20HBS%20Capstone%20Final%20Presentation%20vSend%20-%20extracted%20outline.md#L82) |

---

## 5. User Surface Map

### 5.1 Hub

Insurance Hub has two main tabs:

| Tab | Meaning | Evidence |
|---|---|---|
| `Mua bảo hiểm` | Browse/purchase insurance distribution products and cross-sell modules. | FE03 |
| `Thanh toán phí` | Pay recurring insurance fees and view saved premium policies. | FE03, FE05 |

The homepage also contains header/banner, service groups, cross-sell modules, About, Partners, and voucher/combo bottom sheets.

### 5.2 Embedded / Cross-Sell

Embedded Insurance is used in Bill, Telco, OTA, and Money Transfer contexts. The common UX pattern is:

1. Host journey loads a payment or transaction screen.
2. Insurance component is shown in a zone.
3. User sees a package, default state, promotion, renewal/subscription copy, and detail CTA.
4. User checks/unticks the package.
5. Frontend creates/updates an insurance order token or cart entry.
6. Payment or result page continues with insurance state.

Key audit risks:

| Risk | Why it matters |
|---|---|
| Main mission conflict | Bill/Telco/MT users are primarily paying or transferring money. Insurance must not distract, obscure, or degrade the host journey. |
| Consent ambiguity | Auto renewal, insurance subscription, bill autodebit, and payment source can be cognitively similar but legally/financially different. |
| Repeated exposure | Chat/email discussions suggest limiting repeated offers after non-interest, e.g. MT references a 3-time exposure cap. |
| Tracking consistency | Attachment-rate dashboards need reliable `4072.*` load/click/check/untick events plus zone ID metadata. |

### 5.3 Contract Management

Contract management has two broad tabs:

| Tab | Meaning |
|---|---|
| `Bảo hiểm tren ZaloPay` | Policies purchased through ZaloPay distribution flows. |
| `Hop dong nhan tho` | Life-insurance contracts/premium-collection relationships. |

Important UI behaviors:

- Split active and expired/canceled policies.
- Category chips include motor/auto/accident, travel, payer, trip, home, electronics, tech, school, and others depending on implementation.
- Policy card should show policy name/logo, policy ID, insured person, expiry status, certificate link, and product-specific CTA.
- Travel may have multiple insured people and no simple expiry date in the card; certificate may carry details.
- Screen insurance may need device verification and certificate CTA.
- SaveMoney items may deep link to SaveMoney management.

---

## 6. Core Journey Visuals

### 6.1 Distribution Purchase Sequence

```mermaid
sequenceDiagram
    autonumber
    participant U as User
    participant UI as Insurance Webapp / Host app
    participant A as Ares
    participant P as Provider
    participant Pay as Cashier / UserPayment
    participant Q as Queue / retry
    participant ES as Policy index

    U->>UI: Open hub or embedded zone
    UI->>A: Query package / eligibility / bill context
    A->>P: Query provider package or bill data if needed
    P-->>A: Package / bill / eligibility response
    A-->>UI: Package list, default state, promotion, auto-debit options
    U->>UI: Select or untick package
    UI->>A: Create insurance order
    A->>Pay: Create payment order
    Pay-->>A: Payment callback / status
    A->>P: Deliver policy
    alt Provider returns success
        P-->>A: Policy ID and certificate URL
        A->>ES: Upsert policy
        A-->>UI: Success / certificate ready
    else Provider returns processing
        A->>Q: Enqueue get-deliver-status
        Q->>P: Poll delivery status
        P-->>A: Success / fail / still processing
    else Provider fails
        A->>Q: Enqueue refund or manual check
        A-->>UI: Processing / issue status
    end
```

### 6.2 Order State Machine

```mermaid
stateDiagram-v2
    [*] --> Created: create order
    Created --> PaymentSuccess: payment callback valid
    Created --> Expired: unpaid and expired
    PaymentSuccess --> DeliverProcessing: provider needs async status
    PaymentSuccess --> DeliverSuccess: policy issued sync
    PaymentSuccess --> DeliverManualCheck: unknown / unsafe state
    PaymentSuccess --> DeliverFailed: provider fail
    DeliverProcessing --> DeliverSuccess: status success
    DeliverProcessing --> DeliverFailed: status fail or retry exhausted
    DeliverProcessing --> DeliverManualCheck: ambiguous after retry
    DeliverFailed --> RefundProcessing: refund enqueue
    DeliverManualCheck --> DeliverSuccess: Ops resolves
    DeliverManualCheck --> DeliverFailed: Ops resolves fail
    RefundProcessing --> Refunded: TPE success
    RefundProcessing --> RefundFailed: TPE fail / follow-up needed
    DeliverSuccess --> [*]
    Refunded --> [*]
```

### 6.3 Collection Premium Payment Sequence

```mermaid
sequenceDiagram
    autonumber
    participant U as User
    participant UI as Premium collection UI
    participant A as Ares
    participant P as Payoo / Cathay
    participant Pay as Cashier / UserPayment
    participant B as Bill storage / history

    U->>UI: Enter contract/customer identifier
    UI->>A: Query bill
    A->>P: Query premium/debt data
    P-->>A: Bill list or maintenance/error code
    A-->>UI: Bill data, payment range, customer info
    U->>UI: Confirm payment
    UI->>A: Create order
    A->>Pay: Create payment order
    Pay-->>A: Callback
    A->>P: Deliver payment / update provider
    A->>B: Push bill event and transaction data
    A-->>UI: Success / processing / failed
```

### 6.4 Routing / Offer Selection Logic

```mermaid
flowchart TD
    Start["Host journey enters insurance zone"] --> Blacklist{"User blacklisted?"}
    Blacklist -- Yes --> Hide["Hide insurance offer"]
    Blacklist -- No --> Traffic{"Traffic allocation / experiment"}
    Traffic --> UID["Fixed user-id digit split"]
    UID --> History{"Has payment / purchase history?"}
    History --> Active{"Has active contract?"}
    Active -- Yes --> SuppressOrRenew["Suppress, renew, or show compatible product"]
    Active -- No --> Interaction{"Prior impressions / unticks / clicks"}
    Interaction -- TooManyUnticks --> Hide
    Interaction -- Eligible --> Select["Select product / supplier / package"]
    Select --> Show["Render component and track 4072.000"]
    Show --> UserAction{"User action"}
    UserAction -- Check --> TrackCheck["Track 4072.001 and create/update order"]
    UserAction -- Untick --> TrackUntick["Track 4072.002 and update cart/order"]
    UserAction -- Detail --> Detail["Open detail / terms / certificate info"]
```

### 6.5 Contract Management View

```mermaid
graph TD
    Entry["Open Insurance Management"] --> Tabs{"Tab"}
    Tabs --> ZLP["Bảo hiểm tren ZaloPay"]
    Tabs --> Life["Hop dong nhan tho"]
    ZLP --> Status{"Status filter"}
    Status --> Active["Active policies"]
    Status --> Expired["Expired / canceled policies"]
    Active --> Category["Category chips"]
    Expired --> Category
    Category --> Card["Policy card"]
    Card --> Certificate["View certificate"]
    Card --> Renew["Renew / auto-debit / next payment"]
    Card --> Cancel["Cancel policy where supported"]
    Life --> CollectionPolicies["Saved premium policies"]
    CollectionPolicies --> PayPremium["Pay premium"]
```

---

## 7. Business Rules

### 7.1 Distribution Modes

| Mode | Description | Audit questions |
|---|---|---|
| Standalone | User enters Insurance Hub or partner hub and actively buys a policy. | Is product discovery clear? Is package/benefit comparison easy? Is certificate delivery visible? |
| Embedded | Insurance is included in a host payment journey such as Bill, Telco, or OTA. | Is default state opt-in/opt-out appropriate? Is main payment mission protected? Is consent explicit? |
| Cross-sell | Insurance appears after or around another transaction, e.g. result page or Money Transfer. | Is the offer relevant and timed well? Are repeated exposures controlled? |
| Partner webview | ZaloPay routes user into partner-managed purchase/management pages. | Are boundaries clear when issue/claim/certificate is partner-managed? |
| Collection | ZaloPay collects premiums for existing policies. | Is the distinction between "pay premium" and "buy insurance" clear? |

### 7.2 Eligibility, Routing, And Segments

Routing is expected to combine:

- Traffic percentage allocation.
- Fixed user-ID digit split for stable A/B exposure.
- Payment history.
- Active contract status.
- Prior interactions: click, check, untick, impressions.
- Blacklist exclusions.
- Zone-specific product priority.

Known routing scenario examples include bill contexts such as Electric, PhoneCard, Topup, Water, CF, Edu, and OTA contexts. Routing metrics should reconcile load/check/untick/payment events, especially `4072.000`, `4072.001`, `4072.002`, `1130.000`, and `1130.011`.

### 7.3 Promotion, Free Trial, And Direct Discount

Free trial is strategically important but operationally sensitive.

Known rules and constraints:

- Free trial/direct discount has been positioned as an acquisition hook for Cyber and Bill Protect.
- A documented blocker exists where free-trial voucher application is difficult for non-wallet sources of funds.
- Interim Money Transfer plan discussed in 2026: launch Cyber without first-user free trial to protect launch timeline.
- Long-term solution discussed: Insurance can skip pay for the first period, call partner to issue policy, mark first-period transaction for reconciliation, while broader Agreement Pay root cause remains a platform backlog.

Audit implications:

| Area | What to verify |
|---|---|
| User promise | If "free trial" is shown, verify user is never charged for the first covered period across all allowed SoF. |
| Ledger / reconciliation | Verify 0 VND or skipped-pay issuance is traceable for Finance/Ops and partner reconciliation. |
| Source of funds | Verify Cashier, Agreement Pay, MMF/linked source, and wallet behavior under direct discount. |
| Renewal | Verify the second and later periods are charged based on current policy expiry, not stale initial purchase dates. |

### 7.4 Autodebit / Subscription

The frontend autodebit hook currently focuses on Cyber Risk logic in the source snapshot. It checks agreements by package/policy data and creates a binding only when product/supplier/package conditions are satisfied.

Important business constraints:

- Cyber in Money Transfer can require Agreement Pay support.
- Some standalone flows, such as Peaceful Living roadmap/work items, are expected to force subscription for standalone hub while embedded bill may not support subscription.
- Recent Jira indicates charge-date logic after month 2 should derive from policy expiry rather than original transaction date.

Audit implications:

- Consent must distinguish bill autodebit vs insurance renewal.
- Renewal date copy must match actual charge logic.
- Cancellation/free-look rules must be product-specific.
- Failed autodebit must have clear user notification and recovery path.

### 7.5 Policy Lifecycle

Ares represents policy status as:

| Status | Meaning in product audit |
|---|---|
| ACTIVE | Policy is active. Backend also treats active policies with no expiry/next-payment time as active, and active policies with future min(expired, nextPayment) as active. |
| EXPIRED | Explicitly expired or active policy whose expiry/next-payment threshold has passed. |
| CANCELED | Canceled policy. |

Audit implications:

- UI labels must not imply coverage if backend would classify the policy as expired.
- Policy expiry and next payment date must be easy to distinguish.
- Contract management should not hide active policies due to category mismatch.

### 7.6 Refund, Manual Check, And Failure Recovery

Backend flow shows conservative failure handling:

- Orders can be moved to manual check when the delivery state is ambiguous.
- Failed delivery can trigger refund queues.
- Refund is restricted to manual-check or failed orders.
- Duplicate refund logs are prevented.
- TPE refund status can be init, processing, success, or failed.

Audit implications:

- Users should receive timely status when policy issuance is delayed.
- Ops should have dashboards for manual-check backlog, retry exhaustion, and refund failures.
- CS macros should distinguish "partner pending issuance" from "ZaloPay payment failed" and "certificate delayed."

---

## 8. Technical Architecture

### 8.1 Backend: Ares

`ares` is the Insurance core service. It coordinates product lines, suppliers, provider calls, payment callbacks, order histories, policy storage, retries, and refunds.

```mermaid
graph LR
    API["Ares API / service layer"] --> Supplier["Supplier config + app mapping"]
    API --> Query["Query bill / package"]
    API --> Create["Create order"]
    API --> Callback["Payment callback"]
    Callback --> Deliver["Deliver policy/payment"]
    Deliver --> Provider["Provider API"]
    Deliver --> Queue["Retry queue"]
    Queue --> Status["Get deliver status"]
    Status --> Policy["Policy upsert / ES"]
    Status --> Refund["Refund flow"]
    Refund --> TPE["TPE refund"]
    Query --> Cache["Cache"]
    Create --> Cache
    Query --> BillStorage["Bill storage events"]
```

Key backend concepts:

| Concept | Notes |
|---|---|
| Product line | `3081` for collection, `3275` for Micro Insurance distribution. |
| Supplier ID | Backend snapshot maps supplier IDs such as Saladin Travel, PVI Screen, Saladin Bill Protection, Saladin Trip, VBI Cyber, Chubb Travel, SaveMoney Home, Fuse Credit TopUp. |
| Provider paths | SQL changelogs add Payoo, Saladin OTA/BP/Trip, Igloo, VBI, and related mappings. |
| Order validation | Create order validates supplier active state, cached query result, request rules, and payment constraints such as no multi-bill payment for Micro Insurance. |
| Callback validation | Payment callback validates HMAC/channel/ZP transaction, app user, amount, and embedded order data. |
| Delivery | Delivery can return success, fail, manual check, or processing with later status polling. |
| Policy | Only successful Micro Insurance deliveries can upsert policy records in the inspected path. |
| Refund | Refund can be admin-triggered or queue-triggered after delivery failure. |

### 8.2 Frontend: Insurance Webapp

The source snapshot shows the following modules as audit-relevant:

| Module | Role |
|---|---|
| `features/home` | Hub title, banner, purchase tab, fee tab, service sections, cross-sell modules. |
| `useStandAloneInsurance` | Fetches standalone packages, default selection, opt-out state, order creation, certificate view, event tracking. |
| `useCrossSellInsurance` | Handles embedded/cross-sell package fetch, cart/order token, result-page custom area, polling transaction success, package check/untick. |
| `useAutodebitInsurance` | Handles agreement lookup and binding creation for eligible recurring insurance. |
| `PolicyManagement` | Fetches active/expired/canceled policies, category filters, certificate CTA, cancel/auto-debit details. |
| `constants/insurancePurchase` | Defines frontend supplier IDs, product type labels, package IDs, transaction statuses, and event IDs. |

### 8.3 Source Snapshot Inconsistencies To Verify

These are not product defects by themselves, but they are audit/development hygiene risks:

| Observation | Why it matters |
|---|---|
| `insurance-webapp/src/constants/common.ts` in the inspected snapshot contains Telco-style app IDs and appears not to define several Insurance constants referenced elsewhere. | The source snapshot may be stale, generated, or incomplete; avoid assuming it is the production build source without branch/build confirmation. |
| Frontend supplier IDs include newer suppliers such as School, OfficeHealth, Motorbike, PeacefulLiving, while backend constants inspected list up to a narrower supplier set. | Need current production config or later migrations to reconcile backend/FE mappings. |
| `App.tsx` initializes with `AppID.Topup` and only routes `Home` in the inspected snapshot. |  Máy be a micro-app bootstrap artifact or stale entrypoint; verify against deployed host routing. |
| Local `Fact/Data/Insurance` has no usable data files found in this pass. | Quantitative audit needs dashboard exports or data snapshots. |

---

## 9. Tracking And Analytics

### 9.1 Event Family

Insurance component tracking centers around `4072.*`, including load, check, uncheck, and detail/certificate related actions depending on context. Payment funnel reconciliation references `1130.*` events.

### 9.2 Known Tracking Concerns

| Concern | Evidence / implication |
|---|---|
| Dashboard mismatch | Embedded funnel notes reported mismatches around load and confirm-pay tracking. Audit should reconcile app/zone/event definitions before using CR numbers. |
| Zone ID metadata | Chat thread asks for Insurance zone IDs and metadata to calculate attachment rate. |
| Product coverage | Some dashboards were missing insurance types or bill app-ID filters. |
| Event taxonomy consistency | Use `4072.000` load, `4072.001` check, `4072.002` untick as the minimum funnel spine, then connect to payment submit/confirm and policy issuance. |

### 9.3 Minimum Funnel Definition For Future Audit

```mermaid
flowchart LR
    A["Eligible host transaction"] --> B["Component load<br/>4072.000"]
    B --> C["User checks package<br/>4072.001"]
    B --> D["User unticks package<br/>4072.002"]
    C --> E["Payment submit<br/>1130.000"]
    E --> F["Payment confirm<br/>1130.011"]
    F --> G["Provider deliver success"]
    G --> H["Certificate viewed"]
```

Minimum metrics:

- Load rate: loaded / eligible host transactions.
- Check rate: checked / loaded.
- Untick rate: unticked / loaded.
- Payment conversion: confirm / submit, confirm / loaded.
- Issuance success: deliver success / paid.
- Certificate readiness: certificate available within SLA / deliver success.
- Support rate: CS tickets / issued policies.

---

## 10. Operational Model

### 10.1 Team And Partner Interface

Handover documentation identifies internal roles across squad lead, FE, BE, UI, UX, and QC, plus external working groups for Saladin, Chubb, VBI, Fuse, Igloo, and SaveMoney. The 2025 handover email confirms Insurance Distribution ownership handover and highlights Cyber in Money Transfer as a follow-up item.

Operationally, Insurance depends on:

- Internal product and engineering coordination.
- Partner integration groups.
- Provider API uptime and rate limits.
- CS/Ops escalation for certificate delivery, partner pending states, and refunds.
- Dashboard/reporting alignment for attachment and conversion.

### 10.2 Partner Risk Map

| Partner / supplier | Product areas | Key operational risk |
|---|---|---|
| SaveMoney | Motorbike/auto/home and direct in-app/API flows | Certificate display and partner approval latency; user confusion when policy appears in ZLP but not partner webview or vice versa. |
| Saladin | Travel, payer protection, trip, mweb hub | Provider routing and product coverage differences by context. |
| Chubb | Travel, peaceful living, term-life roadmap | International routing applicability, COI/email/OA notification decisions, API spec alignment. |
| VBI | Cyber | API load from verify/status checks; segment-first optimization; Agreement Pay/free-trial dependency. |
| Fuse | Confident living, school, office health | Embedded bill consent, subscription/renewal clarity, product-specific cancellation. |
| Igloo / PVI | Screen | Device verification, certificate/service activation, refund fee/rules. |
| Payoo / Cathay | Premium collection | Partner maintenance and bill lookup availability. |

---

## 11. CS Ticket Patterns

The CS Ticket folder contains 23 closed Insurance tickets in the inspected snapshot. The table below converts individual cases into audit patterns.

| Pattern | Example evidence | Product risk | Audit follow-up |
|---|---|---|---|
| Paid but certificate/policy not visible | Motorbike SaveMoney user paid but did not receive contract in email or ZLP app; partner later sent certificate and ZLP direct contract management was being integrated. | Trust and regulatory risk; user may need proof of compulsory insurance. | Measure certificate SLA and policy-display success rate by partner/app ID. |
| Category filter mismatch | Contract visible in "All" but not in the motor/auto/accident category. | Management UI can create false belief that policy is missing. | Test category mapping for every supplier/product type. |
| Package selection misunderstanding | User claimed selected >50cc but logs showed <50cc package. | Product copy/package choice clarity; disputes after purchase. | Add package confirmation audit and compare selected package, displayed package, and certificate. |
| Payment success but status processing | User paid but ZLP showed processing until partner approval. | Ambiguous post-payment state. | Define SLA and UX copy for partner-pending issuance. |
| Partner maintenance / lookup failure | Life-insurance bill lookup temporarily disrupted due to partner issue. | Collection reliability and expectation management. | Track query-fail codes and display partner-maintenance copy. |
| Device/UI-specific input bug | Travel DOB date picker could not select month/year on Samsung S25 / Android 16. | Accessibility/device compatibility. | Add device matrix for key purchase flows. |
| System disruption in SaveMoney flow | Motorbike SaveMoney purchase showed system disruption. | Provider availability and fallback copy. | Monitor provider error code and retry policy by supplier. |
| Service/certificate not received after screen insurance | Screen insurance ticket requests service follow-up. | Activation and fulfillment clarity. | Audit device verification, certificate, and claim-start journey. |

---

## 12. Email / Chat Decision Log

These items are useful for audit because they explain why the product behaves the way it does, even when Jira/specs are incomplete.

| Date / source | Decision or signal | Audit implication |
|---|---|---|
| 2025-12-31 handover email | Insurance Distribution PO scope was handed over and Cyber in Money Transfer was called out as a follow-up. | Treat Cyber MT as a priority product-line thread with handover context. |
| 2026-03-20 blocker email | Cyber MT go-live was blocked by free-trial voucher not applying cleanly to non-wallet sources of funds. | Financial-safety audit must include SoF and direct-discount scenarios. |
| 2026-03-24 VBI feedback | VBI reported high API verify volume and suggested ZaloPay store/manage status internally. | Operational audit should examine API call volume, segment-first logic, and caching. |
| 2026-04-16 Cyber MT solution email | Team aligned to remove free trial temporarily and launch first, with Money Transfer UI update and package change. | Audit must distinguish launch compromise from desired long-term flow. |
| 2026-05-22 free-trial solution email | Long-term direction discussed: skip pay first period, proactively issue policy, mark first-period transaction; Agreement Pay root cause remains broader backlog. | Audit should check reconciliation and renewal behavior for any skip-pay rollout. |
| 2026-05-27 Mini Term Life email | Chubb/ZLP discussed no email in sale journey, possible post-sale email collection or Zalo OA notification, and COI without esign before final issued COI. | Trust audit for Term Life must inspect notification and COI timing. |
| 2026-05-28 Bill UI wrap-up | UI concern: rolling text may distract bill payment; bill autodebit and insurance subscription create cognitive load; suggest gradual rollout and exposure caps. | UX audit should explicitly test main-mission distraction and consent comprehension. |
| 2026-05-06 chat | Attachment-rate dashboard needs Insurance event tracking/zone ID clarity; current cases track under event family 4072. | Analytics audit should verify event metadata before using dashboards. |

---

## 13. Jira / Roadmap Snapshot

| Jira | Status in source snapshot | Product meaning |
|---|---|---|
| PCFFS-20739 | In Test | Integrate insurance contracts with ZLP management mini app; certificate deeplink. |
| PCFFS-21610 | In Dev | Enable free trial for Peaceful Living standalone flow. |
| PCFFS-21609 | New | Enable auto-subscription for Peaceful Living standalone; embedded Bill context does not support subscription while standalone hub should force subscription. |
| PCFFS-21662 | Done | Update charging logic for month 3 onward based on policy expiry rather than original transaction date. |
| PCFFS-21289 | New | Create repo for new Term Life product. |
| PCFFS-19979 | New | Agreement Pay new source-of-funds injection for Cyber MT auto subscription. |
| PCFFS-20824 | New | Cashier Native / FS regression for Insurance. |
| PCFFS-19978 | In Test | Technical knowledge takeover for Insurance. |
| PCFFS-19980 | In Analysis | Apply FAU segment check on Insurance Hub before calling VBI, reducing API load. |

---

## 14. Audit Readiness Matrix

### 14.1 UX & Journey

| Audit question | Current evidence | Missing data |
|---|---|---|
| Does the insurance offer support, not disrupt, the host journey? | Bill UI email raises distraction/cognitive-load concern; routing doc defines impression and interaction rules. | Usability test or funnel impact on host bill/MT conversion. |
| Are package choices clear enough to avoid disputes? | CS case shows user confusion over motorbike package selected. | Package confirmation screenshots and transaction-log comparison by product. |
| Is policy management findable and correct? | Contract management spec and FE category filters exist; CS case shows category mismatch. | Full policy category mapping QA across all supplier IDs. |
| Is device compatibility strong? | CS case on Android 16 DOB picker. | Device/browser matrix and regression evidence. |

### 14.2 Financial Safety

| Audit question | Current evidence | Missing data |
|---|---|---|
| Is charged amount exactly the package/premium amount shown? | Backend validates callback amount/order data; portfolio has pricing anchors. | Production reconciliation by app ID/package ID. |
| Are free trials and direct discounts safe across source of funds? | Email/Jira identify blockers with non-wallet SoF and Agreement Pay. | End-to-end tests for wallet, linked bank, SDSL/MMF, PayLater if allowed. |
| Are renewal dates and charges explainable? | Jira update says month 3 charge should follow policy expiry. | Sample policies proving UI copy, policy expiry, and charge job align. |
| Are refunds correctly controlled? | Backend restricts refunds to failed/manual-check orders and prevents duplicate refund logs. | Ops dashboard for refund failures and manual interventions. |

### 14.3 Operational Reliability

| Audit question | Current evidence | Missing data |
|---|---|---|
| Can the system recover from provider delivery delays? | Ares supports deliver-processing retries, manual check, refund queue. | Retry success rate, manual-check aging, partner SLA by supplier. |
| Are partner outages communicated clearly? | CS ticket shows partner maintenance copy. | Standardized maintenance/error copy per provider return code. |
| Are provider APIs protected from excessive calls? | VBI feedback and FAU segment Jira both highlight API load reduction. | API-call-volume dashboard before/after segment-first logic. |
| Are certificates delivered within user expectations? | CS cases show certificate/policy visibility pain. | Certificate-ready SLA by product and provider. |

### 14.4 Trust-Building Over Time

| Audit question | Current evidence | Missing data |
|---|---|---|
| Does the user know what data is shared with partner? | Free-trial framework includes disclosure copy and data-sharing fields. | Current UI screenshots for every embedded product. |
| Can the user prove coverage after purchase? | Contract management spec and certificate CTA exist. | Real successful journey screenshots and certificate links by supplier. |
| Does subscription consent stay understandable across months? | UI wrap-up flags bill autodebit vs insurance subscription cognitive load. | User comprehension test and cancellation rate after first renewal. |
| Are support and cancellation paths clear? | Cancel policy backend exists; management UI has cancel CTA for selected products. | Product-by-product cancellation/refund policy matrix. |

---

## 15. Recommended Audit Plan

1. Build a product inventory with app ID, supplier ID, product type, mode, launch state, and owner.
2. Pull quantitative dashboard snapshots for at least 30 days: eligible traffic, load, check, untick, payment submit, payment confirm, delivery success, certificate view, support ticket count.
3. Create a UX test matrix for the highest-risk journeys: Cyber MT, Bill embedded Peaceful/Payer, Motorbike SaveMoney, Screen insurance, Travel OTA, premium collection lookup.
4. Validate money safety with test cases: wallet, linked bank, SDSL/MMF, free trial, direct discount, renewal, cancellation, refund, provider delayed issuance.
5. Validate policy management with every category chip and every supplier/product type.
6. Review CS tickets by product line and classify root cause: UI misunderstanding, provider delay, payment issue, certificate issue, partner maintenance, data/status mismatch.
7. Run `/product-audit` scoring only after the evidence above is attached or summarized.

---

## 16. Open Questions And Evidence Gaps

| Gap | Why it matters |
|---|---|
| Current production config for all app IDs/supplier IDs | Product overview, FE constants, and backend migrations are not fully aligned in the inspected snapshot. |
| Trạng thái launch hiện tại của Term Life, NNX/bảo lãnh thuốc, Mini Healthcare | Email cho thấy đang có trao đổi integration/design, nhưng trạng thái production cần thêm bằng chứng release/config. |
| Dashboard exports for Insurance | Local Data folder did not contain a usable Insurance dataset in this pass. |
| Full Figma/UI flow extraction | Design folder and Figma links exist, but this doc only summarizes UI behavior from source/spec/email, not full screen-by-screen design. |
| Partner SLA matrix | Needed for certificate delivery, refund, cancellation, and maintenance audit. |
| Event taxonomy validation | Needed before trusting attachment-rate and conversion dashboards. |
| Source branch/build confirmation | `insurance-webapp` snapshot has inconsistencies that should be resolved before code-level audit claims are treated as production truth. |

---

## 17. Source Manifest

### 17.1 Confluence / Product Docs

| Alias | Source | Key line refs used |
|---|---|---|
| C01 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/273538069_Insurance product line overview.md` | Product lines, app IDs, suppliers: L10-L38. |
| C02 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/268095061_Insurance portfolio & SKUs summary info.md` | SKU/pricing anchors: L10-L30. |
| C03 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/268084164_Handover Insurance (Distribution).md` | Internal/external PICs and current projects: L8-L17, L23-L46, L66-L104. |
| C04 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/244520820_Insurance UIUX 2025.md` | Embedded lines, A/B priority, opt-in/opt-out component work: L5-L34. |
| C05 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/224783660_Insurance Contract Management.md` | Contract management tabs, cards, categories, certificate edge cases: L21-L99. |
| C06 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/237002537_Routing Insurance.md` | Routing rules, scenarios, metrics, segment IDs: L15-L158. |
| C07 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/219680272_Embedded Insurance Funnel.md` | Dashboard and event mismatch feedback: L5-L22. |
| C08 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/158044417_Insurance  Promotion Free-Trial Framework.md` | Free-trial framework, sponsor budget, disclosure, event tracking: L14-L132. |
| C09 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/230292981_[Insurance] Thông tin Sản phẩm - Đối tác để hỗ trợ CS xử lý ticket.md` | CS/Ops matrix by app ID, partner, source of funds, refund/cancel, SLA: L10-L127. |
| C10 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/189366979_[Insurance] - App id & Event tracking.md` | Supplier/app/zone mapping and event taxonomy: L150-L214. |
| C11 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/194755527_Cyber Risk -VBI-Bảo hiểm an ninh mạng.md` | Cyber business value, packages, auto debit, edge cases: L52-L176. |
| C12 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/132339429_Phone Cracked Screen​ (Bảo hiểm rơi vỡ màn hình).md` | Screen packages, claim, device verification, refund FAQ, tracking: L31-L175. |
| C13 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/224786861_Fuse - Bảo hiểm Sống tự tin (Credit Topup).md` | Confident Living price, proposition, consent, refund, certificate: L10-L112. |
| C14 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/230285552_Fuse - Bảo hiểm Education Học đường vui khỏe.md` | Stage bảo hiểm học đường, eligibility, quyền lợi, hoàn phí, chứng nhận: L11-L178, L221-L236. |
| C15 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/230287402_Fuse - BH sức khỏe tích lũy.md` | Accumulated health component stages, consent, benefit management: L11-L72. |
| C16 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/219681037_House Protection Embedded Electricity_Water Domain.md` | Home insurance packages, address/bill rules, T&C updates: L14-L164. |
| C17 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/268100140_Bike in app integrate via Savemoney.md` | Motorbike in-app context, fields, autofill, package prices, tracking: L7-L75. |
| C18 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/310009933_Health Insurance - Product Overview.md` | MiniHealth definition, target, workflow, packages: L5-L72. |
| C19 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/305007137_Health Insurance - Product Concept.md` | Health concept, user psychology, strategic product pillars: L5-L64. |
| C20 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/261511567_Chubb  Bill protection auto debit oneflow.md` | Peaceful Living packages, routing, renewal, freelook, claim/cancel rules: L17-L179, L220-L315. |
| C21 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/165223140_OTA Travel Insurance phase 1 - Bảo hiểm trên chuyến bay 1 chiều (One-way Flight).md` | Saladin flight insurance business, packages, conditions, claim/FAQ: L15-L214, L219-L260. |
| C22 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/194762038_OTA Bus Insurance phase 1 - Bảo hiểm chuyến đi trên vé xe Bus 1 chiều one-way.md` | Bus trip insurance business, component, statuses, T&C, tracking: L30-L124, L168-L260. |
| C23 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/153773179_DGS - Thu phí bảo hiểm - Insurance Premium collection.md` | Premium collection business, payment rules, reminders, deep links: L7-L85, L106-L185, L192-L257. |
| C24 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/200830746_OTA Travel Flight- Integrate Chubb.md` | Chubb travel API/COI design, highlight, conditions, claim flow: L50-L83, L176-L340. |
| C25 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/244525885_OTA cross sale insurance after booking successfully.md` | OTA post-booking cross-sell context and behavior: L8-L13. |
| C26 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/261513493_Insurance Zone display.md` | Zone/product placement for Bill, Bus, Flight, Hub, Topup, Money Transfer, Screen: L10-L44. |
| C27 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/251070828_New UI Component adapt routing insurance & A_B Testing UI.md` | New embedded component content for Screen, Confident Living, Payer Protection: L12-L35. |
| C28 | `Wealth Solution/02. Context/Confluence/Insurance/Product Page/207070807_Insurance Hub - Performance Tracking.md` | Hub traffic/click metrics and event distribution tracking: L43-L51, L112-L140. |
| C29 | `Wealth Solution/02. Context/Confluence/Insurance/Technical Page/329207148_MoneyTransfer x VBI.md` | MoneyTransfer x VBI current/new flow, PayNow flag, first-user handling, delivery: L113-L178. |

### 17.2 Source Code

| Alias | Source | Key line refs used |
|---|---|---|
| S01 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/README.md` | Ares / Insurance core / RabbitMQ: L4-L9. |
| S02 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/internal/bill/constant.go` | Payment types, order/refund/policy statuses, supplier IDs, product line 3275: L75-L178. |
| S03 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/create_order.go` | Create-order validation, embed data, cache/queue: L20-L180. |
| S04 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/handle_payment_callback.go` | Callback validation and payment-success transition: L19-L190. |
| S05 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/deliver.go` | Deliver flow, provider request, refund/manual-check enqueue: L15-L200. |
| S06 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/get_deliver_status.go` | Delivery status polling and retry/refund behavior: L15-L177. |
| S07 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/upsert_policy.go` | Policy upsert after successful Micro Insurance delivery: L14-L47. |
| S08 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/query_bill.go` | Query bill, provider mapping, cache, bill-storage event: L23-L183, L211-L270. |
| S09 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/get_policy.go` | Policy query, active/expired/canceled logic, response fields: L19-L204, L285-L381. |
| S10 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/internal/bill/service/refund.go` | Refund constraints, logs, TPE refund, status update: L17-L205. |
| S11 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/changelog/1.1.0.sql` | Collection product line 3081, Payoo providers, mappings: L9-L46. |
| S12 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/changelog/1.2.0.sql` | Micro Insurance product line 3275, Saladin OTA, order history: L3-L76, L181-L183. |
| S13 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/changelog/1.3.0.sql` | Igloo/PVI screen insurance mapping: L6-L22. |
| S14 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/changelog/1.6.0.sql` | Saladin BP/Trip providers and app mappings: L3-L49. |
| S15 | `Wealth Solution/03. Fact/Source Code/Insurance/ares/changelog/1.7.0.sql` | VBI Cyber provider, supplier, app mapping: L3-L21. |
| FE01 | `Wealth Solution/03. Fact/Source Code/Insurance/insurance-webapp/package.json` | React/micro-app dependencies and scripts: L1-L49. |
| FE02 | `Wealth Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/constants/insurancePurchase.ts` | FE supplier IDs, product types, event IDs: L3-L103. |
| FE03 | `Wealth Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/features/home/index.tsx` and `features/home/GroupTabs/index.tsx` | Hub title/tabs and home sections: Home L12-L49, GroupTabs L23-L117. |
| FE04 | `Wealth Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/hooks/useStandAloneInsurance.tsx` | Standalone package fetch/order/default/certificate/event behavior: L15-L247. |
| FE05 | `Wealth Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/hooks/useCrossSellInsurance.tsx` | Cross-sell result page, cart/order token, fetch info, package check/untick: L23-L452. |
| FE06 | `Wealth Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/hooks/useAutodebitInsurance.tsx` | Agreement lookup and binding creation: L22-L125. |
| FE07 | `Wealth Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/features/management/PolicyManagement/InsurancePurchasePolicies.tsx` | Purchase policy management categories/status fetch: L26-L167. |
| FE08 | `Wealth Solution/03. Fact/Source Code/Insurance/insurance-webapp/src/features/management/PolicyManagement/InsurancePurchasePolicy.tsx` | Policy card CTA/certificate/cancel behavior: L24-L164. |

### 17.3 Jira

| Alias | Source | Key line refs used |
|---|---|---|
| J01 | `Wealth Solution/02. Context/Jira/Insurance/PCFFS-20739_[Insur][be] Tích hợp HĐ BH với Quản lí BH của ZLP.md` | Contract-management integration: L5-L20. |
| J02 | `Wealth Solution/02. Context/Jira/Insurance/PCFFS-21610_[Insur][be] Enable free trial cho BH sống an vui - Stand alone flow.md` | Peaceful Living free trial standalone: L5-L19. |
| J03 | `Wealth Solution/02. Context/Jira/Insurance/PCFFS-21609_[Insur][be] Enable auto subcription cho BH sống an vui - Stand alone flow.md` | Peaceful Living subscription mode: L5-L24. |
| J04 | `Wealth Solution/02. Context/Jira/Insurance/PCFFS-21662_[Insur][be] Update logic charge phí cho tháng thứ 3 trở đi.md` | Renewal charge date logic and comments: L5-L30. |
| J05 | `Wealth Solution/02. Context/Jira/Insurance/PCFFS-19979_[Insur][al] Integration with Agreement Pay to inject new SoF.md` | Agreement Pay SoF issue for Cyber MT: L5-L24. |
| J06 | `Wealth Solution/02. Context/Jira/Insurance/PCFFS-19980_[Insur][al] Apply logic check FAU segment on Insur Hub.md` | Segment-first logic to reduce VBI calls: L5-L30. |
| J07 | `Wealth Solution/02. Context/Jira/Insurance/PCFFS-19978_[Insur][al] Take over Insurance Technical Knowledge.md` | Technical ownership / knowledge takeover: L5-L29. |

### 17.4 CS Tickets

| Alias | Source | Pattern |
|---|---|---|
| CS01 | `Wealth Solution/03. Fact/CS Ticket/Insurance/ISSUE-30191_[Ứng dụng] - [1020 - SAVEMONEY] Lỗi ứng dụng - Cas.md` | Paid motorbike insurance but certificate/contract not visible; partner compensation/context. |
| CS02 | `Wealth Solution/03. Fact/CS Ticket/Insurance/ISSUE-35616_[Ứng dụng] - [4326 - Bảo hiểm xe máy Save Money] L.md` | Contract visible in All but not category; partner webview vs ZLP display. |
| CS03 | `Wealth Solution/03. Fact/CS Ticket/Insurance/ISSUE-37225_[Thanh toán] - [4326 - Bảo hiểm xe máy Save Money].md` | Package selection dispute, logs showed selected package. |
| CS04 | `Wealth Solution/03. Fact/CS Ticket/Insurance/ISSUE-37457_[Thanh toán] - [4326 - Bảo hiểm xe máy Save Money].md` | Paid but status processing due partner approval. |
| CS05 | `Wealth Solution/03. Fact/CS Ticket/Insurance/ISSUE-38892_[Ứng dụng] - [NONE] UD-Không tìm thấy hóa đơn - Ti.md` | Partner maintenance / premium lookup disruption. |
| CS06 | `Wealth Solution/03. Fact/CS Ticket/Insurance/ISSUE-38955_[Ứng dụng] - [3274 - Bảo hiểm Du Lịch] Lỗi ứng dụn.md` | DOB date-picker issue on specific Android device. |

### 17.5 Email / Chat

| Alias | Source | Key line refs used |
|---|---|---|
| E01 | `Vault/FlaggedEmails/Insurance/2026-03-20 - AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQADNX9v3wfcpDhiETzjhhXqg= - [WS - Insurance] - [Action Required] Blocker on Free trial Feature – Need Support.md` | Free-trial blocker and growth importance: L1-L46. |
| E02 | `Vault/FlaggedEmails/Insurance/2026-05-22 - AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQANsAAQJjlPFKvnNCwAHwPM4= - Re Apply free trial voucher for other SoF - Discussion.md` | Long-term skip-pay direction and Agreement Pay root-cause note: L34-L81, L199-L231, L255-L265. |
| E03 | `Vault/FlaggedEmails/Insurance/2026-03-24 - AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQAEyY1VPARKtPgrfD1gCnGVc= - [WS - Insurance] Cyber Insurance – VBI Feedback.md` | VBI API overload feedback: L5-L20. |
| E04 | `Vault/FlaggedEmails/Insurance/2026-05-27 - AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQALL63vhbLIpNhmQhFnETmTk= - RE [Chubb Life - Zalopay] Tech Meeting - Mini Term Life.md` | COI/email/OA decisions and API meeting next steps: L13-L31, L85-L100. |
| E05 | `Vault/FlaggedEmails/Insurance/2026-05-28 - AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQAADU-7vJx00XvjGTmyWepM8= - Wrap-up UI Discussion Bill Payment & Insurance.md` | Bill UI cognitive load, static vs rolling text, rollout/exposure cap: L7-L72. |
| E06 | `Vault/FlaggedEmails/Insurance/2025-12-31 - AAQkAGZmZmQ0NmI1LTkyOTYtNDIyNy1hZTFlLWQ3NTkyYTMzZWRiNQAQADr0iuNc781Ig4cEpTIb8wI= - Xác nhận handover scope công việc PO – Domain Insurance (Distribution).md` | Handover and Cyber MT follow-up: L5-L14. |
| CH01 | `Vault/FlaggedChats/Group/26-05-06 - Insurance System Walkthrough Meeting - 19_meeting_MDBhNzdhYjQtYzA0NS00YzAwLWFjOGUtODc4MmVlODZjOWEz_thread_v2.md` | Tracking/zone ID discussion and `4072` mention: messages around exported L1-L5 in chat file. |

### 17.6 HBS 2026 / Other

| Alias | Source | Key line refs used |
|---|---|---|
| O01 | `Wealth Solution/02. Context/Others/03. Insurance/09. Other Task/HBS 2026/Zalopay HBS Capstone Final Presentation vSend.pdf` | Original HBS 2026 capstone deck provided by user for additional review. |
| O02 | `Wealth Solution/02. Context/Others/03. Insurance/09. Other Task/HBS 2026/Zalopay HBS Capstone Final Presentation vSend - extracted outline.md` | Line-numbered extraction of HBS deck headings and page-level content used for truth-mode citation: L7-L83. |

---

## 18. Change Log

| Version | Date | Author | Change |
|---|---|---|---|
| v1.2 | 2026-06-03 | GPT 5.5 | Added HBS 2026 lens, line-numbered HBS extraction, ZaloPay current-state comparison, visual map, and audit additions for future `/product-audit`. |
| v1.1 | 2026-06-03 | GPT 5.5 | Expanded Vietnamese business/product deep dive by individual insurance product; added product-specific Confluence evidence aliases. |
| v1.0 | 2026-06-03 | GPT 5.5 | Initial knowledge base synthesized from Insurance Confluence, Jira, source code, CS tickets, email, chat, and MMF reference format. |
