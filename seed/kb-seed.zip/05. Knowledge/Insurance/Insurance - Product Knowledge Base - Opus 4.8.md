# 🛡️ Insurance — Product Knowledge Base

> Tài liệu hệ thống hoá toàn bộ sản phẩm **Insurance** thuộc ZaloPay Wealth Solution: định vị, danh mục, kiến trúc, luồng nghiệp vụ, từng sản phẩm con, routing phân phối, data model, vận hành & sự cố. Biên soạn theo **TRUTH-mode** — mỗi dữ kiện đều dẫn nguồn `file://` tới Source Code / Confluence / Jira / CS Ticket / Data trong ZLP Workspace. Mục tiêu: làm nền tảng để **audit** sản phẩm Insurance.

---

## 0. Document Control

| Trường | Giá trị |
|---|---|
| **Tên tài liệu** | Insurance - Product Knowledge Base - Opus 4.8 |
| **Phạm vi** | Toàn bộ product line Insurance (Distribution + Collection) và các sản phẩm con |
| **Phiên bản** | **v1.0** (khởi tạo) |
| **Ngày cập nhật** | 2026-06-09 |
| **Owner** | DuyNQ5 |
| **Tech Owner (hệ thống)** | Nguyên. Lê Hoàng (2); Tech Backup: Thành. Nguyễn Khắc (4) [[EA-DD:L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/System%20General/200809702_%5BEA%5D%5BDD%5D%20Insurance.md#L5)] |
| **PO/BO nền tảng** | DGS [[EA-DD:L10](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/System%20General/200809702_%5BEA%5D%5BDD%5D%20Insurance.md#L10)] |
| **Status** | 🟡 Draft (chờ review) |
| **Nguồn biên soạn** | Source Code (`ares`, `insurance-webapp`), Confluence (Product/Technical/System General EA), Jira (PCFFS, 89 ticket), CS Ticket (23 ticket), Data dictionary, Objective/KPI. Xem **§15 Source Index**. |

**Changelog**

| Version | Ngày | Tóm tắt |
|---|---|---|
| v1.0 | 2026-06-09 | Khởi tạo từ đa nguồn: kiến trúc `ares` + `insurance-webapp`, 13+ sản phẩm con, routing engine, premium collection, data model, error codes, roadmap, CS issues. Đánh dấu các điểm mâu thuẫn (§15.3) và gap (§14). |

---

## ⚡ Fact Sheet (TL;DR)

| Thuộc tính | Chi tiết |
|---|---|
| **Định nghĩa** | "Insurance" là nhóm sản phẩm bảo hiểm trong ZaloPay Wealth Solution, gồm 2 product line: **Distribution** (phân phối/bán bảo hiểm) và **Collection** (thu hộ phí bảo hiểm nhân thọ) [[ProdLine:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L7)]. Mục tiêu hệ thống: trả phí dịch vụ bảo hiểm, cấp đơn (travel, bus, bill protection…), quản lý hợp đồng của user [[EA-DD:L13](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/System%20General/200809702_%5BEA%5D%5BDD%5D%20Insurance.md#L13)]. |
| **Trạng thái** | 🟢 Phần lớn Live trên Production; đang phát triển: **Mini Healthcare** (dự kiến cuối T5/2026) và **Mini Term Life** (dự kiến T7/2026) [[AprRep:L13](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Monthly%20Report/329194471_Apr%20Report%20-%20WS_%20Insurance.md#L13)]. |
| **Mô hình phân phối** | Embedded (mua kèm), Cross-sell, Standalone (Hub bảo hiểm), B2B2C [[PortFolio:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/268095061_Insurance%20portfolio%20%26%20SKUs%20summary%20info.md#L7)]. |
| **Hệ thống lõi** | **`ares`** — "Insurance core" (Go 1.21, Gin, GORM/MySQL, Redis, RabbitMQ + Kafka, Elasticsearch) [[aresREADME:L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/README.md#L5)]; dùng chung nền tảng **bill/debt-collection**. Repo: gitlab `aqr/telco/ares` [[EA-DD](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/System%20General/200809702_%5BEA%5D%5BDD%5D%20Insurance.md)]. Frontend: **`insurance-webapp`** (React micro-app) [[webPkg:L2](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/insurance-webapp/package.json#L2)]. |
| **Đối tác Insure-tech / aggregator** | Saladin, Igloo, Chubb, VBI, SaveMoney, Fuse, Payoo, PasarPolis [[ProdLine:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L9)] [[CSPartner:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L9)]. |
| **Nhà bảo hiểm (underwriter)** | Bảo Việt, PVI, VBI, Chubb, ABIC, MIC, GIC, Bảo Long, MSIG, UIC; Collection: Cathay Life, Generali, FWD, MetLife (BIDV), Prevoir [[PortFolio:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/268095061_Insurance%20portfolio%20%26%20SKUs%20summary%20info.md#L9)] [[PremiumCol:L118](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/153773179_DGS%20-%20Thu%20ph%C3%AD%20b%E1%BA%A3o%20hi%E1%BB%83m%20-%20Insurance%20Premium%20collection.md#L118)]. |
| **Nguồn tiền (SOF)** | all SOF (ví ZaloPay, MMF, VietQR, bank, Paylater, Credit card); riêng Payoo chỉ VietQR; Cathay all SOF trừ Credit Card [[CSPartner:L38](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L38)]. |
| **Hạn mức thanh toán** | Theo hạn mức ví, tối đa **20 triệu đồng/giao dịch** [[CSPartner:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L9)]. |
| **Phí dịch vụ** | "Thu phí MC" — ZaloPay đóng vai trò đại lý/đơn vị trung gian thanh toán & hiển thị; phần lớn không thu phí từ user [[CSPartner:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L9)]. |
| **Vòng đời đơn (order)** | `Created(5)` → `PaymentSuccess(6)` → `DeliverManualCheck(-400)` → `DeliverSuccess(1)` / `DeliverFailed(-401)` / `DeliverProcessing(7)`; lỗi cấp đơn → tự động Refund [[aresConst:L89](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/constant.go#L89)] [[aresDeliver:L74](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/service/deliver.go#L74)]. |
| **KPI gần nhất (T4/2026)** | TPV **727 triệu VND** (đạt 67% KPI tháng, -4% MoM) [[AprRep:L11](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Monthly%20Report/329194471_Apr%20Report%20-%20WS_%20Insurance.md#L11)]. |
| **Owner / Version** | DuyNQ5 / **v1.0** — 2026-06-09. |

---

## 1. Tổng quan & Định vị Sản phẩm

### 1.1 Insurance là gì trong hệ ZaloPay
Insurance là một mảng của **Wealth Solution**, cung cấp dịch vụ bảo hiểm cho người dùng ZaloPay theo ba nhóm năng lực: (1) **trả phí** một số dịch vụ bảo hiểm của các nhà cung cấp (Cathay, Generali, FWD…), (2) **cấp đơn bảo hiểm** (travel, bus, bill protection… của Saladin, Igloo, Chubb…), và (3) **quản lý hợp đồng** bảo hiểm của user [[EA-DD:L13](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/System%20General/200809702_%5BEA%5D%5BDD%5D%20Insurance.md#L13)].

Về mặt sản phẩm, Insurance được tổ chức thành **2 product line** [[ProdLine:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L7)]:

- **Distribution** — phân phối/bán bảo hiểm (logo `other_insurance`). Gồm các nhóm: *Compulsory* (TNDS xe máy/ô tô), *Non-compulsory* (Travel, Cyber, Others — Home/Health/PA/CI/Maternity), và *Bill* (các bảo hiểm nhúng theo hoá đơn: Health-accumulate, Confidence Living, Cracked Screen, Payer Protection, Bill Protection, Happy Edu).
- **Collection** — thu hộ phí bảo hiểm nhân thọ (logo `pay_insurance`): Generali, MetLife, FWD, Cathay Life (qua Payoo hoặc tích hợp trực tiếp) [[ProdLine:L33](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L33)].

### 1.2 Định vị chiến lược
- **Tăng TPV & Transaction** ngành bảo hiểm, đặc biệt qua mô hình **embedded** (nhúng SKU bảo hiểm vào các use-case thanh toán có sẵn: nạp điện thoại, mua thẻ, thanh toán hoá đơn điện/nước/học phí/khoản vay, mua vé máy bay/xe bus) để tận dụng traffic lớn của ZaloPay [[Routing:L10](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L10)].
- **ZaloPay là đại lý/đơn vị trung gian** (phân phối, hiển thị, trung gian thanh toán) — rủi ro bảo hiểm và nghĩa vụ bồi thường thuộc nhà bảo hiểm/đối tác [[Phone:L65](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/132339429_Phone%20Cracked%20Screen%E2%80%8B%20%28B%E1%BA%A3o%20hi%E1%BB%83m%20r%C6%A1i%20v%E1%BB%A1%20m%C3%A0n%20h%C3%ACnh%29.md#L65)].
- **Chuyển dịch sang subscription/auto-debit** (gia hạn tự động) để tăng retention: Cracked Screen (đã release auto-sub 15/4/2026), Bill Protect & Cyber (đang triển khai) [[AprRep:L70](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Monthly%20Report/329194471_Apr%20Report%20-%20WS_%20Insurance.md#L70)].

### 1.3 Người dùng & use case
Người dùng ZaloPay đã KYC, mua bảo hiểm theo 3 cách: **chủ động** vào Hub bảo hiểm (standalone), **mua kèm** khi đang thanh toán/đặt vé (embedded/cross-sell), hoặc **nhập mã hợp đồng** để đóng phí bảo hiểm nhân thọ định kỳ (collection). Hợp đồng được tập trung tại **Quản lý hợp đồng** (2 tab: Bảo hiểm trên ZaloPay / Hợp đồng nhân thọ) [[Contract:L31](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224783660_Insurance%20Contract%20Management.md#L31)].

---

## 2. Danh mục Sản phẩm (Portfolio)

### 2.1 Sơ đồ phân loại (Taxonomy)

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }, "flowchart": { "curve": "basis" }}}%%
graph LR
    INS([Insurance]) --> DIST[Distribution<br/>Phân phối/bán BH]
    INS --> COL[Collection<br/>Thu hộ phí BH nhân thọ]

    DIST --> CMP[Compulsory - TNDS]
    DIST --> NON[Non-compulsory]
    DIST --> BILL[Bill / Embedded]

    CMP --> Bike[BH Xe máy<br/>SaveMoney/Saladin]
    CMP --> Car[BH Ô tô<br/>SaveMoney]

    NON --> Travel[BH Du lịch<br/>Saladin & Chubb]
    NON --> Cyber[BH An ninh mạng<br/>VBI]
    NON --> Home[BH Nhà<br/>SaveMoney/PVI]
    NON --> HealthSA[BH Sức khoẻ<br/>Saladin]
    NON --> MiniHealth[Mini Healthcare<br/>MSIG - đang dev]

    BILL --> Phone[BH Màn hình ĐT<br/>Igloo/PVI]
    BILL --> Payer[BH Người thanh toán<br/>Saladin]
    BILL --> BillP[BH Sống An Vui<br/>Chubb - auto debit]
    BILL --> Confidence[BH Sống tự tin<br/>Fuse/GIC]
    BILL --> Edu[BH Học đường vui khoẻ<br/>Fuse/GIC]
    BILL --> HealthAcc[BH Sức khoẻ tích luỹ<br/>Fuse/Bảo Long]
    BILL --> Bus[BH Chuyến đi Bus<br/>Saladin]

    COL --> Cathay[Cathay Life]
    COL --> Payoo[Payoo: Generali/FWD/MetLife/Prevoir]
```

### 2.2 Bảng tra cứu chính (App ID → Sản phẩm → Đối tác → Zone)

> Nguồn: bảng "Insurance product line overview" [[ProdLine:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L9)] và bảng hỗ trợ CS [[CSPartner:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L9)]. `MC ID` = mã merchant để CS/đối soát.

| App ID | MC ID | Sản phẩm | Insure-tech | Underwriter | Method | Zone hiển thị | Hoàn/hủy |
|---|---|---|---|---|---|---|---|
| 1020 / 4326 / 3951 | 450419 | BH Xe máy (TNDS) | SaveMoney / Saladin | ABIC, MIC, PVI, VBI, Bảo Minh | Standalone | Hub bảo hiểm | Không hoàn hủy [[CSPartner:L60](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L60)] |
| 3507 / 3951 | 450419 | BH Ô tô (TNDS) | SaveMoney / Saladin | MIC, Tasco, HDI, PVI, Bảo Việt | Standalone | Hub bảo hiểm | Không hoàn hủy |
| 3274 | 452498 | BH Du lịch (trễ/hủy, hành lý, nội địa) | Saladin | Bảo Việt | Embedded | OTA Flight (Domestic) | Không hoàn (trước khởi hành) [[TravelP1:L214](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/165223140_OTA%20Travel%20Insurance%20phase%201%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20tr%C3%AAn%20chuy%E1%BA%BFn%20bay%201%20chi%E1%BB%81u%20%28One-way%20Flight%29.md#L214)] |
| 3834 | 497426 | BH Du lịch Chubb (domestic/intl) | Chubb | Chubb | Embedded + Cross-sell | OTA Flight | Không hoàn (trừ từ chối visa) [[CSPartner:L58](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L58)] |
| 3676 | 452498 | BH Chuyến đi (Bus) | Saladin | Bảo Việt | Embedded | OTA Bus | (xem §8) |
| 3682 | 476162 | BH An ninh mạng (Cyber) | VBI | VBI | Embedded (Telco) + Cross-sell (chuyển tiền) | topup | Refund qua VBI, SLA 24h [[CSPartner:L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L44)] |
| 3394 | 489497 | BH Màn hình điện thoại | Igloo | PVI | Embedded (Telco - mua thẻ) | phonecard | Hủy 24h, phí hoàn 1.100đ [[CSPartner:L41](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L41)] |
| 2390 | 452498 | BH Người thanh toán (Payer) | Saladin | Bảo Việt | Embedded (Bill - Điện) | electric | Không hoàn hủy [[CSPartner:L33](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L33)] |
| 4491 | 497426 | BH Sống An Vui (Bill Protection) | Chubb | Chubb | Embedded (Bill - Điện), auto-debit | (dự kiến) | Free-look 14 ngày [[CSPartner:L59](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L59)] |
| 4015 | 500228 | BH Sống tự tin (Confidence Living) | Fuse | GIC | Embedded (Bill - khoản vay) | cf | Hoàn trong 3 ngày [[CSPartner:L126](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L126)] |
| 4041 | 500228 | BH Học đường vui khoẻ | Fuse | GIC | Embedded (Bill - học phí) | edu | Hoàn trong 3 ngày [[CSPartner:L124](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L124)] |
| 4042 | 500228 | BH Sức khoẻ tích luỹ | Fuse | Bảo Long | Embedded (Telco - trả sau/mua thẻ) | postpaid | Không hoàn phí [[CSPartner:L122](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L122)] |
| 3935 / 3835 | 450419 | BH Nhà (Micro/Standalone) | SaveMoney | ABIC, PVI Huế | Embedded (Bill điện/nước) / Standalone | water | Không hoàn hủy [[CSPartner:L52](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L52)] |
| 4042 (OFFICE_HEALTH) | — | BH Sức khoẻ tích luỹ (Office) | Fuse | Bảo Long | Embedded/Standalone | postpaid | (xem §8) |
| 3082 | 482402 | Thu phí BH — Cathay Life | (trực tiếp) | Cathay Life | Standalone | Hub thanh toán phí | Tuỳ đối tác; **bảo trì do đối tác cắt API 6/9** [[ProdLine:L35](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L35)] |
| 3232 | 240126 | Thu phí BH — Generali/MetLife/FWD | Payoo | Generali, MetLife, FWD | Standalone | Hub thanh toán phí | Chỉ VietQR [[CSPartner:L63](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L63)] |

> ⚠️ **Lưu ý audit:** cùng một app id (vd `3951` Saladin Mweb, `3232` Payoo) được tái sử dụng cho nhiều underwriter; định danh sản phẩm thực tế nằm ở cặp **(app id, supplier id)** trong code (xem §4, §10). Một số app id (Payoo 3232, Vinatti 4689) ở frontend map về supplier id `0` = **chưa wire** [[webPurchase:L4](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/insurance-webapp/src/constants/insurancePurchase.ts#L4)].

### 2.3 Bảng SKU & giá tiêu biểu

| Sản phẩm | SKU/Gói | Giá | Quyền lợi chính |
|---|---|---|---|
| Cyber (VBI) | Gói tháng / Gói năm (12 kỳ) | 5.000đ/lần (60k/năm) ; 3.000đ/lần (36k/năm) | Bảo vệ 10tr/vụ, tối đa 25tr–50tr/năm + tai nạn cá nhân [[Cyber:L107](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-B%E1%BA%A3o%20hi%E1%BB%83m%20an%20ninh%20m%E1%BA%A1ng.md#L107)] |
| Màn hình ĐT (Igloo/PVI) | MONTHLY-PLAN 7000/11000/16000 | 7.700đ / 12.100đ / 17.600đ (incl VAT) | STBH 1tr / 2tr / 3tr; thời hạn 1 tháng [[Phone:L43](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/132339429_Phone%20Cracked%20Screen%E2%80%8B%20%28B%E1%BA%A3o%20hi%E1%BB%83m%20r%C6%A1i%20v%E1%BB%A1%20m%C3%A0n%20h%C3%ACnh%29.md#L43)] |
| Xe máy (SaveMoney/ABIC) | >50cc / ≤50cc / điện / 3 bánh | 66.000đ / 60.500đ / 60.500đ / 319.000đ (1 năm) | TNDS bắt buộc [[BikeSM:L42](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/268100140_Bike%20in%20app%20integrate%20via%20Savemoney.md#L42)] |
| Sống An Vui (Chubb) | SKU 10001–10004 | 3.000đ / 5.000đ /tháng | Tai nạn 15tr / 30tr + quà Teladoc (10001/10003) [[ChubbBill:L25](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L25)] |
| Sống tự tin (Fuse/GIC) | — | 4.000đ/tháng (Phase 1) | Tai nạn đến 5tr + trợ cấp thất nghiệp 2tr [[SongTuTin:L11](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224786861_Fuse%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20S%E1%BB%91ng%20t%E1%BB%B1%20tin%20%28Credit%20Topup%29.md#L11)] |
| Travel Saladin (nội địa) | Trễ/hủy ; Hành lý ; Du lịch | 30k/60k ; 15k/30k ; 45k/90k…260k | Bồi thường trễ/hủy 400k; hành lý đến 15tr; PA đến 250tr [[PortFolio:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/268095061_Insurance%20portfolio%20%26%20SKUs%20summary%20info.md#L30)] |
| Travel Chubb | Quốc nội / Quốc tế | 45k–140k / 75k–235k | PA đến 210tr; hủy chuyến đến giá vé (max 5tr) [[ChubbTravel:L235](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/200830746_OTA%20Travel%20Flight-%20Integrate%20Chubb.md#L235)] |
| Bus (Saladin) | Gói 10K / 20K | 10.000đ / 20.000đ/chuyến | PA đến 200tr / 400tr [[Bus:L317](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/194762038_OTA%20Bus%20Insurance%20phase%201%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20chuy%E1%BA%BFn%20%C4%91i%20tr%C3%AAn%20v%C3%A9%20xe%20Bus%201%20chi%E1%BB%81u%20one-way.md#L317)] |
| Nhà (SaveMoney/PVI Huế) | Cơ bản / Nâng cao | 3.000đ / 10.000đ/tháng (embed) | Nhà 90tr / 150tr + tai nạn chủ nhà; miễn thường 1tr [[House:L155](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/219681037_House%20Protection%20Embedded%20Electricity_Water%20Domain.md#L155)] |
| Học đường (Fuse/GIC) | Gói 6 tháng / 12 tháng | 60.000đ / 120.000đ (10k/tháng) | Bệnh học đường đến 5tr; tai nạn 13tr; bạo lực HĐ 6tr [[Edu:L19](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230285552_Fuse%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20Education%20H%E1%BB%8Dc%20%C4%91%C6%B0%E1%BB%9Dng%20vui%20kh%E1%BB%8Fe.md#L19)] |
| Sức khoẻ tích luỹ (Fuse/Bảo Long) | tích luỹ theo lần | 2.400đ/giao dịch (200 lần full) | Bệnh văn phòng đến 20tr/năm + trợ cấp nằm viện [[PortFolio:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/268095061_Insurance%20portfolio%20%26%20SKUs%20summary%20info.md#L30)] |
| Mini Healthcare (MSIG) | Gói 1/2/3 | 577k / 1.189tr / 1.645tr /năm (~2.000đ/ngày) | Nội/ngoại trú; bảo lãnh thuốc; *đang phát triển* [[HealthOverview:L66](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009933_Health%20Insurance%20-%20Product%20Overview.md#L66)] |

---

## 3. Business Context — Mục tiêu, KPI & Tuân thủ

### 3.1 KPI & phễu đo lường
Bộ KPI chuẩn (đặc biệt cho Bill Protect) theo phễu Upper → Middle → Bottom [[Metric:L10](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Product%20KPI/01.%20Product%20Contribution/Insurance%20Metric.md#L10)]:

| Tầng | Metric | Công thức |
|---|---|---|
| Upper | # Bill Protect Exposure (Transaction & User level) | # load zone bảo hiểm |
| Middle | % Attachment Rate | # Cashier / # Exposure (Transaction) |
| Bottom | % Conversion Rate (Policy/Bills) | New Subscription / Exposure (Transaction) |
| Bottom | % User Level Cover Rate (New / Cumulative) | New (hoặc Cumulative) Subscription / Exposure (User) |
| Bottom | $ GWP, # Renewal, # Unsubscribed | Gross Written Premium, gia hạn, huỷ |

Benchmark tham chiếu: **cover rate mới 5–7%**, **cover rate luỹ kế 25–30%** [[Metric:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Product%20KPI/01.%20Product%20Contribution/Insurance%20Metric.md#L7)].

### 3.2 Hiệu suất gần nhất (T4/2026)
TPV tháng 4 đạt **727 triệu VND = 67% KPI, -4% MoM**, chủ yếu do **delay go-live Mini Healthcare** và **Cyber x Money Transfer** — hai động lực tăng trưởng lớn nhất theo kế hoạch [[AprRep:L11](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Monthly%20Report/329194471_Apr%20Report%20-%20WS_%20Insurance.md#L11)]. Theo danh mục: **Civil Liability 116% KPI** (xe máy/ô tô), **Travel 104%**, **Billing 144%** (nhờ Cracked Screen + subscription), **Cyber chỉ 11%** (chưa lên luồng Money Transfer) [[AprRep:L33](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Monthly%20Report/329194471_Apr%20Report%20-%20WS_%20Insurance.md#L33)].

### 3.3 Ràng buộc & tuân thủ
- **KYC bắt buộc** cho phần lớn sản phẩm; thông tin định danh (họ tên, ngày sinh, CMND/CCCD, SĐT/email) được forward sang đối tác để cấp đơn [[Phone:L93](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/132339429_Phone%20Cracked%20Screen%E2%80%8B%20%28B%E1%BA%A3o%20hi%E1%BB%83m%20r%C6%A1i%20v%E1%BB%A1%20m%C3%A0n%20h%C3%ACnh%29.md#L93)]. Backend lấy KYC/identity/DOB từ **UM (gRPC)** và đẩy `IsKYC` vào request query đối tác [[aresUM:L41](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/pkg/zlp/um/client.go#L41)].
- **Giới hạn tuổi theo sản phẩm**: Sống An Vui (Chubb) chặn **18–65 tuổi** [[ChubbBill:L117](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L117)]; Travel 6 tháng–80 tuổi [[TravelP1:L154](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/165223140_OTA%20Travel%20Insurance%20phase%201%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20tr%C3%AAn%20chuy%E1%BA%BFn%20bay%201%20chi%E1%BB%81u%20%28One-way%20Flight%29.md#L154)]; Học đường ≥6 tuổi [[Edu:L65](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230285552_Fuse%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20Education%20H%E1%BB%8Dc%20%C4%91%C6%B0%E1%BB%9Dng%20vui%20kh%E1%BB%8Fe.md#L65)].
- **Hạn mức giao dịch** theo ví, tối đa 20tr [[CSPartner:L9](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L9)].
- **Mô hình thương mại**: com-sharing (vd Cyber 20% [[Cyber:L62](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-B%E1%BA%A3o%20hi%E1%BB%83m%20an%20ninh%20m%E1%BA%A1ng.md#L62)]; Mini Healthcare 27%/gói [[HealthRelease:L53](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009898_Health%20Insurance%20-%20Release%20checklist.md#L53)]).

---

## 4. Kiến trúc Hệ thống (System Architecture)

`ares` là một service Go duy nhất, tổ chức quanh domain lõi **`internal/bill`** (engine debt-collection/bill dùng lại cho bảo hiểm), entrypoint `cmd/server/main.go` [[aresREADME:L5](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/README.md#L5)]. Đặc trưng quan trọng: **không có code riêng cho từng đối tác** — chỉ có **một generic provider HTTP client** cấu hình theo DB (BaseURL, path query/deliver/cancel, ClientID, HashKey), auth bằng chữ ký SHA256 [[aresProvider:L19](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/provider/client.go#L19)].

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }, "flowchart": { "curve": "basis" }}}%%
flowchart TB
    subgraph FE["insurance-webapp (React micro-app)"]
      Home["Home/GroupTabs<br/>Mua BH | Thanh toán phí | Quản lý | About"]
      Fee["insurance-fee: BillInput → BillDetails (theo PaymentRule) → Payment"]
      Purchase["insurance-purchase: Motorbike (TNDS)…"]
      Mgmt["management: Policy + Accumulated"]
    end
    SDK["jsSDK / @mp sdk<br/>startCashier · trackEvent · deeplink"]
    Cashier["ZaloPay Cashier (SOF/PMC)"]
    AGAM["AQR Growth Auto-debit Mgmt<br/>(/app/bindings)"]

    subgraph ARES["ares — Insurance core (Go)"]
      H["handler: /app /admin /s2s"]
      SVC["service: create_order · query_bill ·<br/>handle_payment_callback · deliver ·<br/>get_payment_status · cancel_policy · refund"]
      PROV["provider.HTTPClient (generic, DB-config, SHA256)"]
      Q["RabbitMQ queues + Kafka (OTA)"]
      DB[("MySQL: config / history / log")]
      ES[("Elasticsearch: insurance_policy")]
      RDS[("Redis cache")]
    end

    UM["UM (gRPC: profile/KYC)"]
    TPE["TPE (payment status)"]
    UPAY["UPay (order acquiring)"]
    BS["bill-storage (events)"]
    PRV["Providers: Saladin / PVI / VBI / Chubb / SaveMoney / Fuse / Igloo…"]

    Fee -->|createOrder| H
    Purchase --> H
    Fee --> SDK --> Cashier
    Purchase -->|createBinding| AGAM
    Cashier -->|orders:callback| H
    AGAM -->|s2s create-order AgreementPay| H
    H --> SVC --> PROV --> PRV
    SVC --> UPAY
    SVC --> TPE
    SVC --> UM
    SVC --> Q
    SVC --> DB
    SVC --> ES
    SVC --> RDS
    SVC --> BS
```

**Diễn giải:**
- **API surface** (`handler.go`): 3 nhóm route — `/app/api/v1/debt-collection` (user, session auth): `bills:query`, `orders` (create/get), `suppliers`, `product-lines`, `policies`, `policies:cancel`, `orders:callback`; `/admin/api/v1` (refund, reload-config, update-order-status, handle-policy…); `/s2s/api/v1` (server-to-server, dùng cho auto-debit worker) [[aresHandler:L84](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/handler/handler.go#L84)].
- **Tích hợp ZLP** (`pkg/zlp/`): `upay` (Cashier/acquiring tạo order), `tpe` (trạng thái thanh toán), `um` (User Management — profile/KYC qua gRPC), `billstorage` (event/bill tracking) [[aresUM:L41](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/pkg/zlp/um/client.go#L41)].
- **Async**: RabbitMQ cho deliver/refund/get-status/upsert-policy; Kafka cho `OTADeliveryBooking` (giao gói OTA) [[aresQueue:L116](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/queue/consumer.go#L116)].
- **Auto-debit**: việc đăng ký agreement đi qua **AGAM** (`/app/bindings`) — không thuộc `ares`; lần charge định kỳ vào lại `ares` qua **s2s create-order** với product code `AgreementPay (AC003)` [[webBinding:L15](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/insurance-webapp/src/api/createBinding.ts#L15)] [[aresS2S:L60](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/handler/s2s.go#L60)].

> ⚠️ **Conflict (audit):** repo `insurance-webapp` là một **fork telco→insurance** còn lẫn cấu hình telco; bản đúng cho insurance nằm ở **committed HEAD (`production-v2`)**, còn một số file trên đĩa (`constants/common.ts`, `.env.production`) đang là phiên bản telco — xem §15.3.

---

## 5. Vòng đời Giao dịch & Cấp đơn (Order / Deliver State Machine)

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
stateDiagram-v2
    [*] --> Created: CreateOrder + UPay token (5)
    Created --> PaymentSuccess: callback / get_payment_status (TPE=1) (6)
    Created --> Created: retry get_payment_status (chưa success)
    PaymentSuccess --> DeliverManualCheck: deliver() bắt đầu (-400)
    DeliverManualCheck --> DeliverSuccess: provider code 1 — cấp COI/Policy
    DeliverManualCheck --> DeliverProcessing: provider code 7
    DeliverManualCheck --> DeliverFailed: provider code -401
    DeliverProcessing --> DeliverSuccess: get_deliver_status
    DeliverProcessing --> DeliverFailed: get_deliver_status
    DeliverFailed --> Refund: tự động EnqueueRefundOrder
    DeliverSuccess --> [*]
    Refund --> [*]

    state "Policy (Elasticsearch)" as P {
      [*] --> Active: 1
      Active --> Canceled: cancel_policy (3)
      Active --> Expired: 2
    }
```

**Diễn giải các trạng thái** (hằng số tại `constant.go`) [[aresConst:L89](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/constant.go#L89)]:
- `OrderStatusCreated = 5`: đơn vừa tạo, đã có order token từ UPay (Cashier) [[aresCreate:L160](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/service/create_order.go#L160)].
- `OrderStatusPaymentSuccess = 6`: thu tiền thành công; callback chỉ xử lý nếu đơn đang `Created`, validate HMAC `AppKey2` [[aresCallback:L69](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/service/handle_payment_callback.go#L69)].
- `OrderStatusDeliverManualCheck = -400`: trạng thái trung gian khi bắt đầu cấp đơn; nếu provider không trả mã rõ ràng sẽ kẹt ở đây [[aresDeliver:L46](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/service/deliver.go#L46)].
- `OrderStatusDeliverSuccess = 1`: cấp đơn thành công — **COI/Policy nằm trong `DeliverResponse.ExtraInfo.Policy`** [[aresProvider:L233](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/provider/client.go#L233)].
- `OrderStatusDeliverFailed = -401`: cấp đơn thất bại → **tự động enqueue Refund** [[aresDeliver:L74](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/service/deliver.go#L74)].
- `OrderStatusDeliverProcessing = 7`: chờ, re-enqueue get-deliver-status có retry [[aresDeliver:L86](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/service/deliver.go#L86)].
- **Policy status** (ES): Active=1, Expired=2, Canceled=3 [[aresConst:L145](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/constant.go#L145)]. **Refund status**: Failed=-1, Success=1, Init=2, Processing=3 [[aresConst:L120](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/constant.go#L120)].
- **Cancel reason codes**: UserCancel=1, InsufficientBalanceAutoDebit=2, OverduePayment=3 [[aresConst:L176](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/constant.go#L176)].

> 🔎 **Liên hệ CS:** trạng thái `-400/-401` chính là cái CS thường gặp ("CPS -400, chưa nhận được hợp đồng") — xem §11.1.

---

## 6. Bản đồ Tính năng (Use Case Diagram)

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }, "flowchart": { "curve": "basis" }}}%%
graph TD
    User((Người dùng ZaloPay))
    System((Hệ thống Insurance/ares))

    subgraph "Mua / phân phối"
      UC_Standalone(Mua BH tại Hub - Standalone)
      UC_Embedded(Mua kèm BH - Embedded)
      UC_CrossSell(Cross-sell sau giao dịch)
      UC_Subscribe(Đăng ký auto-debit/subscription)
    end
    subgraph "Thu phí & quản lý"
      UC_Collect(Thu phí BH nhân thọ - nhập mã HĐ)
      UC_Manage(Quản lý hợp đồng & xem COI)
      UC_Cancel(Hủy hợp đồng / Refund)
    end
    subgraph "Hệ thống (tự động)"
      UC_Route(Routing hiển thị SKU)
      UC_Deliver(Cấp đơn & đối soát COI)
      UC_AutoCharge(Charge phí định kỳ - AgreementPay)
      UC_Remind(Nhắc kỳ phí - reminder)
    end

    User --> UC_Standalone
    User --> UC_Embedded
    User --> UC_CrossSell
    User --> UC_Subscribe
    User --> UC_Collect
    User --> UC_Manage
    User --> UC_Cancel

    System --> UC_Route
    System --> UC_Deliver
    System --> UC_AutoCharge
    System --> UC_Remind
```

Chi tiết các luồng cốt lõi xem **§7**; routing tự động xem **§9**.

---

## 7. Các Luồng Nghiệp vụ Chính (Core Workflows)

### 7.1 Luồng Embedded (mua kèm) trên hoá đơn / vé
Áp dụng cho hầu hết SKU nhúng (Payer, Cyber, Cracked Screen, House, Travel, Bus, Edu…). SKU bảo hiểm hiển thị trong "zone bảo hiểm" của use-case chính; user tick để mua kèm.

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
sequenceDiagram
    autonumber
    participant U as Người dùng
    participant FE as ZaloPay App (use-case chính)
    participant ARES as ares (Insurance core)
    participant PROV as Provider (đối tác)
    participant PAY as Cashier (SOF/PMC)
    U->>FE: Thanh toán hoá đơn / đặt vé
    FE->>ARES: Load zone bảo hiểm (routing chọn SKU) — event 4072.000
    ARES->>PROV: QueryBill (lấy phí + eligibility)
    PROV-->>ARES: Phí + quyền lợi
    ARES-->>FE: Render SKU bảo hiểm
    U->>FE: Tick SKU (4072.001) + đồng ý điều khoản
    FE->>ARES: createOrder (total_amount, supplier_id, customer_code, bills[])
    ARES->>PAY: tạo order (Cashier), hiển thị thanh toán (2 dòng: dịch vụ chính + phí BH)
    PAY-->>ARES: orders:callback (payment success → status 6)
    ARES->>PROV: Deliver (cấp đơn)
    alt Thành công
        PROV-->>ARES: COI/Policy (status 1)
        ARES-->>U: Thành công + COI tại Quản lý hợp đồng
    else Lỗi (ERR_xxx)
        PROV-->>ARES: mã lỗi → status -401
        ARES->>PAY: tự động Refund
    end
```
Nguồn: createOrder body & startCashier [[webCreateOrder:L14](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/insurance-webapp/src/api/createOrder.ts#L14)]; deliver/refund [[aresDeliver:L74](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/service/deliver.go#L74)]; metric routing [[Routing:L120](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L120)].

### 7.2 Luồng Standalone (Hub bảo hiểm)
User chủ động vào Hub → chọn sản phẩm (vd **BH Xe máy/TNDS**) → nhập thông tin (biển số, chủ xe, SĐT, email, địa chỉ; auto-fill từ KYC nếu "Xe của tôi") → chọn gói + ngày hiệu lực → thanh toán → cấp đơn [[BikeSM:L24](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/268100140_Bike%20in%20app%20integrate%20via%20Savemoney.md#L24)]. Frontend route `/motorbike`, gọi `getInsuranceInfo({supplierID})` [[webMotorbike:L58](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/insurance-webapp/src/features/insurance-purchase/Motorbike/index.tsx#L58)].

### 7.3 Luồng Subscription / Auto-debit (oneflow) — Sống An Vui (Chubb)
Hợp đồng **năm** nhưng thu phí **hàng tháng**; toggle "Đóng tự động, hủy bất cứ khi nào" mặc định ON [[ChubbBill:L58](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L58)].

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
sequenceDiagram
    autonumber
    participant U as User
    participant FE as ZaloPay FE
    participant ARES as ares
    participant AGAM as Auto-debit Mgmt (AGAM)
    participant CB as Chubb
    participant W as Auto-debit Worker
    Note over U,CB: Kỳ 1 — mua + đăng ký auto-debit
    U->>FE: Chọn SKU 10001–10004, xác nhận (ngày T)
    FE->>ARES: createOrder (kỳ phí đầu)
    FE->>AGAM: createBinding (agreement: maxamount, supplier, package)
    ARES->>CB: Deliver / cấp COI (năm)
    CB-->>ARES: COI + Policy ID
    ARES-->>U: Thành công + "đã cài gia hạn tự động"
    Note over U,CB: Free-look 14 ngày
    opt Hủy trong 14 ngày
        U->>FE: Hủy COI
        FE->>CB: Cancel (reason 1024) → hoàn 100% phí kỳ đầu (Chubb Ops thủ công)
    end
    Note over W,CB: Kỳ 2–12 — gia hạn hàng tháng
    W->>ARES: s2s create-order AgreementPay (trong cửa sổ 7 ngày, trước D8)
    alt Debit thành công
        ARES->>CB: đồng bộ qua SFTP batch ngày
        CB-->>U: Gia hạn (không cấp COI mới)
    else Quá hạn (Coverage End +8d)
        ARES->>CB: Cancel COI (reason 1023 Insufficient Balance)
        CB-->>U: Hợp đồng chấm dứt; UI về "mua mới"
    end
```
Cancellation reason codes Chubb: **1023** Insufficient Balance, **1024** User_Opted_Out, **1026** Others [[ChubbBill:L535](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L535)]. Cơ chế s2s AgreementPay (AC003) [[aresS2S:L60](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/handler/s2s.go#L60)].

### 7.4 Luồng Thu phí Bảo hiểm nhân thọ (Collection)
Mô hình **thu hộ** lấy phí dịch vụ MC; tích hợp **Direct** (Cathay Life) và **Indirect qua Payoo** (Generali, FWD, MetLife, Prevoir) [[PremiumCol:L43](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/153773179_DGS%20-%20Thu%20ph%C3%AD%20b%E1%BA%A3o%20hi%E1%BB%83m%20-%20Insurance%20Premium%20collection.md#L43)]. User nhập **mã hợp đồng** → hệ thống query kỳ nợ → chọn kỳ theo payment rule → thanh toán. Mã hợp đồng được lưu như "bill" trong **Bill storage V2** để nhắc kỳ [[PremiumCol:L66](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/153773179_DGS%20-%20Thu%20ph%C3%AD%20b%E1%BA%A3o%20hi%E1%BB%83m%20-%20Insurance%20Premium%20collection.md#L66)].

- **Payment rule Cathay**: thanh toán tất cả kỳ nợ; hoặc từng kỳ theo thứ tự **mới → cũ**; bỏ tick kỳ mới nhất sẽ untick toàn bộ [[PremiumCol:L96](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/153773179_DGS%20-%20Thu%20ph%C3%AD%20b%E1%BA%A3o%20hi%E1%BB%83m%20-%20Insurance%20Premium%20collection.md#L96)].
- **Reminder**: auto query nợ hằng ngày (Cathay có due date) → nhắc qua Noti App/ZMS, deeplink `zalopay://launch/app/3081?...` [[PremiumCol:L168](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/153773179_DGS%20-%20Thu%20ph%C3%AD%20b%E1%BA%A3o%20hi%E1%BB%83m%20-%20Insurance%20Premium%20collection.md#L168)].
- **Deeplink** Hub thu phí: `https://social.zalopay.vn/spa/v2/insurance?...` / `zalopay://launch/app/3081?insurancesection=details&supplierid=&customercode=` [[PremiumCol:L233](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/153773179_DGS%20-%20Thu%20ph%C3%AD%20b%E1%BA%A3o%20hi%E1%BB%83m%20-%20Insurance%20Premium%20collection.md#L233)].

> ⚠️ Cathay Life đang **bảo trì do đối tác cắt API (6/9)** [[ProdLine:L35](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L35)].

### 7.5 Cấp đơn (COI) & Quản lý hợp đồng
COI trả về trong response Deliver (`ExtraInfo.Policy`), lưu vào **Elasticsearch index `insurance_policy`** [[DataDict:L646](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/04.%20Skill/Data%20Expert/Data%20Analysis/Insurance/insurance_tables_structure%20codex.md#L646)]. Trang **Quản lý hợp đồng** 2 tab: (1) *Bảo hiểm trên ZaloPay* (chia chip: Ô tô–Xe máy–Tai nạn → trỏ portal SaveMoney; Du lịch; Người thanh toán; Chuyến đi; Nhà; Thiết bị điện tử; Công nghệ), (2) *Hợp đồng nhân thọ* (mã HĐ đã nhập) [[Contract:L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224783660_Insurance%20Contract%20Management.md#L44)]. Edge case: Travel có thể nhiều người được BH → "Xem trong chứng nhận BH"; Cracked Screen cần bước **Xác thực thiết bị** [[Contract:L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224783660_Insurance%20Contract%20Management.md#L44)].

### 7.6 Hủy & Hoàn tiền (Refund/Cancel)
Chính sách rất khác nhau theo sản phẩm (xem cột "Hoàn/hủy" §2.2). `ares` có API `policies:cancel` (user) và admin `refund`; cancel policy idempotent, ghi `cancel_policy_history` kèm reason code [[aresCancel:L48](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/service/cancel_policy.go#L48)]. Phần lớn refund do **đối tác xử lý thủ công** (vd Chubb Ops, VBI MC tool) chứ không tự động trong app.

---

## 8. Chi tiết từng Sản phẩm con (Product Specs)

> Mỗi sản phẩm nêu: đối tác, mô hình, gói/giá, quyền lợi, eligibility, journey, hoàn/hủy, lỗi. Phần thiếu nguồn đánh dấu `⚠️`.

### 8.1 BH An ninh mạng — Cyber (VBI) · app 3682
- **Đối tác/underwriter:** VBI; com-sharing 20% [[Cyber:L62](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-B%E1%BA%A3o%20hi%E1%BB%83m%20an%20ninh%20m%E1%BA%A1ng.md#L62)].
- **Mô hình:** Embedded trên *Nạp điện thoại (Telco)* + Cross-sell trên *Chuyển tiền*; có gói tháng (one-time) và gói năm (auto-debit 12 kỳ) [[Cyber:L72](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-B%E1%BA%A3o%20hi%E1%BB%83m%20an%20ninh%20m%E1%BA%A1ng.md#L72)].
- **Gói/giá:** Gói tháng 5.000đ/lần (60k/năm) — bảo vệ 10tr/vụ, max 25tr/năm; Gói năm 3.000đ/lần (label −40%) — max 50tr/năm; kèm tai nạn cá nhân đến 10tr [[Cyber:L107](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-B%E1%BA%A3o%20hi%E1%BB%83m%20an%20ninh%20m%E1%BA%A1ng.md#L107)].
- **Free-trial:** "MIỄN PHÍ 1 LẦN THANH TOÁN" cho gói năm với user đủ điều kiện (chưa từng thanh toán app 3682, không phải abuser/blacklist) [[Cyber:L116](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-B%E1%BA%A3o%20hi%E1%BB%83m%20an%20ninh%20m%E1%BA%A1ng.md#L116)].
- **Auto-debit:** 3 điều kiện đăng ký; chặn nếu (kỳ kế − ngày đăng ký) ≤ 7 ngày; cửa sổ chọn ngày Max=E−8, Min=R+1 [[Cyber:L150](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/194755527_Cyber%20Risk%20-VBI-B%E1%BA%A3o%20hi%E1%BB%83m%20an%20ninh%20m%E1%BA%A1ng.md#L150)].
- **FS Hub (đề xuất):** check segment/lịch sử ZaloPay nội bộ trước khi gọi VBI; toggle auto-debit mặc định ON [[CyberFSHub:L121](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/305025442_Cyber%20Insurance%20on%20FS%20Hub.md#L121)].
- **Hoàn/hủy:** gói tháng tự chấm dứt sau 1 tháng; gói năm không hoàn phí sau khi đã cấp COI; refund qua VBI (gửi trans id, SLA 24h) [[CSPartner:L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L44)].
- **Error:** dùng VBI error codes (§11.2); promotion rule ID 7505.

### 8.2 BH Màn hình điện thoại — Cracked Screen (Igloo/PVI) · app 3394
- **Đối tác:** underwriter **PVI**; phân phối/đại lý **Igloo Việt Nam**; ZION trung gian thanh toán [[Phone:L65](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/132339429_Phone%20Cracked%20Screen%E2%80%8B%20%28B%E1%BA%A3o%20hi%E1%BB%83m%20r%C6%A1i%20v%E1%BB%A1%20m%C3%A0n%20h%C3%ACnh%29.md#L65)].
- **Mô hình:** Embedded one-time khi mua thẻ điện thoại (multi-order độc lập); đã release **auto-subscription 15/4/2026** [[AprRep:L70](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Monthly%20Report/329194471_Apr%20Report%20-%20WS_%20Insurance.md#L70)].
- **Gói/giá:** 7.700đ/12.100đ/17.600đ (incl VAT) — STBH 1tr/2tr/3tr; thời hạn 1 tháng; SKU `MONTHLY-PLAN-7000/11000/16000`, product_key `PSP-ZALOPAY` [[Phone:L43](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/132339429_Phone%20Cracked%20Screen%E2%80%8B%20%28B%E1%BA%A3o%20hi%E1%BB%83m%20r%C6%A1i%20v%E1%BB%A1%20m%C3%A0n%20h%C3%ACnh%29.md#L43)].
- **Eligibility:** cần KYC (họ tên + SĐT) [[PhoneFAQ:L33](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/165236535_FAQ%20Grooming%20BH%20Crack%20phone%20Igloo%20%28mutil%20order%20%C4%91%E1%BB%99c%20l%E1%BA%ADp%29.md#L33)].
- **Journey/claim:** mua → COI → **Xác thực thiết bị** (IMEI qua portal Igloo `gadget-customer.iglooinsure.com`, trong 30 ngày); claim trong 3 ngày, mang máy trong 7 ngày, 1 claim/policy, chờ 24h sau xác thực [[Phone:L137](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/132339429_Phone%20Cracked%20Screen%E2%80%8B%20%28B%E1%BA%A3o%20hi%E1%BB%83m%20r%C6%A1i%20v%E1%BB%A1%20m%C3%A0n%20h%C3%ACnh%29.md#L137)].
- **Hoàn/hủy:** trong 48h chưa xác thực → hoàn 100% trừ 1.100đ; sau 48h → hoàn 70% phần còn lại trừ 1.100đ; hotline Igloo 1900 2094 / PVI 1900 545458 [[Phone:L137](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/132339429_Phone%20Cracked%20Screen%E2%80%8B%20%28B%E1%BA%A3o%20hi%E1%BB%83m%20r%C6%A1i%20v%E1%BB%A1%20m%C3%A0n%20h%C3%ACnh%29.md#L137)].

### 8.3 BH Xe máy / Ô tô — TNDS (SaveMoney/Saladin) · app 1020/4326/3507
- **Đối tác:** SaveMoney (+ Saladin), underwriter ABIC/MIC/PVI/VBI; đang chuyển từ webview SaveMoney sang **API in-app (Direct API, app 4326, dự kiến release T8)** [[BikeSM:L11](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/268100140_Bike%20in%20app%20integrate%20via%20Savemoney.md#L11)] [[ProdLine:L11](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L11)].
- **Gói/giá xe máy (1 năm, incl VAT):** >50cc 66.000đ; ≤50cc & xe điện 60.500đ; mô tô 3 bánh 319.000đ [[BikeSM:L42](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/268100140_Bike%20in%20app%20integrate%20via%20Savemoney.md#L42)].
- **Inputs:** biển số, chủ xe, SĐT, email (e-certificate), địa chỉ; auto-fill KYC nếu "Xe của tôi" [[BikeSM:L24](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/268100140_Bike%20in%20app%20integrate%20via%20Savemoney.md#L24)].
- **Hoàn/hủy:** Không hoàn hủy [[CSPartner:L60](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L60)].
- ⚠️ **Gap:** chi tiết quyền lợi/claim, giá 2–3 năm chưa có trong nguồn; FAQ API VBI còn câu hỏi mở (thời gian cấp COI; 1 hay 2 giấy chứng nhận) [[Bike:L17](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/236985063_BH%20Xe%20m%C3%A1y%20-VBI.md#L17)]. **Đây là sản phẩm phát sinh nhiều CS ticket nhất** (§11.1).

### 8.4 BH Người thanh toán — Payer Protection (Saladin) · app 2390
- **Đối tác:** Saladin / Bảo Việt; embedded trên *Bill Điện* [[ProdLine:L31](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L31)].
- **Phí:** 1% giá trị bill (min 1.000đ); CF–Edu 10.000đ; Internet–TV 2.000đ [[Routing:L140](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L140)]. Quyền lợi: tai nạn cá nhân lên đến 100 lần giá trị thanh toán [[Promo:L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/158044417_Insurance%20%20Promotion%20Free-Trial%20Framework.md#L44)].
- **Hoàn/hủy:** Không hoàn hủy; opt-out xử lý qua CS → Saladin [[CSPartner:L33](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L33)].
- **Promotion:** Saladin tài trợ 270tr/chương trình tặng BH 1đ để uplift NPU bill [[Promo:L23](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/158044417_Insurance%20%20Promotion%20Free-Trial%20Framework.md#L23)].

### 8.5 BH Sống An Vui — Bill Protection (Chubb) · app 4491
- **Đối tác:** underwriter **Chubb Việt Nam**; aggregator Fuse; quyền lợi Teladoc (quản lý stress) đính kèm [[ChubbBill:L131](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L131)].
- **Mô hình:** **subscription/auto-debit oneflow** — hợp đồng năm, phí tháng (xem §7.3).
- **SKU/giá:** 10001 (3.000đ + quà), 10002 (3.000đ), 10003 (5.000đ + quà), 10004 (5.000đ); tai nạn 15tr/30tr [[ChubbBill:L25](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L25)].
- **Eligibility:** 18–65 tuổi, KYC, 1 hợp đồng active/khách; chỉ bảo hiểm tai nạn, không bệnh tật [[ChubbBill:L225](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L225)].
- **Billing/grace:** kỳ kế đóng trong cửa sổ 7 ngày, trước 00:01 ngày **D8**; quá hạn (Coverage End+8d) hệ thống hủy COI; ZaloPay retry charge hằng ngày trong grace 7 ngày [[ChubbBill:L159](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L159)].
- **Free-look:** 14 ngày hoàn 100% kỳ đầu (refund thủ công Chubb Ops) [[ChubbBill:L70](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L70)]. ⚠️ T&C ghi 15 ngày — xem §15.3.

### 8.6 BH Sống tự tin — Confidence Living (Fuse/GIC) · app 4015
- **Đối tác:** Fuse (aggregator) / **GIC** (underwriter); embedded trên *Bill – trả khoản vay* [[SongTuTin:L19](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224786861_Fuse%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20S%E1%BB%91ng%20t%E1%BB%B1%20tin%20%28Credit%20Topup%29.md#L19)].
- **Giá/quyền lợi:** 4.000đ/tháng (Phase 1); tai nạn đến 5tr + trợ cấp thất nghiệp 2tr khi doanh nghiệp phá sản/cắt giảm [[SongTuTin:L11](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224786861_Fuse%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20S%E1%BB%91ng%20t%E1%BB%B1%20tin%20%28Credit%20Topup%29.md#L11)]. (Portfolio: 4.000–8.000–15.000đ/tháng) [[PortFolio:L30](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/268095061_Insurance%20portfolio%20%26%20SKUs%20summary%20info.md#L30)].
- **Hoàn/hủy:** hoàn phí nếu hủy trong **3 ngày** kể từ thanh toán kỳ đầu & chưa nhận bồi thường từ GIC [[CSPartner:L126](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L126)].
- ⚠️ **Lưu ý:** "Sống tự tin" (Fuse/GIC) **khác** "Sống An Vui" (Chubb) — không gộp (§15.3).

### 8.7 BH Du lịch — Travel (Saladin/Bảo Việt & Chubb) · app 3274 / 3834
- **Hai thế hệ đối tác:** Saladin/Bảo Việt (trễ-hủy, hành lý, du lịch nội địa, quốc tế) và **Chubb** (chuyến bay nội địa/quốc tế, mới hơn) [[ProdLine:L19](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L19)].
- **Saladin nội địa:** trễ/hủy 30k(1 chiều)/60k(khứ hồi) — bồi thường 400k; hành lý 15k/30k — đến 15tr; du lịch 45k…260k — PA đến 250tr; mua **≥3h trước khởi hành**; **không hoàn** sau khi mua [[TravelP1:L214](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/165223140_OTA%20Travel%20Insurance%20phase%201%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20tr%C3%AAn%20chuy%E1%BA%BFn%20bay%201%20chi%E1%BB%81u%20%28One-way%20Flight%29.md#L214)]; hotline Saladin 1900 638 454.
- **Saladin quốc tế:** coverage đến **1 tỷ đồng** (tử vong/y tế); SEA 99k–320k, Worldwide 160k–419k theo số ngày [[TravelIntl:L85](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/175154414_OTA%20Travel%20Insurance%20phase%202%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20tr%C3%AAn%20chuy%E1%BA%BFn%20bay%20qu%E1%BB%91c%20t%E1%BA%BF%201%20chi%E1%BB%81u%20%28One-way%20Flight%29.md#L85)].
- **Chubb:** quốc nội 45k/68k/140k, quốc tế 75k/115k/235k; PA đến 210tr, hủy chuyến đến giá vé (max 5tr); 6 tuần–85 tuổi; COI lấy qua "COI Retrieve API" (base64→PDF); **không hủy/hoàn trừ từ chối visa** [[ChubbTravel:L235](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/200830746_OTA%20Travel%20Flight-%20Integrate%20Chubb.md#L235)]. App 3834 prod, launch 2/9/2024 [[ChubbCheck:L31](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/207076046_Integrate%20Chubb%20Check%20list%20Phase%201%20-%20Domestic%20one%20way.md#L31)].
- ⚠️ Hiện Chubb embedded đang off, mở luồng cross-sale; international off (chỉ apply khi from/to Vietnam) [[ProdLine:L21](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L21)].

### 8.8 BH Chuyến đi Bus — Trip Protection (Saladin) · app 3676
Embedded trên vé xe bus, 10.000đ/20.000đ/chuyến (ghế đôi ×2): Gói 10K → PA đến 200tr, trợ cấp viện phí 10tr, 300k/ngày; Gói 20K → PA 400tr, 25tr, 500k/ngày (max 3 ngày) [[Bus:L317](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/194762038_OTA%20Bus%20Insurance%20phase%201%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20chuy%E1%BA%BFn%20%C4%91i%20tr%C3%AAn%20v%C3%A9%20xe%20Bus%201%20chi%E1%BB%81u%20one-way.md#L317)]. Edge case "Pending delivery" khi Saladin không trả final status [[Bus:L116](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/194762038_OTA%20Bus%20Insurance%20phase%201%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20chuy%E1%BA%BFn%20%C4%91i%20tr%C3%AAn%20v%C3%A9%20xe%20Bus%201%20chi%E1%BB%81u%20one-way.md#L116)].

### 8.9 BH Nhà — House Protection (SaveMoney/PVI Huế) · app 3935/3835
- **Đối tác:** underwriter **PVI Huế**, phân phối SaveMoney (portfolio cũng ghi ABIC); embedded trên *Bill điện/nước* [[House:L87](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/219681037_House%20Protection%20Embedded%20Electricity_Water%20Domain.md#L87)].
- **Gói/giá:** Cơ bản 3.000đ/tháng (nhà 90tr + tai nạn 10tr = 100tr); Nâng cao 10.000đ/tháng (nhà 150tr + tai nạn 30tr = 180tr, từ 19/6/2025); **miễn thường 1.000.000đ** [[House:L155](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/219681037_House%20Protection%20Embedded%20Electricity_Water%20Domain.md#L155)].
- **Rủi ro:** cháy/nổ/sét, tràn nước, trộm cắp; bảo vệ địa chỉ nhà trên hoá đơn; dedup theo **tên+SĐT người mua** (1 policy active) [[House:L56](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/219681037_House%20Protection%20Embedded%20Electricity_Water%20Domain.md#L56)].
- **Hoàn/hủy:** Không hoàn hủy [[CSPartner:L52](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L52)].

### 8.10 BH Học đường vui khoẻ — Happy Edu (Fuse/GIC) · app 4041
Embedded trên *thanh toán học phí*; 10.000đ/tháng, gói 6 tháng 60k / 12 tháng 120k; quyền lợi bệnh học đường đến 5tr, tai nạn 13tr, bạo lực học đường 6tr; học sinh ≥6 tuổi; hoàn phí trong 3 ngày kỳ đầu [[Edu:L19](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230285552_Fuse%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20Education%20H%E1%BB%8Dc%20%C4%91%C6%B0%E1%BB%9Dng%20vui%20kh%E1%BB%8Fe.md#L19)].

### 8.11 BH Sức khoẻ tích luỹ (Fuse/Bảo Long) · app 4042
Embedded trên Telco *trả sau/mua thẻ*; 2.400đ/giao dịch, tích luỹ 200 lần để đạt full quyền lợi; bệnh văn phòng đến 20tr/năm + trợ cấp nằm viện 300k/ngày (max 7 ngày/năm); **opt-in** (không auto-tick), consent ở giao dịch cấp hợp đồng đầu [[HealthAccum:L27](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230287402_Fuse%20-%20BH%20s%E1%BB%A9c%20kh%E1%BB%8Fe%20t%C3%ADch%20l%C5%A9y.md#L27)]. Không hoàn phí [[CSPartner:L122](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L122)].

### 8.12 Mini Healthcare — MiniHealth MSIG (đang phát triển) · app dự kiến
- **Đối tác:** **MiniHealth MSIG**; tư vấn/claim qua app **Fullerton Health**; nhà thuốc **Pharmacity**; trung gian cập nhật **NNX** [[HealthOverview:L13](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009933_Health%20Insurance%20-%20Product%20Overview.md#L13)].
- **Mô hình:** subscription micro ~**2.000đ/ngày**, Pause & Resume, trial hoàn 3 ngày [[HealthOverview:L13](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009933_Health%20Insurance%20-%20Product%20Overview.md#L13)].
- **Gói/giá:** Gói 1 577k (tổng 20tr), Gói 2 1.189tr (50tr), Gói 3 1.645tr (70tr)/năm [[HealthOverview:L66](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009933_Health%20Insurance%20-%20Product%20Overview.md#L66)].
- **Đặc trưng:** bảo lãnh thuốc trực tuyến + giao thuốc miễn phí; auto-approve claim SLA 30 phút; trẻ em đăng ký độc lập [[HealthOverview:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009933_Health%20Insurance%20-%20Product%20Overview.md#L7)]. Com 27%/gói; **Phase 1 dự kiến 11/5/2026** [[HealthRelease:L13](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009898_Health%20Insurance%20-%20Release%20checklist.md#L13)].
- **Hoàn/hủy:** đã cấp COI → không hoàn; chưa cấp COI → xét case-by-case; **không có nút hủy** trong app (CS thủ công) [[HealthRelease:L39](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009898_Health%20Insurance%20-%20Release%20checklist.md#L39)].

### 8.13 Thu phí BH nhân thọ — Collection (Cathay/Payoo…) · app 3082/3232
Thu hộ phí bảo hiểm nhân thọ: **Cathay Life** (trực tiếp, app 3082) và **Payoo** (app 3232: Generali, MetLife/BIDV, FWD, Prevoir). FWD cần thêm CCCD người thanh toán [[PremiumCol:L118](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/153773179_DGS%20-%20Thu%20ph%C3%AD%20b%E1%BA%A3o%20hi%E1%BB%83m%20-%20Insurance%20Premium%20collection.md#L118)]. Nguồn tiền Payoo **chỉ VietQR** [[CSPartner:L63](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L63)].

---

## 9. Routing Engine & Phân phối Embedded

Có **9 dòng sản phẩm embedded** bán kèm trên 3 domain Telco–Bill–OTA. Cơ chế routing quyết định SKU nào hiển thị trong "zone bảo hiểm" của use-case chính, nhằm tối ưu CR/adoption [[Routing:L10](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L10)].

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }, "flowchart": { "curve": "basis" }}}%%
graph TD
    REQ[Request load zone bảo hiểm] --> R1{Rule routing}
    R1 -->|Trọng số % traffic| W[Random theo tỷ trọng % cấu hình]
    R1 -->|UserID số cuối| U[Chia tập UID 0-9 → SKU A/B]
    R1 -->|Payment history| PH[Ưu tiên SKU user đã mua]
    R1 -->|Contract active| CA[Ưu tiên SKU đang có HĐ hiệu lực]
    R1 -->|Interaction| IN[Theo click / số lần hiển thị / untick]
    W --> EX[Exclude blacklist user] --> SHOW[Hiển thị component SKU]
    U --> EX
    PH --> EX
    CA --> EX
    IN --> EX
```

**Các rule (theo phase ưu tiên)** [[Routing:L20](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L20)]:
1. **Trọng số % traffic** (Done) — chia tỷ trọng theo số request load zone (vd Điện: Người thanh toán 70% / Nhà 30%).
2. **UserID số cuối** (Phase 1) — chia tập user thấy SKU A vs B (vd Flight: UID chẵn→Saladin, lẻ→Chubb).
3. **Payment history** (Phase 2) — ưu tiên SKU user từng mua.
4. **Contract active** (Phase 3) — ưu tiên SKU đang có hợp đồng hiệu lực (cho loại nhiều kỳ như Cyber/Edu).
5. **Interaction** (Phase 4–5) — theo click / sau N lần hiển thị không mua / untick thì ẩn N giao dịch.

**Kịch bản đang chạy (từ 25/3/2025)** [[Routing:L145](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L145)]: Điện→Người thanh toán; Nước→Nhà; Internet→(đã mua Payer? Payer : Sống tự tin); Edu→(đã mua Edu? Edu : Sống tự tin); CF→50/50 Payer/Sống tự tin; Mua thẻ ĐT→50/50 Màn hình/Sống tự tin (từ 8/4); Postpaid→100% Sức khoẻ tích luỹ; Topup→Cyber 70%/Sống tự tin 30%.

**Segment IDs** (Promotion hỗ trợ check "user đã từng thanh toán app X"): 2390→2283, 3274→2284, 3394→2285, 3676→2286, 3682→2287, 3935→2888, 4015→2289, 4041→2290, 3834→2291, 4042→2292 [[Routing:L128](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L128)].

---

## 10. Event Tracking & Data Model

### 10.1 Taxonomy event tracking
| Screen group | Mục đích | Event tiêu biểu |
|---|---|---|
| **4071** | Thu phí BH (Collection) | 4071.001 load page, 4071.002 chọn supplier, 4071.003 nhập mã HĐ, 4071.016 chọn kỳ, 4071.017 click Pay [[PremiumCol:L140](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/153773179_DGS%20-%20Thu%20ph%C3%AD%20b%E1%BA%A3o%20hi%E1%BB%83m%20-%20Insurance%20Premium%20collection.md#L140)] |
| **4072** | Insurance Embedded | 4072.000 load SKU, 4072.001 tick, 4072.002 untick, 4072.003 tìm hiểu thêm [[Promo:L78](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/158044417_Insurance%20%20Promotion%20Free-Trial%20Framework.md#L78)] |
| **4075** | Quản lý hợp đồng | 4075.000/001 chuyển tab, 4075.002 chip subcate, 4075.003 click HĐ tab1, 4075.004 click HĐ tab2 [[Contract:L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224783660_Insurance%20Contract%20Management.md#L44)] |
| **1130** | Order/PE core | 1130.000 submit order, 1130.011 confirm payment [[Routing:L120](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L120)] |
| per-product | màn riêng | vd Motorbike 4078, Cyber 4072.007 xem GCN, purchase 4072.010/013/014 |

**Công thức CR** (routing): E2E CR = Successful Trans (transStatus=1 trong log TPE) / Load component; Adoption = Successful Embedded Insurance Trans / Total main use-case Trans [[Routing:L122](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L122)].

### 10.2 Data model (ERD logic)
Dữ liệu nằm trong 3 MySQL DB + 1 ES index [[DataDict:L15](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/04.%20Skill/Data%20Expert/Data%20Analysis/Insurance/insurance_tables_structure%20codex.md#L15)]:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
erDiagram
    product_line ||--o{ app : has
    app ||--o{ app_supplier_provider : maps
    supplier ||--o{ app_supplier_provider : maps
    provider ||--o{ app_supplier_provider : maps
    app_supplier_provider ||--o{ order_history : generates
    order_history ||--o| insurance_policy : issues
    order_history ||--o{ cancel_policy_history : may_cancel
    order_history ||--o{ order_log : logs
    order_history ||--o{ refund_log : refunds
    provider ||--o{ provider_return_message : maps_codes
```

| Nhóm | DB / Index | Bảng chính |
|---|---|---|
| Cấu hình | `aqr_telco_ares_bill_admin` | `product_line`, `app`, `supplier`, `provider`, `app_supplier_provider`, `provider_maintenance`, `supplier_maintenance`, `provider_return_message`, `client_privilege`, `badge`, `buz_config` [[DataDict:L299](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/04.%20Skill/Data%20Expert/Data%20Analysis/Insurance/insurance_tables_structure%20codex.md#L299)] |
| Giao dịch | `aqr_telco_ares_bill_history` | `order_history_{product_line_id}` (shard theo product line), `cancel_policy_history` [[DataDict:L489](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/04.%20Skill/Data%20Expert/Data%20Analysis/Insurance/insurance_tables_structure%20codex.md#L489)] |
| Log | `aqr_telco_ares_bill_log` | `order_log_{order_prefix}`, `refund_log_{order_prefix}`, `update_status_log_{order_prefix}` [[DataDict:L553](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/04.%20Skill/Data%20Expert/Data%20Analysis/Insurance/insurance_tables_structure%20codex.md#L553)] |
| Policy | Elasticsearch | index `insurance_policy` (lookup theo `_id` + `zalo_pay_id`) [[DataDict:L646](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/04.%20Skill/Data%20Expert/Data%20Analysis/Insurance/insurance_tables_structure%20codex.md#L646)] |

> Định danh sản phẩm = bộ ba **app × supplier × provider** (`app_supplier_provider`); order ghi theo `product_line_id`; policy/COI lưu ở ES — phù hợp với mô hình provider generic ở §4.

---

## 11. Operational Playbook (Vận hành & Sự cố)

### 11.1 Sự cố đã biết (từ CS Ticket)
23 CS ticket Insurance đều ở trạng thái CLOSED; tập trung ở **BH Xe máy SaveMoney** (nhiều nhất), rồi Màn hình ĐT, Du lịch, Sống tự tin.

| Pattern sự cố | Mô tả & nguyên nhân | Hướng xử lý | Nguồn |
|---|---|---|---|
| **COI/HĐ không hiển thị dù mua thành công** | GD thành công nhưng app không hiển thị hợp đồng ở mục "Đã thanh toán"; KH không nhận GCN qua email | Đối tác cập nhật HĐ thủ công → update status GD thành công; dev tích hợp luồng direct in-app + ZaloPay monitor mục quản lý HĐ (dự kiến giữa T6) | [[CS30191:L17](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-30191_%5B%E1%BB%A8ng%20d%E1%BB%A5ng%5D%20-%20%5B1020%20-%20SAVEMONEY%5D%20L%E1%BB%97i%20%E1%BB%A9ng%20d%E1%BB%A5ng%20-%20Cas.md#L17)] [[CS39176:L56](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-39176_%5BThanh%20to%C3%A1n%5D%20-%20%5B4326%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20xe%20m%C3%A1y%20Save%20Money%5D.md#L56)] |
| **CPS -400, chưa nhận được hợp đồng** | Order kẹt ở `DeliverManualCheck (-400)`; log cho thấy PMC 44, package `[PLAN-PACT-ZP-GI-001]`, status −400 (Sống tự tin) | CS chuyển team hỗ trợ; đối soát/cấp lại COI | [[CS38081:L20](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-38081_%5BThanh%20to%C3%A1n%5D%20-%20%5B4015%20-%20S%E1%BB%91ng%20t%E1%BB%B1%20tin%5D%20Ki%E1%BB%83m%20tra%20giao%20.md#L20)] [[CS38074:L23](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-38074_%5BThanh%20to%C3%A1n%5D%20-%20%5B4015%20-%20S%E1%BB%91ng%20t%E1%BB%B1%20tin%5D%20Ki%E1%BB%83m%20tra%20giao%20.md#L23)] |
| **HĐ không hiện ở chip "Ô tô–Xe máy–Tai nạn"** | Mua xe máy hiện ở "Tất cả" nhưng không hiện ở chip lọc; HĐ mua ở ZaloPay không hiện ở webview đối tác | Giải thích cơ chế hiển thị; chuyển portal SaveMoney | [[CS35616:L17](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-35616_%5B%E1%BB%A8ng%20d%E1%BB%A5ng%5D%20-%20%5B4326%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20xe%20m%C3%A1y%20Save%20Money%5D%20L.md#L17)] |
| **GCN "đang xử lý" kéo dài** | KH mua xe máy nhưng GCN báo đang cập nhật | Chờ đối tác cập nhật; CS theo dõi | [[CS39200:L22](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-39200_%5BThanh%20to%C3%A1n%5D%20-%20%5B4326%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20xe%20m%C3%A1y%20Save%20Money%5D.md#L22)] |
| **User muốn hủy giao dịch đã tick BH** | Log xác nhận user tự tick (không phải auto-tick) | CS liên hệ đối tác hủy policy + hoàn tiền | [[CS30773:L57](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-30773_%5BThanh%20to%C3%A1n%5D%20-%20%5B3394%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20m%C3%A0n%20h%C3%ACnh%20%C4%91i%E1%BB%87n%20tho%E1%BA%A1.md#L57)] |

> 🔎 **Rủi ro nghiệp vụ nổi bật (cho audit):** sự cố "đã thu tiền nhưng chưa cấp đơn / không hiển thị HĐ" lặp lại nhiều ở **TNDS xe máy** — KH có thể bị phạt vì không có bảo hiểm khi tham gia giao thông [[CS30191:L17](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/Insurance/ISSUE-30191_%5B%E1%BB%A8ng%20d%E1%BB%A5ng%5D%20-%20%5B1020%20-%20SAVEMONEY%5D%20L%E1%BB%97i%20%E1%BB%A9ng%20d%E1%BB%A5ng%20-%20Cas.md#L17)]. Phụ thuộc lớn vào việc **đối tác cập nhật thủ công**.

### 11.2 Error codes (VBI — dùng chung cho luồng cấp đơn/refund)
[[VBIErr:L8](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/213904192_VBI%20Error%20code%20update.md#L8)]

| Code | Mô tả | Action |
|---|---|---|
| ERR_204 | Thông tin đơn hàng không chính xác | Refund |
| ERR_404 | Không tìm thấy tài nguyên | Refund |
| ERR_504 | Phí bảo hiểm không khớp | Refund |
| ERR_601 | Mã booking đã tồn tại | Refund |
| ERR_604 | Hợp đồng bảo hiểm đã tồn tại | Refund |
| ERR_901 | Khách hàng thuộc blacklist | Refund |
| ERR_902 | Không đủ điều kiện cấp đơn | Refund |
| ERR_904 | Lỗi khi tạo yêu cầu xử lý đơn | Refund |
| ERR_1001 | Lỗi xử lý — liên hệ VBI | Refund |
| Bad Request / Forbidden / Not Found / AUTHENTICATION_FAILED / SIGNATURE_VERIFY_FAIL | Lỗi khởi tạo API | Check lại request |
| Timeout / 429 / 500 | Lỗi server | Retry |

> Về kỹ thuật, lỗi cấp đơn (provider code `-401`) trong `ares` tự động enqueue Refund (§5). Mã đối tác được map qua bảng `provider_return_message` [[DataDict:L427](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/04.%20Skill/Data%20Expert/Data%20Analysis/Insurance/insurance_tables_structure%20codex.md#L427)].

### 11.3 Liên hệ đối tác & SLA (trích)
| Đối tác | Hotline | Email | SLA |
|---|---|---|---|
| Saladin | 1900 638 454 | cs@saladin.vn | xử lý 24h ngày làm việc [[CSPartner:L14](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L14)] |
| VBI | 1900 1566 | cskh@myvbi.vn | refund 24h [[CSPartner:L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L44)] |
| Igloo / PVI | 070 391 3575 / 0961887293 | thien.le@iglooinsure.com | 2-3 ngày làm việc [[CSPartner:L41](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L41)] |
| Chubb | 028 3910 7300 | inquiries.vn@chubb.com | 2-3 ngày làm việc [[CSPartner:L58](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L58)] |
| SaveMoney | 0376 871 793 | tho.tran@savemoney.vn | 2-3 ngày làm việc [[CSPartner:L52](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L52)] |
| Fuse Online | +84 28 7300 8803 | cs@fuse.com.vn | 8h-20h T2-T6 [[CSPartner:L122](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/230292981_%5BInsurance%5D%20Th%C3%B4ng%20tin%20S%E1%BA%A3n%20ph%E1%BA%A9m%20-%20%C4%90%E1%BB%91i%20t%C3%A1c%20%C4%91%E1%BB%83%20h%E1%BB%97%20tr%E1%BB%A3%20CS%20x%E1%BB%AD%20l%C3%BD%20ticket.md#L122)] |

---

## 12. Trust & Safety

- **Minh bạch vai trò:** mỗi sản phẩm nêu rõ underwriter / đại lý / trung gian thanh toán (vd PVI + Igloo + ZION cho Cracked Screen) [[Phone:L65](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/132339429_Phone%20Cracked%20Screen%E2%80%8B%20%28B%E1%BA%A3o%20hi%E1%BB%83m%20r%C6%A1i%20v%E1%BB%A1%20m%C3%A0n%20h%C3%ACnh%29.md#L65)].
- **KYC & dữ liệu cá nhân:** consent chia sẻ thông tin (họ tên, ngày sinh, CMND/CCCD/hộ chiếu, email) cho đối tác để thực hiện hợp đồng; chỉ bán khi đủ định danh [[Promo:L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/158044417_Insurance%20%20Promotion%20Free-Trial%20Framework.md#L44)].
- **Quyền hủy/free-look:** Sống An Vui 14 ngày; Sống tự tin/Học đường 3 ngày; Cracked Screen 48h/70%; Travel/Bus/Payer/Nhà thường không hoàn (đã ghi rõ §2.2).
- **An toàn tài chính:** lỗi cấp đơn → tự động refund (§5); cancel policy idempotent ghi history (§7.6).
- ⚠️ **Điểm cần củng cố (audit):** opt-out của embedded chủ yếu xử lý qua CS→đối tác (thủ công); chưa có nút hủy in-app cho nhiều sản phẩm; phụ thuộc đối tác cập nhật COI khi cấp đơn chậm.

---

## 13. Lịch sử & Roadmap

### 13.1 Đã release (trích từ Jira + monthly report)
- **Auto-subscription Cracked Screen** — release **15/4/2026**; TPV +366%, MPU +191% MoM [[AprRep:L70](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Monthly%20Report/329194471_Apr%20Report%20-%20WS_%20Insurance.md#L70)].
- Routing engine: trọng số % (Done) + UID (Phase 1) đã chạy từ 25/3/2025 [[Routing:L145](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/237002537_Routing%20Insurance.md#L145)].
- 89 Jira ticket Insurance (đa số DONE/LIVE): các hạng mục Cyber auto-debit, Term Life repo/API, KYC screens, event tracking, free-trial, multi-bill promotion, Mini Heo Ke design… [[JiraDir](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Jira/Insurance)].

### 13.2 Đang làm / kế hoạch (T5–T7/2026) [[AprRep:L80](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/01.%20Objective/Monthly%20Report/329194471_Apr%20Report%20-%20WS_%20Insurance.md#L80)]
| Initiative | Status | Dự kiến |
|---|---|---|
| Cyber Insurance embedded trên **Money Transfer** (không promotion) | IN PROGRESS | T5 (5B) |
| Cyber trên **FS Hub & Insurance Hub** + auto-renewal, đổi tần suất scan | IN PROGRESS | T5–6A |
| Auto-subscription **Bill Protect** (cross-sell + standalone) + free-trial | IN PLAN | T6 |
| **Mini Healthcare** (MVP: intro, chọn gói, mua & cấp HĐ, quản lý HĐ) | IN PROGRESS | cuối T5 |
| **Mini Term Life** (Chubb) | IN PROGRESS | T7 |
| Kéo dài thời gian chờ hủy hợp đồng (15 → 30 ngày) để tăng retention | Planned | — |

---

## 14. Open Questions & Gaps

1. **BH Xe máy/Ô tô (SaveMoney):** thiếu chi tiết quyền lợi/claim/giá đa năm trong nguồn; FAQ API VBI còn câu hỏi mở (thời gian cấp COI, số lượng GCN) [[Bike:L17](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/236985063_BH%20Xe%20m%C3%A1y%20-VBI.md#L17)].
2. **Provider code:** toàn bộ đối tác chạy qua 1 generic HTTP client cấu hình DB; hành vi thật (endpoint, key, mã lỗi) nằm trong DB config, **không** trong repo — cần dump config để audit đầy đủ (§4).
3. **Frontend supplier 16–19** (School/OfficeHealth/Motorbike/PeacefulLiving) không có hằng số supplier-id tương ứng trong `ares/constant.go` (max=15) — cần xác minh là supplier DB-only [[webPurchase:L4](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/insurance-webapp/src/constants/insurancePurchase.ts#L4)].
4. **Mini Healthcare:** thiếu eligibility (tuổi), error codes, app_id/SKU id, hotline — tài liệu còn ở pha pre-launch [[HealthOverview:L13](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/310009933_Health%20Insurance%20-%20Product%20Overview.md#L13)].
5. **Premium collection:** payment-rule ID cụ thể & danh sách kỳ phí Payoo (case có/không trả amount) chưa định nghĩa hết [[PremiumCol:L120](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/153773179_DGS%20-%20Thu%20ph%C3%AD%20b%E1%BA%A3o%20hi%E1%BB%83m%20-%20Insurance%20Premium%20collection.md#L120)].
6. **Chưa nạp sâu trong v1.0** (đề xuất cho v1.1): bộ data dictionary 75KB chi tiết từng cột; toàn bộ 89 Jira ticket (mới nhóm theo tiêu đề/trạng thái); contract đối tác (commercial terms); email/chat flagged; folder `02. Context/Others/03. Insurance/08. Audit` (audit cũ) & `00. Handover`.

---

## 15. Appendix

### 15.1 Source Index (Manifest)
| Nhóm nguồn | Vị trí (relative tới `Wealth Solution/`) | Đã nạp v1.0 |
|---|---|---|
| Source Code — backend | `03. Fact/Source Code/Insurance/ares/` | ✅ (kiến trúc, state machine, providers) |
| Source Code — frontend | `03. Fact/Source Code/Insurance/insurance-webapp/` | ✅ (routes, app_id/supplier map, flows) |
| Confluence — System General (EA) | `02. Context/Confluence/System General/200809702_[EA][DD] Insurance.md` (+ Technical/Integration/Transfer&payment) | ◑ (DD chính; 3 file còn lại tham khảo) |
| Confluence — Product Page | `02. Context/Confluence/Insurance/Product Page/` (~50 file) | ✅ (các sản phẩm chính + platform) |
| Confluence — Technical Page | `02. Context/Confluence/Insurance/Technical Page/` | ◑ (Mini Healthcare App, MoneyTransfer x VBI) |
| Jira | `02. Context/Jira/Insurance/` (89) + `02. Context/Jira/FS Hub/` (cyber) | ◑ (nhóm theo tiêu đề/trạng thái) |
| CS Ticket | `03. Fact/CS Ticket/Insurance/` (23) | ✅ (pattern + 5 ticket trích dẫn) |
| Data dictionary | `04. Skill/Data Expert/Data Analysis/Insurance/` (codex 75KB, antigravity) | ◑ (inventory bảng/ERD) |
| Objective / KPI | `01. Objective/` (Monthly Report, Business KPI, Product Strategy, Insurance Metric) | ◑ (KPI + báo cáo T4) |
| Data thực tế | `03. Fact/Data/Insurance/OTA Insurance Performance…xlsx` | ◻ (chưa nạp — v1.1) |
| Design / UI | `02. Context/Design/Insurance/` (Figma, UI preview, Mini Healthcare UI.pdf) | ◻ (chưa nạp — v1.1) |
| Others / Handover / Audit | `02. Context/Others/03. Insurance/` | ◻ (chưa nạp — v1.1) |

### 15.2 Glossary
- **COI** — Certificate of Insurance (giấy chứng nhận bảo hiểm).
- **SOF / PMC** — Source of Funds / payment-method-code (vd PMC 44 = nguồn MMF).
- **AgreementPay (AC003)** — product code cho thanh toán theo agreement (auto-debit). CashierPay=AC002, Gateway=AC004 [[aresConst:L77](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/constant.go#L77)].
- **Embedded / Cross-sell / Standalone** — mua kèm / gợi ý sau giao dịch / mua chủ động tại Hub.
- **TNDS** — bảo hiểm trách nhiệm dân sự bắt buộc (xe máy/ô tô).
- **Insure-tech / Aggregator** — đơn vị công nghệ phân phối (Saladin, Igloo, Fuse, SaveMoney); **Underwriter** — nhà bảo hiểm chịu rủi ro (PVI, Chubb, VBI, GIC…).
- **ares** — service lõi Insurance (Go), tái dụng engine bill/debt-collection.
- **AGAM** — AQR Growth Auto-debit Management (đăng ký agreement auto-debit).
- **UM / TPE / UPay** — User Management / payment-status gateway / order-acquiring core.

### 15.3 Nhật ký Mâu thuẫn (Conflicts Log)
| # | Mâu thuẫn | Nguồn A | Nguồn B | Khuyến nghị (Fact-first) |
|---|---|---|---|---|
| 1 | Free-look Sống An Vui: **14 ngày** (logic auto-debit/API) vs **15 ngày** (T&C) | [[ChubbBill:L70](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L70)] | [[ChubbBill:L269](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/261511567_Chubb%20%20Bill%20protection%20auto%20debit%20oneflow.md#L269)] | Dùng **14 ngày** (logic vận hành); rà lại wording T&C khách hàng |
| 2 | "Sống tự tin" (Fuse/GIC) bị gọi nhầm lẫn với "Sống An Vui" (Chubb) | [[SongTuTin:L19](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/224786861_Fuse%20-%20B%E1%BA%A3o%20hi%E1%BB%83m%20S%E1%BB%91ng%20t%E1%BB%B1%20tin%20%28Credit%20Topup%29.md#L19)] | [[AutoDebit:L41](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/254654045_Auto%20Debit%20Oneflow%20subcription%20Insurance.md#L41)] | **2 sản phẩm khác nhau** — không gộp |
| 3 | Frontend định nghĩa supplier 16–19, backend `ares` chỉ tới 15 | [[webPurchase:L4](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/insurance-webapp/src/constants/insurancePurchase.ts#L4)] | [[aresConst:L155](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/Insurance/ares/internal/bill/constant.go#L155)] | Xác minh supplier DB-only; đồng bộ enum |
| 4 | `insurance-webapp` working tree lẫn cấu hình **telco**; bản insurance đúng ở HEAD `production-v2` | on-disk `constants/common.ts`, `.env.production` | committed HEAD | Lấy **HEAD** làm chuẩn cho webapp |
| 5 | Đối tác Travel/Health/House so với giả định ban đầu | [[ProdLine:L19](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/Insurance/Product%20Page/273538069_Insurance%20product%20line%20overview.md#L19)] | brief assumptions | Travel = Saladin + Chubb; Health flagship = MSIG (Fullerton); House = PVI Huế × SaveMoney |

---

*Hết tài liệu v1.0. Mọi dữ kiện có dẫn nguồn `file://`; phần `⚠️`/◑/◻ là gap đã biết, sẽ bổ sung ở v1.1 (data dictionary chi tiết, toàn bộ Jira, contract đối tác, audit cũ, performance data, Design UI).*


