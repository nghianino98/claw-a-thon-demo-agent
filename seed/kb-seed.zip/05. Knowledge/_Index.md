# 📚 Wealth Solution — Knowledge Index

Điểm vào tra cứu tri thức sản phẩm. **AI đọc bảng này trước** để biết mở file nào (tiết kiệm token). Mỗi sản phẩm có 1 file `<P>/<P> - Knowledge.md` (layout: Fact Sheet → 12 mục → Changelog → Manifest).

> Cập nhật tự động bởi skill `product-documentation` (mode SYNC) / workflow `.agents/workflows/knowledge-sync.md`. Lần sync gần nhất ghi ở cột tương ứng.

| Sản phẩm | Tên user-facing | Đối tác | Trạng thái | Version | Cập nhật | File |
|---|---|---|---|---|---|---|
| **FI** | Gói nhận lãi định kỳ (UTĐT) | Infina (Kafi kế hoạch) | 🟢 Legal approved — go-live T6/2026 | v2.0 | 2026-05-30 | [Standard](FI/FI%20-%20Knowledge.md) / [Comprehensive](FI/FI%20Knowledge%20-%20Comprehensive.md) |
| **MMF** | Số dư sinh lời / TKTL | Infina | 🟢 Live | v2.0 | 2026-06-14 | [Overview](MMF/MMF%20-%20High-Level%20Overview.md) / [Business Spec](MMF/MMF%20-%20Product%20Business%20Specification.md) / [Tech Spec](MMF/MMF%20-%20System%20&%20Technical%20Specification.md) / [Ops Guide](MMF/MMF%20-%20Operations,%20Payment%20&%20Reconciliation%20Guide.md) / [Data & Event Map](MMF/MMF%20-%20Event%20Tracking%20&%20Data%20Mapping.md) |
| **FD** | Tài khoản tiết kiệm / TKTK | Cake, CIMB | — | — | *chưa tạo* | — |
| **CCQ** | Chứng chỉ quỹ | — | — | — | *chưa tạo* | — |
| **Insurance** | Bảo hiểm | — | — | — | *chưa tạo* | — |
| **Stock** | Chứng khoán | DNSE | — | — | *chưa tạo* | — |
| **FS Hub** | Financial Services Hub | Internal | — | — | *chưa tạo* | — |
| **FS Profile** | Financial Services Profile | Internal | — | — | *chưa tạo* | — |

## Cách dùng (cho AI tra cứu)
1. Đọc bảng trên → xác định sản phẩm liên quan câu hỏi.
2. Mở `<P>/<P> - Knowledge.md`, đọc **Fact Sheet** trước; chỉ đọc sâu mục cần thiết.
3. Trả lời kèm citation từ doc (doc đã có link nguồn gốc `file://#L`).

## Trạng thái build
- ✅ FI (v2.0 — comprehensive, deep-read source code), MMF (v2.0 — comprehensive, 5 documents)
- ⬜ FD, CCQ, Insurance, Stock, FS Hub, FS Profile — chạy BUILD hoặc để SYNC tự dựng skeleton.
