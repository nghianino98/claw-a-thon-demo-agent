# 📘 Fixed Deposit (FD) — Product Knowledge Base

---

## ⚡ Fact Sheet (TL;DR)

| Thuộc tính | Chi tiết |
|---|---|
| **Tên sản phẩm** | Gửi Tiết Kiệm (Fixed Deposit | FD) |
| **Đối tác cung cấp** | **Ngân hàng TNHH Một Thành Viên CIMB Việt Nam** & **Ngân hàng Số Cake by VPBank** [[Thông tin SP:L12](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/161198999_%5BFD%5D%20Tho%CC%82ng%20tin%20sa%CC%89n%20pha%CC%82%CC%89m.md#L12), [Core Tech:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Technical%20Page/310007104_FD%20System%20%E2%80%94%20Core%20knowledge.md#L7)]. |
| **Trạng thái** | 🟢 Live (Đang chạy thực tế trên môi trường Production). |
| **Đối tượng áp dụng** | Người dùng mang quốc tịch Việt Nam, từ đủ **18 tuổi trở lên** [[FAQ:L12](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/165241783_%5BFD%5D%20FAQ.md#L12)]. |
| **Kỳ hạn gửi** | 1 tháng, 3 tháng, 6 tháng, 9 tháng và 12 tháng [[FAQ:L28](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/165241783_%5BFD%5D%20FAQ.md#L28)]. |
| **Quy tắc Nạp tiền** | * **CIMB:** Gửi tối thiểu **100.000đ/sổ** [[Hạn mức:L15](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L15)]; tối đa **100.000.000đ tổng gốc/user** [[Hạn mức:L14](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L14)]. Nạp qua VietQR [[HHLD:L41](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/151173335_%5BFD%5D%20App%20Info%20&%20Human%20Resource.md#L41)].<br>* **Cake:** Gửi tối thiểu **100.000đ/sổ**; tối đa **100.000.000đ/sổ** [[Hạn mức:L117](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L117)]; không giới hạn số sổ [[Hạn mức:L117](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L117)]. |
| **Quy tắc Rút tiền** | Hỗ trợ rút tiền linh hoạt trước hạn một phần hoặc toàn bộ gốc [[FAQ:L33](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/165241783_%5BFD%5D%20FAQ.md#L33)]. Các kênh nhận tiền bao gồm:<br>1. **Ví ZaloPay** [[Break MMF:L26](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/284987959_%5BFD%5D%20-%20User%20Guide%20-%20Break%20FD%20to%20MMF.md#L26)].<br>2. **Tài khoản Số Dư Sinh Lời (MMF)** (luồng 2-step nạp Ví -> MMF) [[Break MMF:L58-60](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/284987959_%5BFD%5D%20-%20User%20Guide%20-%20Break%20FD%20to%20MMF.md#L58-60)].<br>3. **Tài khoản ngân hàng của user (IBFT)** (Giới hạn tối đa 20.000.000đ/giao dịch gồm cả gốc + lãi, hiện chỉ khả dụng cho CIMB) [[Break Bank:L53-54](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/284997084_%5BFD%5D%20-%20User%20Guide%20-%20Break%20FD%20to%20bank.md#L53-54)]. |
| **Quy tắc Sinh lời** | * **Đến hạn (Maturity):** Nhận lãi suất có kỳ hạn theo cam kết ban đầu.<br>* **Rút trước hạn (Premature break):** Phần rút trước hạn hưởng lãi suất **không kỳ hạn** tính trên số ngày gửi thực tế [[FAQ:L33](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/165241783_%5BFD%5D%20FAQ.md#L33)]. Phần còn lại (nếu thoả mãn số dư tối thiểu) tiếp tục hưởng lãi suất có kỳ hạn như cũ. |
| **Thuế TNCN** | **0%** (Tiền lãi từ tiền gửi tại các tổ chức tín dụng được miễn thuế thu nhập cá nhân theo Luật Thuế TNCN Việt Nam). |
| **Vận hành (AppID)** | * **Rút tiền (chung):** AppID `186` [[CS Cake:L88](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762822_%5BFD%5D%5BCAKE%5D%20CS%20Support.md#L88)].<br>* **Nạp tiền (CIMB):** AppID `888` [[CS Cake:L89](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762822_%5BFD%5D%5BCAKE%5D%20CS%20Support.md#L89)].<br>* **Nạp tiền (Cake):** AppID `8686` [[CS Cake:L89](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762822_%5BFD%5D%5BCAKE%5D%20CS%20Support.md#L89)]. |
| **Hạ tầng kỹ thuật** | Monorepo gồm 3 service lõi (`apigateway`, `account`, `management`) giao tiếp nội bộ qua gRPC và 2 service connectors riêng biệt dịch nghĩa sang REST API của đối tác ngân hàng [[Core Tech:L7](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Technical%20Page/310007104_FD%20System%20%E2%80%94%20Core%20knowledge.md#L7), [Core Tech:L68-70](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Technical%20Page/310007104_FD%20System%20%E2%80%94%20Core%20knowledge.md#L68-70)]. Async messaging dùng RabbitMQ và Kafka [[Core Tech:L99-100](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Technical%20Page/310007104_FD%20System%20%E2%80%94%20Core%20knowledge.md#L99-100)]. |
| **Owner / Phiên bản** | DuyNQ5 / **v1.2** — Cập nhật ngày 2026-06-03. |

---

## 1. Tổng quan & Định vị Sản phẩm

Sản phẩm **Gửi Tiết Kiệm (Fixed Deposit | FD)** là một mảnh ghép quan trọng trong hệ sinh thái Wealth Solution của ZaloPay, cho phép người dùng mở các sổ tiết kiệm trực tuyến có kỳ hạn trực tiếp tại các đối tác ngân hàng liên kết (CIMB, CAKE) thông qua nền tảng trung gian của ZaloPay [[Thông tin SP:L12-13](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/161198999_%5BFD%5D%20Tho%CC%82ng%20tin%20sa%CC%89n%20pha%CC%82%CC%89m.md#L12-13)].

### 1.1 Vai trò các bên
* **ZaloPay:** Đóng vai trò là đơn vị hiển thị, tích hợp giao diện (Miniapp), và thực hiện vai trò trung gian thanh toán (qua Acquiring Core ACv2 và Payment Engine) để nạp tiền mở sổ, hoặc chi tiền (Disbursement Core) topup về ví/tài khoản ngân hàng của user khi tất toán/rút trước hạn [[Thông tin SP:L23](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/161198999_%5BFD%5D%20Tho%CC%82ng%20tin%20sa%CC%89n%20pha%CC%82%CC%89m.md#L23)].
* **Ngân hàng Đối tác (CIMB, CAKE):** Đóng vai trò là tổ chức nhận tiền gửi hợp pháp. Tiền gửi được bảo chứng, tính lãi và bảo vệ bởi Bảo hiểm tiền gửi Việt Nam [[FAQ:L36](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/165241783_%5BFD%5D%20FAQ.md#L36)]. Mọi dữ liệu về tài sản đầu tư thực tế do ngân hàng lưu giữ và phản ánh về ZaloPay qua API Connectors [[Core Tech:L68-70](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Technical%20Page/310007104_FD%20System%20%E2%80%94%20Core%20knowledge.md#L68-70)].

---

## 2. Nghiệp vụ & Business Rules

Sản phẩm FD tích hợp hai đối tác ngân hàng có các business rules và thuật toán rút trước hạn khác biệt đáng kể:

### 2.1 Đối chiếu Quy tắc Nghiệp vụ (CIMB vs CAKE)

| Tiêu chí | Ngân hàng CIMB | Ngân hàng CAKE |
|---|---|---|
| **Số tiền nạp tối thiểu** | **100.000đ/sổ** [[Hạn mức:L15](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L15)] | **100.000đ/sổ** [[Hạn mức:L117](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L117)] |
| **Hạn mức tích lũy tối đa** | **100.000.000đ tổng gốc/user** [[Hạn mức:L14](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L14)] | **100.000.000đ/sổ**, không giới hạn số lượng sổ [[Hạn mức:L117](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L117)] |
| **Hạn mức rút tối thiểu** | **2.000đ** [[Hạn mức:L17](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L17)] | **100.000đ** [[Hạn mức:L117](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L117)] |
| **Quy tắc rút một phần gốc** | Số dư gốc còn lại sau khi rút $\geq$ **100.000đ** [[Hạn mức:L13](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L13)]. | * Số tiền rút từ **10% đến 90%** giá trị gốc của sổ [[Hạn mức:L117](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L117)].<br>* Số gốc còn lại sau rút $\geq$ **100.000đ** [[Hạn mức:L117](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/236985591_%5BFD%5D%20Ha%CC%A3n%20mu%CC%9B%CC%81c%20Open_Break.md#L117)]. |
| **Phương thức đáo hạn** | Tự động đáo hạn (gốc + lãi nhập gốc tái ký kỳ hạn cũ với lãi suất mới tại ngày đáo hạn) [[FAQ:L35](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/165241783_%5BFD%5D%20FAQ.md#L35)]. | Tương tự, tự động đáo hạn gốc + lãi theo kỳ hạn cũ. |
| **Rút tiền về tài khoản ngân hàng** | Khả dụng (IBFT tối đa 20.000.000đ/giao dịch gồm cả lãi) [[Break Bank:L53-54](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/284997084_%5BFD%5D%20-%20User%20Guide%20-%20Break%20FD%20to%20bank.md#L53-54)]. | Chưa hỗ trợ (Đang roadmap). |
| **Xác thực OTP khi rút** | Không yêu cầu OTP (chỉ xác thực qua mã PIN ví ZaloPay) [[Break MMF:L47](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/284987959_%5BFD%5D%20-%20User%20Guide%20-%20Break%20FD%20to%20MMF.md#L47)]. | Bắt buộc nhập mã OTP gửi từ đối tác ngân hàng Cake [[Break MMF:L46](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/284987959_%5BFD%5D%20-%20User%20Guide%20-%20Break%20FD%20to%20MMF.md#L46)]. |

---

## 3. Bản đồ Tính năng dạng UML Use Case Diagram

Sơ đồ ca sử dụng UML dưới đây phân tách các tính năng hiện tại (Core - Active) và các tính năng tương lai / đang phát triển (Future Roadmap / Brainstorm):

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }, "flowchart": { "curve": "basis" }}}%%
graph TD
    User((Người dùng ZaloPay))
    System((Hệ thống FD-Core))
    BankPartner((Ngân hàng Đối tác))
    
    subgraph "Tính năng Hiện tại (Core - Active)"
        UC_Onboard(Đăng ký & Mở CASA Bank)
        UC_Open_VietQR(Mở sổ tiết kiệm qua VietQR)
        UC_View_Assets(Xem danh sách & Chi tiết sổ)
        UC_Break_Wallet(Rút trước hạn về Ví ZaloPay)
        UC_Break_Bank(Rút trước hạn về Ngân hàng liên kết)
        UC_Break_MMF(Rút trước hạn về MMF)
        UC_Force_NFC(Xác thực NFC theo TT40)
    end
    
    subgraph "Tác vụ chạy ngầm / Nghiệp vụ"
        UC_Rollover(Đáo hạn tự động)
        UC_Recon(Đối soát và Manual Refund)
        UC_Sync_CASA(Đồng bộ trạng thái CASA)
        UC_Loyalty_Bonus(Tặng bonus rate cho User)
    end
    
    User --> UC_Onboard
    User --> UC_Open_VietQR
    User --> UC_View_Assets
    User --> UC_Break_Wallet
    User --> UC_Break_Bank
    User --> UC_Break_MMF
    User --> UC_Force_NFC
    
    System --> UC_Sync_CASA
    System --> UC_Recon
    System --> UC_Rollover
    System --> UC_Loyalty_Bonus
    
    UC_Onboard --> BankPartner
    UC_Open_VietQR --> BankPartner
    UC_Break_Wallet --> BankPartner
    UC_Break_Bank --> BankPartner
    UC_Break_MMF --> BankPartner
    UC_Force_NFC --> BankPartner
    UC_Rollover --> BankPartner
```

---

## 4. Cấu trúc dữ liệu & ERD (Entity Relationship Diagram)

Hệ thống quản lý thông tin khách hàng và giao dịch tiết kiệm thông qua cơ sở dữ liệu quan hệ PostgreSQL với sơ đồ ERD chi tiết dưới đây [[ERD:L11-155](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/316890946_%5BFD%5D%20ERD.md#L11-155)]:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }, "er": { "useWidth": 150 }}}%%
erDiagram
    fixed_deposit_account {
        bigint id PK
        varchar user_id FK
        bigint partner_id FK
        bigint user_skey
        varchar partner_account_number
        varchar partner_account_name
        varchar status "active / closed / dormant"
        varchar origin "FixedDeposit / anotherZPproduct"
        varchar status_detail
        super extra
        timestamp create_time
        timestamp update_time
    }
    
    fixed_deposit_fixed_deposit {
        varchar fixed_deposit_id PK
        bigint id
        varchar user_id FK
        bigint user_skey
        bigint partner_id FK
        bigint zp_trans_id
        varchar status
        bigint original_balance
        bigint current_balance
        bigint receive_total_amount
        bigint tenor
        bigint estimate_interest
        double interest_rate
        varchar maturity_instruction
        varchar start_date
        varchar end_date
        timestamp create_time
        timestamp update_time
    }
    
    fixed_deposit_order {
        varchar bc_request_id PK
        bigint id
        varchar user_id FK
        bigint user_skey
        varchar fixed_deposit_id FK
        bigint app_trans_id
        bigint app_id "888 / 8686 / 186"
        bigint internal_fd_id
        bigint zp_trans_id
        varchar bank_trans_id
        varchar bank_trans_time
        varchar trans_type "OPEN / BREAK"
        bigint partner_id FK
        bigint amount
        varchar status "PROCESSING / SUCCEEDED / FAILED / BANKTRANS_SUCCEEDED / BANKTRANS_FAILED"
        varchar bank_error_code
        varchar internal_error_code
        varchar payment_destination "WALLET / BANK / MMF"
        timestamp create_time
        timestamp update_time
    }

    fixed_deposit_binding_log {
        bigint request_id PK
        varchar user_id FK
        bigint user_skey
        bigint partner_id FK
        varchar current_step
        varchar reject_code
        varchar full_name
        varchar phone_number
        varchar id_number
        varchar birthday
        varchar gender
        timestamp create_time
        timestamp update_time
    }

    fixed_deposit_standardize_profile_log {
        bigint request_id FK
        bigint user_id
        bigint partner_id
        varchar current_step
        varchar gender
        varchar reject_code
        timestamp create_time
        timestamp update_time
    }

    fixed_deposit_event_mart {
        bigint mart_skey PK
        varchar user_id FK
        varchar event_id
        varchar sub_event_id
        varchar frontend_platform
        session session_id
        super metadata
        timestamp event_time
    }
    
    fixed_deposit_account ||--o{ fixed_deposit_fixed_deposit : "1-N (user_id, partner_id)"
    fixed_deposit_fixed_deposit ||--o{ fixed_deposit_order : "1-N (fixed_deposit_id)"
    fixed_deposit_account |o--o{ fixed_deposit_binding_log : "1-N (user_id, partner_id)"
    fixed_deposit_binding_log ||--o| fixed_deposit_standardize_profile_log : "1-1 (request_id)"
    fixed_deposit_account |o..o{ fixed_deposit_event_mart : "Lưu vết UI"
```

---

## 5. Quy trình Nghiệp vụ Chi tiết (Core Workflows)

### 5.1 Vòng đời Trạng thái Đơn hàng (Order State Machine)
Đơn hàng trong hệ thống FD lưu giữ các trạng thái trung gian phục vụ việc đối soát và xử lý bất đồng bộ từ PE (Payment Engine):

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
stateDiagram-v2
    [*] --> PROCESSING : Tạo yêu cầu giao dịch
    
    PROCESSING --> BANKTRANS_SUCCEEDED : PE báo nạp/rút thành công, chưa nhận phản hồi từ Bank
    PROCESSING --> BANKTRANS_FAILED : PE báo giao dịch lỗi cần đối soát
    PROCESSING --> FAILED : Giao dịch bị từ chối hoặc hết hạn (Expired)
    
    BANKTRANS_SUCCEEDED --> SUCCEEDED : Connector gọi Bank thành công và cập nhật sổ
    BANKTRANS_SUCCEEDED --> FAILED : Gọi đối tác thất bại hoặc đối soát T+1 xác nhận lỗi
    
    BANKTRANS_FAILED --> FAILED : Đối soát xác định lỗi chính thức
    BANKTRANS_FAILED --> SUCCEEDED : Đối soát xác định tiền đã vào tài sản của user
    
    SUCCEEDED --> REFUNDED : Trạng thái nạp thành công nhưng cần hoàn tiền thủ công / tự động (khi break bank lỗi)
    
    FAILED --> [*]
    SUCCEEDED --> [*]
    REFUNDED --> [*]
```

### 5.2 Luồng Đăng ký & Onboarding CASA
Quy trình định danh eKYC và mở tài khoản thanh toán CASA tại đối tác ngân hàng CIMB/CAKE:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
sequenceDiagram
    autonumber
    participant User as Người dùng
    participant App as ZaloPay App (Client)
    participant Gateway as API Gateway
    participant Account as Account Service
    participant UM as User Management System
    participant Partner as Connector (CIMB/CAKE)
    
    User->>App: Bấm đăng ký Mở Tài Khoản Tiết Kiệm
    App->>Gateway: Check user eligibility
    Gateway->>Account: Forward gRPC Request
    Account->>UM: Lấy thông tin eKYC và Độ tuổi
    alt Tuổi < 18 hoặc chưa KYC Level 2
        UM-->>Account: Hạn chế
        Account-->>App: Báo lỗi và block luồng đăng ký
    else Hợp lệ
        UM-->>Account: KYC Approved (Tuổi >= 18)
        Account-->>App: Trả về điều khoản & Hợp đồng CASA
    end
    User->>App: Ký hợp đồng điện tử (E-Sign)
    App->>Account: Submit Consent & Contract Agreement
    Account->>Partner: Register User & Create CASA (họ tên, CCCD, selfie...)
    alt Thông tin CMND/CCCD đã dùng mở > 2 tài khoản tại CIMB
        Partner-->>Account: Lỗi: Limit Exceeded / ID Number Used
        Account-->>App: Hiển thị lỗi và hướng dẫn gỡ liên kết
    else Thành công
        Partner-->>Account: Trả về Số tài khoản CASA (partner_account_number)
        Account->>Account: Lưu Account status = 'active'
        Account-->>App: Màn hình kích hoạt thành công, cho phép mở sổ
    end
```

### 5.3 Luồng Nạp tiền Mở sổ (Open FD via VietQR)
Luồng nạp tiền sử dụng phương thức VietQR để đưa dòng tiền trực tiếp từ tài khoản ngân hàng của user vào tài khoản ký quỹ mở tại CIMB/CAKE:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
sequenceDiagram
    autonumber
    participant User as Người dùng
    participant App as ZaloPay App (Client)
    participant Account as Account Service
    participant Management as Management Service
    participant AC as Acquiring Core (ACv2)
    participant Partner as Connector (CIMB/CAKE)
    participant Kafka as Kafka Broker
    
    User->>App: Chọn Kỳ hạn, Nhập số tiền gửi -> Bấm "Tiếp tục"
    App->>Account: ConfirmOpenFDOrder (amount, partner_id)
    Note over Account: Validate số tiền gửi (Min 100k, Max 100M tổng gốc của CIMB)
    Account->>AC: Khởi tạo đơn hàng (CreateOrder)
    AC-->>Account: Trả về mã VietQR động
    Account-->>App: Hiển thị mã VietQR cho user
    User->>User: Mở ứng dụng Ngân hàng của mình -> Quét QR và thanh toán
    AC->>Management: Webhook báo thanh toán VietQR thành công
    Management->>Management: Cập nhật order status = 'BANKTRANS_SUCCEEDED'
    Management->>Kafka: Đẩy command sync (delay=60s)
    
    Note over Management: Sau 60s, consume Kafka message
    Management->>Partner: API Open Fixed Deposit (account_no, amount)
    alt Ngân hàng đối tác phản hồi thành công
        Partner-->>Management: Trả về Số sổ FD (fixed_deposit_id)
        Management->>Management: Cập nhật order status = 'SUCCEEDED' & Tạo sổ tiết kiệm
        Management->>App: SSE thông báo tạo sổ thành công, bắt đầu tính lãi
    else Ngân hàng lỗi quá tải (429/503) hoặc timeout
        Partner-->>Management: Lỗi
        Management->>Kafka: Đẩy lại command vào delay topic để retry tiếp
    end
```

### 5.4 Luồng Rút tiền trước hạn về MMF (Break FD to MMF - 2-step Flow)
Rút tiền trực tiếp vào Số Dư Sinh Lời (MMF) thực chất là chuỗi hai giao dịch chạy bất đồng bộ để tránh thất thoát tiền của user [[Break MMF:L58-60](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/284987959_%5BFD%5D%20-%20User%20Guide%20-%20Break%20FD%20to%20MMF.md#L58-60)]:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
sequenceDiagram
    autonumber
    participant User as Người dùng
    participant App as ZaloPay App (Client)
    participant Account as Account Service
    participant Management as Management Service
    participant Redis as Redis Cache
    participant Partner as Connector (CIMB/CAKE)
    participant PE as Payment Engine
    participant MMF as MMF Core Service
    
    User->>App: Chọn Sổ FD -> Bấm "Rút trước hạn" -> Chọn đích nhận: MMF
    App->>Account: InitBreakFDToMMF(fixed_deposit_id, amount)
    Note over Account: Validate hạn mức MMF của user (Max 100M/2M)
    Account->>Redis: Lock user-level transaction (chống race condition)
    Account->>Partner: Request Block/Close FD Asset (IfnCreateRedemption / Cake partial close)
    Partner-->>Account: Confirmed (Khóa tài sản tạm thời tại Bank)
    Account->>Management: Tạo Order status = 'PROCESSING'
    Account-->>App: Yêu cầu xác thực PIN / OTP (Cake)
    User->>App: Xác thực mã PIN / OTP
    App->>Management: ConfirmBreakFDToMMF
    
    Note over Management: [Giao dịch 1]: Rút tiền FD về ví ZaloPay
    Management->>PE: Gọi Disbursement rút tiền về ví ZaloPay của user
    PE-->>Management: SUCCESS (Tiền mặt đã vào ví)
    Management->>Partner: ConfirmRedemption (status=SUCCEEDED - Trừ tài sản chính thức tại Bank)
    
    Note over Management: [Giao dịch 2]: Nạp tiền từ ví vào MMF
    Management->>MMF: Gọi API nạp tiền MMF (Deposit) từ ví
    alt MMF nạp thành công
        MMF-->>Management: SUCCESS
        Management->>Management: Cập nhật order status = 'SUCCEEDED' (Thành công toàn phần)
        Management-->>App: Thông báo tiền đã vào tài khoản MMF thành công
    else MMF nạp thất bại (VD: do MMF user vượt hạn mức 100M)
        MMF-->>Management: FAILED (Lỗi hạn mức hoặc lỗi hệ thống MMF)
        Management->>Management: Cập nhật order status = 'PARTIALLY_SUCCEEDED' (Thành công bán phần)
        Management-->>App: Thông báo: Rút FD về Ví thành công, nạp MMF thất bại (Tiền được giữ lại ở Ví ZaloPay)
    end
    Account->>Redis: Giải phóng lock
```

### 5.5 Luồng Rút tiền trước hạn về Ngân hàng (Break FD to Bank - IBFT Flow)
Áp dụng đối với user nạp tiền qua VietQR, nay muốn rút trực tiếp về tài khoản ngân hàng liên kết để tránh hạn mức ví ZaloPay [[Break Bank:L116-118](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/284997084_%5BFD%5D%20-%20User%20Guide%20-%20Break%20FD%20to%20bank.md#L116-118)]:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }}}%%
sequenceDiagram
    autonumber
    participant User as Người dùng
    participant App as ZaloPay App (Client)
    participant Account as Account Service
    participant Management as Management Service
    participant Partner as Connector (CIMB)
    participant PE as Payment Engine
    participant IBFT as IBFT Core (Zion Bank gateway)
    
    User->>App: Chọn rút FD về Ngân hàng (Nhập STK, chọn Bank)
    App->>Account: InitBreakFDToBank(fixed_deposit_id, amount, bank_info)
    Note over Account: Validate hạn mức: Tiền rút + Lãi <= 20.000.000đ/giao dịch
    Account->>Partner: Lock & Close FD Asset tại Bank
    Partner-->>Account: Confirmed
    Account->>Management: Tạo Order status = 'PROCESSING'
    
    Note over Management: [Giao dịch 1]: Rút tiền FD về ví trung gian của Zion
    Management->>PE: Chuyển tiền từ Bank về Escrow Account của Zion tại ZaloPay
    PE-->>Management: SUCCESS
    
    Note over Management: [Giao dịch 2]: Chi hộ IBFT từ ví trung gian Zion về bank của user
    Management->>IBFT: Thực hiện lệnh chuyển tiền nhanh Napas 247
    alt IBFT chuyển khoản thành công
        IBFT-->>Management: SUCCESS
        Management->>Partner: ConfirmRedemption (status=SUCCEEDED - Xác nhận trừ tài sản)
        Management->>Management: Cập nhật order status = 'SUCCEEDED' (Thành công toàn phần)
        Management-->>App: Báo rút tiền về ngân hàng thành công
    else IBFT chuyển khoản thất bại (VD: Sai số tài khoản thụ hưởng, lỗi Napas)
        IBFT-->>Management: FAILED
        Management->>Partner: ConfirmRedemption (status=SUCCEEDED)
        Management->>PE: Gọi refund hoàn tiền từ ví trung gian Zion về Ví ZaloPay của user
        PE-->>Management: SUCCESS
        Management->>Management: Cập nhật order status = 'PARTIALLY_SUCCEEDED' (Tiền hoàn về ví ZaloPay)
        Management-->>App: Báo: Rút về Ngân hàng lỗi, tiền đã được hoàn lại ví ZaloPay của bạn
    end
```

---

## 6. Quy định Pháp lý & Tuân thủ (NFC & VNeID)

Theo các văn bản quy định của Ngân hàng Nhà nước (đặc biệt là Thông tư 40 - TT40), việc thực hiện rút tiết kiệm trực tuyến yêu cầu các bước định danh chặt chẽ qua chip CCCD hoặc tài khoản định danh điện tử VNeID:

### 6.1 Cơ chế cập nhật NFC tại CIMB
* **Quy trình:** Khi người dùng thực hiện rút sổ (hoặc định danh lần đầu), hệ thống của CIMB yêu cầu thông tin đối soát sinh trắc học và dữ liệu quét NFC từ chip thẻ CCCD của người dùng [[TT40 NFC:L24](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/230293377_%5BFD%5D%5BCIMB%5D%20TT40%20-%20Force%20update%20NFC%20before%20break%20FD.md#L24)]. Dữ liệu này gồm các nhóm trường định danh bảo mật từ Bộ Công an (BCA).
* **Trạng thái nfc_status trong DB:**
  - `init`: Trạng thái khởi tạo hồ sơ (profile_approved, image_approved).
  - `submitted`: Đang chờ đối tác phê duyệt (waiting approval).
  - `succeed`: Đã được đối tác phê duyệt thành công.
  - `failed`: Bị đối tác từ chối (rejected) [[TT40 NFC:L51-54](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/230293377_%5BFD%5D%5BCIMB%5D%20TT40%20-%20Force%20update%20NFC%20before%20break%20FD.md#L51-54)].

### 6.2 Sự cố thiếu trường Gender (dg13)
* **Nguyên nhân:** Dữ liệu NFC đọc ra từ thẻ CCCD gắn chip truyền về hệ thống User Management (UM) của ZaloPay có thể bị thiếu trường thông tin **Gender** (Nằm trong file bảo mật `dg13` của BCA) [[CS Ticket NFC:L59](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/FD/ISSUE-27487_%5BTa%CC%80i%20khoa%CC%89n%5D%20-%20%5BTa%CC%80i%20khoa%CC%89n%20tie%CC%82%CC%81t%20kie%CC%A3%CC%82m%5D%20Ca%CC%A3%CC%82p%20nha%CC%A3%CC%82t%20NFC%20-.md#L59)]. Do trường này là optional từ phía BCA nên đầu thu của UM không bắt buộc.
* **Hậu quả:** Khi ZaloPay gửi thông tin NFC sang ngân hàng đối tác để phê duyệt hồ sơ rút tiền, đối tác sẽ từ chối phê duyệt do thiếu trường bắt buộc `Gender`. Giao diện Miniapp sẽ liên tục yêu cầu user thực hiện lại thao tác áp điện thoại quét NFC (Tap NFC) mỗi khi truy cập sản phẩm FD [[CS Ticket NFC:L22-23](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/FD/ISSUE-27487_%5BTa%CC%80i%20khoa%CC%89n%5D%20-%20%5BTa%CC%80i%20khoa%CC%89n%20tie%CC%82%CC%81t%20kie%CC%A3%CC%82m%5D%20Ca%CC%A3%CC%82p%20nha%CC%A3%CC%82t%20NFC%20-.md#L22-23)].
* **Quy trình xử lý CS:** Báo cáo khách hàng thực hiện quét lại NFC cẩn thận. Nếu vẫn tiếp tục lỗi, CS chuyển ticket sang cho team UM của ZaloPay để can thiệp cấu hình và đồng bộ thủ công [[CS Ticket NFC:L71](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/FD/ISSUE-27487_%5BTa%CC%80i%20khoa%CC%89n%5D%20-%20%5BTa%CC%80i%20khoa%CC%89n%20tie%CC%82%CC%81t%20kie%CC%A3%CC%82m%5D%20Ca%CC%A3%CC%82p%20nha%CC%A3%CC%82t%20NFC%20-.md#L71)].

---

## 7. Các Sự cố Thường gặp & Quy trình CS Support

Trong vận hành sản phẩm FD, các kịch bản lỗi hệ thống sau đây thường xuyên xảy ra, yêu cầu CS nắm vững nguyên nhân để giải đáp và phối hợp với Đội ngũ Kỹ thuật xử lý:

### 7.1 Lỗi Tài khoản CASA bị đóng băng (Dormant Account)
* **Hiện tượng:** Người dùng thực hiện nạp tiền mở sổ báo lỗi không thực hiện được. Hệ thống trả lỗi `DORMANT_USERS` từ cổng CIMB [[CS Support CIMB:L31](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L31)].
* **Nguyên nhân:** Tài khoản thanh toán CASA mở tại ngân hàng đối tác của người dùng không có bất kỳ giao dịch nạp/rút tiền nào phát sinh trong vòng 12 tháng liên tục, dẫn đến hệ thống ngân hàng tự động đưa tài khoản về trạng thái tạm khóa (dormant) [[CS Support CIMB:L33-34](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L33-34)].
* **Khắc phục:** Hệ thống FD hiện tại đã chủ động phát hiện trạng thái này thông qua việc kiểm tra API `casaLimitStatus` và hiển thị Banner/Bottom Sheet ngăn chặn giao dịch nạp và hướng dẫn user liên hệ hotline CIMB (1900969696) để làm thủ tục kích hoạt lại tài khoản thanh toán [[FAQ:L39](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/165241783_%5BFD%5D%20FAQ.md#L39), [Database:L34-37](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/189384977_%5BFD%5D%20Database%20-%20BE.md#L34-37)].

### 7.2 Lỗi Vượt hạn mức tháng 100 triệu của tài khoản eKYC
* **Hiện tượng:** Khách hàng tất toán/rút trước hạn sổ tiết kiệm báo lỗi thất bại, dù số dư sổ hoàn toàn hợp lệ [[FAQ:L41](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/165241783_%5BFD%5D%20FAQ.md#L41)].
* **Nguyên nhân:** Theo quy định của Ngân hàng Nhà nước, tài khoản thanh toán mở bằng phương thức định danh điện tử eKYC sẽ có hạn mức giao dịch tối đa là 100.000.000 VNĐ/tháng dương lịch [[FAQ:L41](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/165241783_%5BFD%5D%20FAQ.md#L41)]. Khi user rút tiền từ sổ FD về tài khoản thanh toán để đưa về ví ZaloPay, tổng số tiền chuyển (bao gồm cả gốc và tiền lãi phát sinh) cộng dồn trong tháng vượt quá 100 triệu sẽ bị ngân hàng chặn lại [[FAQ:L41](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/165241783_%5BFD%5D%20FAQ.md#L41)].
* **Khắc phục:** CS hướng dẫn user chia nhỏ số tiền rút dưới hạn mức còn lại của tháng, hoặc hướng dẫn user liên hệ hotline đối tác để thực hiện nâng cấp định danh tài khoản thanh toán (Video Call hoặc định danh tại quầy) [[FAQ:L41](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/165241783_%5BFD%5D%20FAQ.md#L41)].

### 7.3 Conflict Đăng ký giữa FD và Tài khoản Trả sau (Paylater)
* **Hiện tượng:** Người dùng vào sản phẩm FD để đăng ký mở tài khoản thanh toán nhưng liên tục gặp thông báo lỗi đăng ký thất bại [[CS Support CIMB:L48-49](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L48-49)].
* **Nguyên nhân:** Cả hai sản phẩm **Fixed Deposit (FD)** và **Tài khoản Trả sau (Paylater)** đều dùng chung hạ tầng tài khoản thanh toán CASA mở tại ngân hàng đối tác CIMB. Nếu trước đó user đã từng onboard hoặc gửi thông tin đăng ký Paylater (kể cả trạng thái cuối là Approved hay Rejected), thông tin định danh của user đã được khởi tạo và lưu giữ trên hệ thống CIMB. Khi user đăng ký FD, hệ thống phát sinh xung đột quyền (permission) và trùng lặp thông tin định danh do chưa được liên kết chéo [[CS Support CIMB:L48-49](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L48-49)].
* **Khắc phục:** CS kiểm tra lịch sử xem user đã từng onboard Paylater chưa [[CS Support CIMB:L51-52](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L51-52)].
  - Nếu có: Tạo ticket Jira chuyển cho team tech FD (assign cho `haiph2` hoặc PIC FD) để chạy script liên kết và cập nhật trạng thái thủ công cho tài khoản, sau đó báo user vào thử lại [[CS Support CIMB:L53-56](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L53-56)].
  - Nếu chưa: Hướng dẫn user liên hệ trực tiếp CIMB để kiểm tra xem có thông tin nào bị lệch so với dữ liệu định danh trên ZaloPay [[CS Support CIMB:L57-60](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L57-60)].

### 7.4 Quy trình Manual Refund tiền nạp lỗi sau đối soát
* **Hiện tượng:** Người dùng bị trừ tiền trong ví ZaloPay khi thực hiện nạp tiền mở sổ, tuy nhiên không thấy ghi nhận sổ mới trên app và giao dịch rơi vào trạng thái pending hoặc thất bại [[CS Support CIMB:L36](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L36), [CS Cake:L56](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762822_%5BFD%5D%5BCAKE%5D%20CS%20Support.md#L56)].
* **Nguyên nhân:** Giao dịch thanh toán tại ZaloPay thành công nhưng kết nối gọi sang tạo sổ tại đối tác bị lỗi (Timeout, lỗi đường truyền hoặc hệ thống ngân hàng nâng cấp bảo trì).
* **Quy trình xử lý:** Tiền trừ của user sẽ được thực hiện hoàn trả thủ công (Manual Refund) sau khi có kết quả đối soát dữ liệu với đối tác ngân hàng [[CS Support CIMB:L36](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L36)].
  - CS cần kiểm tra xem giao dịch đã qua chu kỳ đối soát (Reconciliation) chưa [[CS Support CIMB:L37](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L37)].
  - Mốc đối soát:
    - Giao dịch phát sinh **trước ~8h tối (giờ Cut-off)** của ngày T: đối soát vào ngày T+1 hoặc ngày đầu tiên sau kỳ nghỉ lễ [[CS Support CIMB:L40-41](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L40-41)].
    - Giao dịch phát sinh **sau ~8h tối** của ngày T: đối soát vào ngày T+2 hoặc ngày thứ 2 sau kỳ nghỉ lễ [[CS Support CIMB:L42-43](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L42-43)].
  - Nếu đã qua thời gian đối soát mà khách vẫn chưa nhận được tiền hoàn: CS tạo ticket chuyển OP (domain: HienTTD) để kích hoạt lệnh hoàn tiền thủ công cho khách [[CS Support CIMB:L38](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/FD/Product%20Page/194762828_%5BFD%5D%5BCIMB%5D%20CS%20Support.md#L38)].
