# FD (Fixed Deposit) - Product Knowledge Base

> Mục tiêu: hệ thống hóa kiến thức sản phẩm FD để làm nền cho các lần Product Audit sau này. Tài liệu này **không chấm điểm pass/fail**; các nhận định audit phải được thực hiện riêng theo Product Audit Checklist v6 với evidence cụ thể.

---

## 0. Cách dùng tài liệu này

| Nhu cầu | Đọc phần |
|---|---|
| Nắm nhanh FD là gì, đang live logic nào | `Fact Sheet`, `Business Rules` |
| Audit UX / journey | `Feature Map`, `Journey Inventory`, `Core Workflows` |
| Audit money safety / limits / source-of-fund | `Money Rules`, `Payment Destinations`, `Order State Machine` |
| Audit reliability / ops / CS | `Operational Reliability`, `CS Ticket Taxonomy` |
| Audit tech / data | `Architecture`, `Data Model`, `Metrics & Queries` |
| Trace evidence | `Source Manifest` cuối tài liệu |

**Quy tắc evidence:** mỗi claim quan trọng được gắn mã `[E..]` dẫn tới source local trong workspace. Nếu Confluence cũ khác source hiện tại, ưu tiên source/code/Jira mới hơn và ghi rõ mâu thuẫn.

---

## 1. Fact Sheet (TL;DR)

| Thuộc tính | Chi tiết |
|---|---|
| **Tên sản phẩm** | FD / Fixed Deposit / "Gửi Tiết Kiệm" / "Tài khoản tiết kiệm" |
| **Định vị** | Tiền gửi có kỳ hạn trực tuyến qua ZaloPay, do ngân hàng đối tác cung cấp. ZaloPay hỗ trợ hiển thị sản phẩm và trung gian thanh toán, không phải bên phát hành tiền gửi. [E1] [E2] |
| **Đối tác chính** | **CIMB Việt Nam** và **CAKE by VPBank**. Core system mô tả hai partner connectors CIMB/CAKE. [E15] [E18] |
| **Vai trò ZaloPay** | Hiển thị thông tin sản phẩm, hỗ trợ truy cập, nạp/rút qua ví hoặc kênh thanh toán liên quan; các điều khoản tiền gửi theo thỏa thuận giữa ngân hàng và khách hàng. [E1] |
| **Điều kiện user** | FAQ CIMB ghi user hợp lệ là công dân Việt Nam, đủ 18 tuổi trở lên. [E3] |
| **Onboarding** | User cần KYC, mở/liên kết CASA/partner account, ký hợp đồng, OTP/face challenge/NFC/VNeID tùy partner và trạng thái. [E4] [E40] [E42] |
| **Tính năng core** | Onboarding, mở gói FD, xem tài sản, rút trước hạn, rollover/đáo hạn, lịch sử giao dịch, thông tin sản phẩm/FAQ, promotion/bonus rate, rút về ví/ngân hàng/MMF. [E9] [E20] [E21] [E25] |
| **Kỳ hạn** | FE hiện hỗ trợ theme kỳ hạn 1/3/6/9/12 tháng. FAQ CIMB cũng ghi 1/3/6/9/12, trong khi trang product info cũ ghi 6/9/12. Khi audit cần kiểm tra theo partner/current config. [E7] [E1] [E21] |
| **Lãi** | Hình thức cơ bản là trả lãi cuối kỳ; mở sau điểm đối soát có thể ghi nhận tính lãi từ T+1; lãi suất bảng tính có thể trễ so với lãi tại màn xác nhận mở gói. [E5] [E6] |
| **Mở FD - hạn mức hiện hành** | Source FE và limit doc mới ghi min open **100.000đ**, max **100.000.000đ**. Với CIMB là total principal; với CAKE là 100M/sổ và không giới hạn số sổ theo limit doc. [E11] [E14] [E23] |
| **Rút trước hạn - CIMB** | Min rút hiện hành **2.000đ**; remaining balance phải >= **100.000đ** nếu rút một phần; rút về bank tối đa 20M/giao dịch bao gồm lãi; rút về ví không giới hạn theo rule trong limit doc. [E12] |
| **Rút trước hạn - CAKE** | Min rút **100.000đ**; số tiền rút phải trong khoảng 10%-90% giá trị gốc và remaining >=100.000đ nếu rút một phần. [E14] |
| **Payment destinations** | `ZALOPAY_WALLET`, `BINDING_BANK`, `ZALOPAY_MMF`. [E25] |
| **OTP / xác thực** | OTP code length 6; FAQ cũ có rule về pending/OTP và guide hiện tại ghi rút về bank/MMF: CAKE yêu cầu OTP, CIMB không yêu cầu OTP. [E10] [E21] [E36] [E37] |
| **Support hotline** | FE constants: CIMB `1900969696`, CAKE `1900636686`. [E24] |
| **Core data tables** | `account`, `binding_log`, `fixed_deposit`, `order`, `promotion_schemes`, `promotion_applications`. [E28] [E29] [E30] [E31] [E34] [E35] |
| **CS evidence volume** | FD có 788 CS ticket local; tài liệu này chỉ gom taxonomy và representative tickets, không thay thế report CS full. |

---

## 2. Knowledge Map

```mermaid
%%{init: {"theme": "neutral", "themeVariables": {"fontFamily": "Inter, Arial, sans-serif"}}}%%
flowchart LR
    FD["FD Product Knowledge Base"]
    Confluence["Confluence\nProduct / Technical / Operation"]
    Source["Source Code\nbackend / fd-app / db"]
    Jira["Jira\nRoadmap & delivery"]
    CS["CS Ticket\nCustomer pain taxonomy"]
    Data["FD Schema / Queries\nWarehouse model"]
    Audit["Product Audit v6\n4 axes"]

    Confluence --> FD
    Source --> FD
    Jira --> FD
    CS --> FD
    Data --> FD
    FD --> Audit
```

**Coverage hiện tại**

| Nguồn | Đã cover | Ghi chú audit |
|---|---|---|
| Confluence Product Page | Product info, FAQ, onboarding, break FD, limits, bank/MMF withdrawal, promotion. | Có nhiều page cũ, cần check version/staleness khi audit. |
| Confluence Technical Page | Core knowledge, services, connectors, eventing, storage, design patterns. | Dùng để audit reliability/data correctness. |
| Source Code | API routes, FE screen keys, constants, payment destination, DB schema, promotion schema. | Đây là source ưu tiên khi rule trong FAQ cũ khác code hiện tại. |
| Jira | Bank withdrawal limit, SDSL/MMF withdrawal, promotion, revamp home, NFC/VNeID, Cashier. | Dùng để phân biệt live/done/planned. |
| CS Ticket | 788 ticket FD, gom theo taxonomy. | Dùng để tìm negative evidence khi audit. |
| UI Flow | Không thấy folder UI Flow riêng cho FD. UI evidence lấy từ Confluence screen docs và `fd-app`. | Gap cần bổ sung nếu sau này có Figma/flow folder riêng. |

---

## 3. Product Scope & Boundary

FD là sản phẩm tiền gửi có kỳ hạn do ngân hàng đối tác cung cấp, embedded trong ZaloPay. Với CIMB, mô tả sản phẩm nhấn mạnh ngân hàng là bên cung cấp tiền gửi, còn ZaloPay hỗ trợ hiển thị và trung gian thanh toán. Đây là boundary quan trọng khi audit trust copy, legal wording, dispute và customer support. [E1]

### 3.1 Partner Model

| Partner | Vai trò | Điểm cần audit |
|---|---|---|
| CIMB | CASA + Fixed Deposit; connector xử lý onboarding, KYC/selfie, contract sign, FD create/break/list/interest, OTP, transaction, cashback. [E18] | Ràng buộc CASA, TT40, dormant/blocked account, NFC/VNeID, monthly transaction limit. |
| CAKE | Onboarding + TD management; connector đơn giản hơn, no Redis theo core knowledge. [E18] | SSO/consent, OTP khi break, limit 10%-90%, Cake-specific profile resubmit. |
| ZaloPay | Miniapp, payment orchestration, display, history, CS routing, MMF/bank/wallet destination. [E1] [E20] | Phải rõ ai chịu trách nhiệm, tiền đang ở đâu, pending/refund đi đâu. |

### 3.2 Feature Map

```mermaid
%%{init: {"theme": "neutral", "themeVariables": {"fontFamily": "Inter, Arial, sans-serif"}}}%%
flowchart TD
    User(("User ZaloPay"))
    FD["FD Miniapp"]
    Partner["Partner Bank\nCIMB / CAKE"]
    ZLP["ZaloPay Payment\nPE / FMC / Wallet"]
    MMF["Số dư sinh lời\nMMF"]
    Bank["External Bank Account"]

    User --> Access["Access / Search / Deeplink"]
    Access --> FD
    FD --> Onboard["Onboarding\nKYC / CASA / Consent / Contract"]
    FD --> Open["Open FD\nsimulate / reserve / OTP / cashier"]
    FD --> Asset["Asset Management\nsummary / package detail"]
    FD --> Break["Break FD\nwallet / bank / MMF"]
    FD --> Promo["Promotion\nbonus rate / cashback"]
    FD --> Support["FAQ / CS Support / Operation"]

    Onboard --> Partner
    Open --> ZLP --> Partner
    Break --> Partner
    Break --> ZLP
    Break --> Bank
    Break --> MMF
    Promo --> FD
```

---

## 4. Business Rules

### 4.1 Eligibility & Onboarding Rules

1. User phải đủ điều kiện KYC và partner policy; FAQ CIMB ghi quốc tịch Việt Nam và đủ 18 tuổi trở lên. [E3]
2. Nếu chưa có tài khoản thanh toán/CASA phù hợp, user phải đi qua flow mở tài khoản/liên kết trước khi mở gói tiết kiệm. [E4] [E40]
3. Onboarding entry check theo thứ tự: binding/existing account, KYC status, onboarding status, rồi điều hướng sang màn phù hợp. [E40]
4. Submit BOD2 gọi CIMB; pass thì đi sign contract, một số case như existing customer, onboarding already, age not allow, ID invalid, duplicated request id cần map UI riêng. [E41]
5. Ký hợp đồng gồm xem hợp đồng, chữ ký, T&C, OTP; sau OTP pass thì về home, pending/rejected xử lý theo status. [E42]
6. FE constants đã encode nhiều lỗi CASA cần audit copy: `AGE_INVALID`, `ID_EXPIRED`, `IDENTITY_INFORMATION_MISSING`, `NFC_NOT_VERIFIED`, `ID_NUMBER_USED`, `USER_ALREADY_HAS_AN_ACCOUNT`, `ANOTHER_ERROR`. [E22]

### 4.2 Open FD Rules

| Rule | Current source | Audit note |
|---|---|---|
| Min open | 100.000đ theo constants và limit doc mới. [E11] [E23] | FAQ cũ còn ghi 500.000đ cho CIMB; cần verify partner config live khi audit. [E8] |
| Max open | 100.000.000đ theo constants; CIMB total principal, CAKE 100M/sổ theo limit doc. [E11] [E14] [E23] | Không dùng FAQ 50M làm current source nếu code/config đã update. |
| Tenor | FE package themes 1/3/6/9/12; FAQ ghi 1/3/6/9/12. [E7] [E21] | Partner-specific availability cần lấy từ `/interest-rate` hoặc config. |
| Interest display | Lãi tại màn xác nhận mở gói là source user nên tin; bảng tính có thể bị trễ khi bank update rate. [E6] | Audit F1/F2 cần kiểm tra copy giải thích latency. |
| Rollover | FAQ có rule rollover/bảo hiểm cũ; DB hiện có `fixed_deposit.status=ROLLOVER`, `origin=ROLLOVER`, maturity instruction gồm rollover principal/interest hoặc principal. [E9] [E30] | Cần audit post-maturity clarity và partner-specific availability. |

### 4.3 Break FD Rules

| Partner / Destination | Rule | Evidence |
|---|---|---|
| CIMB / any destination | Min rút 2.000đ; nếu rút một phần, remaining >=100.000đ; cho rút toàn bộ nếu remaining = 0. | [E12] |
| CIMB / binding bank | Rút về bank tối đa 20M/giao dịch bao gồm lãi; Jira DONE và test passed. | [E12] [E37] [E52] |
| CIMB / wallet | Limit doc ghi rút về ví không giới hạn theo rule hiện hành. | [E12] |
| CAKE / any destination | Min rút 100.000đ; min 10%, max 90% giá trị gốc; remaining >=100.000đ. | [E14] |
| Premature interest | Lãi rút trước hạn cần tính theo số ngày giữ tiền, lãi suất rút trước hạn và rule làm tròn/hiển thị trong limit doc. | [E13] |
| Bank destination | User có thể dùng bank đã lưu, thêm bank mới, hoặc chọn bank khác; có khác biệt bank list theo device vs account. | [E37] |
| MMF destination | Break FD về MMF tạo 2 giao dịch: FD -> ví ZaloPay, rồi ví ZaloPay -> Số dư sinh lời. | [E36] |
| OTP | Guide bank/MMF ghi Cake yêu cầu OTP, CIMB không yêu cầu OTP. | [E36] [E37] |

### 4.4 Money Transparency & State Rules

`order` chỉ có `trans_type` `OPEN` và `BREAK`; trạng thái persistence gồm `PROCESSING`, `BANKTRANS_FAILED`, `BANKTRANS_SUCCEEDED`, `SUCCEEDED`, `FAILED`, `REFUNDED`. [E31]

```mermaid
%%{init: {"theme": "neutral", "themeVariables": {"fontFamily": "Inter, Arial, sans-serif"}}}%%
stateDiagram-v2
    [*] --> PROCESSING: Create order
    PROCESSING --> BANKTRANS_SUCCEEDED: PE/FMC success
    PROCESSING --> BANKTRANS_FAILED: bank/payment failed
    PROCESSING --> FAILED: terminal failure
    BANKTRANS_SUCCEEDED --> SUCCEEDED: FD sync success
    BANKTRANS_FAILED --> REFUNDED: refund completed
    FAILED --> [*]
    SUCCEEDED --> [*]
    REFUNDED --> [*]
```

Open FD backend docs mô tả status flow `PROCESSING -> BANKTRANS_SUCCEEDED -> SUCCEEDED`, `BANKTRANS_FAILED -> REFUNDED`, hoặc `FAILED`; status update đến từ Kafka/RabbitMQ handlers và FD sync. FE type definitions cũng có asset/order status để drive màn package/history. [E26] [E39]

### 4.5 Payment Destination Model

```mermaid
%%{init: {"theme": "neutral", "themeVariables": {"fontFamily": "Inter, Arial, sans-serif"}}}%%
flowchart TD
    Break["User creates BREAK order"] --> Dest{payment_destination}
    Dest --> Wallet["ZALOPAY_WALLET\nRút về ví"]
    Dest --> Bank["BINDING_BANK\nRút về bank liên kết"]
    Dest --> MMF["ZALOPAY_MMF\nRút về Số dư sinh lời"]

    Wallet --> Done1["FD break result shown"]
    Bank --> IBFT["IBFT to user's bank"]
    MMF --> Deposit["Trigger MMF deposit"]

    IBFT --> Done2{IBFT result}
    Done2 -->|success| BankOK["Thành công toàn phần"]
    Done2 -->|failed| BankPartial["Thành công bán phần\nrefund về ví"]

    Deposit --> Done3{MMF deposit result}
    Done3 -->|success| MMFOK["Thành công toàn phần"]
    Done3 -->|failed| MMFPartial["Thành công bán phần\nmoney stays in wallet"]
```

---

## 5. Journey Inventory

### 5.1 FE Screen Inventory

FE `ScreenKey` hiện có các màn chính sau: `Splash`, `Error`, `AddInformation`, `NonUser`, `NewNonUser`, `SignContract`, `FaceChallenge`, `Otp`, `Home`, `Main`, `Account`, `AccountDetail`, `AssetManagement`, `OpeningPackage`, `EarlyWithdrawal`, `WithdrawDetail`, `PackageDetail`, `Deposit`, `Redemption`, `ProductInfo`, `UserManual`, `FAQ`, `CreateAccountCIMBResult`, `LandingPage`, `PreviewInformation`, `WaitingApprove`. [E21]

Bottom tab gồm Home, Asset, Account; tab Asset match opening package và early withdrawal. FE type definitions có asset/order status để map trạng thái package, opening order và break order vào UI/history. [E21] [E26]

### 5.2 Onboarding Journey

```mermaid
%%{init: {"theme": "neutral", "themeVariables": {"fontFamily": "Inter, Arial, sans-serif"}}}%%
sequenceDiagram
    autonumber
    participant U as User
    participant App as FD Miniapp
    participant GW as API Gateway
    participant Acc as Account Service
    participant UM as UM/KYC
    participant Partner as CIMB/CAKE Connector

    U->>App: Access FD
    App->>GW: GET /users/permission + /onboarding/permission
    GW->>Acc: Check binding/KYC/onboarding
    Acc->>UM: Get KYC/profile/NFC/VNeID status
    Acc->>Partner: Check partner onboarding/account status
    alt Eligible
        App->>U: Show BOD2 / consent / contract flow
        U->>App: Submit profile + sign contract
        App->>GW: POST onboarding/application/wet-sign/request-otp/verify-otp
        GW->>Acc: Orchestrate onboarding
        Acc->>Partner: Submit application / verify OTP
        Partner-->>Acc: Approved / waiting / rejected
        Acc-->>App: Onboarding status
        App-->>U: Home / waiting approval / reject guidance
    else Not eligible
        App-->>U: Bottom sheet / update KYC / contact CS / MMF cross-sell
    end
```

### 5.3 Open FD Journey

```mermaid
%%{init: {"theme": "neutral", "themeVariables": {"fontFamily": "Inter, Arial, sans-serif"}}}%%
sequenceDiagram
    autonumber
    participant U as User
    participant App as FD Miniapp
    participant GW as API Gateway
    participant Mgmt as Management Service
    participant PE as ZLP Payment
    participant Bank as Partner Bank

    U->>App: Select partner / tenor / amount
    App->>GW: GET /users/interest-rate + /fixed-deposit/simulate/open
    GW->>Mgmt: Simulate open FD
    Mgmt->>Bank: Simulate / rate / maturity
    App-->>U: Review amount, rate, end date, bonus
    App->>GW: POST /users/fixed-deposit/order/reserve (optional)
    App->>GW: GET /users/fixed-deposit/order/soft-otp (if required)
    U->>App: Confirm open
    App->>GW: POST /users/fixed-deposit/order/open
    GW->>Mgmt: Create order
    Mgmt->>PE: Payment/cashier request
    PE-->>Mgmt: PROCESSING / BANKTRANS_SUCCEEDED / BANKTRANS_FAILED
    Mgmt->>Bank: Sync/create FD if payment succeeded
    Bank-->>Mgmt: FD created / failed
    Mgmt-->>App: Order status
    App-->>U: Processing / success / fail / refund status
```

### 5.4 Break FD Journey

```mermaid
%%{init: {"theme": "neutral", "themeVariables": {"fontFamily": "Inter, Arial, sans-serif"}}}%%
sequenceDiagram
    autonumber
    participant U as User
    participant App as FD Miniapp
    participant GW as API Gateway
    participant Mgmt as Management Service
    participant Bank as Partner Bank
    participant ZLP as ZLP Wallet/Bank/MMF

    U->>App: Tap "Rút trước hạn"
    App->>GW: GET /users/fixed-deposit/simulate/break
    GW->>Mgmt: Simulate breaking FD
    Mgmt->>Bank: Estimate premature interest
    App-->>U: Compare "rút trước hạn" vs "chờ đáo hạn"
    U->>App: Choose amount + destination
    App->>GW: POST /users/fixed-deposit/order/break
    GW->>Mgmt: Create BREAK order with payment_destination
    Mgmt->>Bank: Break FD
    Bank-->>Mgmt: Break result
    alt Destination = wallet
        Mgmt->>ZLP: Credit wallet
    else Destination = bank
        Mgmt->>ZLP: Route IBFT to binding bank
    else Destination = MMF
        Mgmt->>ZLP: Trigger MMF deposit
    end
    Mgmt-->>App: Final / partial / pending state
    App-->>U: Result + history detail
```

Confluence flow cũ có màn so sánh giữa rút trước hạn và chờ đáo hạn; khi audit cần xem đây là điểm bắt buộc để user hiểu phần lãi bị mất, ngày đáo hạn và destination tiền nhận. [E44]

### 5.5 UX Audit Hotspots

| Hotspot | Why it matters | Evidence |
|---|---|---|
| Eligibility / reject copy | CS tickets show generic "Có lỗi xảy ra" for ID already used / CIMB ineligible; users confused and CS asked to improve copy. | [E45] [E46] |
| Waiting approval / loading state | Latest Cake ticket shows user thought app had no UI after "bổ sung thông tin"; later log showed status became waiting approval. | [E50] |
| Pending break locks book | Failed break with no final state temporarily locks the book until reconciliation; this is high-risk state clarity. | [E47] |
| Refund/pending sync | CS noted T+2 reconciliation/status sync between tools can be choppy; OP routing needed. | [E48] |
| Source-of-fund confusion | User/CS confused wallet top-up limit vs FD deposit from wallet; source-of-fund copy needs clarity. | [E49] |
| Lost SIM / OTP recovery | New ticket asks for Cake package code because user lost SIM and still has money in FD. | [E51] |

---

## 6. Technical Architecture

### 6.1 Core Components

Core knowledge states FD has three backend services and two partner connectors, internal gRPC communication, and mobile client over HTTP REST. [E15]

```mermaid
%%{init: {"theme": "neutral", "themeVariables": {"fontFamily": "Inter, Arial, sans-serif"}}}%%
flowchart LR
    App["FD Miniapp\nZPI/ZPA"]
    Gateway["API Gateway\nsession auth / PII log censor / routes"]
    Account["Account Service\nonboarding / binding / read path"]
    Management["Management Service\norders / lifecycle / async events"]
    Cimb["CIMB Connector\ngRPC -> bank REST"]
    Cake["CAKE Connector\ngRPC -> bank REST"]
    PE["PE / FMC / ACV2"]
    Kafka["Kafka"]
    Rabbit["RabbitMQ"]
    Redis["Redis\nlocks / OTP / cache / maintenance"]
    DB["MySQL/PostgreSQL\nFD persistence"]
    S3["MinIO/S3\nKYC docs/selfie"]
    MMF["MMF Service"]

    App --> Gateway
    Gateway --> Account
    Gateway --> Management
    Account --> Cimb
    Account --> Cake
    Management --> Cimb
    Management --> Cake
    Management <--> PE
    PE --> Kafka --> Management
    Rabbit --> Management
    Account --> Redis
    Management --> Redis
    Account --> DB
    Management --> DB
    Account --> S3
    Management --> MMF
```

### 6.2 Service Responsibilities

| Service | Responsibility | Evidence |
|---|---|---|
| API Gateway | Single entry point, session auth, PII log censoring, routes to Account/Management. | [E16] [E20] |
| Account Service | User-facing stateful orchestrator: onboarding, binding, open/break orchestration, maintenance, A/B flags, Temporal onboarding flows. | [E16] |
| Management Service | Async event processor and lifecycle manager for payment outcomes, bank sync, refund, MMF order status. | [E17] |
| CIMB Connector | Onboarding, FD create/break/simulate/list/interest, account, statement, OTP, transaction, cashback. | [E18] |
| CAKE Connector | Onboarding and TD management. | [E18] |

### 6.3 API Surface

| Group | Key APIs | Audit use |
|---|---|---|
| KYC/permission | `/users/kyc/status`, `/users/kyc/info`, `/users/permission`, `/users/onboarding/permission` | Eligibility and entry routing |
| Onboarding | `/resources`, `/onboarding/contract`, `/onboarding/status`, `/onboarding/application`, `/request-otp`, `/verify-otp`, `/wet-sign`, `/link-account`, `/trigger-resubmit`, `/complete-face-challenge` | Activation, KYC, support recovery |
| FD order | `/fixed-deposit/simulate/open`, `/order/reserve`, `/order/soft-otp`, `/orders`, `/order/open`, `/order/break`, `/simulate/break` | Money movement, state clarity |
| Asset/order detail | `/assets/summary`, `/assets`, `/assets/detail`, `/orders/detail` | Data freshness, asset accuracy |
| Config/support | `/config/application`, `/config/partners`, `/binding-banks`, `/payment-methods`, `/bank-account/validate`, `/consents`, `/promotions`, `/configurations` | Dynamic config, bank/MMF destinations, promotion |

Full route evidence: [E20]

### 6.4 Design Patterns & Reliability Controls

Core knowledge explicitly lists connector abstraction, partner manager via A/B flags, Redis-backed maintenance, Redis idempotency locks, DR site consumer, and event-driven lifecycle via Kafka/PE/FMC/MMF events. [E19]

Audit implication:

| Pattern | Reliability question |
|---|---|
| Connector abstraction | Does partner-specific behavior leak into generic UI/copy incorrectly? |
| Partner Manager | Are partner feature flags synced with UI capability and maintenance state? |
| Maintenance mode | Does UI show clear degraded/blocked state by feature: onboarding/open/break? |
| Redis idempotency | Are duplicate open/break orders prevented and copy clear on retry? |
| Event-driven lifecycle | Are pending/refund states observable and communicated across app, CS tool, history? |

---

## 7. Data Model

### 7.1 ERD

```mermaid
%%{init: {"theme": "neutral", "themeVariables": {"fontFamily": "Inter, Arial, sans-serif"}}}%%
erDiagram
    ACCOUNT {
        bigint id PK
        bigint zalopay_id
        bigint partner_id
        string partner_account_number
        string partner_account_name
        enum status
        string status_detail
        string origin
        json extra
    }
    BINDING_LOG {
        bigint request_id PK
        bigint zalopay_id
        bigint partner_id
        string id_number
        json ic_images
        string current_step
        string reject_code
        json extra
    }
    FIXED_DEPOSIT {
        bigint id PK
        bigint zp_user_id
        int partner_id
        string fixed_deposit_id
        enum status
        enum origin
        bigint original_balance
        bigint current_balance
        bigint received_total_amount
        int tenor
        float interest_rate
        enum maturity_instruction
    }
    ORDER {
        bigint id PK
        bigint app_trans_id
        bigint zp_user_id
        string fixed_deposit_id
        enum trans_type
        int partner_id
        bigint amount
        string payment_destination
        enum status
        int bank_error_code
        int internal_error_code
    }
    PROMOTION_SCHEMES {
        bigint id PK
        string promotion_code
        enum type
        enum flow
        enum frequency
        enum status
        datetime start_time
        datetime end_time
        json extra
    }
    PROMOTION_APPLICATIONS {
        bigint id PK
        bigint zalopay_id
        bigint promotion_scheme_id
        enum status
        bigint partner_id
        datetime applied_time
        timestamp valid_until
        json extra
    }

    ACCOUNT ||--o{ FIXED_DEPOSIT : "zalopay_id + partner_id"
    ACCOUNT ||--o{ BINDING_LOG : "zalopay_id + partner_id"
    FIXED_DEPOSIT ||--o{ ORDER : "fixed_deposit_id"
    PROMOTION_SCHEMES ||--o{ PROMOTION_APPLICATIONS : "promotion_scheme_id"
    PROMOTION_APPLICATIONS ||--o{ ORDER : "promotion_application_ids"
```

### 7.2 Core Tables

| Table | Meaning | Critical fields | Evidence |
|---|---|---|---|
| `account` | Partner account/CASA state per user/partner/account number. | `zalopay_id`, `partner_id`, `partner_account_number`, `status`, `status_detail`, `origin`, `extra`. | [E28] |
| `binding_log` | Onboarding application/profile log. | `request_id`, `zalopay_id`, `partner_id`, `id_number`, `ic_images`, `current_step`, `reject_code`. | [E29] |
| `fixed_deposit` | FD package record. | `fixed_deposit_id`, `status`, `origin`, balances, tenor, interest, maturity instruction, dates. | [E30] |
| `order` | Open/break order and payment lifecycle. | `trans_type`, `payment_destination`, `status`, `bank_error_code`, `internal_error_code`, `fd_request`. | [E31] |
| `promotion_schemes` | Campaign master data. | `promotion_code`, `type`, `flow`, `frequency`, `status`, time window, `extra`. | [E34] |
| `promotion_applications` | User-level promotion assignment/application. | `zalopay_id`, `promotion_scheme_id`, `status`, `partner_id`, `applied_time`, `valid_until`. | [E35] |

### 7.3 Key Metrics for Audit

| Metric | Why audit needs it | Suggested source |
|---|---|---|
| New accounts by origin/partner | Activation quality, entrypoint effectiveness | `fixed_deposit_account` / `account` |
| Open FD success rate | Task completion, payment reliability | `fixed_deposit_order` / `order` by `trans_type=OPEN` |
| Break FD success/partial/refund rate | Money safety, operational reliability | `order` by `trans_type=BREAK`, `payment_destination`, `status` |
| Pending duration p50/p95 | State clarity and support burden | order timestamps and CS tickets |
| Reconciliation manual sync count | Reliability and ops burden | CS tickets + Management sync logs |
| Promotion application rate | Trust in bonus display and eligibility | `promotion_schemes`, `promotion_applications` |
| Partner-specific rejection reasons | UX copy and eligibility clarity | `binding_log.reject_code`, CS tickets |

---

## 8. Promotion & Bonus Rate

### 8.1 Product Logic

The Multiple Interest Rate doc defines the goal: attract new users and retain high-value customers with bonus interest rates via promotion codes, controlled by campaign rules. [E32]

Promotion mechanisms:

1. Promotion team updates FD system with user, promo code, type (`interest_rate` or `cashback`), bonus value, effective window. [E33]
2. On FD screen load, backend checks active promotion; if matched, UI applies label such as `+0.8%` or cashback note. [E33]
3. Cake can receive final interest rate = base + bonus; CIMB uses base rate and cashback handled later by Promotion team in the spec. [E33]
4. Each user can have only one active promotion code at a time; multiple codes should block creation and raise alert. [E33]

### 8.2 Audit Risks

| Risk | Audit question |
|---|---|
| Bonus rate shown but not persisted | Does `fixed_deposit.extra.bonus_rate` and order/promotion application align with UI? |
| Partner mismatch | Does Cake/CIMB behavior differ clearly in UI and confirmation? |
| Expired promotion | Is fallback to base rate communicated or silently changed? |
| Cashback vs interest rate | Does copy explain when/where money is credited: MMF, wallet, or partner? |
| Multiple active codes | Is blocked state user-friendly and supportable? |

---

## 9. Operational Reliability

### 9.1 Eventing & Reconciliation

Management service consumes PE/FMC/MMF Kafka, FD sync Kafka, refund Kafka, order break/recon events, plus RabbitMQ order status and FD sync. [E17] Order states are persisted in `order.status` and backend open flow docs explain transition triggers. [E31] [E39]

Reliability-sensitive scenarios:

| Scenario | What can go wrong | Audit evidence to collect |
|---|---|---|
| Open FD payment success, FD sync delayed | Wallet charged but FD package not visible. | `order.status=BANKTRANS_SUCCEEDED`, `fixed_deposit` missing/delayed, CS complaints. |
| Banktrans failed | User may be blocked from retry until final status/recon. | CS ticket examples [E47] [E48] |
| Break to bank partial success | FD break success, IBFT failed, refund to wallet needed. | User guide state table [E38], `payment_destination=BINDING_BANK`. |
| Break to MMF partial success | FD break success, MMF deposit failed, money stays in wallet. | User guide state table [E36], MMF order status. |
| Partner maintenance | Onboarding/open/break blocked by feature/partner. | Maintenance state type [E27], core maintenance pattern [E19]. |
| OTP/SIM issue | User cannot complete partner OTP or recover package info. | CS lost SIM ticket [E51]. |

### 9.2 CS Ticket Taxonomy

Representative patterns from 788 FD tickets:

| Pattern | Description | Representative evidence |
|---|---|---|
| Generic onboarding error | User sees "Có lỗi xảy ra" while root cause is ID already used or partner policy; CS explicitly asked to improve message. | [E45] [E46] |
| Partner reject / ineligible | CIMB `ANOTHER_ERROR` or missing/invalid ID data; needs clearer CS/partner routing. | [E46] |
| Pending/banktrans failed blocks retry | Failed break order without final state can lock book until reconciliation next day. | [E47] |
| Refund / final status sync | User reports failed break but not refunded; team updates final status and notes T+2/OP handoff issue. | [E48] |
| Source-of-fund limit confusion | 50M top-up issue was wallet top-up limit, not FD deposit limit from wallet to FD. | [E49] |
| Cake onboarding waiting/blank perception | User thought supplement info screen did not open; log showed onboarding submitted and waiting approval. | [E50] |
| Lost SIM / package code support | User lost SIM while still holding Cake FD and needs package code for bank-assisted withdrawal. | [E51] |

### 9.3 Support Playbook Seeds

| User complaint | First checks | Likely owner |
|---|---|---|
| "Đã trừ tiền nhưng chưa có sổ" | `order` by app/zp trans, status, PE/FMC event, FD sync status, partner connector logs. | FD BE + OP if reconciliation |
| "Rút thất bại/chưa hoàn" | `order.status`, `payment_destination`, banktrans status, refund status, CS SLA. | FD BE + OP |
| "Không đăng ký được" | `binding_log.current_step`, `reject_code`, KYC/NFC/VNeID fields, partner account status. | FD BE + UM/partner |
| "Không nhận OTP" | Partner, phone used for CASA, OTP request/verify logs, lost SIM flow. | Partner/CS/FD |
| "Không thấy nút rút" | Package status, pending order, partner maintenance, FE state route. | FD FE/BE |
| "Lãi/bonus sai" | interest_rate endpoint, promotion application, FD extra, confirmation screen snapshot. | FD BE/FE + Promotion |

---

## 10. Audit-Readiness Map

### 10.1 Product Audit v6 Axes

| Axis | FD knowledge to inspect | Evidence types |
|---|---|---|
| UX & Journey Design | Entry routing, onboarding resubmit, KYC/NFC/VNeID, open FD review, break FD comparison, destination selection, history detail. | Confluence flows, `fd-app` screens/API, CS "generic copy" tickets. |
| Financial Safety | Eligibility, partner boundary, amount limits, interest/maturity, payment destination, bonus/cashback, refund, TT40/IBFT 20M. | Limit docs, source constants, order table, Jira limit tasks, partner docs. |
| Operational Reliability | Pending/final state, banktrans failed, reconciliation, maintenance, idempotency, partner downtime, MMF partial success. | Management service eventing, order state machine, CS recon tickets. |
| Trust-Building Over Time | History consistency, support contact, lost SIM/OTP recovery, rollover explanation, package code/partner traceability, bonus traceability. | FAQ, CS tickets, transaction detail docs, source data model. |

### 10.2 Audit Checklist Seeds

| Audit item seed | Why important | Suggested evidence path |
|---|---|---|
| User understands ZaloPay vs bank role before depositing | Legal/trust boundary. | Product Info + screens + contract/T&C |
| User sees final rate/bonus before confirming open FD | Money transparency. | Interest API + confirmation screen + promotion data |
| Limits are consistent across FAQ, UI, source, CS scripts | Prevent false expectation. | Limit doc + FE constants + FAQ stale check |
| Break FD comparison explains financial impact | Premature withdrawal cost. | Break FD flow + simulate API |
| Destination selection explains partial-success outcomes | Bank/MMF multi-leg transactions. | Break to bank/MMF guides + order status |
| Pending state has clear ETA and next action | Reduce CS volume. | CS pending tickets + UI states |
| Reject copy is specific and actionable | Avoid "Có lỗi xảy ra" confusion. | CS tickets [E45] [E46], CasaErrorCode mapping |
| Lost SIM / OTP recovery is documented | User can recover money access. | Operation guideline + CS ticket [E51] |
| Promotion/cashback is traceable | Trust over time. | Promotion DB + order + transaction history |
| Maintenance by partner/feature is clear | Graceful degradation. | Maintenance config + UI state |

### 10.3 Known Staleness / Contradictions

| Topic | Older source | Newer/current source | Audit action |
|---|---|---|---|
| CIMB min open | FAQ/product info: 500.000đ. [E8] [E1] | Limit doc + FE constants: 100.000đ. [E11] [E23] | Verify runtime `/config/application` before scoring. |
| CIMB max total | FAQ/product info: 50M. [E8] [E1] | Limit doc + FE constants: 100M. [E11] [E23] | Treat FAQ as stale unless product confirms. |
| Break remaining balance | Old break flow: 500.000đ remaining. [E43] | Limit doc + constants: 100.000đ remaining. [E12] [E23] | Use source/config; update old docs if audit gap. |
| Break min CIMB | Old flow/FAQ: 1.000đ or older values. [E8] | Limit doc + constants: 2.000đ. [E12] [E23] | Confirm partner-specific current config. |
| UI Flow folder | User request mentions UI Flow. | No FD-specific UI Flow folder found; evidence is Confluence + `fd-app`. | Add missing design/flow artifacts if available later. |

### 10.4 Open Questions for Future Audit

1. Which partner/rule config is live today per `/config/application` for CIMB and CAKE?
2. Is Cake fully enabled for all destinations or still phased by whitelist/segment?
3. Does transaction history show refund/MMF/bank partial-success states consistently across Home, Asset, ZaloPay History, and CS Tool?
4. Are partner maintenance states surfaced at entrypoint before user starts a flow?
5. Are lost SIM and package-code recovery flows documented in Operation Page and visible to CS?
6. Does promotion application persist and display correctly after rollover/break?
7. Are "bank account saved by device" vs "bank account saved by ZaloPay account" semantics still current?
8. Which Figma/UI Flow assets are official for the revamp FD home and withdrawal flow?

---

## 11. Roadmap & Decision Log

| Theme | Evidence | Product meaning |
|---|---|---|
| Break FD to bank | Jira DONE: IBFT limit 20M/trans and tests passed. [E52] | New destination increases SOF complexity and history/refund states. |
| Break FD to MMF/SDSL | Jira DONE: add payment destination MMF, integrate MMF confirm deposit, trigger deposit when break order succeeds. [E53] | Creates two-leg transaction and partial success risk. |
| Bonus rate / promotion | Promotion spec + DB schema. [E32] [E33] [E34] [E35] | FD has personalization/benefit logic that must be audited for trust. |
| NFC/VNeID | FE constants map CIMB to VNEID source and CAKE to NFC source. [E25] | Partner-specific identity recovery affects onboarding/drop-off. |
| Home revamp | Jira `PCFFS-17520` is LIVE in file list; needs UI evidence for audit. | Likely changes discoverability and trust signal on Home. |

---

## 12. Source Manifest

| ID | Source |
|---|---|
| E1 | [FD Product Info - product role/limits](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/161198999_[FD] Thông tin sản phẩm.md#L12>) |
| E2 | [FD FAQ - definition](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/165241783_[FD] FAQ.md#L11>) |
| E3 | [FD FAQ - eligibility](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/165241783_[FD] FAQ.md#L12>) |
| E4 | [FD FAQ - registration steps](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/165241783_[FD] FAQ.md#L14>) |
| E5 | [FD FAQ - start date/T+1](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/165241783_[FD] FAQ.md#L22>) |
| E6 | [FD FAQ - interest display and payout](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/165241783_[FD] FAQ.md#L23>) |
| E7 | [FD FAQ - tenors](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/165241783_[FD] FAQ.md#L28>) |
| E8 | [FD FAQ - open/break/insurance older rules](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/165241783_[FD] FAQ.md#L32>) |
| E9 | [FD FAQ - rollover/insurance](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/165241783_[FD] FAQ.md#L35>) |
| E10 | [FD FAQ - monthly limit/pending/OTP](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/165241783_[FD] FAQ.md#L41>) |
| E11 | [Limit Open/Break - CIMB updates](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/236985591_[FD] Hạn mức Open_Break.md#L13>) |
| E12 | [Limit Open/Break - CIMB current rules](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/236985591_[FD] Hạn mức Open_Break.md#L30>) |
| E13 | [Limit Open/Break - premature interest formula](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/236985591_[FD] Hạn mức Open_Break.md#L69>) |
| E14 | [Limit Open/Break - CAKE rules](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/236985591_[FD] Hạn mức Open_Break.md#L115>) |
| E15 | [FD Core Knowledge - overview](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Technical Page/310007104_FD System — Core knowledge.md#L7>) |
| E16 | [FD Core Knowledge - API Gateway/Account Service](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Technical Page/310007104_FD System — Core knowledge.md#L23>) |
| E17 | [FD Core Knowledge - Management consumers](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Technical Page/310007104_FD System — Core knowledge.md#L47>) |
| E18 | [FD Core Knowledge - partner connectors](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Technical Page/310007104_FD System — Core knowledge.md#L66>) |
| E19 | [FD Core Knowledge - storage/design patterns](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Technical Page/310007104_FD System — Core knowledge.md#L92>) |
| E20 | [API Gateway routes](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/backend/services/apigateway/controller/controller.go#L83>) |
| E21 | [FE constants - screens/tabs/limits](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/fd-app/packages/shared/src/constants/index.ts#L44>) |
| E22 | [FE constants - onboarding/error codes](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/fd-app/packages/shared/src/constants/index.ts#L89>) |
| E23 | [FE constants - partner IDs and amount limits](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/fd-app/packages/shared/src/constants/index.ts#L252>) |
| E24 | [FE constants - interest/tel/support](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/fd-app/packages/shared/src/constants/index.ts#L263>) |
| E25 | [FE constants - auth/payment destinations](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/fd-app/packages/shared/src/constants/index.ts#L333>) |
| E26 | [FE types - assets/order status](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/fd-app/packages/shared/src/types/index.ts#L98>) |
| E27 | [FE types - deep link/NFC/maintenance/promotion](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/fd-app/packages/shared/src/types/index.ts#L309>) |
| E28 | [DB account table](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/backend/pkg/resources/sql/account.sql#L1>) |
| E29 | [DB binding_log table](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/backend/pkg/resources/sql/binding_log.sql#L1>) |
| E30 | [DB fixed_deposit table](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/backend/pkg/resources/sql/fixed_deposit.sql#L1>) |
| E31 | [DB order table](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/backend/pkg/resources/sql/order.sql#L1>) |
| E32 | [Multiple interest rate - problem/high level](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/254663308_[FD] Multiple interest rate.md#L21>) |
| E33 | [Multiple interest rate - flow/edge cases](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/254663308_[FD] Multiple interest rate.md#L57>) |
| E34 | [DB promotion_schemes](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/backend/pkg/resources/sql/promotion_schemes.sql#L1>) |
| E35 | [DB promotion_applications](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/backend/pkg/resources/sql/promotion_applications.sql#L1>) |
| E36 | [User Guide - Break FD to MMF](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/284987959_[FD] - User Guide - Break FD to MMF.md#L26>) |
| E37 | [User Guide - Break FD to bank context/limit](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/284997084_[FD] - User Guide - Break FD to bank.md#L34>) |
| E38 | [User Guide - Break FD to bank states](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/284997084_[FD] - User Guide - Break FD to bank.md#L116>) |
| E39 | [Backend open FD order state machine](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/Source Code/FD/backend/docs/flows/open_fd_flow.md#L97>) |
| E40 | [CIMB CASA Registration - access/precheck](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/153772487_[FD][CIMB][Main-Flow] CASA Registration.md#L63>) |
| E41 | [CIMB CASA Registration - submit BOD2](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/153772487_[FD][CIMB][Main-Flow] CASA Registration.md#L218>) |
| E42 | [CIMB CASA Registration - sign/OTP/final status](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/153772487_[FD][CIMB][Main-Flow] CASA Registration.md#L241>) |
| E43 | [CIMB Break FD - older amount validation](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/158049274_[FD][CIMB][Main-Flow] Break FD.md#L7>) |
| E44 | [CIMB Break FD - comparison screen](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Confluence/FD/Product Page/158049274_[FD][CIMB][Main-Flow] Break FD.md#L73>) |
| E45 | [CS ISSUE-25831 - ID already used / unclear message](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/CS Ticket/FD/ISSUE-25831_[Tài khoản] - [Tài khoản tiết kiệm] Đăng ký dịch v.md#L19>) |
| E46 | [CS ISSUE-26036 - ANOTHER_ERROR / copy improvement](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/CS Ticket/FD/ISSUE-26036_[Tài khoản] - [Tài khoản tiết kiệm] Đăng ký dịch v.md#L19>) |
| E47 | [CS ISSUE-22078 - banktrans failed locks book](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/CS Ticket/FD/ISSUE-22078_[TKTK] - Lỗi không Rút tiền Gửi tiết kiệm trước hạ.md#L19>) |
| E48 | [CS ISSUE-25656 - break refund/status sync](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/CS Ticket/FD/ISSUE-25656_[TKTK] Hỗ trợ kiểm tra giao dịch - 5232719.md#L19>) |
| E49 | [CS ISSUE-22029 - wallet top-up limit confusion](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/CS Ticket/FD/ISSUE-22029_[TT] - [TKTK_Nạp tiền] - Kiểm tra nguyên nhân nạp .md#L19>) |
| E50 | [CS ISSUE-40487 - Cake waiting approval perception](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/CS Ticket/FD/ISSUE-40487_[Ứng dụng] - [Tài khoản tiết kiệm] UD-Bị treo_ loa.md#L21>) |
| E51 | [CS ISSUE-40535 - lost SIM / package code support](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/03. Fact/CS Ticket/FD/ISSUE-40535_[Ứng dụng] - [Tài khoản tiết kiệm] Tư vấn quy trìn.md#L20>) |
| E52 | [Jira PCFFS-14695 - bank withdrawal 20M](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Jira/FD/PCFFS-14695_[fd][be] Limit 20tr_ trans for withdraw to bank.md#L17>) |
| E53 | [Jira PCFFS-15030 - trigger deposit to SDSL/MMF](<file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My Drive/GOOGLE DRIVE/01. My Work/02. ZALOPAY/02. ZaloPay PO/02. Product/ZLP Workspace/Wealth Solution/02. Context/Jira/FD/PCFFS-15030_[fd][be] Handle trigger deposit to SDSL.md#L17>) |

---

## Changelog

| Version | Change |
|---|---|
| GPT5.5 draft | First consolidated FD knowledge base for audit preparation. Built from Confluence, Source Code, Jira, CS Tickets, FD schema/query skills, and MMF knowledge-base structure. |
