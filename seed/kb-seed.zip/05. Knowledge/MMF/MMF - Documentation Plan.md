# MMF (Money Market Fund) — Documentation Plan

---

> [!IMPORTANT]
> **YÊU CẦU TỐI THƯỢNG (MỆNH LỆNH BẮT BUỘC):**
> Bộ tài liệu được tạo ra phải đảm bảo độ chính xác tuyệt đối, mô tả cực kỳ chi tiết, đầy đủ và toàn diện mọi khía cạnh nghiệp vụ và kỹ thuật của sản phẩm MMF (Số dư sinh lời). Tuyệt đối nghiêm cấm việc tóm tắt sơ sài, bỏ sót các trường hợp biên (edge cases), các trạng thái lỗi (error handling), cơ chế bù trừ (compensation/retry), hoặc bỏ qua các chi tiết kỹ thuật cốt lõi (database fields, event topics, APIs).
> 
> Mọi thông tin nghiệp vụ/kỹ thuật phải đi kèm trích dẫn nguồn bằng hyperlink trực tiếp đến tài liệu gốc như Confluence, Jira (sử dụng link web dạng `https://confluence.zalopay.vn/...` hoặc `https://jira.zalopay.vn/...` được trích xuất từ header của các tệp nguồn trong workspace). Không sử dụng các đường dẫn tệp tuyệt đối dài dòng trên máy tính cục bộ. Đối với các tệp mã nguồn, sử dụng đường dẫn tương đối từ gốc workspace (ví dụ: `[Backend/user-binding/main.go](03. Fact/Source Code/MMF/Backend/user-binding/main.go)`).

Kế hoạch này kết hợp quy chuẩn của workflow [/product-doc-pack](.agents/workflows/product-doc-pack.md) và các phát hiện nghiệp vụ, kỹ thuật sâu sắc nhất từ specs và mã nguồn thực tế để xây dựng **5 tài liệu chuyên biệt hoàn chỉnh** lưu trữ trong thư mục [MMF](Wealth Solution/05. Knowledge/MMF/).

---

## 📅 Cấu trúc Bộ 5 Tài liệu Chuyên biệt & Checklists Chi tiết

### 📄 Tài liệu 1: [MMF - High-Level Overview.md](Wealth Solution/05. Knowledge/MMF/MMF - High-Level Overview.md)
Tập trung vào bức tranh tổng quan của sản phẩm Số dư sinh lời, định vị chiến lược, phân tích thị trường và cấu trúc kiến trúc C1/C2.
*   **⚡ Fact Sheet (TL;DR):**
    *   Hạn mức số dư tối đa: 100M VND (user >=18 tuổi), 2M VND (user 16-17 tuổi - `[ĐANG THỰC HIỆN]`), chặn dưới 16 tuổi. Hạn mức SME là 1.000M VND (1 tỷ VND).
    *   Quy tắc nạp tiền: Tối thiểu 10.000 VND. Chỉ hỗ trợ nạp tiền qua VietQR. Ngừng hoàn toàn nạp từ nguồn ví/thẻ liên kết.
    *   Hạn mức rút tiền: Tối đa 30M VND/ngày đối với rút về ví hoặc chuyển khoản P2P. Thanh toán và IBFT không bị giới hạn.
    *   Khung giờ vàng: Chặn nạp tính lãi (23:59 - 01:10), đồng bộ tiền lãi (02:10 - 03:40).
    *   Phí giao dịch: Hoàn toàn miễn phí rút (khái niệm Dual Account đã được loại bỏ hoàn toàn).
*   **1. Tổng quan thị trường & Mục tiêu chiến lược:** Phân tích nhu cầu tích lũy tiền nhàn rỗi và mục tiêu KPIs chiến lược.
*   **2. Phân khúc khách hàng & SWOT:** Phân khúc người dùng cá nhân (Normal, Trẻ tuổi 16-17) và doanh nghiệp (SME).
*   **3. Đối thủ cạnh tranh:** Battlecard so sánh trực tiếp với Túi Thần Tài MoMo và Tikop/Infina.
*   **4. Thách thức & Rủi ro:** Rủi ro pháp lý (Compliance), rủi ro vận hành từ đối tác Infina và rủi ro hệ thống.
*   **5. Kiến trúc kỹ thuật tổng quan (System Architecture):**
    *   📊 **Mermaid System C1/C2 Architecture Diagram:** Biểu diễn các service trong monorepo backend và cách kết nối với các Core nội bộ (Acquiring Core, Disbursement Core, User Profile) và API đối tác Infina.
*   **6. Lộ trình phát triển & Trạng thái tính năng:** Milestones cập nhật đến Q2/2026.

---

### 📄 Tài liệu 2: [MMF - Product Business Specification.md](Wealth Solution/05. Knowledge/MMF/MMF - Product Business Specification.md)
Đặc tả cực kỳ chi tiết nghiệp vụ của từng luồng người dùng, các bước thực hiện, điều kiện kích hoạt, logic nghiệp vụ và các edge cases màn hình.
*   **1. Đăng ký & Onboarding V2:**
    *   Điều kiện: KYC Level 2, kiểm soát độ tuổi chặt chẽ (chặn dưới 16 tuổi). Chặn định danh bằng Hộ chiếu (Passport) hoặc Chứng minh thư Quân đội (Soldier ID).
    *   Quy trình Account Binding V2: Nhập thông tin bổ sung, ký hợp đồng điện tử và kết nối API với Infina. Luồng Re-bind (tái liên kết).
*   **2. Luồng Nạp tiền (Deposit Flow):**
    *   **Nạp chủ động VietQR:** Quét mã VietQR động, giới hạn giao dịch tối thiểu 10.000 VND. Xử lý các edge cases chuyển khoản sai nội dung, chuyển khoản trong khung giờ vàng bảo trì.
    *   **Tự động nạp khi nhận tiền (Priority MMF Toggle):** Tự động sweep số tiền P2P hoặc quét QR nhận tiền cá nhân thẳng vào MMF. Xử lý khi chạm hạn mức tối đa.
    *   **SME Auto Settle:** Tự động trích nạp từ ví SME sang tài khoản SDSL sau khi quyết toán doanh thu. Hạn mức AUM 1 tỷ VND.
*   **3. Luồng Rút tiền (Redemption Flow):**
    *   **Rút về ví Zalopay:** Hạn mức 30M/ngày, hoàn toàn miễn phí. Quy trình gọi treo tiền Infina, Disbursement chi hộ và cơ chế SAGA compensating rollback khi thất bại.
    *   **Rút trực tiếp về tài khoản ngân hàng (Contingency - Rút khẩn cấp):** Cho phép người dùng thêm bank (trùng khớp họ tên eKYC) và rút tiền trực tiếp từ tài khoản lưu ký Infina/BIDV khi hệ thống Zalopay gặp sự cố ví.
*   **4. Luồng Thanh toán & Chuyển khoản (Payment & Transfer SOF):**
    *   **Thanh toán sử dụng nguồn tiền MMF (PMC 44):** Tích hợp làm nguồn tiền thanh toán (1-step passthrough trực tiếp, 2-step fallback cho hóa đơn đa kỳ).
*   **5. Hoàn tiền & Cashback:** Hoàn tiền giao dịch lỗi về MMF (Asset Exchange) và cashback tự động tích lũy.
*   **6. Đóng tài khoản & Chấm dứt dịch vụ:** Đóng chủ động (điều kiện số dư = 0) và đóng tự động do tuân thủ pháp lý đối với user dưới 16 tuổi.
*   **7. Màn hình tài khoản & Tính lãi:** Logic hiển thị thông tin số dư, tiền lời tích lũy, lãi suất và hiển thị ước tính ngày nhận tiền lời (T+1).
*   👉 Tham chiếu tài liệu bản đồ tracking hành vi người dùng: [MMF - Event Tracking & Data Mapping.md](Wealth Solution/05. Knowledge/MMF/MMF - Event Tracking & Data Mapping.md).
*   📊 **Sơ đồ luồng nghiệp vụ (Business Flowcharts):** Vẽ các sơ đồ Mermaid biểu diễn trải nghiệm người dùng đối với luồng Đăng ký, Nạp VietQR, Rút tiền và Thanh toán PMC 44.

---

### 📄 Tài liệu 3: [MMF - System & Technical Specification.md](Wealth Solution/05. Knowledge/MMF/MMF - System & Technical Specification.md)
Đặc tả chi tiết kiến trúc hệ thống, monorepo backend, APIs integration spec và database schema của sản phẩm.
*   **1. Cấu trúc monorepo backend `zlp-mmf/mmf/backend`:**
    *   Đặc tả vai trò của các services chính: `user-binding`, `deposit`, `redemption`, `payment`, `order-worker`, `scheduler`, `authorizer` và các service phụ trợ (`balance-orchestrator`, `recurring-deposit-manager`, `campaign-gateway`).
*   **2. Hệ thống Event-driven (Messaging System):**
    *   Đặc tả Kafka topic: `fin.mmf.commands` (6 partitions, hash by `AppTransID` để bảo toàn thứ tự tuyến tính và ngăn race condition).
*   **3. APIs Integration Specification:**
    *   Đặc tả chi tiết REST/gRPC APIs thực tế giữa Zalopay và đối tác Infina (API liên kết, API tạo order, API đối chiếu số dư, Webhook callback).
*   👉 Tham chiếu tài liệu cấu trúc MySQL database và sơ đồ ERD chi tiết: [MMF - Event Tracking & Data Mapping.md](Wealth Solution/05. Knowledge/MMF/MMF - Event Tracking & Data Mapping.md).
*   📊 **Sơ đồ tương tác API (Sequence Diagrams):** Biểu diễn tương tác API giữa Frontend, Gateway, MMF Core Services, các Core nội bộ và Infina API đối với luồng nạp VietQR, rút tiền về ví, và rút khẩn cấp về bank.

---

### 📄 Tài liệu 4: [MMF - Operations, Payment & Reconciliation Guide.md](Wealth Solution/05. Knowledge/MMF/MMF - Operations, Payment & Reconciliation Guide.md)
Hướng dẫn vận hành hàng ngày, đối soát tài chính với đối tác, cấu hình feature flag và xử lý lỗi hệ thống/dự phòng.
*   **1. Chế độ dự phòng Snapshot Balance HA Mode:**
    *   Trạng thái: `[ĐÃ LÊN PROD - CHƯA LIVE]`.
    *   Chi tiết 4 trạng thái hệ thống: ONLINE, OFFLINE (offline ledger, Merchant Wallet fund-out), REPLAY (batch-by-user, pagination of max 100 transactions, idempotency), và SYNCFAILED (account locking).
    *   📊 **Sơ đồ chuyển đổi trạng thái (State Diagram):** Vẽ sơ đồ Mermaid trực quan hóa 4 trạng thái của Snapshot HA Mode và điều kiện kích hoạt.
*   **2. Quy trình Đối soát (Reconciliation) hàng ngày:**
    *   Quy trình đối soát lúc **08:00 AM** qua SFTP.
    *   Logic xử lý chênh lệch số dư: ZLP < Infina (auto-override) vs ZLP > Infina (critical alert, lock account).
    *   Hạch toán tài chính (Accounting Mapping) đối với các loại giao dịch (key ZAS ID và accounting code).
    *   📊 **Sơ đồ luồng đối soát (Reconciliation Flowchart):** Mermaid diagram thể hiện quy trình đối soát balance file hàng ngày.
*   **3. Cấu hình hệ thống & Feature Flags:**
    *   Cấu hình Dynamic Maintenance Rules (chặn nạp tính lãi từ 23:59 - 01:10).
    *   Quản lý danh sách Feature Flags qua endpoint `GET /api/v1/user/config`.
*   **4. Runbooks & Alert Handling:**
    *   Xử lý giao dịch nạp/rút bị pending.
    *   Xử lý sự cố sai lệch số dư sau khi Replay.

---

### 📄 Tài liệu 5: [MMF - Event Tracking & Data Mapping.md](Wealth Solution/05. Knowledge/MMF/MMF - Event Tracking & Data Mapping.md)
Tài liệu chuyên biệt tập trung vào cấu trúc dữ liệu, phục vụ mục đích phân tích hành vi người dùng (Onboarding, Nạp, Rút, Cài đặt, Lịch sử) và Data Warehouse / SQL Query Generation.
*   **1. Bản đồ Event Tracking Hệ thống:** Toàn bộ catalog sự kiện kèm Event ID (tiền tố `01.` và `02.`), Event Name, kiểu tham số (Parameters) và điều kiện kích hoạt.
*   **2. Cấu trúc Database MySQL `mmf` DB:** Chi tiết data dictionary của các bảng `users`, `instant_balance`, `orders`, `balance_histories`, `offers`, `recurring_deposit_plans`, `recurring_deposit_history`.
*   **3. Sơ đồ thực thể quan hệ (ERD Diagram):** Mermaid ERD thể hiện mối liên kết giữa các bảng qua `zalopay_id`, `order_id`, `offer_id` và `recurring_plan_id`.
*   **4. Hướng dẫn sinh câu lệnh SQL Analytics mẫu:** Các query mẫu phục vụ phân tích phễu, tính tổng AUM và báo cáo dòng tiền nạp/rút hàng ngày.
