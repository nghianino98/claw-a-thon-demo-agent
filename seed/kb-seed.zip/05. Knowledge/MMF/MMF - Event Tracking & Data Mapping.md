# MMF (Money Market Fund) — Event Tracking & Data Mapping

---

> [!IMPORTANT]
> **TÀI LIỆU CỐT LÕI VỀ DỮ LIỆU SỐ DƯ SINH LỜI (MMF)**
> Tài liệu này được biên soạn độc lập nhằm phục vụ việc phân tích sản phẩm, tracking hành vi người dùng và hỗ trợ đội ngũ Data Analyst / Product Owner truy vấn dữ liệu nhanh chóng từ Data Warehouse hoặc cơ sở dữ liệu MySQL `mmf` thực tế.
> * Các mã tracking event được đối chiếu trực tiếp với mã nguồn frontend [emitTrackingEvent.ts](03. Fact/Source Code/MMF/Frontend/mmf-apps/packages/mmf-shared/src/shared/emitTrackingEvent.ts).
> * Cấu trúc bảng và ERD được mô tả chi tiết từng trường để phục vụ việc sinh câu lệnh SQL (Query Generation).

---

## 1. Bản đồ Event Tracking Hệ thống (Event Tracking Map)

Theo quy tắc nghiệp vụ của nền tảng Zalopay:
* **Hệ điều hành Android/iOS (Mobile Client):** Các sự kiện được gửi đi bắt buộc tự động thêm tiền tố **`01.`** trước mã Event ID (Ví dụ: `01.6800.000`).
* **Hệ điều hành Web/Zalo Mini App (Web Client):** Các sự kiện được gửi đi bắt buộc tự động thêm tiền tố **`02.`** trước mã Event ID (Ví dụ: `02.6800.000`).

### 1.1 Khóm Sự kiện 1: Giới thiệu & Onboarding Intro (`6801.xxx` - `6804.xxx`)

| Event ID | Event Name | Loại | Tham số (Parameters) | Mô tả chi tiết & Điều kiện kích hoạt (Trigger Rules) |
| :--- | :--- | :---: | :--- | :--- |
| `6801.000` | `onboarding load` | View | `utm_source` (string)<br>`kyc_level` (number) | Kích hoạt khi người dùng chưa liên kết (unbind) truy cập vào màn hình giới thiệu (Introduction/Onboarding Screen). |
| `6801.001` | `onboarding scroll` | Action | Không | Kích hoạt khi người dùng thực hiện thao tác cuộn trang (scroll) trên màn hình Onboarding. |
| `6801.002` | `onboarding tap tutorial collapse` | Click | Không | Kích hoạt khi người dùng click vào accordion hướng dẫn để ẩn/hiện thông tin hướng dẫn. |
| `6801.003` | `onboarding tap continue CTA` | Click | Không | Kích hoạt khi người dùng click vào nút "Tiếp tục" (CTA) để bắt đầu điền thông tin đăng ký. |
| `6801.004` | `onboarding tap close icon` | Click | Không | Kích hoạt khi người dùng click nút "X" ở góc trên để thoát khỏi màn hình onboarding. |
| `6802.000` | `tutorial 1 load` | View | Không | Màn hình hướng dẫn đăng ký (Tutorial Page 1) được hiển thị cho người dùng. |
| `6802.001` | `tutorial 1 tap next` | Click | Không | Người dùng nhấn nút tiếp tục trên Tutorial Page 1. |
| `6802.006` | `tutorial 1 view` | View | Không | Lớp tracking dự phòng khi view màn hình Tutorial Page 1. |
| `6802.007` | `tutorial 1 ignore` | Click | Không | Người dùng nhấn nút bỏ qua trên Tutorial Page 1. |
| `6803.000` | `tutorial 2 load` | View | Không | Màn hình hướng dẫn nạp tiền (Tutorial Page 2) hiển thị. |
| `6803.001` | `tutorial 2 tap next` | Click | Không | Người dùng nhấn tiếp tục trên Tutorial Page 2. |
| `6803.007` | `tutorial 2 view` | View | Không | Lớp tracking dự phòng khi view màn hình Tutorial Page 2. |
| `6803.008` | `tutorial 2 ignore` | Click | Không | Người dùng nhấn nút bỏ qua trên Tutorial Page 2. |
| `6804.000` | `tutorial 3 load` | View | Không | Màn hình hướng dẫn tính lãi (Tutorial Page 3) hiển thị. |
| `6804.001` | `tutorial 3 tap next` | Click | Không | Người dùng nhấn tiếp tục trên Tutorial Page 3. |
| `6804.002` | `tutorial 3 tap close` | Click | Không | Người dùng nhấn đóng Tutorial Page 3 bằng nút X. |
| `6804.007` | `tutorial 3 view` | View | Không | Lớp tracking dự phòng khi view màn hình Tutorial Page 3. |
| `6804.008` | `tutorial 3 finish` | Click | Không | Người dùng nhấn nút "Hoàn tất" trên Tutorial Page 3 để sang bước liên kết. |
| `6804.009` | `tutorial 3 ignore` | Click | Không | Người dùng nhấn nút bỏ qua trên Tutorial Page 3. |

### 1.2 Khóm Sự kiện 2: Các bước điền Thông tin & Ký hợp đồng liên kết (`6805.xxx` - `6808.xxx`)

| Event ID | Event Name | Loại | Tham số (Parameters) | Mô tả chi tiết & Điều kiện kích hoạt (Trigger Rules) |
| :--- | :--- | :---: | :--- | :--- |
| `6805.000` | `binding step 1 load` | View | `loading_time` (number) | Kích hoạt khi màn hình điền thông tin cá nhân (Bước 1) load xong. |
| `6805.001` | `binding step 1 out focus date` | Action | `input_value` (string) | Kích hoạt khi người dùng rời con trỏ (blur) khỏi trường ngày sinh. |
| `6805.002` | `binding step 1 out focus location` | Action | `input_value` (string) | Kích hoạt khi người dùng rời con trỏ khỏi trường thông tin hộ khẩu/nơi cấp. |
| `6805.003` | `binding step 1 back` | Click | Không | Người dùng nhấn nút quay lại tại bước 1. |
| `6805.004` | `binding step 2 next` | Click | Không | Người dùng nhấn nút "Tiếp tục" tại bước 1 để qua bước 2. |
| `6806.000` | `binding step 2 load` | View | Không | Màn hình điền địa chỉ thường trú (Bước 2) hiển thị. |
| `6806.001` | `binding step 2 out focus address` | Action | `input_value` (string) | Người dùng rời con trỏ khỏi ô nhập địa chỉ chi tiết. |
| `6806.002` | `binding step 2 back` | Click | Không | Người dùng nhấn quay lại tại bước 2. |
| `6806.003` | `binding step 2 next` | Click | Không | Người dùng nhấn "Tiếp tục" tại bước 2. |
| `6806.004` | `binding step 2 open privacy link` | Click | Không | Người dùng nhấn mở link điều khoản bảo mật của Zalopay. |
| `6806.007` | `binding info load` | View | `loading_time` (number) | Theo dõi thời gian tải dữ liệu trang điền thông tin bổ sung. |
| `6806.008` | `binding info submit success` | Action | Không | Đăng ký liên kết thành công bước điền thông tin. |
| `6806.009` | `binding info submit failed` | Action | `reason` (string) | Liên kết thất bại kèm mô tả lỗi hệ thống. |
| `6806.010` | `user consent confirmed` | Click | Không | Người dùng bấm xác nhận đồng ý chia sẻ thông tin để mở tài khoản. |
| `6807.000` | `binding step 3 load` | View | Không | Màn hình ký hợp đồng và xem PDF hợp đồng (Bước 3) hiển thị. |
| `6807.001` | `binding step 3 scroll` | Action | `percents` (number) | Đo lường tỷ lệ người dùng cuộn xem file PDF hợp đồng điện tử (từ 0 đến 100). |
| `6807.002` | `binding step 3 partner tnc checkbox` | Click | Không | Người dùng tick vào ô "Tôi đồng ý điều khoản dịch vụ đối tác Infina". |
| `6807.003` | `binding step 3 privacy checkbox` | Click | Không | Người dùng tick vào ô "Tôi đồng ý chính sách chia sẻ dữ liệu bảo mật". |
| `6807.004` | `binding step 3 main cta` | Click | Không | Người dùng nhấn nút "Kích hoạt Số dư sinh lời" để gửi thông tin mở tài khoản. |
| `6807.005` | `binding step 3 back` | Click | Không | Người dùng nhấn quay lại từ bước 3. |
| `6807.006` | `binding step 3 tnc link` | Click | Không | Người dùng nhấn xem chi tiết nội dung hợp đồng. |
| `6807.007` | `binding step 3 error` | Action | Không | Gặp lỗi mạng hoặc API đối tác khi thực hiện ký kết. |
| `6808.000` | `binding result load` | View | `binding_result` (success/failed) | Tải màn hình kết quả mở tài khoản (thành công/thất bại). |
| `6808.001` | `binding result main cta` | Click | Không | Nhấn nút CTA chính tại trang kết quả (Thường là: "Nạp tiền ngay"). |
| `6808.002` | `binding result see details` | Click | Không | Nhấn nút xem chi tiết tài khoản vừa tạo. |
| `6808.003` | `binding result back` | Click | Không | Nhấn nút quay lại. |
| `6808.004` | `binding result go home` | Click | Không | Nhấn nút quay về màn hình trang chủ Zalopay. |
| `6808.005` | `binding result call cs` | Click | Không | Nhấn nút liên hệ CS hỗ trợ (khi bị lỗi). |

### 1.3 Khóm Sự kiện 3: Giao diện Nạp tiền VietQR (`6800.xxx`)

| Event ID | Event Name | Loại | Tham số (Parameters) | Mô tả chi tiết & Điều kiện kích hoạt (Trigger Rules) |
| :--- | :--- | :---: | :--- | :--- |
| `6800.000` | `deposit load` | View | `utm_source` (string)<br>`kyc_level` (number)<br>`user_balance` (number) | Kích hoạt khi người dùng mở màn hình nạp tiền MMF. |
| `6800.001` | `deposit tap days link` | Click | `input_value` (number) | Click nút giả lập số ngày để tính thử lợi nhuận tích lũy. |
| `6800.002` | `deposit focus days input` | Action | `input_value` (number) | Rời/Focus vào ô nhập số ngày. |
| `6800.003` | `deposit blur days input` | Action | `input_value` (number) | Rời khỏi ô nhập số ngày. |
| `6800.004` | `deposit main cta` | Click | Không | Người dùng nhấn nút xác nhận "Nạp tiền" tại Form. |
| `6800.005` | `deposit focus amount input` | Action | `input_value` (number) | Focus vào ô nhập số tiền nạp. |
| `6800.006` | `deposit blur amount input` | Action | `input_value` (number) | Blur khỏi ô nhập số tiền nạp. |
| `6800.007` | `deposit tap close icon` | Click | Không | Người dùng nhấn đóng màn hình nạp tiền bằng nút X. |
| `6800.008` | `deposit tap erase icon` | Click | Không | Người dùng nhấn icon xóa nhanh nội dung tiền nạp. |
| `6800.009` | `deposit cta done in days` | Click | `input_value` (number) | Hoàn tất nhập số ngày tính lợi nhuận. |
| `6800.010` | `deposit max amount tooltip binded` | Click | Không | Xem giải thích hạn mức chứa tối đa (đối với user đã liên kết). |
| `6800.011` | `deposit tap maximum link` | Click | Không | Nhấn nút tự điền hạn mức nạp tối đa còn lại. |
| `6800.012` | `deposit suggestion max binded` | Click | Không | Nhấn nút nạp tối đa (đối với user đã liên kết). |
| `6800.013` | `deposit suggestion click binded` | Click | `order` (number) | Nhấn chọn số tiền nạp gợi ý (50k, 100k, 500k...) (đã liên kết). |
| `6800.014` | `deposit profit detail binded` | Click | Không | Xem chi tiết cách tính lợi nhuận từ màn hình nạp (đã liên kết). |
| `6800.039` | `deposit load target binding` | View | `utm_source` (string) | Load màn hình nạp tiền đặc thù làm đích của phễu liên kết. |
| `6800.040` | `deposit load screen detail` | View | `utm_source` (string)<br>`user_status` (registered/kyced/pending_kyc...) | Tải chi tiết màn hình nạp tiền kèm trạng thái KYC của user. |
| `6800.041` | `deposit click scan qr unbind` | Click | Không | Click nút lấy mã VietQR nạp tiền khi chưa liên kết (kích hoạt luồng binding nhanh). |
| `6800.042` | `deposit click scan qr binded` | Click | Không | Click nút lấy mã VietQR nạp tiền khi đã liên kết tài khoản. |
| `6800.043` | `deposit max info tooltip` | View | Không | Tải tooltip hiển thị giải thích về hạn mức chứa. |
| `6800.044` | `deposit show limit bts` | View | Không | Tải Bottom Sheet cảnh báo hạn mức chứa tối đa đã chạm. |
| `6800.045` | `deposit close limit bts` | Click | Không | Nhấn đóng Bottom Sheet cảnh báo hạn mức chứa. |
| `6800.055` | `deposit show vietqr bts` | View | `qr_code` (string) | Hiển thị thành công Bottom Sheet chứa mã VietQR nạp tiền động. |
| `6800.057` | `deposit close vietqr bts` | Click | `callback_data` (string) | Đóng Bottom Sheet chứa mã VietQR nạp tiền. |
| `6800.058` | `deposit suggestion max unbind` | Click | Không | Nhấn nút nạp tối đa (đối với user chưa liên kết). |
| `6800.059` | `deposit profit detail unbind` | Click | Không | Xem chi tiết cách tính lợi nhuận (chưa liên kết). |
| `6800.060` | `deposit show input bts unbind` | View | Không | Hiển thị Bottom Sheet điền số tiền nạp khi chưa liên kết. |
| `6800.061` | `deposit click tnc link` | Click | Không | Click liên kết xem hợp đồng hợp tác đầu tư (BCC) trên trang nạp. |
| `6800.062` | `deposit click auth cta` | Click | Không | Click nút CTA xác thực tại trang nạp. |
| `6800.063` | `deposit switch to redeem` | Click | Không | Click nút chuyển nhanh từ màn hình nạp sang màn hình rút. |
| `6800.064` | `deposit suggestion click unbind` | Click | `order` (number) | Nhấn chọn số tiền nạp gợi ý (50k, 100k...) (chưa liên kết). |
| `6800.065` | `deposit show input bts binded` | View | Không | Hiển thị Bottom Sheet điền số tiền nạp đối với user đã liên kết. |
| `6800.066` | `deposit max amount tooltip unbind` | Click | Không | Xem giải thích hạn mức chứa tối đa (đối với user chưa liên kết). |

### 1.4 Khóm Sự kiện 4: Luồng Rút tiền (`6809.xxx` - `6811.xxx`)

| Event ID | Event Name | Loại | Tham số (Parameters) | Mô tả chi tiết & Điều kiện kích hoạt (Trigger Rules) |
| :--- | :--- | :---: | :--- | :--- |
| `6809.000` | `redemption load` | View | `kyc_level` (number)<br>`user_mmf_balance` (number)<br>`user_balance` (number) | Tải màn hình nhập số tiền cần rút về Ví. |
| `6809.001` | `redemption focus input` | Action | `input_value` (number) | Focus vào ô nhập số tiền rút. |
| `6809.002` | `redemption blur input` | Action | `input_value` (number) | Blur khỏi ô nhập số tiền rút. |
| `6809.003` | `redemption main cta` | Click | Không | Nhấn nút "Tiếp tục" tại màn hình nhập số tiền rút. |
| `6809.004` | `redemption close` | Click | Không | Nhấn nút X để đóng màn hình rút tiền. |
| `6809.005` | `redemption erase` | Click | Không | Nhấn icon xóa nhanh số tiền vừa nhập. |
| `6809.014` | `redemption screen view` | View | Không | Tải màn hình Form rút tiền. |
| `6809.015` | `redemption action click` | Click | `amount` (number) | Nhấn xác nhận số tiền rút trên Form. |
| `6809.016` | `redemption survey view` | View | Không | Hiển thị bảng khảo sát lý do rút tiền. |
| `6809.017` | `redemption survey submit` | Click | Không | Bấm gửi khảo sát lý do rút tiền. |
| `6810.000` | `redemption cashier load` | View | `order_id` (string) | Màn hình Cashier (Xác nhận giao dịch rút tiền) hiển thị. |
| `6810.001` | `redemption cashier confirm` | Click | Không | Người dùng bấm xác nhận thanh toán (TopupByUserID) và nhập PIN. |
| `6810.002` | `redemption cashier back` | Click | Không | Quay lại từ màn hình Cashier rút tiền. |
| `6811.000` | `redemption result load` | View | `status` (succeeded/failed/pending)<br>`order_id` (string) | Tải màn hình thông báo kết quả rút tiền. |
| `6811.001` | `redemption result main cta` | Click | Không | Nhấn nút "Hoàn tất" tại màn hình kết quả. |
| `6811.002` | `redemption result back` | Click | Không | Nhấn nút quay lại từ màn hình kết quả. |

### 1.5 Khóm Sự kiện 5: Trang chủ, Lãi suất & Tích lũy tự động (`6812.xxx`, `6822.xxx`, `6827.xxx`)

| Event ID | Event Name | Loại | Tham số (Parameters) | Mô tả chi tiết & Điều kiện kích hoạt (Trigger Rules) |
| :--- | :--- | :---: | :--- | :--- |
| `6812.001` | `home load` | View | `current_balance` (number)<br>`utm_source` (string)<br>`binding_status` (string)<br>`kyc_level` (number)<br>`binding_progress` (number/null) | Kích hoạt khi người dùng đã liên kết mở màn hình Dashboard chính của Số dư sinh lời. |
| `6812.002` | `home click details` | Click | Không | Click vào nút "Xem chi tiết" để xem cơ cấu tiền lãi và số dư. |
| `6812.003` | `home press deposit` | Click | `current_balance` (number)<br>`interest_rate` (number)<br>`latest_deposit` (string/null)<br>`timestamp` (number) | Nhấn nút "Chuyển tiền vào" tại trang chủ SDSL. |
| `6812.004` | `home press utilities` | Click | Không | Nhấn mở Bottom Sheet "Tiện ích" tại trang chủ MMF. |
| `6812.005` | `home see all transactions` | Click | Không | Click "Xem lịch sử giao dịch". |
| `6812.006` | `home click single transaction` | Click | Không | Click vào một giao dịch cụ thể hiển thị tại list giao dịch gần đây. |
| `6812.007` | `home click faq earning` | Click | Không | Click câu hỏi thường gặp về cách tính lợi nhuận. |
| `6812.008` | `home click faq register` | Click | Không | Click câu hỏi thường gặp về cách đăng ký mở tài khoản. |
| `6812.009` | `home click faq deposit` | Click | Không | Click câu hỏi thường gặp về cách nạp tiền. |
| `6812.010` | `home pull to refresh` | Action | Không | Người dùng vuốt màn hình xuống để reload lại số dư thực tế. |
| `6812.011` | `home scroll` | Action | `percents` (number) | Theo dõi độ sâu cuộn trang chủ của người dùng. |
| `6812.012` | `home utilities show bts` | View | Không | Tải Bottom Sheet danh sách tiện ích của tài khoản tích lũy. |
| `6812.013` | `home cta redeem` | Click | `current_balance` (number)<br>`binding_status` (string)<br>`first_redemption` (string/null)<br>`latest_deposit` (string/null)<br>`timestamp` (number) | Người dùng nhấn nút "Rút tiền" trên trang chủ. |
| `6812.014` | `home continue binding` | Click | `binding_progress` (string/number/null) | Người dùng nhấn nút tiếp tục luồng liên kết đang bỏ dở. |
| `6812.015` | `home click faq redeem` | Click | Không | Nhấn xem hướng dẫn rút tiền. |
| `6812.016` | `home click faq calc profit` | Click | Không | Nhấn xem hướng dẫn tính lãi. |
| `6812.017` | `home click faq analytics` | Click | Không | Nhấn xem hướng dẫn phân tích số dư và lịch sử giao dịch. |
| `6812.018` | `show cashback banner` | View | Không | Banner hướng dẫn nhận cashback vào Số dư sinh lời được hiển thị. |
| `6812.019` | `home click cashback deposit` | Click | Không | Nhấn nút "Gửi tích lũy" từ banner cashback. |
| `6812.020` | `home click cashback skip` | Click | Không | Nhấn nút "Bỏ qua" banner cashback. |
| `6812.021` | `home show popup ignore cashback` | View | `ignore_cashback_banner` (number) | Hiển thị pop-up cảnh báo khi người dùng nhấn bỏ qua cashback. |
| `6812.133` | `home screen load status` | View | `utm_source` (string)<br>`status` (active/locked/u15) | Tải màn hình Home kèm phân nhóm tình trạng tài khoản (Hoạt động bình thường / Khóa / Dưới 15 tuổi). |
| `6812.151` | `home tab click promotion` | Click | Không | Click mở Tab Ưu đãi / Khuyến mãi từ trang chủ MMF. |
| `6812.152` | `home tab click history` | Click | Không | Click mở Tab Lịch sử từ trang chủ MMF. |
| `6812.153` | `home tab click account` | Click | Không | Click mở Tab Tài khoản từ trang chủ MMF. |
| `6812.154` | `home click payment zone` | Click | Không | Click nút tiện ích "Thanh toán hoá đơn" từ vùng số dư MMF. |
| `6812.155` | `home click transfer zone` | Click | Không | Click nút tiện ích "Chuyển tiền P2P" từ vùng số dư MMF. |
| `6812.156` | `home click faq profit` | Click | Không | Click xem FAQ về lợi nhuận. |
| `6812.157` | `home click faq policy` | Click | Không | Click xem FAQ về chính sách bảo mật/sản phẩm. |
| `6812.158` | `home click faq view more` | Click | Không | Click xem tất cả danh sách FAQ. |
| `6812.159` | `home show toggle prioritize` | View | Không | Tải và hiển thị Toggle cấu hình tự động tích lũy khi có dòng tiền vào. |
| `6812.160` | `home click toggle prioritize` | Click | Không | Bấm bật/tắt Toggle tự động tích lũy. |
| `6812.161` | `home show explore banner` | View | Không | Banner khám phá tính năng được hiển thị. |
| `6812.162` | `home click explore banner` | Click | `location` (left/right) | Người dùng click vào banner khám phá (bên trái/bên phải). |
| `6812.163` | `home click priority balance zone` | Click | Không | Click kích hoạt nhanh tính năng tự động tích lũy từ vùng số dư trang chủ. |
| `6812.170` | `home click close account u15` | Click | Không | Người dùng dưới 15 tuổi click vào nút xác nhận tại thông báo thu hồi tài khoản. |
| `6812.180` | `home load progress bar` | View | `current_tier` (number)<br>`nbr_interest_tier` (number)<br>`next_tier` (number) | Hiển thị thanh tiến trình nạp tiền để thăng cấp lãi suất (Tích luỹ bậc thang). |
| `6812.181` | `home click progress bar cta` | Click | `current_milestone` (number)<br>`CTA_content` (string) | Click vào nút kêu gọi hành động trên thanh tiến trình tích luỹ bậc thang. |
| `6812.182` | `home load list task modal` | View | Không | Hiển thị Modal danh sách nhiệm vụ tích lũy nhận thưởng. |
| `6822.000` | `cashback show modal` | View | `next_action` (open_mmf/need_kyc/adjust_kyc) | Hiển thị modal hướng dẫn cấu hình nhận tiền hoàn (cashback) vào MMF. |
| `6822.001` | `cashback click privacy` | Click | Không | Click xem chính sách bảo mật thông tin trên modal cashback. |
| `6822.002` | `cashback click consent` | Click | Không | Click tick chọn đồng ý kích hoạt nhận cashback. |
| `6822.003` | `cashback click cta` | Click | `next_action` (open_mmf/need_kyc/adjust_kyc) | Click nút xác nhận đồng ý trên modal cashback. |
| `6822.004` | `cashback show result` | View | `status` (success/partial_success/fail)<br>`step` (string)<br>`error_code` (number) | Hiển thị kết quả liên kết/nạp tiền cashback thành công hay thất bại. |
| `6822.005` | `cashback click result cta` | Click | `next_action` (back/continue) | Click nút đóng hoặc tiếp tục tại trang kết quả nhận cashback. |
| `6827.009` | `nonuser home load` | View | `utm_source` (string)<br>`user_type` (not_deposited_yet/not_binding)<br>`status` (locked/u15/active/unbind) | Kích hoạt khi người dùng chưa đăng ký/chưa có tiền nạp mở trang chủ SDSL. |
| `6827.010` | `nonuser click main action` | Click | Không | Bấm nút nạp/rút tiền tại giao diện non-user. |
| `6827.014` | `nonuser click payment` | Click | Không | Bấm tiện ích thanh toán hoá đơn tại giao diện non-user. |
| `6827.015` | `nonuser click transfer` | Click | Không | Bấm tiện ích chuyển tiền P2P tại giao diện non-user. |
| `6827.016` | `nonuser click deposit now` | Click | `card_number` (number) | Click nút "Nạp ngay" trên card hướng dẫn thứ N. |
| `6827.017` | `nonuser swipe explore` | Action | Không | Vuốt xem các card hướng dẫn tích lũy. |
| `6827.018` | `nonuser click faq interest` | Click | Không | Xem FAQ tính lãi tại giao diện non-user. |
| `6827.019` | `nonuser click faq deposit` | Click | Không | Xem FAQ nạp/rút tại giao diện non-user. |
| `6827.020` | `nonuser click faq view more` | Click | Không | Bấm xem thêm danh sách câu hỏi thường gặp. |
| `6827.021` | `nonuser show priority toggle` | View | Không | Hiển thị toggle tự động tích luỹ dòng tiền tại giao diện non-user. |
| `6827.022` | `nonuser click priority toggle` | Click | Không | Bấm bật/tắt toggle tự động tích luỹ dòng tiền tại giao diện non-user. |
| `6827.023` | `home click activate mmf` | Click | Không | Click nút "Kích hoạt tài khoản" trên vùng số dư trang chủ ví Zalopay. |
| `6827.024` | `home click receive cashback` | Click | Không | Click nút "Nhận tiền hoàn vào Số dư sinh lời" từ ví. |
| `6827.025` | `home click receive money` | Click | Không | Click nút nhận tiền. |

### 1.6 Khóm Sự kiện 6: Chi tiết Tài khoản, Cấu hình Tự động tích lũy & Đóng tài khoản (`6813.xxx`, `6828.xxx`, `6830.xxx`)

| Event ID | Event Name | Loại | Tham số (Parameters) | Mô tả chi tiết & Điều kiện kích hoạt (Trigger Rules) |
| :--- | :--- | :---: | :--- | :--- |
| `6813.001` | `account details load` | View | `current_balance` (number)<br>`contract_status` (preparing/finished) | Tải tab thông tin chi tiết tài khoản Số dư sinh lời. |
| `6813.002` | `account show interest rate` | View | `number_interest_rate` (number) | Hiển thị lãi suất hiện tại của tài khoản. |
| `6813.003` | `account load interest chart` | View | `current_balance` (number)<br>`interest_rate` (number)<br>`latest_deposit` (string)<br>`timestamp` (number) | Biểu đồ lịch sử tích lũy số tiền hiển thị thành công. |
| `6813.004` | `account click instant balance` | Click | Không | Nhấn xem thông tin chi tiết về số dư khả dụng (instant balance). |
| `6813.005` | `account click distribution balance` | Click | Không | Nhấn xem thông tin chi tiết về số dư đang chờ xử lý từ đối tác. |
| `6813.006` | `account click escrow balance` | Click | Không | Nhấn xem thông tin chi tiết về số dư phong tả. |
| `6813.008` | `account load screen details` | View | `loading_time` (number) | Tải thành công màn hình cấu hình tài khoản. |
| `6813.009` | `account reload` | Action | Không | Bấm tải lại thông tin tài khoản. |
| `6813.010` | `account back click` | Click | Không | Bấm quay lại từ màn hình tài khoản. |
| `6813.011` | `account scroll` | Action | `percents` (number) | Cuộn xem thông tin tài khoản. |
| `6813.012` | `account view contract` | Click | Không | Nhấn nút "Xem hợp đồng điện tử đã ký". |
| `6813.015` | `account click close account` | Click | Không | Nhấn vào nút liên kết yêu cầu ngừng sử dụng dịch vụ / đóng tài khoản. |
| `6813.016` | `account show balance` | Click | Không | Nhấn icon con mắt để hiển thị số tiền số dư. |
| `6813.017` | `account hide balance` | Click | Không | Nhấn icon con mắt để ẩn số dư. |
| `6813.018` | `account toggle hide balance` | Click | `status` (enable/disable) | Bấm toggle ẩn/hiện số dư tại trang cài đặt nhanh. |
| `6813.019` | `account close check working time` | Action | `status` (allow/not_allow) | Trả về kết quả kiểm tra xem có nằm trong khung giờ làm việc để đóng tài khoản. |
| `6813.020` | `account close confirm proceed` | Click | Không | Người dùng bấm xác nhận tiếp tục quy trình đóng tài khoản. |
| `6813.021` | `account show priority toggle` | View | `user_status` (existing/new) | Hiển thị toggle tự động tích lũy (Priority Sweep). |
| `6813.022` | `account priority switch on` | Click | Không | Người dùng bấm gạt nút sang trạng thái ON. |
| `6813.023` | `account priority consent confirmed` | Click | Không | Người dùng click đồng ý điều khoản tự động trích tiền từ ví. |
| `6813.024` | `account show transfer toggle` | View | `status` (ON/OFF) | Hiển thị toggle cho phép nhận tiền P2P trực tiếp vào MMF. |
| `6813.025` | `account config transfer toggle` | Click | `action` (switch_on/switch_off) | Người dùng bấm bật/tắt nhận tiền P2P vào MMF. |
| `6813.026` | `account show touchpoint esof` | View | Không | Hiển thị banner giới thiệu thanh toán trực tiếp từ nguồn MMF. |
| `6813.027` | `account click touchpoint esof` | Click | Không | Bấm vào banner giới thiệu thanh toán nguồn MMF. |
| `6828.000` | `prioritize screen load` | View | `source` (string/null)<br>`user_type` (new/existing)<br>`stage` (1st_time_users/not_1st_time_users)<br>`next_action` (open_mmf/need_kyc/adjust_kyc) | Tải trang giới thiệu tính năng Tự động tích lũy (Priority Sweep Screen). |
| `6828.001` | `prioritize accept consent` | Click | Không | Người dùng chọn đồng ý chính sách và điều khoản trên trang giới thiệu. |
| `6828.002` | `prioritize compare interest` | Click | Không | Nhấn nút "So sánh lợi nhuận tích luỹ". |
| `6828.003` | `prioritize show compare bts` | View | Không | Tải Bottom Sheet biểu đồ so sánh lãi suất ví, ngân hàng và MMF. |
| `6828.004` | `prioritize click confirm` | Click | Không | Nhấn nút xác nhận kích hoạt tính năng tự động tích lũy. |
| `6828.005` | `prioritize show pin modal` | View | Không | Hiển thị Modal yêu cầu nhập mật khẩu PIN của ví Zalopay. |
| `6828.006` | `prioritize confirm pin` | Action | `status` (succeed/failed) | Người dùng nhập PIN xác thực (Thành công/Sai mật khẩu). |
| `6828.007` | `prioritize show result` | View | `status` (succeed/partially_succeed/failed)<br>`step` (binding/enable_priority/enable_sof_agreement_pay/deposit)<br>`error_code` (number) | Hiển thị modal thông báo kết quả kích hoạt tự động tích luỹ. |
| `6828.008` | `prioritize result click cta` | Click | `status` (succeed/partially_succeed/failed)<br>`action` (back/deposit/mmf_home) | Người dùng bấm CTA trên trang kết quả. |
| `6830.000` | `suspension flow load` | View | Không | Hiển thị trang xác nhận tạm dừng tích luỹ sinh lời. |
| `6830.010` | `suspension result` | Action | `status` (succeeded/error)<br>`error_message` (string) | Nhận kết quả API tạm dừng dịch vụ và đóng tài khoản tại đối tác. |

### 1.7 Khóm Sự kiện 7: Lịch sử Giao dịch & Màn hình Chi tiết Giao dịch (`6814.xxx` - `6815.xxx`)

| Event ID | Event Name | Loại | Tham số (Parameters) | Mô tả chi tiết & Điều kiện kích hoạt (Trigger Rules) |
| :--- | :--- | :---: | :--- | :--- |
| `6814.001` | `history main view` | View | Không | Khởi chạy trang lịch sử giao dịch Số dư sinh lời. |
| `6814.002` | `history empty view` | View | Không | Người dùng không có bất kỳ giao dịch nào, hiển thị màn hình trống. |
| `6814.003` | `history trans list view` | View | `filter_date` (string)<br>`filter_trans_type` (string) | Hiển thị danh sách các lệnh nạp/rút tiền của tài khoản. |
| `6814.004` | `history interest list view` | View | `filter_date` (string)<br>`filter_trans_type` (interest) | Hiển thị danh sách tiền lời cộng dồn nhận được hàng ngày. |
| `6814.005` | `history load list count` | View | `trans_number` (number) | Ghi nhận số lượng giao dịch tải lên thành công trên danh sách. |
| `6814.006` | `history click single transaction` | Click | `trans_type` (string)<br>`trans_date` (string)<br>`trans_status` (string) | Người dùng click vào một item giao dịch để xem chi tiết. |
| `6815.001` | `transaction detail load` | View | `trans_type` (string)<br>`trans_status` (string) | Tải màn hình chi tiết giao dịch (Transaction Detail Screen). |
| `6815.002` | `transaction detail back` | Click | Không | Người dùng đóng hoặc click nút back để thoát khỏi màn hình chi tiết. |
| `6815.003` | `transaction detail support click` | Click | Không | Click nút "Yêu cầu hỗ trợ" / "Tra soát giao dịch" từ trang chi tiết. |
| `6815.004` | `transaction detail help click` | Click | Không | Click nút xem hướng dẫn quy tắc giao dịch nạp/rút tương ứng. |

---

## 2. Cấu trúc Database MySQL `mmf` DB (DWH Source Schema)

Hệ thống cơ sở dữ liệu MySQL `mmf` được đồng bộ sang hệ thống Data Warehouse phục vụ báo cáo. Dưới đây là mô tả chi tiết của từng bảng, trường dữ liệu, kiểu dữ liệu và ý nghĩa nghiệp vụ để phục vụ việc tự động tạo query SQL.

### 2.1 Bảng `users` (Thông tin tài khoản dịch vụ của User)
Bảng lưu trữ thông tin đăng ký liên kết dịch vụ MMF của người dùng ví Zalopay.

| Tên trường (Field) | Kiểu dữ liệu | Nullable | Khóa | Ý nghĩa nghiệp vụ & Ràng buộc logic |
| :--- | :--- | :---: | :---: | :--- |
| `id` | `INT` | NO | PK | ID tự tăng của hệ thống. |
| `zalopay_id` | `BIGINT UNSIGNED` | NO | UK | ID định danh duy nhất của người dùng trên hệ thống ví Zalopay. |
| `phone_number` | `VARCHAR(20)` | YES | | Số điện thoại đăng ký ví của người dùng. |
| `full_name` | `VARCHAR(100)` | YES | | Họ và tên đầy đủ lấy từ thông tin định danh eKYC. |
| `binding_status` | `ENUM` | NO | | Trạng thái liên kết tài khoản:<br>`init` - Mới bắt đầu điền thông tin,<br>`binding` - Đang chờ API Infina phản hồi,<br>`open` - Liên kết thành công và tài khoản đang hoạt động,<br>`close` - Đã đóng tài khoản chủ động,<br>`reject` - Bị từ chối mở tài khoản do eKYC lỗi,<br>`lock` - Bị khóa tài khoản do lệch đối soát số dư. |
| `account_type` | `VARCHAR(50)` | NO | | Loại tài khoản. Mặc định là `pro` (VietQR-only, miễn phí rút tiền). Giá trị `normal` đã bị loại bỏ nhưng giữ lại cấu trúc để tương thích ngược. |
| `address` | `VARCHAR(255)` | YES | | Địa chỉ thường trú chi tiết do người dùng điền lúc Onboarding. |
| `tax_number` | `VARCHAR(50)` | YES | | Mã số thuế thu nhập cá nhân của người dùng (nếu có). |
| `extra_data` | `JSON` | YES | | Dữ liệu cấu hình mở rộng (Lưu thời gian ký hợp đồng, cấu hình tài khoản contingency bank, v.v.). |
| `meta` | `JSON` | YES | | Thông tin metadata kỹ thuật bổ sung của user. |
| `created_at` | `TIMESTAMP` | NO | | Thời điểm người dùng bắt đầu luồng Onboarding. |
| `updated_at` | `TIMESTAMP` | NO | | Thời điểm cập nhật trạng thái gần nhất. |

### 2.2 Bảng `instant_balance` (Số dư snapshot thời gian thực)
Bảng lưu trữ snapshot số dư mới nhất của người dùng được đồng bộ từ đối tác Infina hoặc cập nhật qua các giao dịch thành công.

| Tên trường (Field) | Kiểu dữ liệu | Nullable | Khóa | Ý nghĩa nghiệp vụ & Ràng buộc logic |
| :--- | :--- | :---: | :---: | :--- |
| `id` | `INT` | NO | PK | ID tự tăng. |
| `zalopay_id` | `BIGINT UNSIGNED` | NO | FK, UK | Liên kết sang bảng `users(zalopay_id)`. |
| `total_balance` | `INT` | NO | | Tổng số dư hiện có trong tài khoản MMF của user (đơn vị: VNĐ). |
| `total_interest_amount`| `INT` | NO | | Tổng số tiền lời tích lũy cộng dồn mà user nhận được từ trước tới nay. |
| `total_deposit_amount` | `INT` | NO | | Tổng số tiền user đã nạp thành công (lũy kế). |
| `total_redemption_amount`| `INT` | NO | | Tổng số tiền user đã rút thành công (lũy kế). |
| `reconciled` | `TINYINT` | NO | | Cờ trạng thái đối soát hàng ngày (`0` - Chưa đối soát hoặc lệch số dư, `1` - Đã đối soát khớp hoàn toàn với file balance của Infina). |
| `last_updated` | `TIMESTAMP` | NO | | Thời điểm số dư được cập nhật mới nhất. |

### 2.3 Bảng `orders` (Nhật ký giao dịch chi tiết)
Bảng lưu trữ tất cả các yêu cầu và lịch sử giao dịch nạp tiền, rút tiền, hoàn tiền của tài khoản Số dư sinh lời.

| Tên trường (Field) | Kiểu dữ liệu | Nullable | Khóa | Ý nghĩa nghiệp vụ & Ràng buộc logic |
| :--- | :--- | :---: | :---: | :--- |
| `id` | `BIGINT UNSIGNED` | NO | PK | ID tự tăng duy nhất của order. |
| `zalopay_id` | `BIGINT UNSIGNED` | NO | FK | Liên kết sang `users(zalopay_id)`. |
| `app_trans_id` | `VARCHAR(255)` | NO | UK | Mã giao dịch duy nhất do Zalopay sinh (Format: `yymmdd_appid_xxxxx`). |
| `zp_trans_id` | `BIGINT` | YES | | Mã giao dịch của ví Zalopay tương ứng (nếu rút tiền về ví hoặc thanh toán). |
| `app_id` | `INT` | NO | | Mã định danh của ứng dụng/cổng thanh toán. |
| `offer_id` | `INT` | YES | FK | Liên kết sang `offers(id)` để xác định lãi suất áp dụng. |
| `amount` | `INT UNSIGNED` | NO | | Số tiền thực hiện giao dịch (đơn vị: VNĐ). |
| `status` | `ENUM` | NO | | Trạng thái giao dịch:<br>`init` - Khởi tạo lệnh nạp/rút,<br>`pending` - Đang chờ NAPAS chuyển tiền (nạp VietQR) hoặc chờ Infina xử lý,<br>`payment_succeeded` - Đã trừ tiền ví/đã chuyển NAPAS thành công nhưng chưa sync xong quỹ,<br>`succeeded` - Giao dịch thành công hoàn toàn,<br>`failed` - Giao dịch thất bại (được rollback số dư),<br>`refunded` - Giao dịch đã hoàn tiền. |
| `type` | `ENUM` | NO | | Loại giao dịch chính: `deposit` (nạp tiền), `redemption` (rút tiền), `refund` (hoàn tiền thanh toán). |
| `sub_type` | `ENUM` | NO | | Loại luồng chi tiết:<br>`viet_qr` - Nạp chủ động VietQR,<br>`auto_receive_tf` - Tự động nạp khi nhận tiền ví,<br>`cashback` - Nhận tiền hoàn chiến dịch khuyến mãi,<br>`payment` - Rút thanh toán trực tiếp hoá đơn (PMC 44),<br>`ibft` - Rút tiền khẩn cấp trực tiếp về Bank thụ hưởng,<br>`transfer` - Rút chuyển tiền P2P,<br>`recurring` - Nạp định kỳ tự động. |
| `fee` | `DECIMAL(10,2)`| NO | | Phí giao dịch (Mặc định: `0.00` do đã chuyển sang pro package). |
| `partner_trans_id` | `VARCHAR(255)` | YES | | Mã ID giao dịch đối ứng do Infina cấp khi tạo lệnh sang hệ thống đối tác. |
| `partner_error_code` | `INT` | YES | | Mã lỗi do API đối tác trả về (nếu có sự cố). |
| `internal_error_code` | `INT` | YES | | Mã lỗi nội bộ do MMF Core trả về. |
| `is_pay` | `BOOLEAN` | NO | | Cờ xác định giao dịch rút tiền này phục vụ luồng thanh toán hóa đơn. |
| `metadata` | `JSON` | YES | | Thông tin mở rộng của giao dịch (chứa thông tin ngân hàng thụ hưởng, log callback IPN). |
| `transaction_time` | `TIMESTAMP` | YES | | Thời điểm giao dịch thực tế được khớp tại Infina/Bank. |
| `created_at` | `TIMESTAMP` | NO | | Thời điểm user tạo yêu cầu giao dịch trên app. |
| `updated_at` | `TIMESTAMP` | NO | | Thời điểm cập nhật trạng thái giao dịch gần nhất. |

#### 2.3.1 Bộ giá trị 2 trường mã lỗi của `orders` (Error Code Decoding)

Hai trường `internal_error_code` và `partner_error_code` là điểm tra cứu lỗi giao dịch khi phân tích data. Catalog chi tiết theo từng luồng nằm ở [MMF - Product Business Specification.md](MMF%20-%20Product%20Business%20Specification.md) và [MMF - System & Technical Specification.md §7](MMF%20-%20System%20&%20Technical%20Specification.md). Tóm tắt giá trị thường gặp:

* **`internal_error_code`** (mã lỗi nội bộ MMF — set bởi MMF Core):
  * `ErrorOrderIsFailedFirst` — callback nạp tiền tới khi order đã `failed` trước đó → auto-refund [order_status.go:L184](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L184).
  * `ErrorInvalidPaymentChannel` — order `viet_qr` nhận callback từ PMC ≠ 46 → auto-refund [order_status.go:L198](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L198).
* **`partner_error_code`** (status code đối tác — set bởi Order Worker / callback):
  * `501` — `http.StatusNotImplemented`: produce message sang Order Worker thất bại (luồng nạp), set qua `updateDepositStatusCode` → ghi vào `PartnerErrorCode` [order_status.go:L82-L91](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L82-L91).
  * **Infina:** `40005` (trùng trans_id), `40006` (sai amount), `40008` (sai timestamp), `40009` (lệch total balance), `42900`/`42901` (retry too fast), `50300` (Infina down) — Order Worker ghi qua `UpdatePartnerErrorCodeTx` [order_redemption_handler.go:L372-L383](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/order-worker/handler/order_redemption_handler.go#L372-L383).
  * **Disbursement Core:** `-68` (duplicate), `-101` (ví không tồn tại), `-406` (ví đạt hạn mức nhận tiền), `-500` (lỗi hệ thống ZLP).
  * **Acquiring Core / TPE:** `-16/-17` (pending), `-36/-46/-57` (fail chưa trừ tiền), `-993` (order not exist / acquirer), `-999` (bảo trì).

> **Gợi ý query phân tích lỗi:** Lọc `status = 'failed'` + `internal_error_code IS NOT NULL` → lỗi do MMF/logic; lọc `status IN ('failed','pending')` + `partner_error_code IS NOT NULL` → lỗi/đang chờ do đối tác (Infina/DC). Kết hợp `sub_type` để tách theo luồng (`viet_qr`/`payment`/`ibft`/`transfer`/`recurring`).

### 2.4 Bảng `balance_histories` (Nhật ký biến động số dư / Ledger)
Bảng ghi chép lại mọi sự kiện làm thay đổi số dư tài khoản của người dùng. Dùng để đối soát và dựng lại số dư tại bất kỳ thời điểm nào trong quá khứ.

| Tên trường (Field) | Kiểu dữ liệu | Nullable | Khóa | Ý nghĩa nghiệp vụ & Ràng buộc logic |
| :--- | :--- | :---: | :---: | :--- |
| `id` | `INT` | NO | PK | ID tự tăng. |
| `zalopay_id` | `BIGINT UNSIGNED` | NO | FK | Liên kết sang `users(zalopay_id)`. |
| `open_balance` | `DECIMAL(15,2)`| NO | | Số dư đầu kỳ trước khi xảy ra biến động giao dịch. |
| `current_balance` | `DECIMAL(15,2)`| NO | | Số dư trung gian đang xử lý (nếu có). |
| `ending_balance` | `DECIMAL(15,2)`| NO | | Số dư cuối kỳ sau khi cộng/trừ giao dịch thành công. |
| `net_asset_value` | `DECIMAL(15,2)`| NO | | Giá trị tài sản ròng tương đương tại Infina. |
| `net_interest` | `DECIMAL(15,2)`| NO | | Số tiền lời biến động trong kỳ giao dịch này (áp dụng cho action `calc_interest`). |
| `net_principal` | `DECIMAL(15,2)`| NO | | Số tiền gốc biến động trong giao dịch. |
| `action_type` | `ENUM` | NO | | Sự kiện gây biến động:<br>`calc_deposit` - Ghi tăng số dư do nạp tiền thành công,<br>`calc_redemption` - Ghi giảm số dư do rút tiền thành công,<br>`calc_interest` - Ghi tăng số dư do cộng tiền lời hàng ngày,<br>`adjustment` - Điều chỉnh số dư thủ công bằng tay do chênh lệch đối soát. |
| `metadata` | `JSON` | YES | | Lưu mã giao dịch `order_id` hoặc mã quyết định điều chỉnh. |
| `created_at` | `TIMESTAMP` | NO | | Thời điểm ghi nhận biến động số dư. |
| `updated_at` | `TIMESTAMP` | NO | | Thời điểm cập nhật lịch sử biến động. |

### 2.5 Bảng `offers` (Cấu hình gói Lãi suất sản phẩm)
Bảng lưu trữ cấu hình các gói lãi suất do đối tác cung cấp hoặc Zalopay trợ giá khuyến mãi.

| Tên trường (Field) | Kiểu dữ liệu | Nullable | Khóa | Ý nghĩa nghiệp vụ & Ràng buộc logic |
| :--- | :--- | :---: | :---: | :--- |
| `id` | `INT UNSIGNED` | NO | PK | ID gói lãi suất. |
| `product_name` | `VARCHAR(100)` | NO | | Tên hiển thị của gói lãi suất tích luỹ. |
| `interest_rate` | `FLOAT` | NO | | Tỷ suất sinh lời năm (% p.a.), ví dụ: `5.0`. |
| `interest_type` | `ENUM` | NO | | Loại tính lãi: `simple` (lãi đơn), `compound` (lãi kép). |
| `rollover_type` | `ENUM` | NO | | Chu kỳ cộng dồn lãi suất: `daily` (hàng ngày), `monthly` (hàng tháng). |
| `active` | `TINYINT` | NO | | Cờ trạng thái hoạt động (`0` - Hết hạn/Tắt, `1` - Đang áp dụng cho người dùng mới). |
| `savings_offer_id` | `VARCHAR(100)` | YES | | ID mã cấu hình gói lãi suất tương ứng bên hệ thống đối tác Infina. |
| `start_date` | `TIMESTAMP` | YES | | Ngày bắt đầu áp dụng gói lãi suất này. |
| `end_date` | `TIMESTAMP` | YES | | Ngày kết thúc áp dụng gói lãi suất này. |

### 2.6 Bảng `recurring_deposit_plans` (Cấu hình kế hoạch nạp tiền định kỳ)
Bảng lưu trữ thông tin thiết lập nạp tiền định kỳ tự động (Recurring Deposit) của người dùng.

| Tên trường (Field) | Kiểu dữ liệu | Nullable | Khóa | Ý nghĩa nghiệp vụ & Ràng buộc logic |
| :--- | :--- | :---: | :---: | :--- |
| `id` | `BIGINT` | NO | PK | ID kế hoạch tự tăng. |
| `zalopay_id` | `BIGINT UNSIGNED` | NO | FK | Liên kết sang `users(zalopay_id)`. |
| `amount` | `INT` | NO | | Số tiền đăng ký nạp định kỳ tự động mỗi chu kỳ. |
| `agreement_pay_token` | `VARCHAR(255)` | YES | | Mã Token liên kết thanh toán ví/thẻ để tự động trích nợ không cần OTP. |
| `status` | `ENUM` | NO | | Trạng thái kế hoạch: `open` (đang hoạt động), `close` (đã huỷ bỏ), `pending` (tạm dừng). |
| `frequency` | `ENUM` | NO | | Chu kỳ lặp: `daily` (mỗi ngày), `weekly` (mỗi tuần), `monthly` (mỗi tháng). |
| `is_all_zlp_balance` | `TINYINT` | NO | | Cờ trích sạch ví: `1` - Trích toàn bộ số dư ví Zalopay sang MMF vào ngày quét, `0` - Chỉ trích đúng số tiền `amount`. |
| `day_of_week` | `ENUM` | YES | | Nếu chu kỳ là `weekly`: chọn ngày quét trích (`mon`, `tue`, `wed`, `thu`, `fri`, `sat`, `sun`). |
| `day_of_month` | `INT` | YES | | Nếu chu kỳ là `monthly`: chọn ngày quét trích từ ngày `1` đến `31`. |
| `created_at` | `TIMESTAMP` | NO | | Ngày tạo kế hoạch nạp định kỳ. |
| `updated_at` | `TIMESTAMP` | NO | | Ngày cập nhật kế hoạch gần nhất. |

### 2.7 Bảng `recurring_deposit_history` (Nhật ký thực thi nạp tiền định kỳ)
Bảng log lại các lần hệ thống tự động quét trích tiền từ ví sang MMF theo lịch của người dùng.

| Tên trường (Field) | Kiểu dữ liệu | Nullable | Khóa | Ý nghĩa nghiệp vụ & Ràng buộc logic |
| :--- | :--- | :---: | :---: | :--- |
| `id` | `BIGINT UNSIGNED` | NO | PK | ID log thực thi tự tăng. |
| `recurring_plan_id` | `BIGINT` | NO | FK | Liên kết sang `recurring_deposit_plans(id)`. |
| `zalopay_id` | `BIGINT UNSIGNED` | NO | FK | Liên kết sang `users(zalopay_id)`. |
| `order_id` | `BIGINT UNSIGNED` | NO | FK | Liên kết sang `orders(id)` để tra cứu trạng thái thanh toán của giao dịch trích nạp đó. |
| `amount` | `INT UNSIGNED` | NO | | Số tiền thực tế trích nạp thành công hoặc thất bại. |
| `status` | `ENUM` | NO | | Kết quả thực thi trích nạp: `init`, `succeeded`, `failed`. |
| `error_code` | `INT` | YES | | Ghi nhận lỗi ví không đủ tiền, token hết hạn (nếu thất bại). |
| `created_at` | `TIMESTAMP` | NO | | Thời điểm hệ thống chạy tiến trình trích nạp tự động. |
| `updated_at` | `TIMESTAMP` | NO | | Thời điểm cập nhật kết quả trích nạp. |

---

## 3. Sơ đồ Thực thể Quan hệ (ERD Diagram)

Dưới đây là sơ đồ ERD trực quan mô tả mối quan hệ giữa các thực thể dữ liệu trong cơ sở dữ liệu `mmf` bằng cú pháp Mermaid:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" } }}%%
erDiagram
    users ||--o{ orders : "zalopay_id"
    users ||--o| instant_balance : "zalopay_id"
    users ||--o{ balance_histories : "zalopay_id"
    users ||--o{ recurring_deposit_plans : "zalopay_id"
    recurring_deposit_plans ||--o{ recurring_deposit_history : "recurring_plan_id"
    orders ||--o{ recurring_deposit_history : "order_id"
    orders }o--|| offers : "offer_id"

    users {
        int id PK
        bigint_unsigned zalopay_id UK
        varchar phone_number
        varchar full_name
        enum binding_status
        varchar account_type
        varchar address
        varchar tax_number
        json extra_data
        json meta
        timestamp created_at
        timestamp updated_at
    }

    instant_balance {
        int id PK
        bigint zalopay_id FK,UK
        int total_balance
        int total_interest_amount
        int total_deposit_amount
        int total_redemption_amount
        tinyint reconciled
        timestamp last_updated
    }

    orders {
        bigint_unsigned id PK
        bigint_unsigned zalopay_id FK
        varchar app_trans_id UK
        bigint zp_trans_id
        int offer_id FK
        int_unsigned amount
        enum status
        enum type
        enum sub_type
        decimal fee
        varchar partner_trans_id
        int partner_error_code
        int internal_error_code
        boolean is_pay
        json metadata
        timestamp transaction_time
        timestamp created_at
        timestamp updated_at
    }

    balance_histories {
        int id PK
        bigint_unsigned zalopay_id FK
        decimal open_balance
        decimal current_balance
        decimal ending_balance
        decimal net_asset_value
        decimal net_interest
        decimal net_principal
        enum action_type
        json metadata
        timestamp created_at
        timestamp updated_at
    }

    recurring_deposit_plans {
        bigint id PK
        bigint zalopay_id FK
        int amount
        varchar agreement_pay_token
        enum status
        enum frequency
        tinyint is_all_zlp_balance
        enum day_of_week
        int day_of_month
        timestamp created_at
        timestamp updated_at
    }

    recurring_deposit_history {
        bigint_unsigned id PK
        bigint_unsigned recurring_plan_id FK
        bigint_unsigned zalopay_id FK
        bigint_unsigned order_id FK
        int_unsigned amount
        enum status
        int error_code
        timestamp created_at
        timestamp updated_at
    }

    offers {
        int_unsigned id PK
        varchar product_name
        float interest_rate
        enum interest_type
        enum rollover_type
        tinyint active
        varchar savings_offer_id
        timestamp start_date
        timestamp end_date
    }
```

---

## 4. Hướng dẫn sinh câu lệnh SQL Analytics mẫu (Query Generation Helper)

Dưới đây là một số cấu trúc câu lệnh SQL mẫu thường dùng để truy xuất báo cáo nghiệp vụ, giúp AI hoặc Data Analyst có thể đối chiếu và sinh câu lệnh tự động.

### 4.1 Báo cáo phễu đăng ký sử dụng dịch vụ (Onboarding Conversion)
Query để xem tỷ lệ kích hoạt tài khoản thành công của người dùng đăng ký:
```sql
SELECT 
    binding_status,
    COUNT(zalopay_id) AS total_users,
    MIN(created_at) AS first_onboard_date,
    MAX(created_at) AS last_onboard_date
FROM users
GROUP BY binding_status;
```

### 4.2 Báo cáo AUM tích lũy (Tổng số dư Số dư sinh lời)
Query tính tổng AUM khả dụng của toàn bộ hệ thống và phân khúc theo độ tuổi (người dùng cá nhân thông thường vs doanh nghiệp SME):
```sql
SELECT 
    u.account_type,
    COUNT(ib.zalopay_id) AS total_active_users,
    SUM(ib.total_balance) AS total_aum,
    AVG(ib.total_balance) AS average_balance,
    SUM(ib.total_interest_amount) AS total_paid_interest
FROM instant_balance ib
JOIN users u ON ib.zalopay_id = u.zalopay_id
WHERE u.binding_status = 'open'
GROUP BY u.account_type;
```

### 4.3 Báo cáo doanh số nạp/rút theo ngày (Daily Transaction Summary)
Query phân tích dòng tiền vào (Inflow) và dòng tiền ra (Outflow) phân loại theo các loại giao dịch (VietQR, Auto Sweep, P2P, Direct Bank, Payment):
```sql
SELECT 
    DATE(transaction_time) AS report_date,
    type,
    sub_type,
    COUNT(id) AS transaction_count,
    SUM(amount) AS total_volume,
    COUNT(DISTINCT zalopay_id) AS unique_active_users
FROM orders
WHERE status = 'succeeded'
GROUP BY report_date, type, sub_type
ORDER BY report_date DESC, total_volume DESC;
```
