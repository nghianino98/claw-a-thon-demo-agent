# MMF (Money Market Fund) — System & Technical Specification

---

> [!IMPORTANT]
> **YÊU CẦU TỐI THƯỢNG (MỆNH LỆNH BẮT BUỘC):**
> Tài liệu này mô tả chi tiết và chính xác tuyệt đối kiến trúc hệ thống, các APIs tích hợp, cơ chế SAGA và thiết kế cơ sở dữ liệu của sản phẩm Số dư sinh lời (MMF).
> * Mọi thông tin kỹ thuật được đối chiếu trực tiếp từ source code monorepo `zlp-mmf/mmf/backend/` và các database migration thực tế.
> * Các liên kết trích dẫn sử dụng hyperlink trực tiếp đến Confluence/Jira gốc. Đường dẫn mã nguồn sử dụng relative path từ gốc workspace.
> * Chi tiết cấu trúc bảng MySQL và sơ đồ ERD được quản lý độc lập tại [MMF - Event Tracking & Data Mapping.md](MMF%20-%20Event%20Tracking%20&%20Data%20Mapping.md) để tránh trùng lặp thông tin.

---

## 1. Kiến trúc Hệ thống Monorepo Backend (`zlp-mmf/mmf/backend`)

Hệ thống backend của Số dư sinh lời được tổ chức dưới dạng Monorepo Go, chia thành các microservices độc lập nhưng chia sẻ chung cơ sở dữ liệu MySQL `mmf` và cache Redis phục vụ đồng bộ trạng thái nhanh và phân phối khoá (distributed locks) [Overview Backend #278882737](https://confluence.zalopay.vn/pages/viewpage.action?pageId=278882737).

### 1.1 Chi tiết các Microservices Cốt lõi

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" } }}%%
graph TD
    subgraph Services ["Tầng Dịch vụ (Go Monorepo)"]
        BIND[user-binding]
        DEP[deposit]
        RED[redemption]
        BAL[balance-orchestrator]
        WORKER[order-worker]
        SCHED[scheduler]
        REC[recurring-deposit-manager]
        CAMP[campaign-gateway]
    end

    subgraph Storage ["Tầng Lưu trữ & Cache"]
        DB[(Shared MySQL: mmf)]
        Redis[(Shared Redis Cache)]
    end

    subgraph Comm ["Tầng Giao tiếp"]
        Kafka{Kafka Message Bus}
    end

    BIND & DEP & RED & BAL & WORKER & SCHED & REC & CAMP --> DB
    BIND & DEP & RED & BAL & WORKER & SCHED --> Redis
    WORKER & DEP & RED & SCHED <--> Kafka
```

#### A. Dịch vụ Liên kết Người dùng (`user-binding`)
* **Chức năng:** Quản lý vòng đời tài khoản người dùng MMF, thực hiện xác thực eKYC, độ tuổi, loại giấy tờ tùy thân và gọi API Infina để tạo/hủy tài khoản liên kết.
* **Các file code chính:**
  * [check_binding.go](03. Fact/Source Code/MMF/Backend/user-binding/controllers/check_binding.go): Kiểm tra trạng thái liên kết hiện tại, tính toán độ tuổi và xác định KYC level của user khi mở app.
  * [submit_binding_user.go](03. Fact/Source Code/MMF/Backend/user-binding/controllers/submit_binding_user.go): Tiếp nhận thông tin eKYC bổ sung, ký hợp đồng điện tử BCC và gọi API đối tác Infina để mở tài khoản.
  * [submit_unbinding_user.go](03. Fact/Source Code/MMF/Backend/user-binding/controllers/submit_unbinding/submit_unbinding_user.go): Xử lý yêu cầu đóng tài khoản chủ động từ phía người dùng hoặc tự động unbind do vi phạm giới hạn độ tuổi.

#### B. Dịch vụ Nạp tiền (`deposit`)
* **Chức năng:** Xử lý luồng nạp tiền thông qua VietQR động. Sinh thông tin mã QR, quản lý hạn mức nạp, và tiếp nhận webhook callback từ Acquiring Core để cập nhật trạng thái giao dịch.
* **Các file code chính:**
  * [create_order.go](03. Fact/Source Code/MMF/Backend/deposit/controllers/create_order.go): Tiếp nhận yêu cầu nạp tiền, sinh mã VietQR và khởi tạo order với trạng thái `init`.
  * [order_status.go](03. Fact/Source Code/MMF/Backend/deposit/controllers/order_status.go): Tiếp nhận callback IPN từ Acquiring Core, kiểm tra chữ ký HMAC, validate logic payer, cập nhật trạng thái order và kích hoạt refund tự động nếu gặp lỗi nghiệp vụ.

#### C. Dịch vụ Rút tiền (`redemption`)
* **Chức năng:** Xử lý yêu cầu rút tiền về Ví hoặc rút trực tiếp về tài khoản Ngân hàng thụ hưởng. Thực hiện kiểm soát hạn mức rút ngày, gọi API đối tác Infina đóng băng số dư, và điều phối luồng bù trừ tài chính (SAGA).
* **Các file code chính:**
  * [create_mmf_redemption_order.go](03. Fact/Source Code/MMF/Backend/redemption/controllers/create_mmf_redemption_order.go): Khởi tạo yêu cầu rút tiền, kiểm tra hạn mức ngày và gọi Acquiring Core tạo order rút.
  * [confirm_order.go](03. Fact/Source Code/MMF/Backend/redemption/controllers/confirm_order.go): Tiếp nhận yêu cầu xác thực OTP/PIN, gọi API Infina đóng băng tiền (freeze), gọi Disbursement Core thực hiện chuyển tiền (TopupByUserID), và trigger confirm hoặc unfreeze (nếu lỗi).
  * [internal_charge_pmc_44.go](03. Fact/Source Code/MMF/Backend/redemption/controllers/internal_charge_pmc_44.go): Cung cấp gRPC API cho Payment Engine thực hiện trừ tiền ngầm từ tài khoản MMF để thanh toán các hóa đơn dịch vụ (SOF PMC 44).
  * [redeem_fund_out_validator.go](03. Fact/Source Code/MMF/Backend/redemption/controllers/redeem_fund_out_validator.go): Thực hiện kiểm tra hạn mức rút tiền hàng ngày tùy theo loại tài khoản và phân hạng người dùng.

#### D. Dịch vụ Điều phối Số dư (`balance-orchestrator`)
* **Chức năng:** Đóng vai trò là cổng định tuyến (router) truy vấn số dư MMF. Quản lý trạng thái vận hành Snapshot HA Mode (ONLINE, OFFLINE, REPLAY, SYNCFAILED) để đảm bảo tính sẵn sàng của hệ thống khi đối tác Infina downtime.

#### E. State Machine Giao dịch (`order-worker`)
* **Chức năng:** Consume các tin nhắn bất đồng bộ từ Kafka để tiếp tục xử lý các lệnh nạp, rút tiền. Thực hiện gọi API đối tác Infina để khớp lệnh mua/bán chứng chỉ quỹ và đồng bộ số dư `instant_balance` trong DB.

#### F. Lập lịch Cron & Quy trình (`scheduler`)
* **Chức năng:** Chạy các tiến trình định kỳ như đối soát (08:00 AM), đồng bộ file lãi (02:10 - 03:40 AM), tự động quyết toán SME, và quét trích nạp định kỳ. Scheduler được vận hành dựa trên **Temporal Workflow Engine** nhằm tăng cường khả năng theo dõi và chịu lỗi.

---

## 2. Thiết kế Kafka Messaging System

Kể từ T5/2026, toàn bộ message broker RabbitMQ cũ đã được di trú hoàn toàn sang hạ tầng Kafka Cluster để cải thiện thông lượng và khả năng mở rộng [Proposed Solution & Migration Plan #325191742](https://confluence.zalopay.vn/pages/viewpage.action?pageId=325191742).

### 2.1 Cấu hình Topic & Định tuyến (Routing Strategy)

* **Command Topic chính:** `fin.mmf.commands`
* **Số lượng Partitions:** **6 partitions**.
* **Cơ chế phân vùng (Partition Key Strategy):**
  * Đối với các tin nhắn liên quan đến giao dịch (Deposit, Redemption, Refund): Sử dụng **`AppTransID`** làm partition key.
  * Đối với các tin nhắn liên quan đến vòng đời user (Binding, Unbinding, Lock): Sử dụng **`zalopay_id`** làm partition key.
* **Mục đích:** Đảm bảo tất cả các sự kiện/lệnh của cùng một người dùng (hoặc cùng một giao dịch) luôn được định tuyến vào **cùng một partition** duy nhất. Cơ chế này cam kết việc xử lý bất đồng bộ tại `order-worker` tuân thủ đúng thứ tự tuyến tính theo thời gian (FIFO per partition), loại bỏ hoàn toàn race condition khi cập nhật số dư snapshot song song.

### 2.2 Các loại Event Payloads chính (Kafka Message Schema)

```json
{
  "event_id": "EVT_MMF_REDEMPTION_SUCCESS",
  "topic": "fin.mmf.commands",
  "timestamp": 1781427600000,
  "payload": {
    "zalopay_id": 9918027441706,
    "app_trans_id": "260614_1451_00002193",
    "partner_trans_id": "IFN_RED_88294710",
    "amount": 500000,
    "status": "succeeded",
    "type": "redemption",
    "sub_type": "viet_qr",
    "payment_channel": 46
  }
}
```

---

## 3. Đặc tả Luồng Tương tác APIs (Sequence Diagrams)

### 3.1 Luồng Nạp tiền qua VietQR (Active Deposit)

Sơ đồ tuần tự mô tả chi tiết các bước xác thực, sinh mã QR động và xử lý callback IPN từ Acquiring Core:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" } }}%%
sequenceDiagram
    autonumber
    participant User as Khách hàng
    participant FE as App Frontend
    participant GW as API Gateway
    participant DEP as deposit-service
    participant Infina as Infina Partner API
    participant AC as Acquiring Core V2
    participant DB as MySQL Database

    User->>FE: Bấm chọn "Nạp tiền" & Nhập số tiền (Ví dụ: 100,000đ)
    FE->>GW: POST /api/v1/deposit/initiate
    GW->>DEP: InitiateDeposit gRPC Call
    
    rect rgb(240, 240, 240)
        Note over DEP: Kiểm tra Preconditions
        DEP->>DEP: Kiểm tra giờ chặn nạp (Chặn từ 23:55 - 00:01)
        DEP->>DB: Truy vấn check binding_status == 'open' & total_balance < 100M
    end

    DEP->>Infina: POST /partner/v1/deposit/qr-code (amount, muid)
    Infina-->>DEP: Trả về qr_url (Virtual Account BIDV) & partner_trans_id
    
    DEP->>DB: INSERT INTO orders (app_trans_id, amount, status='init', sub_type='viet_qr')
    DEP-->>GW: Trả về mã QR (qr_url) + AppTransID
    GW-->>FE: Hiển thị mã VietQR động & nội dung chuyển khoản
    
    Note over User, Infina: User mở app Bank bất kỳ -> Quét mã VietQR -> Chuyển tiền qua NAPAS
    
    NAPAS->>Infina: Ghi nhận tiền vào Virtual Account
    Infina->>AC: Callback Webhook thông báo nhận tiền
    
    AC->>GW: POST /api/v1/authorizer/callback/deposit (IPN request)
    GW->>DEP: Forward callback data
    
    rect rgb(245, 235, 235)
        Note over DEP: Xác thực & Cập nhật Order (Xử lý trong DB Transaction)
        DEP->>DEP: checkMACCallbackValid() - Xác thực chữ ký HMAC
        DEP->>DB: SELECT * FROM orders WHERE app_trans_id = ? FOR UPDATE (Lock row)
        DEP->>DEP: Validate payment_channel == 46 (PMCVietQR)
        DEP->>DB: UPDATE orders SET status='payment_succeeded'
    end
    
    DEP->>Kafka: Publish event CallbackStatusDeposit (topic: fin.mmf.commands)
    DEP-->>GW: HTTP 200 OK (Xác nhận nhận callback thành công)
    GW-->>AC: HTTP 200 OK
    
    Note over DEP, DB: Order Worker consume Kafka event bất đồng bộ
    DEP->>Infina: POST /partner/v1/deposit/confirm (partner_trans_id)
    Infina-->>DEP: Confirm Success
    DEP->>DB: UPDATE orders SET status='succeeded'
    DEP->>DB: UPDATE instant_balance SET total_balance = total_balance + 100k
    
    DEP->>FE: SSE / WebSocket push thông báo nạp tiền thành công
    FE->>User: Hiển thị màn hình kết quả: Nạp thành công 100,000đ
```

### 3.2 Luồng Rút tiền về ví Zalopay (SAGA & Compensating Workflow)

Khi người dùng rút tiền về ví, hệ thống áp dụng pattern SAGA để đảm bảo tính toàn vẹn dữ liệu. Nếu bước Disbursement (chi hộ) gặp sự cố, hệ thống tự động kích hoạt Compensating Transaction để unfreeze số dư bên Infina, trả tiền về SDSL của user:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" } }}%%
sequenceDiagram
    autonumber
    participant FE as App Frontend
    participant RED as redemption-service
    participant Infina as Infina Partner API
    participant DC as Disbursement Core
    participant DB as MySQL Database
    participant Kafka as Kafka Cluster

    FE->>RED: POST /api/v1/redemption/create (amount)
    RED->>DB: SELECT total_balance FROM instant_balance FOR UPDATE (Lock)
    RED->>RED: Validate balance >= amount & validate daily limit (< 30M)
    
    RED->>Infina: POST /partner/v1/redemption/freeze (amount, muid)
    alt Infina từ chối (Ví dụ: Số dư không đủ thực tế tại Quỹ)
        Infina-->>RED: Error: INSUFFICIENT_BALANCE
        RED-->>FE: Trả về lỗi: Số dư không đủ thực tế tại đối tác
    else Freeze thành công
        Infina-->>RED: Freeze Success (partner_trans_id)
        RED->>DB: INSERT INTO orders (app_trans_id, amount, status='pending', type='redemption')
        
        rect rgb(230, 245, 230)
            Note over RED, DC: Thực hiện SAGA Step 1: Chi tiền về ví
            RED->>DC: Request TopupByUserID gRPC Call (Disbursement Core)
        end
        
        alt DC chuyển tiền thành công
            DC-->>RED: Topup Success
            RED->>Kafka: Publish event SuccessRedemption
            RED-->>FE: Trả về kết quả: Rút tiền thành công
            
            Note over RED, Infina: Async confirm order worker
            RED->>Infina: POST /partner/v1/redemption/confirm (partner_trans_id)
            Infina-->>RED: Confirm Success (Khớp lệnh bán CCQ thành công)
            RED->>DB: UPDATE orders SET status='succeeded'
            RED->>DB: UPDATE instant_balance SET total_balance = total_balance - amount
            
        else DC chuyển tiền thất bại (Ví user bị khoá/lỗi core ví)
            DC-->>RED: Topup Failed (ERROR_WALLET_LOCKED)
            
            rect rgb(255, 235, 235)
                Note over RED, Infina: SAGA Compensating Step: Giải phóng tiền phong toả
                RED->>DB: UPDATE orders SET status='failed', internal_error_code='WALLET_LOCKED'
                RED->>Kafka: Publish event RefundOrderRedemption
            end
            
            Note over RED, Infina: Async unfreeze order worker
            RED->>Infina: POST /partner/v1/redemption/unfreeze (partner_trans_id)
            Infina-->>RED: Unfreeze Success (Hoàn trả số dư khả dụng bên Infina)
            
            RED-->>FE: Trả về lỗi: Ví điện tử bị khóa. Tiền được hoàn lại SDSL.
        end
    end
```

### 3.3 Luồng Rút tiền Khẩn cấp (Contingency Direct-to-Bank)

Luồng rút tiền trực tiếp từ tài khoản lưu ký Infina/BIDV về tài khoản ngân hàng của khách hàng khi hệ thống ví Zalopay gặp sự cố core ví:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" } }}%%
sequenceDiagram
    autonumber
    participant User as Khách hàng
    participant FE as App Frontend
    participant RED as redemption-service
    participant Infina as Infina Partner API
    participant DB as MySQL Database

    User->>FE: Chọn Rút về tài khoản Bank liên kết & Nhập số tiền
    FE->>RED: POST /api/v1/redemption/direct-bank (amount, saved_bank_id)
    
    RED->>RED: Kiểm tra Contingency Mode == ON
    RED->>DB: SELECT * FROM users WHERE zalopay_id = ?
    RED->>RED: Đối chiếu tên chủ thẻ/bank thụ hưởng phải trùng khớp với full_name eKYC
    
    RED->>Infina: POST /partner/v1/redemption/direct-bank (amount, bank_details)
    
    alt Infina xử lý thành công
        Infina-->>RED: Direct Bank Accepted (partner_trans_id)
        RED->>DB: INSERT INTO orders (status='pending', sub_type='ibft', partner_trans_id)
        RED-->>FE: Trả về kết quả: Lệnh chuyển khoản liên ngân hàng đang được thực hiện
        
        Note over RED, Infina: Đối tác xử lý chuyển khoản Napas -> Callback kết quả
        Infina->>RED: Webhook callback (status = success)
        RED->>DB: UPDATE orders SET status='succeeded'
        RED->>DB: UPDATE instant_balance SET total_balance = total_balance - amount
    else Infina từ chối/Lỗi hạn mức đối tác
        Infina-->>RED: Error: PARTNER_LIMIT_EXCEEDED
        RED->>DB: INSERT INTO orders (status='failed', internal_error_code='PARTNER_LIMIT_EXCEEDED')
        RED-->>FE: Trả về lỗi: Rút tiền trực tiếp thất bại, hạn mức đối tác vượt quá
    end
```

### 3.4 Luồng Thanh toán Hóa đơn qua MMF (SOF PMC 44)

Sơ đồ xử lý thanh toán 1-step passthrough từ Payment Engine:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" } }}%%
sequenceDiagram
    autonumber
    participant PE as Payment Engine
    participant RED as redemption-service
    participant Infina as Infina Partner API
    participant DB as MySQL Database

    PE->>RED: gRPC Call: ChargeByPmcMMF (zalopay_id, amount, merchant_wallet_id)
    
    RED->>RED: checkMaintenanceMode() - Kiểm tra hệ thống bảo trì
    RED->>DB: SELECT * FROM users WHERE zalopay_id = ?
    RED->>RED: GetAccountType (Normal / SME)
    
    rect rgb(240, 240, 240)
        Note over RED: Kiểm soát hạn mức thanh toán
        RED->>RED: isNeedToValidateFundOutLimit()
        Note over RED: Account Normal -> Bắt buộc check hạn mức 30M/ngày<br>Account SME -> Miễn check hạn mức thanh toán hóa đơn
        RED->>RED: validateFundOutLimit()
    end

    RED->>Infina: POST /partner/v1/redemption/freeze (amount, muid)
    Infina-->>RED: Freeze Success (partner_trans_id)
    
    RED->>DB: INSERT INTO orders (status='pending', type='redemption', sub_type='payment', is_pay=true)
    
    RED->>Infina: POST /partner/v1/redemption/confirm (partner_trans_id)
    Infina-->>RED: Confirm Success
    
    RED->>DB: UPDATE orders SET status='succeeded'
    RED->>DB: UPDATE instant_balance SET total_balance = total_balance - amount
    
    RED-->>PE: gRPC Response: Charge Success (app_trans_id, amount, fee=0)
```

---

## 4. Cơ chế SAGA & Compensating Transactions

Trong các giao dịch tài chính phân tán giữa Zalopay (ví), MMF Core và Infina (quỹ), tính nhất quán dữ liệu được đảm bảo thông qua pattern SAGA Orchestration do `redemption-service` và `order-worker` thực thi.

### 4.1 Chi tiết các bước SAGA (Redemption Workflow)

1. **Local Transaction (Zalopay MMF):** 
   * Đọc số dư khả dụng từ bảng `instant_balance` bằng `SELECT ... FOR UPDATE` [confirm_order.go:302-332](03. Fact/Source Code/MMF/Backend/redemption/controllers/confirm_order.go#L302-L332).
   * Tạo bản ghi giao dịch trong bảng `orders` với trạng thái ban đầu là `pending`.
2. **Pivot Transaction (Infina API):**
   * Gọi API `/partner/v1/redemption/freeze` để tạm khóa số dư CCQ của người dùng tại đối tác Infina. Bước này đảm bảo số dư khả dụng thực tế của user được bảo vệ và không bị rút kép tại các kênh khác.
3. **Disbursement Step (Zalopay Wallet Core):**
   * Gọi Disbursement Core gRPC API `TopupByUserID` để chuyển tiền mặt tương ứng vào ví điện tử chính của người dùng.
4. **Compensating / Confirm Step:**
   * **Trường hợp Disbursement THÀNH CÔNG:** Hệ thống gửi tin nhắn Kafka `SuccessRedemption` đến `order-worker` để gọi API `/partner/v1/redemption/confirm` giải phóng khoản đóng băng và chuyển thành lệnh bán CCQ thành công.
   * **Trường hợp Disbursement THẤT BẠI (Compensating):** Nếu Disbursement trả lỗi (ví dụ: `ERROR_WALLET_LOCKED`), hệ thống cập nhật order DB sang `failed` và gửi message `RefundOrderRedemption` đến `order-worker`. Worker sẽ gọi API `/partner/v1/redemption/unfreeze` để giải phóng khoản đóng băng bên Infina, khôi phục lại số dư khả dụng trong SDSL cho người dùng.

### 4.2 Các trạng thái lỗi & Cơ chế Retry / Timeout của SAGA

Ba kết quả khi gọi Disbursement Core (`createOrderTopupToDC`) quyết định nhánh xử lý — `isPending` được kiểm tra **trước** `err` vì pending là trạng thái cần xử lý đặc biệt [confirm_order.go:L110-L143](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_order.go#L110-L143):

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" } }}%%
stateDiagram-v2
    [*] --> CreatingOrder
    CreatingOrder --> InfinaFreeze : tạo order pending
    InfinaFreeze --> CallDC : freeze OK
    InfinaFreeze --> FailNoCompensate : freeze FAIL (ErrorConfirmRedemptionCallIFNFail)
    CallDC --> DC_Success : DC success
    CallDC --> DC_Pending : DC pending (order_status=4)
    CallDC --> DC_Failed : DC failed (xác định)

    DC_Success --> ConfirmInfina : produce SuccessRedemption (NoDelay)
    DC_Pending --> QueryStatus30m : produce QueryStatusRedemption (delay 30')
    DC_Failed --> Unfreeze : produce RefundOrderRedemption + order=failed

    ConfirmInfina --> RetryConfirm : Infina status 42900/42901
    RetryConfirm --> ConfirmInfina : retry (ErrRetryConfirmRedemptionInfina)
    ConfirmInfina --> [*] : succeeded
    QueryStatus30m --> ConfirmInfina : DC trả success sau 30'
    QueryStatus30m --> Unfreeze : DC trả failed sau 30'
    Unfreeze --> [*] : refunded (hoàn SDSL)
    FailNoCompensate --> [*] : không freeze nên không cần unfreeze
```

* **Pivot Transaction lỗi (Infina freeze fail):** Không cần compensate (chưa freeze gì). Trả `Internal` + `ErrorConfirmRedemptionCallIFNFail`. Order ở DB là `pending`/không tạo, không trừ số dư.
* **Disbursement PENDING:** DC cam kết trả status trong **30 phút**; hệ thống không block user mà produce `QueryStatusRedemption` (`x-delay = 1.800.000ms`). Order Worker sẽ query lại; nếu success → confirm Infina, nếu failed → unfreeze. FE nhận lỗi tạm và hiển thị "đang xử lý".
* **Disbursement FAILED:** `handleUpdateStatusOrderFailedAndRefund()` set order `failed` + ghi `internal_error_code`, produce `RefundOrderRedemption` → Order Worker gọi Infina `unfreeze` để hoàn số dư khả dụng [confirm_order.go:L230-L249](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_order.go#L230-L249).
* **Confirm Infina quá nhanh (race):** Infina trả `42900 too_many_request` / `42901 retry_too_fast` → coi là **retryable**, Order Worker bắn lại message (`ErrRetryConfirmRedemptionInfina`) thay vì đánh fail [order_redemption_handler.go:L385-L406](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/order-worker/handler/order_redemption_handler.go#L385-L406).
* **Cơ chế retry chung của Order Worker:** message handler trả `rabbitmq.NewErrRetry(...)` khi gặp lỗi tạm (ví dụ "status is processing, need to retry"), worker reschedule message với delay `errRetry.Interval()` [order_redemption_handler.go:L78](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/order-worker/handler/order_redemption_handler.go#L78), [handler.go:L183-L189](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/order-worker/handler/handler.go#L183-L189).

---

## 5. Cơ chế Quản lý Idempotency & Rollout Rules

Để đảm bảo an toàn cho các API giao dịch, tránh tình trạng duplicate request do user double click hoặc lỗi retry từ Gateway, `deposit-service` triển khai cơ chế **Idempotency Rollout Management** [idempotency_rollout.go:20-205](03. Fact/Source Code/MMF/Backend/deposit/controllers/idempotency_rollout.go#L20-L205).

### 5.1 Các APIs Quản lý Idempotency

* **`ListIdempotencyRolloutRules`:** Lọc danh sách các rules đang hoạt động theo `client_id` và `source`.
* **`UpsertIdempotencyRolloutRule`:** Tạo hoặc cập nhật cấu hình rule. Cấu trúc cấu hình gồm:
  * `ClientID` (string): ID định danh client (ví dụ: `frontend_app`, `merchant_gateway`).
  * `Source` (string): Nguồn request (`viet_qr`, `priority_sweep`...).
  * `Enabled` (boolean): Cờ bật/tắt kiểm tra idempotency của rule này.
  * `WhitelistZalopayIDs` (array): Danh sách các `zalopay_id` đặc biệt được phép bypass kiểm tra trùng lặp để phục vụ test hoặc ops khẩn cấp.
* **`DeleteIdempotencyRolloutRule`:** Xóa bỏ rule khỏi cấu hình.
* **Quy tắc đặt Redis Key:** Các rule được cache trong Redis dưới format key: `mmf:idempotency:rule:{client_id}:{source}` để tăng tốc độ truy vấn ở tầng gateway validation.

---

## 6. Logic Nghiệp vụ & Kỹ thuật bổ sung từ Source Code

### 6.1 Logic Khóa & Reset khi đổi tuổi Realtime
* Hệ thống liên tục theo dõi độ tuổi người dùng. Khi người dùng mở app (Dashboard MMF), `check_binding.go` thực hiện logic:
  * Gọi `validateUserAge()` tính toán tuổi dựa trên ngày sinh định danh eKYC CCCD [check_binding.go:212-213](03. Fact/Source Code/MMF/Backend/user-binding/controllers/check_binding.go#L212-L213).
  * Nếu tuổi người dùng đột ngột bị phát hiện dưới 16 tuổi (ví dụ: eKYC cập nhật lại thông tin ngày sinh chính xác hơn) → Hệ thống tự động đặt `LockReason = LockReasonUnder15` và cập nhật `binding_status = LOCK` ngay lập tức [check_binding.go:179-199](03. Fact/Source Code/MMF/Backend/user-binding/controllers/check_binding.go#L179-L199).
  * Tiếp sau đó, scheduler sẽ kích hoạt luồng đóng tài khoản tự động (Force Under-15), tất toán toàn bộ số dư và gửi trả về ví trước khi chấm dứt hợp đồng.
* **Đối với user 16-17 tuổi (`SEGMENT_AGE_16_17`) — `[ĐANG THỰC HIỆN - CHƯA LIVE]`:** Ràng buộc hạn mức chứa tối đa dự kiến là **2.000.000đ** [Xử lý user theo độ tuổi #322294833](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322294833). Trên môi trường Production hiện tại, logic kiểm tra độ tuổi 16-17 tuổi đang bị tạm khóa bằng comment trong code, dẫn tới việc user 16-17 tuổi sẽ tạm thời bị chặn ở precondition chung do yêu cầu tuổi >= 18.

### 6.2 Logic Phân cấp Hạn mức Rút tiền
* Quyết định validation hạn mức rút được xử lý linh hoạt tại `redeem_fund_out_validator.go` [redeem_fund_out_validator.go:29-76](03. Fact/Source Code/MMF/Backend/redemption/controllers/redeem_fund_out_validator.go#L29-L76).
* Đối với tài khoản Doanh nghiệp SME (`AccountSME`): Hệ thống tự động bypass việc kiểm tra hạn mức rút tiền hàng ngày khi thanh toán hóa đơn. `isNeedToValidateFundOutLimit()` trả về `false` cho tài khoản SME ngoại trừ trường hợp thanh toán bằng luồng P2P.

---

## 7. Tổng hợp Mã lỗi & Cơ chế Xử lý Exception toàn hệ thống

> Đây là **master error catalog** của MMF, gom toàn bộ mã lỗi xuất hiện trong các luồng. Phần "tình huống lỗi theo từng luồng nghiệp vụ" chi tiết được đặt tại [MMF - Product Business Specification.md](MMF%20-%20Product%20Business%20Specification.md) (mỗi luồng có 1 bảng error riêng). Phần này tập trung vào góc nhìn kỹ thuật: phân lớp mã lỗi, ánh xạ gRPC↔HTTP, trường lưu lỗi trong DB, và chính sách retry.

### 7.1 Phân lớp 4 nhóm mã lỗi

| Nhóm | Nguồn phát sinh | Định dạng | Lưu ở đâu | Ví dụ |
| :--- | :--- | :--- | :--- | :--- |
| **Internal MMF** | `errorregistry.Error*` trong source MMF | tên hằng + `code` số + message | trả FE qua gRPC; ghi `internal_error_code` (bảng `orders`) | `ErrorBlockDeposit`, `ErrorNotEnoughBalanceToRedeem` |
| **Partner Infina** | API Infina (deposit/redemption/binding) | status code 5 chữ số (`4xxxx`/`5xxxx`) | ghi `partner_error_code` | `40009 invalid total balance`, `42900 too_many_request` |
| **Acquiring Core / TPE** | Core thanh toán nội bộ | số âm (`-1` → `-6035`) | hiển thị Result page / Trans detail | `-36`, `-62`, `-993`, `-999` |
| **Disbursement Core** | Core chi hộ (TopupByUserID) | số âm (`-68`, `-101`, `-401`, `-402`, `-406`, `-500`) | hiển thị Trans detail | `-101 wallet not exists`, `-406 fund-in limit` |

> ⚠️ Giá trị **số (code)** của các hằng `errorregistry.Error*` được định nghĩa tập trung trong package dùng chung `gitlab.zalopay.vn/fin/zlp-mmf/mmf/pkg/errorregistry` — package này **không có trong snapshot source code** hiện tại, nên tài liệu chỉ xác minh được **tên hằng + message + gRPC code** tại các call-site (xem Open Questions). Khi cần map sang số cụ thể, tra trực tiếp `pkg/errorregistry` trên repo gốc.

### 7.2 Ánh xạ gRPC code ↔ HTTP & ý nghĩa nghiệp vụ

Thống kê tần suất sử dụng trong 3 service chính (deposit, redemption, user-binding):

| gRPC code | HTTP tương ứng | Ý nghĩa trong MMF | Tần suất (xấp xỉ) |
| :--- | :--- | :--- | :--- |
| `Internal` | 500 | Lỗi hệ thống/đối tác, cho retry | ~110 chỗ |
| `InvalidArgument` | 400 | Request sai định dạng/thiếu trường | ~106 chỗ |
| `FailedPrecondition` | 412 | Vi phạm điều kiện nghiệp vụ (KYC, số dư, hạn mức, tuổi) | ~16 chỗ |
| `NotFound` | 404 | Không tìm thấy order/user | ~10 chỗ |
| `Unavailable` | 503 | Chặn giờ nạp / maintenance | ~6 chỗ |
| `AlreadyExists` | 409 | Duplicate / không acquire được lock | ~4 chỗ |
| `PermissionDenied` | 403 | Sai partner code / không có quyền | ~2 chỗ |
| `OK` | 200 | Thành công | ~19 chỗ |

*(Thống kê từ grep `GRPCCode: codes.*` trên source MMF Backend.)*

### 7.3 Trường lưu lỗi trong bảng `orders`

Mỗi giao dịch lỗi lưu vết theo **2 trường tách biệt** để Ops phân biệt lỗi nội bộ vs lỗi đối tác:

* **`internal_error_code`** — mã lỗi nội bộ MMF, set khi auto-refund deposit (`ErrorOrderIsFailedFirst`, `ErrorInvalidPaymentChannel`) hoặc khi redemption fail [order_status.go:L295-L301](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L295-L301).
* **`partner_error_code`** — status code đối tác. Order Worker gọi `UpdatePartnerErrorCodeTx` lưu status code Infina khi confirm redemption không thành công (ví dụ ghi `42900`) [order_redemption_handler.go:L372-L383](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/order-worker/handler/order_redemption_handler.go#L372-L383). Trường hợp produce message thất bại ở luồng deposit, hệ thống ghi `partner_error_code = 501`.

### 7.4 Bảng tra cứu Partner Status Code (Infina) — nguồn gốc

Tham chiếu đầy đủ tại [99. Mapping Partner and Internal Error Code](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/MMF/Technical%20Page/80653653_%5BPCF-FS%5D%20%5BMMF%5D%2099.%20Mapping%20Partner%20and%20Internal%20Error%20Code.md):

| Code | Tên | Ý nghĩa | Retryable? |
| :--- | :--- | :--- | :--- |
| `40000` | bad_request | Request không hợp lệ | Không |
| `40002` | signature_incorrect | Sai chữ ký giữa Infina ↔ ZLP | Không |
| `40005` | trans_id exists | Trùng ZPTransID (idempotency) | Không (đã xử lý) |
| `40006` | invalid amount | Số tiền không đúng | Không |
| `40007` | invalid checksum | Sai checksum | Không |
| `40008` | invalid timestamp | Sai thời điểm tính lãi/tạo request | Không |
| `40009` | invalid total balance | Số dư user tại Infina không khớp | Không (cần đối soát) |
| `40101` | invalid_token | Token OAuth hết hạn | Refresh token |
| `40401` | user_not_exists | Không tìm thấy user tại Infina | Không |
| `40402` | offer not exists | Offer không tồn tại (deposit) | Không |
| `42900` | too_many_request | Quá nhiều request/s | **Có** |
| `42901` | retry_too_fast | Confirm quá nhanh | **Có** |
| `50000` | internal_server_error | Lỗi nội bộ Infina | Có (backoff) |
| `50300` | service_unavailable / under maintenance | Infina down | Có (backoff) |
| `50301` | db_error | Lỗi DB Infina | Có (backoff) |
| `50302` | unexpected_error | Lỗi không xác định Infina | Có (backoff) |

Danh sách code cần retry confirm redemption (`listIfnStatusCodeNeedRetryConfirmRedemption`) hiện gồm `42900` [order_redemption_handler.go:L398-L406](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/order-worker/handler/order_redemption_handler.go#L398-L406).

### 7.5 Chính sách Retry / Timeout / Delay

| Cơ chế | Giá trị | Mục đích | Evidence |
| :--- | :--- | :--- | :--- |
| Refund delay (deposit) | **5s** (`refundDelay`) | Chờ pay event TPE được Acquiring Core consume, tránh `-101 Đơn hàng không tồn tại` | [order_status.go:L240-L254](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L240-L254) |
| Query status redemption (pending) | **30 phút** (`ThirtyMinutesDelay`) | DC cam kết trả status sau 30′ | [confirm_order.go:L30-L34](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_order.go#L30-L34) |
| Retry confirm Infina | event-driven (`ErrRetryConfirmRedemptionInfina`) | Khi Infina trả 42900/42901 | [order_redemption_handler.go:L336-L343](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/order-worker/handler/order_redemption_handler.go#L336-L343) |
| Reschedule message lỗi tạm | `rabbitmq.NewErrRetry` + `x-delayed-message` | Worker tự reschedule với delay | [handler.go:L199-L226](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/order-worker/handler/handler.go#L199-L226) |
| Query refund (deposit) | delay theo `queryStatusRefundDelayInSeconds`, có retry | Theo dõi refund tới khi xong | [query_status_refund.go:L69-L82](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/order-worker/handler/query_status_refund.go#L69-L82) |

### 7.6 Edge case Idempotency

* Lock 1-request-per-user khi binding (`mmf:submit_binding:lock_1_request:%d`) và lock 1-transaction-per-user khi rút (`mmf:redemption:lock_trans_%d`) ngăn double-submit. Unlock luôn dùng `context.Background()` để tránh deadlock khi request gốc timeout/cancel [confirm_order.go:L302-L332](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_order.go#L302-L332).
* `checkExistAppTransID` + Infina `40005 (trans_id exists)` là 2 lớp idempotency: lớp nội bộ (DB) và lớp đối tác. Nếu cả 2 cùng "đã tồn tại" → trả `ErrorConfirmRedemptionAppTransIsExisted` thay vì tạo bút toán trùng.
* Asset Exchange (`asset_exchange_exchange.go`) phát hiện trùng order → `ErrorDuplicateOrderCreation` [asset_exchange_exchange.go:L211](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/grpc/asset_exchange_exchange.go#L211).

### 7.7 Open Questions & Gaps (kỹ thuật)

* ⚠️ **Giá trị số của `errorregistry.Error*`**: package `mmf/pkg/errorregistry` không có trong snapshot → chưa map được tên hằng → số code cụ thể. Cần bổ sung từ repo gốc.
* ⚠️ **`balance-orchestrator`**: trong snapshot chỉ có `proto/` và `main.go` (stub) — logic state machine HA Mode (ONLINE/OFFLINE/REPLAY/SYNCFAILED) mô tả tại [MMF - Operations, Payment & Reconciliation Guide.md](MMF%20-%20Operations,%20Payment%20&%20Reconciliation%20Guide.md) hiện **chỉ có nguồn Confluence** (Snapshot Balance Appendix), chưa đối chiếu được với code.
* ⚠️ **Danh sách đầy đủ retryable codes** (`listIfnStatusCodeNeedRetryConfirmRedemption`): comment code xác nhận `42900`; cần xác minh có thêm `42901`/`50xxx` hay không trong định nghĩa list gốc.
