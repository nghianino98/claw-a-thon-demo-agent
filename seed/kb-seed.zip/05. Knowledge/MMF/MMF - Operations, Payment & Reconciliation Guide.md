# MMF (Money Market Fund) — Operations, Payment & Reconciliation Guide

---

> [!IMPORTANT]
> **YÊU CẦU TỐI THƯỢNG (MỆNH LỆNH BẮT BUỘC):**
> Tài liệu này mô tả chi tiết quy trình đối soát tài chính, hạch toán kế toán, cấu hình hệ thống và vận hành chế độ dự phòng Snapshot HA của sản phẩm Số dư sinh lời (MMF).
> * Tất cả logic nghiệp vụ và kỹ thuật trong tài liệu này đều được đối chiếu trực tiếp từ Phụ lục Đối soát thực tế và code của service `balance-orchestrator`.
> * Các liên kết trích dẫn sử dụng hyperlink trực tiếp đến Confluence/Jira gốc. Đường dẫn mã nguồn sử dụng relative path từ gốc workspace.

---

## 1. Chế độ Dự phòng Snapshot Balance HA Mode

Chế độ dự phòng Snapshot Balance HA Mode (High Availability) được thiết kế nhằm đảm bảo hoạt động thanh toán (SOF PMC 44) và rút tiền MMF của khách hàng hoàn toàn không bị gián đoạn khi hệ thống của đối tác Infina gặp sự cố kết nối hoặc downtime kéo dài [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L25-27](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L25-27).

* **Trạng thái triển khai:** `[ĐÃ LÊN PROD - CHƯA LIVE]` (Đã hoàn tất deploy code lên production nhưng chưa kích hoạt live cho toàn bộ người dùng) [Handover #151163446:L146](https://confluence.zalopay.vn/pages/viewpage.action?pageId=151163446#L146).

> ⚠️ **Lưu ý nguồn (TRUTH-mode):** Logic state machine HA Mode dưới đây được mô tả từ **Confluence Snapshot Balance Appendix #322286117**. Trong snapshot source code hiện tại, service `balance-orchestrator` chỉ chứa `proto/` + `main.go` (stub) nên **chưa đối chiếu được mã lỗi/transition với code thực tế**. Các mã lỗi vận hành ở mục này vì vậy mang tính nghiệp vụ (operation), chưa phải `errorregistry` constant. Xem Open Questions cuối tài liệu.

### 1.1 Chi tiết 4 Trạng thái vận hành (Operation Modes)

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" } }}%%
stateDiagram-v2
    [*] --> ONLINE : Bắt đầu hệ thống
    
    ONLINE --> OFFLINE : Infina sập kết nối > 5 phút (P1/P2)
    note right of OFFLINE
        - Chạy bằng Snapshot Balance nội bộ
        - Trích nạp/rút qua Merchant Wallet
    end note
    
    OFFLINE --> REPLAY : Infina phục hồi (Operator trigger)
    note right of REPLAY
        - Đồng bộ giao dịch theo user batch
        - User đang sync bị khóa tạm (SYNCING)
    end note
    
    REPLAY --> ONLINE : Đồng bộ thành công 100% (Khớp số dư)
    
    REPLAY --> SYNCFAILED : Lỗi replay hoặc lệch số dư cuối
    note bottom of SYNCFAILED
        - Khóa tài khoản user bị lệch
        - Infina ngắt tính lãi user
        - Ops phối hợp xử lý tay
    end note
    
    SYNCFAILED --> REPLAY : Giải quyết lệch (Cộng bù số dư) & Replay lại
```

#### A. ONLINE Mode (Trạng thái bình thường)
* **Logic hoạt động:** Hệ thống MMF Core định tuyến tất cả các yêu cầu truy vấn số dư, nạp tiền và rút tiền trực tiếp đến API đối tác Infina thời gian thực.
* **Cơ chế dự phòng song song:** Mỗi khi giao dịch nạp/rút/thanh toán thành công tại đối tác, hệ thống tự động cập nhật số dư snapshot mới nhất của user vào bảng `instant_balance` trong DB [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L57-58](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L57-58). Điều này đảm bảo dữ liệu snapshot nội bộ luôn tiệm cận thời gian thực với số liệu của Infina.

#### B. OFFLINE Mode (Trạng thái ngoại tuyến)
* **Điều kiện kích hoạt:** Tự động kích hoạt khi kết nối API sang Infina gặp sự cố (gRPC/HTTP timeouts liên tục trên 5 phút, tỷ lệ lỗi HTTP 5xx vượt quá 15% trong 3 phút liên tục), hoặc do Ops kích hoạt thủ công từ Admin Tool khi có thông báo bảo trì khẩn cấp từ đối tác [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L82-84](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L82-84).
* **Logic hoạt động:** 
  * MMF Core đóng vai trò là Ledger độc lập. Mọi yêu cầu truy vấn số dư được trả về trực tiếp từ bảng `instant_balance`.
  * Các giao dịch rút tiền và nạp tiền được xử lý và ghi nhận trực tiếp vào bảng `balance_snapshot` thay vì gọi API Infina.
  * Mọi bản ghi giao dịch trong bảng `orders` phát sinh trong thời gian này được đánh dấu là **"Giao dịch hỗ trợ kỹ thuật"** (`technical_support_order = true`).
* **Cơ chế dòng tiền:** 
  * **Nạp tiền:** Tiền chuyển khoản VietQR nạp vào được tạm giữ tại tài khoản thu hộ của Zalopay.
  * **Rút tiền:** Tiền mặt chi trả cho khách hàng được trích nợ trực tiếp từ **ví Merchant của Infina** mở tại Zalopay (`MerchantWalletID` của Infina được khai báo trong cấu hình hệ thống) [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L116-122](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L116-122).

#### C. REPLAY Mode (Trạng thái đồng bộ lại)
* **Điều kiện kích hoạt:** Do Ops kích hoạt từ Admin Tool sau khi kiểm tra kết nối API sang Infina đã hoàn toàn phục hồi ổn định.
* **Logic hoạt động:** 
  * Hệ thống tiếp tục chạy offline đối với các yêu cầu giao dịch mới của người dùng để tránh gián đoạn trải nghiệm.
  * Đồng thời, tiến trình **Replayer** sẽ được khởi chạy ngầm để quét toàn bộ các giao dịch có cờ `technical_support_order = true` và đẩy sang API Infina để đồng bộ lại dữ liệu.
* **Thuật toán Replay & Pagination:**
  * Để tránh race condition, Replay được xử lý theo **batch của từng user** (1 user = 1 batch) [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L135-136](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L135-136).
  * Trong lúc 1 user đang chạy replay, trạng thái tài khoản của user đó được đánh dấu là `SYNCING` và bị **khóa tạm thời** đối với mọi giao dịch mới.
  * Nếu một user phát sinh **nhiều hơn 100 giao dịch offline**, hệ thống sẽ tự động chia nhỏ thành các batch phụ (sub-batches) với **tối đa 100 giao dịch/batch**, sau đó gọi API Replay của Infina phân trang (pagination) tuần tự để cam kết đúng trật tự thời gian (FIFO) của transaction log [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L135-136](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L135-136).
  * **Idempotency check:** Replayer gửi kèm mã `app_trans_id` của từng giao dịch trong request. Infina đối chiếu mã này với transaction log nội bộ của họ để đảm bảo không ghi trùng lặp bút toán (double posting) [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L163-164](https://confluence.zalopay.vn/pages/viewpage.action?pageId=163-164).

#### D. SYNCFAILED Mode (Trạng thái lỗi đồng bộ)
* **Điều kiện kích hoạt:** Kích hoạt tự động đối với các user có tiến trình replay bị đối tác trả lỗi non-retryable (ví dụ: lỗi thông tin tài khoản, lỗi sai định dạng), hoặc số dư cuối cùng sau khi replay tất cả các giao dịch offline không khớp với Snapshot Balance của Zalopay [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L149-150](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L149-150).
* **Hành vi hệ thống:**
  * Tài khoản MMF của user bị **khóa lập tức** (`binding_status = LOCK`). User không thể thực hiện nạp/rút hay thanh toán.
  * Hệ thống gửi yêu cầu sang Infina **tạm ngắt tính lãi** đối với tài khoản này để bảo toàn số dư [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L153](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L153).
  * Bắn cảnh báo Critical Alert sang Slack/Telegram cho Ops 2 bên xử lý tra soát thủ công.

---

## 2. Quy trình Đối soát số dư hàng ngày (Reconciliation)

Tiến trình đối soát số dư (Balance Reconciliation) được vận hành tự động bởi Scheduler vào lúc **08:00 AM** hàng ngày nhằm đảm bảo tính nhất quán tuyệt đối về tiền gốc và tiền lãi của người dùng giữa 2 hệ thống [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L204](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L204).

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" } }}%%
flowchart TD
    Start([08:00 AM: Chạy Đối soát]) --> DownloadFile[Tải Balance File từ SFTP Infina]
    DownloadFile --> LoopUsers[Quét từng dòng User trong File]
    LoopUsers --> CheckState{Trạng thái hệ thống ngày hôm qua?}
    
    CheckState -- ONLINE Mode --> CompareOnline{So khớp số dư: ZLP vs Infina}
    CheckState -- OFFLINE/REPLAY Mode --> CompareOffline{So khớp số dư sau Replay}

    CompareOnline -- Khớp --> MarkOK[Đánh dấu reconciled = 1] --> NextUser
    CompareOnline -- Lệch: ZLP < Infina --> AutoOverride[ZLP tự động ghi đè tăng số dư theo Infina] --> LogAdjust[Ghi log điều chỉnh số dư] --> NextUser
    CompareOnline -- Lệch: ZLP > Infina --> LockAndAlert[LOCK tài khoản User & Bắn alert Critical cho Ops] --> NextUser

    CompareOffline -- Khớp --> UnblockUser[Mở khoá tài khoản -> NORMAL] --> MarkOK
    CompareOffline -- Lệch --> ContinueLock[Giữ khoá LOCK tài khoản & Xuất file lệch lên SFTP] --> Investigate[Ops 2 bên tra soát tay] --> NextUser

    NextUser --> End([Kết thúc đối soát])
```

### 2.1 Đối soát ngày bình thường (Online Mode)
1. **Tải dữ liệu đối soát:** MMF Scheduler tải balance file định dạng mã hóa của Infina từ máy chủ SFTP chung.
2. **So khớp số dư:** Hệ thống so sánh trường `total_balance` trong bảng `instant_balance` với giá trị thực tế tại đối tác Infina (`actual_balance`) của từng `zalopay_id`.
3. **Quy tắc xử lý lệch số dư:**
  * **Trường hợp Zalopay Snapshot < Actual Balance (Infina):**
    * Nguyên nhân: Do tiền lãi hàng ngày được cộng dồn bên đối tác nhưng tiến trình sync lãi của Zalopay bị chậm trễ hoặc do làm tròn số có lợi cho user.
    * Xử lý: Hệ thống tự động cập nhật ghi đè (override) tăng số dư snapshot trong DB Zalopay bằng số dư của Infina để đảm bảo quyền lợi khách hàng. Không khóa tài khoản user [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L214-219](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L214-219).
  * **Trường hợp Zalopay Snapshot > Actual Balance (Infina):**
    * Nguyên nhân: Rủi ro hệ thống bị rút kép hoặc lỗi logic hạch toán ghi nhận thừa tiền cho user.
    * Xử lý: Gửi cảnh báo Critical Alert lập tức về Telegram/Slack của Ops và **thực hiện LOCK tài khoản user lập tức** để ngăn ngừa thất thoát quỹ. Phối hợp với Infina đối chiếu lịch sử giao dịch để tìm nguyên nhân [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L220-222](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L220-222).

### 2.2 Đối soát ngày có phát sinh Replay (Offline/Replay Mode)
1. Tiến hành chạy đối soát sau khi Replayer thông báo hoàn tất replay toàn bộ các giao dịch offline của ngày hôm trước.
2. Hệ thống tải file số dư sau replay từ SFTP và tiến hành so sánh.
3. **Quy tắc xử lý:**
  * **Nếu Khớp:** Hệ thống tự động mở khóa tài khoản user, đưa trạng thái từ `SYNCING`/`LOCK` về `NORMAL` và cập nhật cờ `reconciled = 1`.
  * **Nếu Lệch:** **Tiếp tục giữ trạng thái LOCK tài khoản**, không cho phép user giao dịch. Hệ thống xuất file danh sách user lệch lên SFTP để Ops 2 bên tiến hành kiểm tra thủ công.

---

## 3. Quy trình Hạch toán Tài chính (Accounting Mapping)

Mọi biến động dòng tiền nạp, rút và thanh toán của Số dư sinh lời đều được ánh xạ tự động vào Cổng Hạch toán ZAS của Zalopay định kỳ vào lúc **11:00 PM** hàng ngày trước khi khóa sổ:

* **Mã hạch toán kế toán (Accounting Code):** `2013002001`
* **Mã định danh hệ thống hạch toán ZAS (ZAS ID):** `591802744170628111`
* **Quy tắc ánh xạ:**
  * Các giao dịch nạp tiền qua tài khoản thu hộ VietQR và các giao dịch rút chi hộ (TopupByUserID) đều sinh bút toán tự động mapping qua cặp key-value này để đảm bảo kế toán Zalopay có thể đối chiếu chính xác dòng tiền với ngân hàng lưu ký BIDV.

---

## 4. Runbooks & Alert Handling (Hướng dẫn Xử lý Sự cố)

### 4.1 Xử lý giao dịch nạp tiền bị Pending (User bị trừ tiền bank nhưng SDSL chưa tăng)
* **Triệu chứng:** Người dùng chuyển khoản VietQR thành công, tài khoản ngân hàng báo trừ tiền nhưng số dư SDSL không đổi. Trạng thái order trong bảng `orders` là `pending` hoặc `payment_succeeded`.
* **Quy trình xử lý:**
  1. Ops lấy mã `app_trans_id` từ khách hàng hoặc log lỗi.
  2. Sử dụng Admin Tool hoặc gọi API `GetOrderStatusByAppTransID` sang đối tác Infina để tra cứu [GetOrderStatus API Documentation #305030026](https://confluence.zalopay.vn/pages/viewpage.action?pageId=305030026).
  3. **Nếu đối tác báo THÀNH CÔNG:** Ops bấm nút `Force Sync` trên Admin Tool để trigger đồng bộ thủ công. Hệ thống sẽ cập nhật trạng thái order thành `succeeded` và cộng số tiền vào `instant_balance` cho user.
  4. **Nếu đối tác báo THẤT BẠI / KHÔNG TỒN TẠI:** Ops chuyển tiếp thông tin sang bộ phận CS của Infina để kiểm tra dòng tiền tại ngân hàng BIDV. Nếu tiền đã vào tài khoản thu hộ nhưng Infina bị lỗi không ghi nhận, Infina chịu trách nhiệm chuyển tiền điều chỉnh bổ sung hoặc hoàn trả lại tài khoản gốc cho user.

### 4.2 Xử lý sự cố lệch số dư sau Replay (Sync Failed)
* **Triệu chứng:** Hệ thống bắn cảnh báo hàng loạt tài khoản user bị đưa vào trạng thái `Sync Failed` và khóa tài khoản sau khi chuyển từ Offline sang Replay Mode.
* **Quy trình xử lý:**
  1. Ops xuất danh sách các user bị sync failed từ bảng `users` (`binding_status = LOCK` và `meta` chứa thông tin sync failed).
  2. Phối hợp với Ops Infina trích xuất nhật ký giao dịch offline của các user này để đối chiếu từng bút toán.
  3. **Khắc phục chênh lệch:**
     * Nếu do lỗi làm tròn hoặc logic tính lãi của Zalopay làm sai số dư: Zalopay chịu trách nhiệm đền bù.
     * Đối tác Infina thực hiện gọi API **cộng tiền điều chỉnh bổ sung (adjustment)** vào tài khoản của user tương ứng với số tiền lệch để tránh tài khoản bị âm số dư thực tế [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L181-182](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L181-182).
  4. Sau khi số dư thực tế tại Infina đã khớp với Snapshot của Zalopay, Ops kích hoạt chạy lại tiến trình Replay cho các user này từ Admin Tool để mở khóa tài khoản và khôi phục tính năng tính lãi [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L182](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L182).

#### Bảng triage mã lỗi nạp tiền pending (§4.1)

| Mã / dấu hiệu | Nguồn | Ý nghĩa | Hành động Ops |
| :--- | :--- | :--- | :--- |
| `-16` / `-17` | Acquiring Core | NCC chưa trả kết quả → đang chờ xử lý | Chờ callback; nếu quá 30′ thì `Force Sync` |
| `-101` | Acquiring Core (refund) | Đơn hàng không tồn tại (gọi refund quá sớm) | Hệ thống đã delay 5s; nếu vẫn lỗi → tra Infina rồi refund tay |
| `partner_error_code = 501` | MMF | Produce message Order Worker thất bại | Trigger lại đồng bộ thủ công order |
| `40005` | Infina | Trùng ZPTransID | Giao dịch đã ghi nhận, không nạp lại |
| `40008` | Infina | Sai timestamp tính lãi | Báo Infina kiểm tra thời điểm bắt đầu tính lãi |
| `50300` | Infina | Server Infina down | Chờ Infina phục hồi / cân nhắc OFFLINE mode |

### 4.3 Xử lý lệch số dư khi Đối soát (ONLINE Mode)

* **Triệu chứng:** Cảnh báo Critical từ job đối soát 08:00 AM, có user bị `binding_status = LOCK`.
* **Quy trình:**
  1. Phân loại chiều lệch: **ZLP Snapshot < Infina** → hệ thống đã tự override tăng số dư, **không LOCK** (chỉ ghi log điều chỉnh); **ZLP Snapshot > Infina** → hệ thống **LOCK user** + bắn alert (rủi ro rút kép / ghi thừa tiền).
  2. Với case `ZLP > Infina`: phối hợp Infina trích lịch sử giao dịch của user, tìm bút toán thừa.
  3. Sau khi xác định nguyên nhân và khớp lại số dư → mở LOCK qua Admin Tool.
* *Nguồn:* [Snapshot Balance - Reconciliation & Settlement Appendix #322286117:L214-L222](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322286117#L214-L222).

### 4.4 Xử lý giao dịch Rút tiền Pending / Thất bại

* **Triệu chứng:** User rút tiền, FE báo "đang xử lý" hoặc lỗi; order `pending`/`failed`.
* **Phân loại theo bước lỗi (đối chiếu `internal_error_code` & `partner_error_code`):**
  1. **Lỗi freeze Infina** (`ErrorConfirmRedemptionCallIFNFail`): chưa trừ số dư, chưa freeze → an toàn, user thử lại.
  2. **Disbursement Core PENDING** (`order_status = 4`): hệ thống đã hẹn `QueryStatusRedemption` sau 30′. Nếu sau 30′ vẫn pending → Ops dùng `retry_query_status` để query lại; nếu DC success → confirm Infina, nếu fail → unfreeze hoàn SDSL.
  3. **TPE trả `-993`** (`ErrorCode_ORDER_NOT_EXIST`/`ACQUIRER_*`) nhưng SDSL đã trừ: giao dịch pending ở bước chi tiền về ví → refund cho user (đã có tiền lệ tại [ISSUE-29731](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/MMF/ISSUE-29731_%5BThanh%20to%C3%A1n%5D%20-%20%5B241%20-%20Chuy%E1%BB%83n%20Ti%E1%BB%81n%20ATM%5D%20Ki%E1%BB%83m%20tra%20gi.md#L19)).
  4. **Infina trả `42900`/`42901`** (retry_too_fast): hệ thống tự retry confirm — KHÔNG can thiệp tay trừ khi retry lặp vô hạn.
  5. **DC trả `-406`** (ví user đạt hạn mức nhận tiền): hướng dẫn user nâng hạn mức ví hoặc rút về bank (Direct-to-Bank).
  6. **DC trả `-101`** (ví user không tồn tại / bị khóa): kiểm tra trạng thái ví user; tiền vẫn an toàn ở SDSL sau unfreeze.

### 4.5 Xử lý Charge PMC 44 (SOF) thất bại

* **`ErrorNotEnoughBalanceToRedeem` ("insufficient balance"):** số dư MMF không đủ — Payment Engine fallback sang nguồn tiền khác, không cần Ops xử lý.
* **`ErrorServiceIsUnderMaintenance`:** MMF đang maintenance — kiểm tra lịch maintenance, thông báo PE.
* **`ErrorInvalidPartnerCode`:** request từ kênh external sai partner code — kiểm tra cấu hình partner code của caller.

### 4.6 Bảng tra cứu nhanh: Mã lỗi → Hành động Ops

| Mã / hằng lỗi | Luồng | Hành động Ops |
| :--- | :--- | :--- |
| `ErrorBlockDeposit` | Nạp | Bình thường (khung giờ chặn 23:55–00:01), hướng dẫn user nạp lại sau |
| `-16` / `-17` / pending | Nạp | Chờ callback, `Force Sync` nếu quá hạn |
| `ErrorOrderIsFailedFirst` / `ErrorInvalidPaymentChannel` | Nạp | Đã auto-refund về ví — xác nhận user nhận tiền |
| `42900` / `42901` | Rút/SOF | Hệ thống tự retry — chỉ can thiệp nếu lặp |
| `40009 invalid total balance` | Rút | Đối soát số dư user với Infina (không tự xử lý) |
| `-993` + SDSL đã trừ | Rút | Refund cho user, ghi nhận case |
| `-406` | Rút | User vượt hạn mức nhận tiền ví → rút về bank |
| `Sync Failed` (LOCK) | Vận hành | Theo runbook §4.2 (phối hợp Infina adjustment + replay lại) |
| `ZLP Snapshot > Infina` | Đối soát | LOCK + alert, điều tra rút kép (§4.3) |

---

## 5. Open Questions & Gaps (Vận hành)

* ⚠️ **HA Mode chưa đối chiếu code:** `balance-orchestrator` trong snapshot là stub (`proto/` + `main.go`); toàn bộ logic ONLINE/OFFLINE/REPLAY/SYNCFAILED và ngưỡng kích hoạt (timeout > 5′, lỗi 5xx > 15%/3′) chỉ có nguồn Confluence — cần xác minh khi có source `balance-orchestrator` đầy đủ.
* ⚠️ **Mã lỗi vận hành HA/đối soát** (override, sync-failed, lock) hiện là mô tả nghiệp vụ, **chưa map sang `errorregistry` constant hay alert code cụ thể** — cần bổ sung khi có cấu hình alert (Slack/Telegram) và code job đối soát.
* ⚠️ **Ngưỡng & lịch chính xác:** giờ đối soát (08:00), sync lãi (02:10–03:40), hạch toán ZAS (23:00) lấy từ Confluence/Handover; cần đối chiếu với cấu hình `scheduler` thực tế (Temporal Workflow) khi có source.
