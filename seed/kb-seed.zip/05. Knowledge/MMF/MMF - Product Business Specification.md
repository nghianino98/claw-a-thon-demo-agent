# MMF (Money Market Fund) — Product Business Specification

---

> [!IMPORTANT]
> **YÊU CẦU TỐI THƯỢNG (MỆNH LỆNH BẮT BUỘC):**
> Tài liệu này mô tả chi tiết và chính xác tuyệt đối mọi khía cạnh nghiệp vụ, các bước xử lý và các edge cases của sản phẩm Số dư sinh lời (MMF). Tất cả thông tin nghiệp vụ đều được đối chiếu chéo giữa specs Confluence gốc và Fact thực tế trong source code/database.
> * Các mã tracking event và mô hình database chi tiết được tách thành tài liệu riêng [MMF - Event Tracking & Data Mapping.md](MMF%20-%20Event%20Tracking%20&%20Data%20Mapping.md).
> * Các liên kết trích dẫn sử dụng hyperlink trực tiếp đến Confluence/Jira gốc.

---

## 1. Đăng ký & Mở tài khoản (Onboarding & Binding)

### 1.1 Điều kiện tham gia (Eligibility Rules)

Hệ thống MMF áp dụng các quy tắc kiểm tra điều kiện nghiêm ngặt ở tầng backend (service `user-binding`) trước khi cho phép người dùng kích hoạt dịch vụ:

#### A. Định danh người dùng (eKYC Validation)
* **KYC Level tối thiểu:** Người dùng bắt buộc phải hoàn tất **KYC được phê duyệt** (`identityProfile.GetApproved() == true`). Nếu chưa phê duyệt, hệ thống trả lỗi `ErrorUMKYCLevelNotApprove` với message `"profile_level_invalid"`.
  * *Code evidence:* `submit_binding_user.go:236-239` — `if !identityProfile.GetApproved()` → return error.
* **Phân cấp KYC Level trả về cho Frontend:**
  * `kycLevel = 0`: Chưa định danh.
  * `kycLevel = 2`: User có NFC nhưng chưa KYC đầy đủ, HOẶC KYC pending.
  * `kycLevel = 3` (từ `profile.GetKycProfile().GetLevel()`): KYC Level 3 đầy đủ.
  * *Code evidence:* `check_binding.go:260-272` — `getKYCLevel()` function.

#### B. Loại giấy tờ tùy thân (ID Type Validation)
* **Chấp nhận:** Căn cước công dân (CCCD) hoặc Chứng minh nhân dân (CMND) 9/12 số.
* **Từ chối hoàn toàn:**
  * **Hộ chiếu (Passport):** `idType == types.Passport` → trả lỗi `ErrorIDTypeInvalid` message `"id_type_invalid"`.
  * **Chứng minh thư Quân đội (CMSQ):** `isValidProfile()` kiểm tra `idType == types.CMSQ` → trả `validProfile = false`.
  * *Code evidence:* `submit_binding_user.go:243-247` và `check_binding.go:278-292`.

#### C. Giới hạn độ tuổi (Age Control)
* **Tính tuổi:** Sử dụng hàm `clock.CalculateAge(dob, clock.LayoutYYYYMMDD, currentTime)` tính tuổi chính xác theo ngày sinh từ eKYC.
* **Dưới 16 tuổi:** Khi `age > 0 && age < 16`, hệ thống đặt `LockReason = LockReasonUnder15` và khóa tài khoản user (`binding_status = LOCK`).
  * *Code evidence:* `check_binding.go:212-213` — `validateUserAge()`.
* **Từ 16 đến 17 tuổi (`SEGMENT_AGE_16_17`) — `[ĐANG THỰC HIỆN - CHƯA LIVE]`:** Logic kiểm tra tuổi 16-17 hiện bị **comment out** trong code (`check_binding.go:215-217`): `// } else if age >= 15 && age < 18 { // return false, db.LockReasonUnder18 // }`. Nghĩa là trên production hiện tại, user 16-17 tuổi **chưa bị chặn riêng** nhưng sẽ bị chặn ở bước `checkPreconditionUserProfile` vì `age < 18`.
  * Hạn mức chứa tối đa dự kiến: **2.000.000đ** [Xử lý user theo độ tuổi #322294833](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322294833).
* **Từ 18 tuổi trở lên:** `age < 18` → `ErrorAgeInvalid.New("age_invalid")`. Chỉ user >= 18 mới vượt qua validation.
  * *Code evidence:* `submit_binding_user.go:250-260`.
* **Hạn mức chứa tối đa mặc định (>= 18 tuổi):** **100.000.000đ** [FAQ #183953706](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706).

#### D. Loại tài khoản (Account Type)
* **Account VietQR Only** (`AccountVietQROnly`): Mặc định cho tất cả user cá nhân nếu không chỉ định loại.
* **Account SME** (`AccountSME`): Dành cho hộ kinh doanh cá thể. Yêu cầu thêm: `basicProfile.GetSme() == true` (cờ SME trong User Management phải bật). Nếu không, trả lỗi `ErrorInvalidAccountTierSME`.
  * *Code evidence:* `submit_binding_user.go:263-267`.

### 1.2 Quy trình liên kết tài khoản (Account Binding Flow)

Quy trình nghiệp vụ kích hoạt liên kết tài khoản được thực hiện qua các bước cụ thể sau trong `handleSubmitBinding()`:

1. **Khóa request theo user (Distributed Lock):** Hệ thống acquire distributed lock theo key `mmf:submit_binding:lock_1_request:%d` (zalopay_id) để đảm bảo chỉ xử lý **1 request binding đồng thời cho mỗi user**. Nếu không acquire được lock, trả lỗi `ErrorBindingLockRequestError`.
   * *Code evidence:* `submit_binding_user.go:105-111`.

2. **Kiểm tra trạng thái user trong DB:**
   * Nếu user đã tồn tại với `binding_status = OPEN` → trả lỗi `ErrorUserIsExisted` message `"user already existed"`.
   * Nếu user có `binding_status = CLOSE` và `total_deposit_amount == 0` → cho phép **rebind** (tái liên kết).
   * *Code evidence:* `submit_binding_user.go:205-229`.

3. **Kiểm tra KYC & Tuổi** (như mô tả ở mục 1.1).

4. **Gọi API Infina đăng ký tài khoản:**
   * Request gửi sang Infina bao gồm: `zalopay_id`, `muid` (obfuscated ID), `full_name`, `identity_code` (số CCCD/CMND), `identity_issued_date`, `identity_issued_location`, `address` (permanent address), `gender`, `phone_number`, `nationality` (mặc định `"VN"`), `date_of_birth`, `identity_card_format`, `identity_expire_date`, `binding_source` (MMF hoặc FI).
   * Xử lý response Infina:
     * `IfnStatus == success` → tiếp tục lưu DB.
     * `StatusCode == ValidationError` + message chứa `"duplicate ID card"` → trả lỗi `IfnUserMessageDupIDCard` (trùng CCCD đã đăng ký trước đó).
     * `IfnUserID == ""` → trả lỗi `ErrorIFNBadRequest`.
   * *Code evidence:* `submit_binding_user.go:343-401`.

5. **Lưu tài khoản vào DB:**
   * **Binding mới:** Gọi `BindingUserTxWithZax()` tạo record mới với `binding_status = OPEN`, lưu `consent_time` từ request.
   * **Re-binding:** Gọi `RebindingUserTxWithZax()` cập nhật record cũ, thêm `rebinding_time`.
   * *Code evidence:* `submit_binding_user.go:162-178, 276-323`.

6. **Khởi tạo instant_balance:** Tạo row mới trong bảng `instant_balance` với tất cả giá trị = 0 (`total_balance`, `total_interest_amount`, `total_deposit_amount`, `total_redemption_amount`).
   * *Code evidence:* `submit_binding_user.go:182-190`.

7. **Publish events sau binding:** Phát sự kiện `OPEN` hoặc `REOPEN` sang hệ thống Event System và Promotion.

### 1.3 Luồng Re-bind (Tái liên kết)
* **Điều kiện rebind:** `user.Exist == false` (record tồn tại nhưng đã inactive) VÀ `binding_status == CLOSE`.
  * *Code evidence:* `submit_binding_user.go:272-274` — `isEligibleRebinding()`.
* **Kiểm tra bổ sung:** `total_deposit_amount` trong `instant_balance` phải == 0 (đảm bảo user đã rút hết tiền trước khi đóng).
* **Hành vi:** Không tạo tài khoản mới mà cập nhật record cũ, gọi Infina API binding lại và đặt `binding_status = OPEN`.

### 1.4 Logic xử lý lỗi & Bảng mã lỗi luồng Onboarding/Binding

> **Quy ước:** "Error constant" là tên hằng lỗi nội bộ MMF (`errorregistry.Error*`) trả về cho Frontend kèm `code` số (định nghĩa trong package dùng chung `mmf/pkg/errorregistry` — **không nằm trong snapshot source nên giá trị số cụ thể chưa xác minh được**, xem Phần Open Questions của tài liệu này). "gRPC code" là `google.golang.org/grpc/codes` mà service trả ra, Gateway map sang HTTP tương ứng.

**Logic rẽ nhánh khi gọi Infina đăng ký tài khoản** (`handleSubmitBinding` → bước 4): hệ thống phân loại response Infina theo thứ tự ưu tiên: (1) `IfnStatus == success` → lưu DB; (2) `StatusCode == ValidationError` + message chứa `"duplicate ID card"` → trả `IfnUserMessageDupIDCard` (CCCD đã đăng ký cho tài khoản khác); (3) `IfnUserID == ""` → trả `ErrorIFNBadRequest`; (4) các lỗi gọi Infina khác (timeout, 5xx) → `ErrorIFNCallRequestError` [submit_binding_user.go:L343-L401](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/submit_binding_user.go#L343-L401).

| Tình huống lỗi | Error constant (message) | gRPC code | Hành vi hệ thống | Evidence |
| :--- | :--- | :--- | :--- | :--- |
| Đang có 1 request binding khác của cùng user (không acquire được distributed lock) | `ErrorBindingLockRequestError` | `AlreadyExists` | Từ chối request thứ 2, user thử lại sau | [submit_binding_user.go:L110](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/submit_binding_user.go#L110) |
| User đã có tài khoản `binding_status = OPEN` | `ErrorUserIsExisted` ("user already existed") | `AlreadyExists` | Không tạo lại, trả lỗi đã tồn tại | [submit_binding_user.go:L211](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/submit_binding_user.go#L211) |
| KYC chưa được phê duyệt (`identityProfile.GetApproved() == false`) | `ErrorUMKYCLevelNotApprove` ("profile_level_invalid") | `FailedPrecondition` | Chặn binding, yêu cầu hoàn tất KYC | [submit_binding_user.go:L239](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/submit_binding_user.go#L239) |
| Giấy tờ là Hộ chiếu (Passport) hoặc CMSQ | `ErrorIDTypeInvalid` ("id_type_invalid") | `FailedPrecondition` | Từ chối loại giấy tờ | [submit_binding_user.go:L246](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/submit_binding_user.go#L246) |
| Không lấy được ngày sinh / tuổi < 18 | `ErrorAgeInvalid` ("age_invalid") | `FailedPrecondition` | Chặn binding (user < 18) | [submit_binding_user.go:L254-L259](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/submit_binding_user.go#L254-L259) |
| Tài khoản SME nhưng cờ `basicProfile.GetSme()` chưa bật | `ErrorInvalidAccountTierSME` | `FailedPrecondition` | Chặn mở tài khoản SME | [submit_binding_user.go:L263-L267](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/submit_binding_user.go#L263-L267) |
| CCCD đã đăng ký cho tài khoản Infina khác | `IfnUserMessageDupIDCard` (từ message Infina `"duplicate ID card"`) | `FailedPrecondition` | Chặn binding trùng CCCD | [submit_binding_user.go:L343-L401](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/submit_binding_user.go#L343-L401) |
| Infina trả `IfnUserID` rỗng | `ErrorIFNBadRequest` | `Internal` | Không lưu DB, rollback | [submit_binding_user.go:L343-L401](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/submit_binding_user.go#L343-L401) |
| Lỗi gọi Infina (timeout / 5xx) khi lấy application config / binding | `ErrorIFNCallRequestError` | `Internal` | Trả lỗi, không đổi trạng thái | [get_application_config.go:L162-L218](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/get_application_config.go#L162-L218) |
| Lỗi lấy profile user từ User Management | `ErrorUPGetProfileUserError` | `Internal` | Trả lỗi khi check binding | [check_binding.go:L111](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/check_binding.go#L111) |
| Đã xác nhận hợp đồng nhưng user đã bound rồi (race) | `ErrorBindingCheckExistedUserError` ("User has already bound") | `FailedPrecondition` | Bỏ qua, không tạo trùng | [confirm_agreement_create_mmf.go:L66-L73](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/confirm_agreement_create_mmf.go#L66-L73) |
| Ghi nhận đồng ý hợp đồng thất bại | `ErrorFailToMarkAgreementCreateAccount` | `Internal` | Không tạo tài khoản | [confirm_agreement_create_mmf.go:L90](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/confirm_agreement_create_mmf.go#L90) |

**Partner status code (Infina) liên quan binding** (tham chiếu bảng mapping gốc): `40100 unauthorized`, `40101 invalid_token`, `40400 not_found`, `40401 user_not_exists`, `50000 internal_server_error`, `50300 service_unavailable` [99. Mapping Partner and Internal Error Code:L446-L459](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/MMF/Technical%20Page/80653653_%5BPCF-FS%5D%20%5BMMF%5D%2099.%20Mapping%20Partner%20and%20Internal%20Error%20Code.md#L446-L459).

---

## 2. Luồng Nạp tiền (Deposit Flow)

> [!IMPORTANT]
> **THAY ĐỔI CHIẾN LƯỢC QUAN TRỌNG:**
> Kể từ ngày 08/10/2024, Zalopay MMF dừng hoàn toàn luồng nạp tiền từ nguồn Ví Zalopay và thẻ liên kết (mô hình Dual Account cũ đã bị xóa bỏ hoàn toàn) [FAQ #183953706](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706). Phương thức nạp tiền duy nhất được hỗ trợ hiện nay là **Chuyển khoản VietQR** trực tiếp vào tài khoản thu hộ của Infina.

### 2.1 Luồng Nạp chủ động VietQR (Active Deposit via VietQR)

#### A. Hạn mức & Ràng buộc giao dịch
* Số tiền nạp tối thiểu: **10.000đ/giao dịch** [FAQ #183953706](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706).
* Số tiền nạp tối đa: Phụ thuộc vào hạn mức chứa tối đa trừ đi số dư hiện tại và số tiền pending.
  * **>= 18 tuổi:** **100.000.000đ**
  * **16-17 tuổi (dự kiến):** **2.000.000đ** — `[ĐANG THỰC HIỆN]`
* `MaxDepositCap` được lấy từ `depositCapRepo.GetDefaultMaximumDepositByAccountType()` tùy theo `account_type`.

#### B. Khung giờ chặn nạp tiền (Block Deposit Time)
* Hệ thống chặn hoàn toàn request tạo lệnh nạp trong khung giờ **23:55 → 00:01** (cấu hình qua `timeStartBlockDeposit` và `timeEndBlockDeposit`).
* Sử dụng `clock.IsInTimeRange()` để kiểm tra, trả lỗi `ErrorBlockDeposit` với gRPC code `Unavailable`.
* *Code evidence:* `create_order.go:38-43`.

#### C. Quy trình nghiệp vụ nạp tiền (CreateOrder Flow)

1. **Kiểm tra khung giờ chặn** (Step 1 trong code).
2. **Parse & Validate request:** Validate struct `CreateOrderRequest` gồm các trường: `Amount`, `OfferID`, `AccountTier`, `QRCode`, `RedirectPath`, `IsFirstDeposit`, `Origin`.
   * *Code evidence:* `create_order.go:46-58`.
3. **Gọi Deposit Domain tạo order:** `depositDomain.CreateDepositOrder()` với params:
   * `ProductCode = NatureDeposit` (mã sản phẩm nạp)
   * `Description = TitleOrderDeposit`
   * `DepositFlow = Origin.String()` (nguồn gốc request: app, priority_toggle, recurring...)
   * *Code evidence:* `create_order.go:62-73`.
4. **Response trả về Frontend:** `ID`, `ZalopayID`, `AppTransID`, `AppID`, `Amount`, `Status`, `Type`, `ZpTransToken`, `QRCode`, `AccountTier`.

#### D. Xử lý Callback từ Acquiring Core (OrderStatusHook)

Khi ngân hàng ghi nhận tiền, Infina → Acquiring Core → gọi Webhook callback vào endpoint `OrderStatusHook`:

1. **Parse & Validate callback request** (`parseAndValidateRequest`):
   * Bind struct `CallbackOrderStatusRequest`.
   * **Xác thực chữ ký HMAC:** `checkMACCallbackValid()` so sánh HMAC tính toán từ `CallbackKey` với MAC trong request. Nếu không khớp → log error và bỏ qua (return HTTP 200 để tránh retry).
   * Unmarshal callback data (hỗ trợ cả V1 và V2 format qua flag `EnableV1`).
   * *Code evidence:* `order_status.go:114-155`.

2. **Xác thực danh tính người nạp (Payer Identity Check):**
   * Nếu `MerchantUserID != ""`: Gọi `GetZalopayIDByMUID()` để lấy zalopay_id của người thanh toán.
   * Nếu rỗng: Bypass check (trường hợp nạp VietQR thuần không có merchant user).
   * *Code evidence:* `order_status.go:57-65`.

3. **Cập nhật Order trong transaction (FOR UPDATE lock):**
   * Sử dụng `ExecTxWithIsolationLevel(ctx, ..., sql.LevelReadCommitted)` với `FOR UPDATE` lock để prevent race condition.
   * **Kiểm tra trạng thái hiện tại:**
     * Nếu order đã `succeeded` → log error, return `ErrorOrderStatusAlreadyUpdated` (không xử lý lại).
     * Nếu order đã `failed` → cập nhật order thành `refunded` với `internal_error_code`, kích hoạt **auto refund**.
     * Chỉ xử lý tiếp nếu status hiện tại là `pending` hoặc `init`.
   * **Kiểm tra payment channel cho VietQR:** `isInValidPaymentChannelForVietQR()` — order có `sub_type = viet_qr` phải có `pmc = 46 (PMCVietQR)`. Nếu sai → auto refund.
   * Cập nhật order thành `payment_succeeded` với `zp_trans_id` và `transaction_time`.
   * *Code evidence:* `order_status.go:158-230`.

4. **Đẩy message sang Order Worker:** Produce message type `CallbackStatusDeposit` vào RabbitMQ exchange `order_status` (delayed message exchange) để Order Worker xử lý tiếp (cộng số dư, gửi notification...).
   * *Code evidence:* `order_status.go:307-335`.

5. **Auto-Refund khi lỗi:**
   * Kích hoạt khi gặp 3 loại lỗi: `ErrorInconsistentCreatorDeposit`, `ErrorOrderStatusIsFailed`, `ErrorPaymentChannelIsInvalid`.
   * **Delay 5s trước khi refund** (`ctrl.refundDelay`) — chờ Kafka pay event từ TPE được Acquiring Core consume.
   * Gọi `acClient.CreateRefund()` hoàn tiền về ví Zalopay.
   * Tạo record refund trong DB với `type = refund`.
   * Produce message `QueryStatusRefund` (delay 5s) để Order Worker query status refund.
   * *Code evidence:* `order_status.go:232-293`.

#### E. Edge Cases & Xử lý lỗi nạp tiền
* **Sai nội dung chuyển khoản:** Giao dịch `pending` vô hạn, cần CS tra soát thủ công.
* **Callback khi order đã failed:** Hệ thống tự động refund tiền về ví user thay vì cộng vào SDSL.
* **Invalid payment channel:** Nếu order VietQR nhận callback từ payment channel không phải PMC 46 → tự động refund.
* **Callback duplicate:** Nếu order đã `succeeded` → bỏ qua, return HTTP 200.
* **Produce message thất bại:** Cập nhật `partner_error_code = 501` vào order (HTTP 501 Not Implemented) để tracking.

#### F. Logic Auto-Refund & Bảng mã lỗi luồng Nạp VietQR

**Cây quyết định Refund trong `OrderStatusHook`:** sau khi xử lý callback, hàm `isErrorNeedRefund(err)` trả `true` (kích hoạt `handleAutoRefundDeposit`) **chỉ khi** lỗi thuộc đúng 3 loại: `ErrorInconsistentCreatorDeposit` (người nạp ≠ chủ tài khoản), `ErrorOrderStatusIsFailed` (callback đến khi order đã `failed` trước đó), `ErrorPaymentChannelIsInvalid` (kênh thanh toán ≠ PMC 46) [order_status.go:L428-L436](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L428-L436). Khi refund, order gốc được set `status = refunded` kèm `internal_error_code` tương ứng (`ErrorOrderIsFailedFirst` hoặc `ErrorInvalidPaymentChannel`) [order_status.go:L177-L201](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L177-L201).

**Vì sao delay 5s trước khi refund:** nếu gọi refund ngay, Acquiring Core có thể trả về `-101: Đơn hàng không tồn tại` (do pay event từ TPE chưa được Acquiring Core consume xong). Do đó hệ thống `time.Sleep(refundDelay)` 5s rồi mới gọi `acClient.CreateRefund()` [order_status.go:L240-L254](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L240-L254).

| Tình huống lỗi | Error constant / mã | gRPC code | Hành vi hệ thống | Evidence |
| :--- | :--- | :--- | :--- | :--- |
| Tạo lệnh nạp trong khung giờ chặn 23:55–00:01 | `ErrorBlockDeposit` ("block_deposit") | `Unavailable` | Từ chối tạo order | [create_order.go:L42](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/create_order.go#L42) |
| Request sai định dạng / thiếu trường | `ErrorInvalidArgument` | `InvalidArgument` | Reject sớm | [create_order.go:L49-L57](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/create_order.go#L49-L57) |
| Chữ ký HMAC callback không hợp lệ | (log + bỏ qua) | trả HTTP 200 | Không xử lý, tránh để Acquiring Core retry | [order_status.go:L114-L155](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L114-L155) |
| Callback khi order đã `succeeded` (duplicate) | `ErrorOrderStatusAlreadyUpdated` | (bỏ qua, HTTP 200) | Không cộng số dư lần 2 | [order_status.go:L71](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L71) |
| Callback khi order đã `failed` trước đó | `ErrorOrderStatusIsFailed` → `internal_error_code = ErrorOrderIsFailedFirst` | (auto refund) | Refund tiền về ví user, không cộng SDSL | [order_status.go:L182-L187](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L182-L187) |
| Order `viet_qr` nhưng payment channel ≠ PMC 46 | `ErrorPaymentChannelIsInvalid` → `internal_error_code = ErrorInvalidPaymentChannel` | (auto refund) | Refund tiền về ví user | [order_status.go:L194-L201](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L194-L201) |
| Người nạp ≠ chủ tài khoản MMF | `ErrorInconsistentCreatorDeposit` | (auto refund) | Refund tiền về ví người nạp | [order_status.go:L57-L65](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L57-L65) |
| Produce message sang Order Worker thất bại | `partner_error_code = 501` (`http.StatusNotImplemented` qua `updateDepositStatusCode`) | — | Đánh dấu tracking để xử lý tay | [order_status.go:L82-L91](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/order_status.go#L82-L91) |

**Partner status code (Infina) khi MMF gọi `request update deposit package`:** `40005 Trans ID exists` (trùng ZPTransID), `40006 invalid amount`, `40007 invalid checksum`, `40008 invalid timestamp` (sai thời điểm bắt đầu tính lãi), `40402 offer not exists`, `50300 under maintenance` (server Infina down) [99. Mapping Partner and Internal Error Code:L417-L422](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/MMF/Technical%20Page/80653653_%5BPCF-FS%5D%20%5BMMF%5D%2099.%20Mapping%20Partner%20and%20Internal%20Error%20Code.md#L417-L422).

**Mã lỗi Acquiring Core / TPE quan trọng (hiển thị Result page khi nạp lỗi):** `-16/-17` (NCC chưa trả kết quả → giao dịch chờ xử lý/pending), `-36/-46/-57` (giao dịch thất bại, tài khoản chưa bị trừ tiền), `-54` (hết hạn thanh toán), `-62/-63` (tài khoản không đủ tiền), `-101` (hoàn tiền thành công ATM/VISA 3-5 ngày), `-999` (hệ thống bảo trì). Bảng đầy đủ ~330 mã (`-1` → `-6035`) tại [99. Mapping Partner and Internal Error Code:L20-L411](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/MMF/Technical%20Page/80653653_%5BPCF-FS%5D%20%5BMMF%5D%2099.%20Mapping%20Partner%20and%20Internal%20Error%20Code.md#L20-L411).

### 2.2 Luồng Ưu tiên Nạp MMF (Enable MMF Priority Toggle)

Khi user bật tính năng "Ưu tiên Số dư sinh lời", flow xử lý trong `EnableMMFPriority`:

1. **Validate PIN:** Gọi `userProfileClient.ValidatePin()` xác thực mã PIN Zalopay.
   * Xử lý lỗi PIN chi tiết: `ErrorUMPinNotMatch` (sai PIN), `ErrorUMExceedPinNotMatch` (vượt quá số lần nhập sai), `ErrorUMPinHasExpired` (PIN hết hạn).
   * *Code evidence:* `enable_mmf_priority.go:335-368`.

2. **Distributed Lock:** Acquire lock key `fin:mmf:lock_enable_mmf_priority:%d` để prevent concurrent requests.

3. **Kiểm tra trạng thái binding:**
   * **User đã binding (status = OPEN):** Xử lý 2 việc **song song** (goroutine):
     * Enable MMF SOF (Source of Fund) cho Payment Engine.
     * Confirm Deposit toàn bộ số dư ví Zalopay vào MMF (nếu balance > 0).
   * **User chưa binding:** Lưu request vào Redis cache (TTL = **3 ngày**) với key `EnableMMFPriority:%d`, chờ KYC phê duyệt.
   * *Code evidence:* `enable_mmf_priority.go:78-141, 163-238`.

4. **Deposit từ Ví Zalopay vào MMF:**
   * Gọi `userAssetClient.GetZalopayBalance()` lấy số dư ví.
   * Nếu `balance <= 0` → skip (không lỗi, set `ErrorZalopayBalanceIsZero`).
   * Nếu `balance > 0` → gọi `depositDomain.ConfirmDepositOrder()` với `DepositFlow = SourceMMFTogglePriority`, `SubType = Recurring`.

5. **Update ExtraData:** Sau khi hoàn tất, cập nhật `users.extra_data`:
   * `ToggleSetting = {FlowTopup: true, FlowTransfer: true}` — cho phép auto-sweep khi nhận tiền P2P và chuyển khoản.
   * `EnabledPriorityMMF = true` (chỉ khi status = Success).
   * `ToggleExtraInfo = {UpdatedTime, UpdatedBy}`.

#### ⚠️ Tình huống lỗi & Error code — Enable MMF Priority

| Tình huống lỗi | Error constant (message) | gRPC code | Hành vi | Evidence |
| :--- | :--- | :--- | :--- | :--- |
| User đã bật Priority trước đó | `ErrorAlreadyEnableMMFPriority` ("user already enabled priority MMF") | `FailedPrecondition` | Bỏ qua, không bật lại | [enable_mmf_priority.go:L171](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/enable_mmf_priority.go#L171) |
| Sai PIN | `ErrorUMPinNotMatch` | `InvalidArgument` | Yêu cầu nhập lại PIN | [enable_mmf_priority.go:L356](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/enable_mmf_priority.go#L356) |
| Nhập sai PIN quá số lần | `ErrorUMExceedPinNotMatch` | `InvalidArgument` | Khóa tạm, chờ 15 phút | [enable_mmf_priority.go:L360](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/enable_mmf_priority.go#L360) |
| PIN hết hạn | `ErrorUMPinHasExpired` | `InvalidArgument` | Yêu cầu cập nhật PIN | [enable_mmf_priority.go:L364](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/enable_mmf_priority.go#L364) |
| Số dư ví = 0 khi confirm deposit | `ErrorZalopayBalanceIsZero` | (skip, không lỗi user) | Vẫn bật SOF, bỏ qua sweep | [enable_mmf_priority.go:L225-L252](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/enable_mmf_priority.go#L225-L252) |
| Bật SOF cho Payment Engine thất bại (list/update SOF) | `ErrorEnableMMFSOFFailedToListSOF` / `ErrorEnableMMFSOFNotExisted` / `ErrorEnableMMFSOFFailedToUpdateListSOF` | `Internal` | Rollback việc bật Priority | [enable_mmf_sof.go:L29-L84](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/enable_mmf_sof.go#L29-L84) |
| Lỗi service nội bộ chung | `ErrorServiceError` | `Internal` | Trả lỗi chung, user thử lại | [enable_mmf_priority.go:L64-L131](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/enable_mmf_priority.go#L64-L131) |

### 2.3 Luồng Nạp Định kỳ Tự động (Recurring Deposit)

Service `deposit` cung cấp API `RegisterRecurringDepositPlan`:

1. **Kiểm tra binding status = OPEN** và user đã tồn tại.
2. **Validate request:** Kiểm tra `amount` không vượt `MaxDepositCap` (lấy theo account type).
3. **Kiểm tra plan tồn tại:** Mỗi user chỉ được đăng ký **1 recurring plan** tại một thời điểm. Nếu đã có → trả lỗi `ErrorRecurringPlanExisted`.
4. **Gọi gRPC sang `recurring-deposit-manager`:** Gửi params `Amount`, `IsAllZalopayBalance` (nạp hết số dư ví), `Frequency` (daily/weekly/monthly), `DayOfWeek`, `DayOfMonth`, `HashedPin`.
5. **Hủy plan:** API `CancelActiveRecurringPlan` cho phép hủy plan đang active.
* *Code evidence:* `register_recurring_deposit.go:23-100`, `cancel_active_recurring_plan.go`.

#### ⚠️ Tình huống lỗi & Error code — Recurring Deposit

| Tình huống lỗi | Error constant (message) | gRPC code | Hành vi | Evidence |
| :--- | :--- | :--- | :--- | :--- |
| Request đăng ký sai định dạng / amount vượt `MaxDepositCap` | `ErrorInvalidArgument` | `InvalidArgument` | Reject | [register_recurring_deposit.go:L41-L71](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/register_recurring_deposit.go#L41-L71) |
| User không tồn tại / binding chưa OPEN | `ErrorServiceError` ("user not found" / "user binding not open") | `Internal` | Chặn đăng ký plan | [register_recurring_deposit.go:L57-L63](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/register_recurring_deposit.go#L57-L63) |
| User đã có 1 recurring plan active | `ErrorRecurringPlanExisted` (`RecurringPlanExistedMsg`) | `AlreadyExists` | Không cho đăng ký plan thứ 2 | [register_recurring_deposit.go:L81](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/register_recurring_deposit.go#L81) |
| Sai PIN / quá số lần / hết hạn khi đăng ký | `ErrorUMPinNotMatch` / `ErrorUMExceedPinNotMatch` / `ErrorUMPinHasExpired` | `InvalidArgument` | Yêu cầu nhập lại | [register_recurring_deposit.go:L109-L116](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/register_recurring_deposit.go#L109-L116) |
| Hủy plan thất bại | `ErrorCancelRecurringDepositPlansFailed` | `Internal` | Giữ nguyên plan, báo lỗi | [cancel_active_recurring_plan.go:L30-L44](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/cancel_active_recurring_plan.go#L30-L44) |
| Lấy danh sách plan / lịch sử thất bại | `ErrorGetRecurringDepositPlansFailed` / `ErrorGetRecurringDepositHistoriesFailed` | `Internal` | Trả lỗi đọc dữ liệu | [recurring_plans.go:L75](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/deposit/controllers/recurring_plans.go#L75) |

> **Ghi chú kỹ thuật:** Service `recurring-deposit-manager` bọc lỗi thực thi plan định kỳ trong struct `RecurringError{Code: errorregistry.RecurringDepositErrorCode, Cause: error}` (format log `code: %d, cause: %v`) — mã `RecurringDepositErrorCode` định nghĩa trong `mmf/pkg/errorregistry` (ngoài snapshot) [errors.go:L9-L19](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/recurring-deposit-manager/internal/domain/errors/errors.go#L9-L19).

### 2.4 Luồng Quyết toán Doanh nghiệp (SME Auto Settle) — `[ĐÃ CÓ]`
* **Đối tượng:** Tài khoản `account_type = SME` sử dụng cổng merchant Zalopay.
* **Cơ chế:** Merchant Platform quyết toán → nạp vào SME Wallet → MMF Core auto-sweep sang SDSL.
* **Hạn mức tối đa SME:** **1.000.000.000đ (1 tỷ VND)** [MMF Limit Offer #268095994](https://confluence.zalopay.vn/pages/viewpage.action?pageId=268095994).
* **Lưu ý:** Account SME **không bị validate fund-out limit** khi rút (`isNeedToValidateFundOutLimit` trả `false` cho `AccountSME`).
  * *Code evidence:* `confirm_order.go:284-300`.

---

## 3. Luồng Rút tiền (Redemption Flow)

### 3.1 Luồng rút về Ví Zalopay (CreateMMFRedemptionOrder + ConfirmOrder)

#### A. Hạn mức rút tiền
* **Hạn mức rút tối đa/ngày:** Cấu hình qua `redemptionConfigRepo.GetFundOutLimitByAccountType()`, phân theo:
  * API Version (v1, v2)
  * Account Tier (Standard, Premium)
  * Account Type (Normal, SME, VietQROnly)
* **Giá trị unlimited:** Nếu config = `-1` → không giới hạn (`isUnlimitedFundout`).
* **Logic validate:** `mmfSourceRedeemFundOutValidator()` tính `todayRedeemedAmount + amount + fee > dailyRedemptionThreshold` → trả lỗi `ErrorValidateTodayRedemptionError` kèm message hiển thị số tiền còn lại có thể rút.
  * *Code evidence:* `redeem_fund_out_validator.go:29-76`.
* **Miễn phí rút:** `fee = 0` trong mọi flow rút tiền.

#### B. Quy trình Create Redemption Order (2-Step)

**Step 1 — CreateMMFRedemptionOrder (Tạo order sơ bộ):**
1. Kiểm tra binding status.
2. Validate request (amount, format).
3. Validate fund-out limit theo ngày.
4. Validate số dư hiện tại: `GetCurrentInstantBalanceByZPIDWithZax()` → nếu `totalBalance == 0` hoặc `totalBalance < amount` → `ErrorNotEnoughBalanceToRedeem`.
5. Gọi **Acquiring Core V2** tạo order: `acV2Client.CreateOrderV2()` với:
   * `PaymentType = TOPUP`
   * `DestAsset = UserWallet (MAIN)` — đích đến là ví chính user.
   * `ProductCode = FS002` (mã sản phẩm rút tiền).
   * `Description = "Rút tiền Số dư sinh lời về Ví Zalopay"`.
   * `EmbedData.PartnerCode = MMFSOFPartnerCodePremium`.
6. Trả về `OrderToken` + `StepUpMethod = PIN` (bắt buộc xác thực PIN ở bước confirm).
* *Code evidence:* `create_mmf_redemption_order.go:24-126`.

**Step 2 — processOrderRedemption (Confirm & Execute):**
1. **Validate số dư lần 2:** `checkEnoughCurrentBalance()` — double-check ngay trước khi thực hiện.
2. **Lấy thông tin user:** `processGetUserInformation()` — lấy phone_number cho notification.
3. **Kiểm tra idempotency:** `checkExistAppTransID()` — đảm bảo AppTransID chưa tồn tại.
4. **Distributed Lock per user:** Key `mmf:redemption:lock_trans_%d` — chỉ cho phép **1 giao dịch rút tại một thời điểm** cho mỗi user. Lock sử dụng `context.Background()` khi unlock để tránh deadlock khi request timeout.
   * *Code evidence:* `confirm_order.go:302-332`.
5. **Gọi Infina Freeze & Tạo order DB:** `handleCreateOrderRedemptionToIfnAndUpdateRedemptionBalance()`.
6. **Gọi Disbursement Core:** `createOrderTopupToDC()` → `TopupByUserID` cộng tiền vào ví.
7. **Xử lý kết quả DC:**
   * **Thành công:** Produce message `SuccessRedemption` → Order Worker confirm với Infina.
   * **Pending:** Produce message `QueryStatusRedemption` delay **30 phút** (`ThirtyMinutesDelay = 1800000ms`). Trả lỗi cho Frontend.
   * **Thất bại:** `handleUpdateStatusOrderFailedAndRefund()` → update order `failed` + produce message `RefundOrderRedemption` để Order Worker gọi Infina unfreeze.
   * *Code evidence:* `confirm_order.go:69-143, 230-249`.

#### C. Constant & Configuration
* `defaultRedemptionDescription = "Rút tiền Số dư sinh lời về Ví Zalopay"`.
* `ThirtyMinutesDelay = 30 * 60 * 1000ms` — timeout chờ DC trả kết quả.
* `FifteenMinutesDelay = 15 * 60 * 1000ms` — delay dùng trong một số flow khác.
* Message routing: RabbitMQ exchange `order_status`, kind `x-delayed-message`.

#### D. Logic chi tiết `processOrderRedemption` & ánh xạ gRPC code

`processOrderRedemption()` thực thi tuần tự 8 bước, mỗi bước fail trả về gRPC code khác nhau [confirm_order.go:L69-L143](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_order.go#L69-L143):

1. **Check số dư (`checkEnoughCurrentBalance`)** → fail: `FailedPrecondition`.
2. **Lấy user info / phone** → fail: `FailedPrecondition`.
3. **Check AppTransID tồn tại (`checkExistAppTransID`)** → fail: `FailedPrecondition`.
4. **Acquire distributed lock `mmf:redemption:lock_trans_%d`** → fail: `AlreadyExists` + `ErrorConfirmRedemptionAcquireLockFail`. (Unlock dùng `context.Background()` để tránh deadlock khi request timeout.)
5. **Tạo order + gọi Infina freeze (`handleCreateOrderRedemptionToIfnAndUpdateRedemptionBalance`)** → fail: `Internal` + `ErrorConfirmRedemptionCallIFNFail` ("internal error").
6. **Gọi Disbursement Core `TopupByUserID` (`createOrderTopupToDC`)** → 3 nhánh kết quả:
   * **PENDING:** DC cam kết trả status sau **30 phút**. Hệ thống produce `QueryStatusRedemption` (delay = `ThirtyMinutesDelay` = 1.800.000ms) và trả `Internal` + `ErrorConfirmRedemptionCreateTransferFundError` ("Transfer fund fail with status PENDING, order_status = 4") [confirm_order.go:L116-L133](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_order.go#L116-L133).
   * **THẤT BẠI (xác định):** trả `Internal` với error gốc; `handleUpdateStatusOrderFailedAndRefund()` set order `failed` + `internal_error_code` và produce `RefundOrderRedemption` để Order Worker gọi Infina **unfreeze** [confirm_order.go:L230-L249](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_order.go#L230-L249).
   * **THÀNH CÔNG:** nếu DC trả `succeeded` → produce `SuccessRedemption` (NoDelay); nếu chưa rõ → produce `QueryStatusRedemption` (NoDelay) [confirm_order.go:L145-L169](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_order.go#L145-L169).

**Order Worker xác nhận với Infina (async):** khi gọi Infina update redemption status, nếu Infina trả `status_code = 42900` ("You are retrying too fast") → coi là **retryable**, produce lại message confirm (`ErrRetryConfirmRedemptionInfina`); các status_code khác → lưu `partner_error_code` vào DB rồi trả lỗi. Nếu Infina trả `RefundStatus = Refunded` → cập nhật order `refunded` [order_redemption_handler.go:L336-L406](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/order-worker/handler/order_redemption_handler.go#L336-L406).

#### E. ⚠️ Bảng mã lỗi luồng Rút về ví

| Tình huống lỗi | Error constant (message) | gRPC code | Hành vi hệ thống | Evidence |
| :--- | :--- | :--- | :--- | :--- |
| Số dư không đủ để rút | `ErrorNotEnoughBalanceToRedeem` | `FailedPrecondition` | Chặn tạo lệnh rút | [create_mmf_redemption_order.go:L154-L172](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/create_mmf_redemption_order.go#L154-L172) |
| Vượt hạn mức rút trong ngày (30M) | `ErrorValidateTodayRedemptionError` (kèm số tiền còn lại) | `FailedPrecondition` | Chặn rút, hiển thị hạn mức còn lại | [create_mmf_redemption_order.go:L143-L144](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/create_mmf_redemption_order.go#L143-L144) |
| Lỗi đọc instant_balance | `ErrorGetInstantBalanceError` | `Internal` | Trả lỗi đọc số dư | [create_mmf_redemption_order.go:L166](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/create_mmf_redemption_order.go#L166) |
| Gọi Acquiring Core tạo order rút lỗi | `ErrorCreateOrderACError` ("System encountered an error") | `Internal` | Không tạo được order rút | [create_mmf_redemption_order.go:L103](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/create_mmf_redemption_order.go#L103) |
| Validate request rút sai | `ErrorCreateOrderRedemptionValidateError` | `InvalidArgument` | Reject sớm | [create_mmf_redemption_order.go:L47](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/create_mmf_redemption_order.go#L47) |
| Không acquire được lock giao dịch | `ErrorConfirmRedemptionAcquireLockFail` | `AlreadyExists` | Chặn rút song song của cùng user | [confirm_order.go:L97](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_order.go#L97) |
| Gọi Infina freeze lỗi | `ErrorConfirmRedemptionCallIFNFail` ("internal error") | `Internal` | Không tạo lệnh bán CCQ | [confirm_order.go:L106](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_order.go#L106) |
| Disbursement Core PENDING (chờ 30 phút) | `ErrorConfirmRedemptionCreateTransferFundError` ("...status PENDING, order_status = 4") | `Internal` | Produce `QueryStatusRedemption` delay 30′, FE hiển thị đang xử lý | [confirm_order.go:L124](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_order.go#L124) |
| AppTransID đã tồn tại (duplicate) | `ErrorConfirmRedemptionAppTransIsExisted` ("AppTransId is existed") | `FailedPrecondition` | Idempotency, không xử lý lại | [redemption_handler.go:L109](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/redemption_handler.go#L109) |
| Hệ thống đang bảo trì | `ErrorServiceIsUnderMaintenance` | `Unavailable` | Chặn rút trong maintenance | [internal_confirm_order.go:L62](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/internal_confirm_order.go#L62) |
| Order rút không tìm thấy khi query status | `ErrorGetStatusRedemptionOrderMissMatch` ("order not found") | `NotFound` | Trả không tìm thấy | [order_status.go:L49](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/order_status.go#L49) |

**Partner status code (Infina) luồng Redemption:** `40000 bad_request`, `40001 invalid_field`, `40002 signature_incorrect`, `40005 ZP request ID exists`, `40006 invalid amount`, `40009 invalid total balance` (số dư user tại Infina không khớp), `40101 invalid_token`, `40401 user_not_exists`, `42900 too_many_request` **(retryable)**, `42901 retry_too_fast` **(retryable)**, `50000 internal_server_error`, `50301 db_error`, `50302 unexpected_error` [99. Mapping Partner and Internal Error Code:L436-L459](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/MMF/Technical%20Page/80653653_%5BPCF-FS%5D%20%5BMMF%5D%2099.%20Mapping%20Partner%20and%20Internal%20Error%20Code.md#L436-L459).

**Disbursement Core code (Transfer fund — chi tiền về ví, hiển thị trong Trans detail):** `-68 Duplicate resource` (trùng PartnerOrderID/AppTransID), `-101 User wallet account not exists` / `Order not found`, `-401 Request param illegal`, `-402 Unauthorized`, `-406 User wallet reaches a fund-in limitation` (ví đạt hạn mức nhận tiền), `-500 ZaloPay system error` [99. Mapping Partner and Internal Error Code:L460-L472](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/02.%20Context/Confluence/MMF/Technical%20Page/80653653_%5BPCF-FS%5D%20%5BMMF%5D%2099.%20Mapping%20Partner%20and%20Internal%20Error%20Code.md#L460-L472).

> **CS evidence thực tế:** Case TPE trả `-993` (`ErrorCode_ORDER_NOT_EXIST` / `ACQUIRER_*`) nhưng SDSL của khách đã bị trừ — giao dịch pending ở bước "chi tiền về ví" và đã được refund sau khi CS báo lại [ISSUE-29731](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/CS%20Ticket/MMF/ISSUE-29731_%5BThanh%20to%C3%A1n%5D%20-%20%5B241%20-%20Chuy%E1%BB%83n%20Ti%E1%BB%81n%20ATM%5D%20Ki%E1%BB%83m%20tra%20gi.md#L19).

### 3.2 Luồng Rút trực tiếp về tài khoản Ngân hàng (Contingency Plan) — `[ĐANG THỰC HIỆN]`
* **Mục đích:** Kênh thanh khoản dự phòng khi hệ thống ví gặp sự cố.
* **Xác thực tài khoản:** Infina đối chiếu tên chủ tài khoản ngân hàng phải trùng khớp hoàn toàn với tên eKYC user.
* **Xác thực OTP:** Yêu cầu mã OTP gửi về điện thoại trước khi lưu tài khoản ngân hàng thụ hưởng.
* **Confirm Redemption to Bank:** File `confirm_redemption_to_bank.go` (15KB) xử lý flow IBFT trực tiếp qua Infina.

#### ⚠️ Tình huống lỗi & Error code — Rút về Bank (Direct-to-Bank / IBFT)

| Tình huống lỗi | Error constant (message) | gRPC code | Hành vi | Evidence |
| :--- | :--- | :--- | :--- | :--- |
| Tính năng/khung giờ rút-về-bank bị chặn | `ErrorConfirmRedemptionToBankBlocked` | `FailedPrecondition` | Chặn rút về bank | [confirm_redemption_to_bank.go:L60-L67](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_redemption_to_bank.go#L60-L67) |
| Tài khoản ngân hàng thụ hưởng không hợp lệ / tên không khớp eKYC | `ErrorValidateBankAccountError` | `InvalidArgument` | Chặn lưu tài khoản bank | [internal_create_order.go:L135](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/internal_create_order.go#L135) |
| Sai PIN / quá số lần / hết hạn | `ErrorUMPinNotMatch` / `ErrorUMExceedPinNotMatch` / `ErrorUMPinHasExpired` | `InvalidArgument` | Yêu cầu nhập lại PIN | [confirm_redemption_to_bank.go:L136-L144](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_redemption_to_bank.go#L136-L144) |
| OTP hết hạn | `ErrorVerifyExpiredOTP` | `FailedPrecondition` | Yêu cầu gửi lại OTP | [confirm_redemption_to_bank.go:L378](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_redemption_to_bank.go#L378) |
| Yêu cầu OTP bị chặn (quá số lần) | `ErrorRequestOTPIsBlocked` | `FailedPrecondition` | Khóa tạm việc gửi OTP | [confirm_redemption_to_bank.go:L379](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_redemption_to_bank.go#L379) |
| Biz order không tồn tại trong cache | `ErrorConfirmRedemptionBizAppTransIDNotExisted` ("biz order not exist in cache") | `FailedPrecondition` | Không xác nhận được lệnh | [confirm_redemption_to_bank.go:L236](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_redemption_to_bank.go#L236) |
| Order đã được xử lý trước đó (idempotency) | `ErrorConfirmRedemptionOrderAlreadyProcessed` ("order already processed") | `FailedPrecondition` | Không xử lý lại | [confirm_redemption_to_bank.go:L329](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_redemption_to_bank.go#L329) |
| Gọi Infina chuyển khoản bank thất bại | `ErrorConfirmRedemptionToBankFailed` | `Internal` | Order `failed`, không trừ số dư | [confirm_redemption_to_bank.go:L251](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_redemption_to_bank.go#L251) |

### 3.3 Luồng Charge by PMC 44 (Thanh toán SOF MMF)

Khi Payment Engine gọi gRPC `ChargeByPmcMMF()`:

1. **Validate request:** Kiểm tra tính hợp lệ request từ PE, validate Merchant Wallet ID.
2. **Kiểm tra maintenance mode:** `isUnderMaintenance()`.
3. **Lấy Account Type:** `GetAccountTypeByZalopayID()`, fallback `AccountNormal` nếu lỗi.
4. **Validate fund-out limit:** Áp dụng cho organic redemption (AppID 1451 + source MMF) và các AppID cấu hình (241, 450, 10000). **Account SME** được exempt nếu source là MMF.
   * Trường hợp SME + P2P flow: Vẫn validate (`isSmeAndP2PFlow()`).
5. **Charge flow:** Tạo `redemptionOrderInfo` với:
   * `Fee = 0` — không tính phí.
   * `DestinationFlow` dựa trên `PaymentFlow` và `isChargeByMW`.
   * `IsChargeFlow = true`, `IsChargeByMerchantWallet` = true/false.
6. **Gọi `processOrderRedemption()`** — flow rút tiền giống như rút thường.
* *Code evidence:* `internal_charge_pmc_44.go:24-100`.

#### ⚠️ Tình huống lỗi & Error code — Charge by PMC 44 (SOF)

Vì `ChargeByPmcMMF` tái sử dụng `processOrderRedemption`, toàn bộ error ở §3.1.E đều áp dụng. Bổ sung các lỗi đặc thù của luồng SOF:

| Tình huống lỗi | Error constant (message) | gRPC code | Hành vi | Evidence |
| :--- | :--- | :--- | :--- | :--- |
| Hệ thống đang maintenance | `ErrorServiceIsUnderMaintenance` ("service is maintenance") | `Unavailable` | Từ chối charge | [internal_cxm_confirm_order.go:L39](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/internal_cxm_confirm_order.go#L39) |
| Partner code không hợp lệ (gọi từ kênh external) | `ErrorInvalidPartnerCode` ("partner code is invalid") | `PermissionDenied` | Từ chối request | [external_create_order.go:L30-L31](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/external_create_order.go#L30-L31) |
| Số dư MMF không đủ thanh toán hóa đơn | `ErrorNotEnoughBalanceToRedeem` ("insufficient balance") | `FailedPrecondition` | Từ chối charge, PE fallback nguồn khác | [internal_cxm_confirm_order.go:L68](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/internal_cxm_confirm_order.go#L68) |
| Vượt hạn mức (chỉ áp dụng Account Normal; SME được miễn trừ trừ luồng P2P) | `ErrorValidateTodayRedemptionError` | `FailedPrecondition` | Chặn charge nếu vượt 30M/ngày | [confirm_order.go:L284-L300](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/redemption/controllers/confirm_order.go#L284-L300) |

---

## 4. Luồng Thanh toán & Chuyển tiền (Payment & Transfer SOF)

### 4.1 Thanh toán sử dụng nguồn tiền MMF (PMC 44)
* **1-Step Passthrough:** Payment Engine → gRPC `ChargeByPmcMMF` → MMF rút ngầm từ Infina → cộng thẳng vào merchant.
* **2-Step Fallback (Hóa đơn đa kỳ):** Rút MMF → ví user → trích thanh toán.

### 4.2 P2P & Personal QR Passthrough — `[ĐANG THỰC HIỆN]`
* **Toggle Priority:** Khi `EnabledPriorityMMF = true` và `ToggleSetting.FlowTransfer = true`, tiền chuyển P2P vào sẽ auto-sweep sang MMF.

---

## 5. Hoàn tiền & Cashback (Refund & Promotion)

### 5.1 Hoàn tiền giao dịch (Refund to MMF)
* Khi giao dịch PMC 44 bị lỗi/hủy → merchant hoàn tiền → Asset Exchange Core → cộng lại MMF user.
* Ghi nhận `transaction type = REFUND` trong bảng `orders`.

### 5.2 Cashback tự động tích lũy
* Cashback từ Mega Campaign → service `campaign-gateway` → tạo order nạp đặc biệt (không tính hạn mức VietQR).

---

## 6. Đóng tài khoản & Chấm dứt dịch vụ

### 6.1 Yêu cầu đóng chủ động (User-initiated Unbinding)

Xử lý trong `handleSubmitUnBindingUser()`:

1. **Kiểm tra khung giờ chặn đóng tài khoản:** `validateBlockAccountTime()` — chặn đóng tài khoản trong khung giờ cấu hình `BlockCloseAccountTime.StartTime` → `EndTime` (thường **00:00:00 → 05:00:00**).
   * *Code evidence:* `submit_unbinding_user.go:40-46, 140-147`.

2. **Kiểm tra user tồn tại:** Nếu user không exist → `ErrUserNotExisted`.

3. **Validate số dư & pending:**
   * `validateUserBalance()`: `TotalBalance` phải == 0.
   * `validatePendingAmount()`: `TotalPendingOrdersAmount` phải == 0 (không có lệnh nào đang xử lý).
   * Nếu vi phạm → trả lỗi `ErrorUnbindingInsBalanceNotZeroError` hoặc `ErrorUnbindingHasPendingTransError`.
   * *Code evidence:* `submit_unbinding_user.go:149-210`.

4. **Gọi Infina hủy liên kết & cập nhật DB:** `unbindingAndUpdateStatusUser()` — đặt `binding_status = CLOSE`, lưu `close_reason`.

### 6.2 Đóng tự động do tuân thủ pháp lý (Force Under-15)

Khi nhận trigger `UnbindTriggerFlowForceUnder15`:

1. **Xác thực user dưới 15:** `verifyUserUnder15()`.
2. **Force redeem all balance:** `redeemAllBalanceForUnder15()` — rút toàn bộ số dư về ví.
3. **Sleep 5 giây:** Chờ xử lý redeem hoàn tất.
4. **Validate balance = 0:** Kiểm tra lại sau khi redeem.
5. **Unbind:** Đặt `close_reason = CloseReasonUnder15`.
* *Code evidence:* `submit_unbinding_user.go:99-122`.

### 6.3 ⚠️ Tình huống lỗi & Error code — Đóng tài khoản

| Tình huống lỗi | Error constant (message) | gRPC code | Hành vi | Evidence |
| :--- | :--- | :--- | :--- | :--- |
| Đóng tài khoản trong khung giờ chặn (00:00–05:00) | (validate block time) | `FailedPrecondition` | Từ chối đóng, hẹn ngoài khung giờ | [submit_unbinding_user.go:L40-L46](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/submit_unbinding_user.go#L40-L46) |
| User không tồn tại | `ErrUserNotExisted` | `NotFound` | Không có gì để đóng | [submit_unbinding_user.go:L149-L210](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/submit_unbinding_user.go#L149-L210) |
| Số dư `TotalBalance` ≠ 0 | `ErrorUnbindingCheckInsBalanceError` / `ErrorUnbindingInsBalanceNotZeroError` | `FailedPrecondition` | Chặn đóng, yêu cầu rút hết tiền | [check_closing_account_eligibility.go:L76](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/check_closing_account_eligibility.go#L76) |
| Còn lệnh đang xử lý (`TotalPendingOrdersAmount` ≠ 0) | `ErrorUnbindingCheckPendingAmountError` / `ErrorUnbindingHasPendingTransError` | `FailedPrecondition` | Chặn đóng, chờ pending hoàn tất | [check_closing_account_eligibility.go:L89](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/check_closing_account_eligibility.go#L89) |
| Deactive user (Infina hủy liên kết) thất bại | `ErrorDeactivateUserError` | `Internal` | Giữ trạng thái, báo lỗi | [deactive_user.go:L43](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/deactive_user.go#L43) |

> **Edge case Force Under-15:** sau `redeemAllBalanceForUnder15()` hệ thống `Sleep 5s` rồi validate lại balance = 0 mới unbind. Nếu redeem chưa hoàn tất (balance vẫn > 0) → **không unbind**, để scheduler retry ở lần chạy sau, tránh đóng tài khoản khi còn tiền [submit_unbinding_user.go:L99-L122](file:///Users/lap16947/Library/CloudStorage/GoogleDrive-nguyenquangduy0211@gmail.com/My%20Drive/GOOGLE%20DRIVE/01.%20My%20Work/02.%20ZALOPAY/02.%20ZaloPay%20PO/02.%20Product/ZLP%20Workspace/Wealth%20Solution/03.%20Fact/Source%20Code/MMF/Backend/user-binding/controllers/submit_unbinding_user.go#L99-L122).

---

## 7. Idempotency & Rollout Rules

### 7.1 Idempotency Rollout Management
Service `deposit` cung cấp CRUD API quản lý **Idempotency Rollout Rules** cho phép enable/disable kiểm tra idempotency theo từng `client_id` + `source`:
* `ListIdempotencyRolloutRules`: Lọc theo client_id/source.
* `UpsertIdempotencyRolloutRule`: Tạo/cập nhật rule với `Enabled` flag và `WhitelistZalopayIDs` (danh sách user được phép bypass).
* `DeleteIdempotencyRolloutRule`: Xóa rule.
* Rule key format: `{client_id}:{source}`.
* *Code evidence:* `idempotency_rollout.go:20-205`.

---

## 8. Màn hình chính & Lợi nhuận (Account Screen & Interest)

* **Số dư sinh lời hiện tại:** Lấy từ `instant_balance.total_balance`.
* **Tiền lời tích lũy:** `total_interest_amount` từ bảng `instant_balance`.
* **Lãi suất hiện tại (% p.a.):** Cấu hình từ admin, lấy qua `get_list_interest.go` và `interest_detail.go`.
* **Check binding status khi mở app:**
  * Nếu user đang `OPEN` → `shouldRecheckBindingStatus()` return true → gọi `checkUserUnderAgeAndUpdateStatus()` kiểm tra tuổi realtime.
  * Nếu dưới 16 tuổi → tự động lock account ngay tại thời điểm mở app.
  * *Code evidence:* `check_binding.go:123-133, 179-199`.
* **Hiển thị close reason cho user CLOSED:** Lấy `close_reason` từ bảng `unbind_logs` qua `getUnbindReason()`.
* **Eligible rebinding check:** Nếu user CLOSED + `total_deposit_amount == 0` → `EligibleRebinding = true`.
  * *Code evidence:* `check_binding.go:139-167`.
