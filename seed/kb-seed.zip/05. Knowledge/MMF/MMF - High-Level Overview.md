# MMF (Money Market Fund) — High-Level Overview

---

## ⚡ Fact Sheet (TL;DR)

| Thuộc tính | Chi tiết | Nguồn trích dẫn (Citation) |
| :--- | :--- | :--- |
| **Tên sản phẩm** | MMF (Money Market Fund) — "Số dư sinh lời" / "Tài khoản tích luỹ (TKTL)" | [FAQ #183953706:L14](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706#L14) |
| **Đối tác liên kết** | **Real Stake Fintech (Infina)** cung cấp nền tảng tích hợp; **Công ty Quản lý Quỹ ACB (ACBC)** & **Công ty Cổ phần Quản lý Quỹ PVI (PVI AM)** quản lý danh mục đầu tư; **Ngân hàng TMCP Đầu tư và Phát triển Việt Nam (BIDV)** lưu ký tài sản. | [FAQ #183953706:L14](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706#L14) |
| **Trạng thái vận hành** | 🟢 Live (Đang hoạt động thực tế trên môi trường Production). | *Thực tế vận hành* |
| **Hạn mức chứa số dư (AUM Limit)** | * **Người dùng cá nhân >= 18 tuổi:** Tối đa **100.000.000đ/user**.<br>* **Người dùng cá nhân 16-17 tuổi (`SEGMENT_AGE_16_17`):** Tối đa **2.000.000đ/user** `[ĐANG THỰC HIỆN - CHƯA LIVE]` (Hiện tại Production chỉ chấp nhận user >= 18 tuổi).<br>* **Doanh nghiệp SME:** Tối đa **1.000.000.000đ (1 tỷ)/user**.<br>* *Lưu ý: Tiền thưởng cashback khuyến mãi và tiền lời tích luỹ hàng ngày không tính cộng dồn vào hạn mức chứa tối đa.* | [FAQ #183953706:L156](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706#L156)<br>[Xử lý user theo độ tuổi #322294833:L29](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322294833#L29)<br>[MMF Limit Offer #268095994:L19](https://confluence.zalopay.vn/pages/viewpage.action?pageId=268095994#L19)<br>[Overview #278882737:L80](https://confluence.zalopay.vn/pages/viewpage.action?pageId=278882737#L80) |
| **Quy tắc Nạp tiền** | Tối thiểu **10.000đ/giao dịch**. Phương thức nạp tiền duy nhất là **Chuyển khoản VietQR** trực tiếp vào tài khoản thu hộ của Infina. Hoàn toàn dừng nạp từ nguồn ví/thẻ liên kết trực tiếp (ngăn chặn rủi ro thanh khoản). | [FAQ #183953706:L146](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706#L146)<br>[FAQ #183953706:L202](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706#L202) |
| **Quy tắc Rút tiền** | Hạn mức rút tối đa **30.000.000đ/ngày** đối với rút về ví hoặc chuyển khoản P2P. Các giao dịch thanh toán và IBFT không bị giới hạn hạn mức. Hoàn toàn miễn phí rút tiền (Cơ chế dual package cũ đã bị loại bỏ hoàn toàn sau khi di trú sang VietQR-only). | [Handover #151163446:L89-90](https://confluence.zalopay.vn/pages/viewpage.action?pageId=151163446#L89-90)<br>[Migrate to Vietqr_only user #213883271:L11-12](https://confluence.zalopay.vn/pages/viewpage.action?pageId=213883271#L11-12) |
| **Lợi nhuận & Thuế** | Lợi nhuận tích luỹ cộng dồn theo ngày (lãi kép), đã tự động khấu trừ **5% thuế TNCN** tại nguồn bởi Infina. Tính lời theo quy tắc **T+1** kể từ ngày nạp thành công. | [FAQ #183953706:L457](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706#L457)<br>[FAQ #183953706:L387](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706#L387) |
| **Khung giờ vàng** | * **Chặn nạp tính lãi:** **23:59 – 01:10** hàng ngày.<br>* **Đồng bộ tiền lãi:** **02:10 – 03:40** hàng ngày. | [Handover #151163446:L108-109](https://confluence.zalopay.vn/pages/viewpage.action?pageId=151163446#L108-109) |

---

## 1. Tổng quan thị trường & Mục tiêu chiến lược

### 1.1 Tổng quan thị trường
Sản phẩm Quỹ thị trường tiền tệ (Money Market Fund - MMF) tích hợp trực tiếp vào ví điện tử giải quyết nhu cầu tối ưu hóa dòng tiền nhàn rỗi trong ngắn hạn của người dùng. Khách hàng được hưởng tỷ suất sinh lời vượt trội so với tài khoản ngân hàng không kỳ hạn thông thường (thường chỉ 0.1% - 0.2% p.a.), trong khi vẫn duy trì tính thanh khoản tức thời phục vụ chi tiêu hằng ngày thông qua các kênh thanh toán trực tiếp.

### 1.2 Định vị chiến lược của Zalopay MMF
*   **Tối ưu tính thanh khoản (Liquidity):** Người dùng có thể rút tiền tức thì về ví hoặc sử dụng trực tiếp Số dư sinh lời làm nguồn tiền thanh toán (Source of Funds - SOF) cho mọi dịch vụ trên Zalopay mà không cần thực hiện bước rút tiền thủ công.
*   **Tăng trưởng AUM (Asset Under Management):** Giữ chân dòng tiền nhàn rỗi trong hệ sinh thái ví, giảm tỷ lệ rút tiền mặt về ngân hàng liên kết, từ đó tạo nguồn thu trung gian qua phí quản lý quỹ và tối ưu hóa chi phí cash-out của nền tảng.
*   **Mục tiêu KPIs Chiến lược:**
        *   Tăng tỷ lệ kích hoạt tài khoản Số dư sinh lời (TKTL) của khách hàng mới ngay sau khi thực hiện eKYC thành công [Overview #278882737:L68](https://confluence.zalopay.vn/pages/viewpage.action?pageId=278882737#L68).
        *   Đạt tỷ lệ chuyển đổi thanh toán bằng nguồn tiền MMF chiếm trên 20% tổng sản lượng giao dịch thanh toán trong hệ sinh thái Zalopay.

---

## 2. Phân khúc khách hàng & SWOT

### 2.1 Phân khúc khách hàng mục tiêu
*   **Phân khúc Phổ thông (Normal Segment):** Khách hàng cá nhân >= 18 tuổi đã định danh KYC Level 2, có nhu cầu tích lũy tiền nhàn rỗi quy mô nhỏ và vừa (số dư dưới 100 triệu) [FAQ #183953706:L156](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706#L156).
*   **Phân khúc Trẻ tuổi (Youth Segment) — `[ĐANG THỰC HIỆN - CHƯA LIVE]`:** Nhóm tuổi học sinh 16-17 tuổi có nhu cầu tích lũy chi tiêu nhỏ lẻ, dự kiến hạn mức tối đa 2.000.000đ [Xử lý user theo độ tuổi #322294833:L29](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322294833#L29). Hiện tại Production vẫn giới hạn độ tuổi đăng ký tối thiểu là 18 tuổi.
*   **Phân khúc Doanh nghiệp (SME Segment):** Hộ kinh doanh cá thể hoặc doanh nghiệp nhỏ sử dụng SDSL để sinh lời từ doanh thu bán hàng nhàn rỗi trước khi quyết toán, hạn mức chứa tối đa 1 tỷ VND [MMF Limit Offer #268095994:L19](https://confluence.zalopay.vn/pages/viewpage.action?pageId=268095994#L19).

### 2.2 Ma trận SWOT

| Điểm mạnh (Strengths) | Điểm yếu (Weaknesses) |
| :--- | :--- |
| * Tích hợp sâu vào hệ sinh thái Zalo & Zalopay, thanh toán 1-step không cần rút về ví.<br>* Lợi nhuận tính theo ngày (lãi kép) có tính thanh khoản cao.<br>* Cơ chế dự phòng Snapshot HA tự chủ giao dịch khi đối tác sập. | * Phụ thuộc hoàn toàn vào API đối tác Infina để quản lý tài sản và tính lãi.<br>* Hạn mức chứa (100M) và hạn mức rút P2P (30M/ngày) bị giới hạn hơn tài khoản ngân hàng. |
| **Cơ hội (Opportunities)** | **Thách thức & Rủi ro (Threats)** |
| * Dư địa thị trường tích lũy cá nhân tại Việt Nam còn rất lớn.<br>* Cơ hội cross-sell chéo sang các sản phẩm FD, Stock, CCQ trong Wealth Hub. | * Sự thay đổi quy định pháp lý từ Ngân hàng Nhà nước đối với hoạt động thu hộ, chi hộ liên kết quỹ.<br>* Cạnh tranh khốc liệt về tỷ suất sinh lời với các ví điện tử khác (ví dụ: Túi Thần Tài MoMo). |

---

## 3. Đối thủ cạnh tranh (Competitor Analysis)

| Tính năng | Zalopay MMF (Số dư sinh lời) | Túi Thần Tài MoMo (Đối thủ chính) | Tikop / Infina App |
| :--- | :--- | :--- | :--- |
| **Tỷ suất sinh lời** | Khoảng 5.0% - 6.0% p.a. | Khoảng 4.5% - 5.5% p.a. | 5.5% - 7.0% p.a. |
| **Đối tác quản lý quỹ** | ACB Capital (ACBC) & PVI AM | Vietcombank (VCBF) | Finsight, Mirae Asset |
| **Tích hợp thanh toán** | Rất mượt mà (Passthrough làm nguồn SOF trực tiếp) | Mượt mà (Thanh toán trực tiếp) | Không hỗ trợ thanh toán trực tiếp (chỉ rút về ví/bank) |
| **Tính sẵn sàng (HA)** | **Có Snapshot Balance** (Xử lý offline khi đối tác down) | Chưa rõ (Thường chặn giao dịch khi lỗi đối tác) | Không hỗ trợ offline mode |
| **Hạn mức chứa tối đa** | 100.000.000đ | 100.000.000đ | Không giới hạn hoặc rất lớn |
| **Phí rút tiền** | **Miễn phí hoàn toàn** (Đã bỏ cơ chế dual account Normal thu phí 0.3%) | Miễn phí trong hạn mức rút nhất định | Có phí rút tùy theo kỳ hạn/gói sản phẩm |

---

## 4. Thách thức & Rủi ro

*   **Rủi ro Pháp lý (Compliance Risk):**
    *   Quy định bắt buộc kiểm soát độ tuổi chặt chẽ: Chặn mở tài khoản và tự động đóng/thanh lý tài khoản của user dưới 16 tuổi từ 01/04/2026 [Handle user under 15 #285001689](https://confluence.zalopay.vn/pages/viewpage.action?pageId=285001689).
    *   Kiểm soát dòng tiền nạp/rút tuân thủ Thông tư và các quy định về trung gian thanh toán và chuyển khoản trực tiếp liên kết quỹ.
*   **Rủi ro Vận hành từ Đối tác (Partner Operational Risk):**
    *   Hệ thống của Infina gặp sự cố kết nối kéo dài, dẫn đến việc không thể mua/bán chứng chỉ quỹ kịp thời.
    *   Lỗi tính toán và đồng bộ file lãi suất hàng ngày gây khiếu nại từ người dùng.
*   **Rủi ro Hệ thống (System Risk):**
    *   Sai lệch số dư chênh lệch giữa Snapshot Balance nội bộ và Số dư thực tế tại đối tác Infina trong quá trình Replay giao dịch offline.
    *   Nghẽn hàng đợi (Head-of-Line Blocking) khi xử lý async qua Kafka nếu không thiết kế các topic delay phù hợp.
    *   **Rủi ro xử lý lỗi phân tán:** Giao dịch rút/thanh toán đi qua nhiều hệ thống (MMF → Infina freeze → Disbursement Core → Infina confirm). Lỗi/timeout ở mỗi chặng có mã lỗi và hành vi bù trừ (compensation/refund/unfreeze) riêng; nếu retry/đối soát không chuẩn có thể gây pending kéo dài hoặc lệch số dư. Chi tiết tình huống lỗi + mã lỗi từng luồng xem [MMF - Product Business Specification.md](MMF%20-%20Product%20Business%20Specification.md); master error catalog + chính sách retry xem [MMF - System & Technical Specification.md §7](MMF%20-%20System%20&%20Technical%20Specification.md); runbook xử lý sự cố theo mã lỗi xem [MMF - Operations, Payment & Reconciliation Guide.md §4](MMF%20-%20Operations,%20Payment%20&%20Reconciliation%20Guide.md).

---

## 5. Kiến trúc kỹ thuật tổng quan (System Architecture)

Kiến trúc hệ thống Zalopay MMF và mô hình tương tác với các cấu phần nội bộ và đối tác được thể hiện qua sơ đồ khối dưới đây:

```mermaid
%%{init: {"theme": "neutral", "themeVariables": { "fontFamily": "Outfit, Inter, sans-serif" }, "flowchart": { "curve": "basis" }}}%%
flowchart TD
    subgraph ClientLayer ["Tầng Ứng dụng & Cổng vào"]
        App[Zalopay Client App] --> APIGW[API Gateway]
    end

    subgraph MMFCore ["Hệ thống MMF (zlp-mmf monorepo)"]
        DEP[deposit-service]
        RED[redemption-service]
        BIND[user-binding-service]
        AUTH[authorizer-service]
        WORKER[order-worker]
        SCHED[scheduler-service]
        BAL_ORCH[balance-orchestrator]
        REC_MGR[recurring-deposit-manager]
        CAMPAIGN[campaign-gateway]

        DEP & RED & BIND & AUTH & WORKER & SCHED & BAL_ORCH & REC_MGR & CAMPAIGN --> DB[(Shared MySQL Database: mmf)]
        DEP & RED & BIND & WORKER & SCHED & BAL_ORCH --> Cache[(Redis Cache)]
    end

    subgraph MessageQueues ["Hàng đợi Tin nhắn (Kafka)"]
        KAFKA{Kafka Cluster}
        WORKER -->|Publish events| KAFKA
        DEP & RED & BIND & SCHED & BAL_ORCH -.->|Produce commands| KAFKA
        KAFKA -.->|Consume commands/callbacks| WORKER
    end

    subgraph InternalCores ["Các Core nội bộ Zalopay"]
        AC[Acquiring Core v2]
        DC[Disbursement Core]
        UM[User Management / Profile]
        EKYC[eKYC Service]
        PE[Payment Engine]
        
        DEP -->|Create payment| AC
        RED -->|TopupByUserID| DC
        BIND -->|Query KYC/Age| UM
        BIND -->|Verify identity| EKYC
        DEP -->|Active scan VietQR| PE
    end

    subgraph PartnerLayer ["Hệ thống đối tác (Infina)"]
        PartnerAPI[Infina Partner API]
        
        WORKER -->|HTTP: Execute orders| PartnerAPI
        BIND -->|HTTP: Bind/Unbind| PartnerAPI
        SCHED -->|HTTP/SFTP: Daily Sync| PartnerAPI
        PartnerAPI -->|Webhook/OAuth| AUTH
    end

    APIGW --> DEP & RED & BIND & AUTH & BAL_ORCH & CAMPAIGN
```

---

## 6. Lộ trình phát triển & Trạng thái tính năng

| Mốc phát triển | Tính năng / Thay đổi | Trạng thái tính năng | Nguồn tham khảo |
| :--- | :--- | :---: | :--- |
| **08/10/2024** | Chuyển dịch sang phương thức **Nạp tiền qua VietQR** duy nhất. Ngừng nạp ví/ATM. | `[ĐÃ CÓ]` | [FAQ #183953706:L202](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706#L202) |
| **08/10/2024** | Bãi bỏ hoàn toàn mô hình **Dual Account** (Pro/Normal). Toàn bộ user hưởng chính sách miễn phí rút tiền và nạp qua VietQR. | `[ĐÃ CÓ]` | [Action plan \| Migrate to Vietqr_only user #213883271:L11-12](https://confluence.zalopay.vn/pages/viewpage.action?pageId=213883271#L11-12) |
| **01/04/2026** | Đóng và thanh lý tài khoản tự động của user **dưới 16 tuổi**. | `[ĐÃ CÓ]` | [Handle user under 15 #285001689](https://confluence.zalopay.vn/pages/viewpage.action?pageId=285001689) |
| **T5/2026** | Di trú hoàn toàn messaging bus từ **RabbitMQ sang Kafka**. | `[ĐÃ CÓ]` | [Proposed Solution & Migration Plan #325191742](https://confluence.zalopay.vn/pages/viewpage.action?pageId=325191742) |
| **T5/2026** | Nâng hạn mức chứa tối đa lên **100.000.000đ** (user >= 18 tuổi). | `[ĐÃ CÓ]` | [FAQ #183953706:L156](https://confluence.zalopay.vn/pages/viewpage.action?pageId=183953706#L156) |
| **T6/2026** | Áp dụng hạn mức chứa tối đa **2.000.000đ** (user 16-17 tuổi). | `[ĐANG THỰC HIỆN]` | [Xử lý user theo độ tuổi #322294833:L29](https://confluence.zalopay.vn/pages/viewpage.action?pageId=322294833#L29) |
| **T6/2026** | Tích hợp chế độ **Rút tiền khẩn cấp trực tiếp về bank (Direct-to-Bank)**. | `[ĐANG THỰC HIỆN]` | [Handover #151163446:L252](https://confluence.zalopay.vn/pages/viewpage.action?pageId=151163446#L252) |
| **Q3/2026** | **Tự động trích nạp khi nhận tiền (Auto Deposit via Priority Toggle)**. | `[ĐANG THỰC HIỆN]` | [Overview #278882737:L101](https://confluence.zalopay.vn/pages/viewpage.action?pageId=278882737#L101) |
| **Q3/2026** | Nhận tiền chuyển khoản P2P và Personal QR thẳng vào MMF. | `[ĐANG THỰC HIỆN]` | [Receive P2P transfer and topup via Personal QR to MMF #224761610](https://confluence.zalopay.vn/pages/viewpage.action?pageId=224761610) |
| **Q3/2026** | Triển khai chế độ **Snapshot Balance HA Mode** (Online/Offline/Replay). | `[ĐÃ LÊN PROD - CHƯA LIVE]` | [Snapshot Balance #309989083](https://confluence.zalopay.vn/pages/viewpage.action?pageId=309989083) |
| **Q4/2026** | Phát triển tính năng **Nạp tiền định kỳ (Recurring Deposit)**. | `[CHUẨN BỊ LÀM]` | [Handover #151163446:L83](https://confluence.zalopay.vn/pages/viewpage.action?pageId=151163446#L83) |
